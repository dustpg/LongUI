## LongUI Binary Attributes
  - For performance reasons, LongUI support binary attributes
  - this is a plan, if you really care about performance, put this into "ssues" on github