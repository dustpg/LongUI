﻿1.  UTF-8: 2003年11月UTF-8被RFC 3629重新规范，只能使用原来Unicode定义的区域，
U+0000到U+10FFFF，也就是说最多四个字节
2.  $(SolutionDir)$(Platform)\$(Configuration)\CppAllInOne.exe  
$(SolutionDir)src\ _LongUIAllInOne.cpp LongUI.h algorithm dcomp.h
