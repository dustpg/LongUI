﻿#pragma once
#include <cstdint>
#include "ui_string_view.h"

// ui namespace
namespace UI {
    // detail namespace
    namespace {
        /// <summary>
        /// look up struct, low level
        /// </summary>
        struct s2elll {
            // string view
            PodStringView<char> view;
            // look up table
            const char*const*   table;
            // table size
            uint16_t            length;
            // string step
            uint16_t            step;
            // bad matched
            uint32_t            badcase;
        };
    }
    // make looker
    template<typename T>
    auto MakeLooker(PodStringView<T> view);
}