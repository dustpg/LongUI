﻿#pragma once

// ui namespace
namespace UI { 
    // [begin, end-1) already be sorted
    template<typename T, typename U>
    void lastSort(T begin, T end, U comp) {
        if (end - begin < 2) return;
        for (auto itr = end - 1; itr != begin; --itr) {
            if (comp(itr[-1], itr[0])) break;
            std::swap(itr[-1], itr[0]);
        }
    }
    // remove begin to end
    template<typename T>
    void remove(T begin, T end) {
        for (auto itr = begin; itr < end - 1; ++itr) {
            std::swap(itr[0], itr[1]);
        }
    }
}

