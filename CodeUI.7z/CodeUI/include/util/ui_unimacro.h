﻿#pragma once

#if defined(_MSC_VER) && (_MSC_VER < 1900)
#ifdef __cplusplus
#define noexcept
#define constexpr const
#define alignas(x)
#define alignof(x) sizeof(void*)
#endif
#define __restrict
#endif

#define UNICALL __stdcall

#ifdef _MSC_VER
#define PCN_NOINLINE _declspec(noinline)
#else
#define PCN_NOINLINE __attribute__((noinline))
#endif

#ifdef _MSC_VER
#define PCN_NOVTABLE __declspec(novtable)
#else
#define PCN_NOVTABLE
#endif

