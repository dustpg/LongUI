﻿#pragma once

#if defined(_MSC_VER) && (_MSC_VER < 1900)
#ifdef __cplusplus
#define noexcept
#define constexpr const
#define alignas(x)
#define alignof(x) sizeof(void*)
#endif
#define __restrict
#endif

#define UNICALL __stdcall

#ifdef _MSC_VER
#define PCN_NOINLINE _declspec(noinline)
#define PCN_NOVTABLE _declspec(novtable)
#define PCN_DLLEXPRT
#else
#define PCN_NOINLINE __attribute__((noinline))
#define PCN_NOVTABLE
#define PCN_DLLEXPRT
#endif

#define PCN_DLL_LV1 PCN_DLLEXPRT
#define PCN_DLL_LV2 
