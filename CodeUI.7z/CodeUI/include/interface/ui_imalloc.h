﻿#pragma once

#include "ui_interface.h"

// ui namespace
namespace UI {
    // UI Memory Alloc Interface
    struct PCN_NOVTABLE IUIMAlloc : IUIInterface {
        // alloc for normal space
        virtual void*NormalAlloc(size_t length) noexcept = 0;
        // free for normal space
        virtual void NormalFree(void* address) noexcept = 0;
        // realloc for normal space
        virtual void*NormalRealloc(void* address, size_t length) noexcept = 0;
        // alloc for small space
        virtual void*SmallAlloc(size_t length) noexcept = 0;
        // free for small space
        virtual void SmallFree(void* address) noexcept = 0;
        // realloc for small space
        virtual void*SmallRealloc(void* address, size_t length) noexcept = 0;
    };
}