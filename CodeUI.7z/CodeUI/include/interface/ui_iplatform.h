﻿#pragma once

#include "ui_interface.h"

// ui namespace
namespace UI {
    // UI Platform Interface
    struct PCN_NOVTABLE IUIPlatform : IUIInterface {
        /// <summary>
        /// Mains the loop.
        /// </summary>
        /// <returns></returns>
        virtual void MainLoop() noexcept = 0;
    };
}