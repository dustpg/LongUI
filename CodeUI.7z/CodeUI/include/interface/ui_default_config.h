﻿#pragma once
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// interfaces
#include "../interface/ui_iconfig.h"
// core type
#include "../core/ui_core_type.h"

// ui namespace
namespace UI {
    // CUIDefaultConfigure, default impl for IUIConfigure
    class CUIDefaultConfigure : public IUIConfigure {
    public:
        // ctor
        CUIDefaultConfigure() noexcept {}
        // dtor
        ~CUIDefaultConfigure() noexcept {}
    public:
        // add ref count
        auto UNICALL AddRef() noexcept->uint32_t override;
        // release
        auto UNICALL Release() noexcept->uint32_t override;
    public:
        // get flags for configure
        auto GetConfigureFlag() noexcept->ConfigureFlag override;
        // Get string from table
        //virtual auto GetString(TableString tbl) noexcept -> const wchar_t*;
        // create interface
        auto CreateInterface(const IID& iid, void** obj) noexcept ->Result override;
        // get locale name of ui(for text)
        void GetLocaleName(wchar_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept override;
        // add all custom controls
        void RegisterSome() noexcept override;
        // if use gpu render, you should choose a video card, return the index
        auto ChooseAdapter(const GraphicsAdapterDesc adapters[], const size_t length) noexcept ->size_t override;
        // create custom window
        //auto CreateCustomWindow(WindowPriorityType type, pugi::xml_node node) noexcept->XUIBaseWindow* override { return nullptr; };
        // show the error string
        bool ShowError(const wchar_t* a, const wchar_t* b) noexcept override;
    private:
    };
}

