﻿#pragma once

#include "ui_interface.h"

// ui namespace
namespace UI {
    // script
    struct ScriptUI;
    // argument
    struct EventArgument;
    // UI Configure Interface
    struct PCN_NOVTABLE IUIConfigure : IUIRefCount {
        // flag
        enum ConfigureFlag : uint32_t {
            // no flag
            Flag_None = 0,
            // all flags
            Flag_All = uint32_t(-1),
            // flag for CPU rendering, if not, will call IUIInterface::ChooseAdapter
            Flag_RenderByCPU = 1 << 0,
            // output debug string?
            Flag_OutputDebugString = 1 << 1,
            // render in anytime, like game
            Flag_RenderInAnytime = 1 << 2,
            // only one system window, like game(all child window will be logic window)
            Flag_OnlyOneSystemWindow = 1 << 3,
            // -------------------------------------------------------------
            // [debug flag under DEBUG MODE] output font family infomation
            Flag_DbgOutputFontFamily = 1 << 10,
        };
    public:
        /// <summary>
        /// Get flags for configure
        /// </summary>
        /// <returns>flags for configure</returns>
        virtual auto GetConfigureFlag() noexcept->ConfigureFlag = 0;
        /// <summary>
        /// Get string from table
        /// </summary>
        /// <returns>static string</returns>
        //virtual auto GetString(TableString tbl) noexcept -> const wchar_t* = 0;
        /// <summary>
        /// Gets the locale name
        /// </summary>
        /// <param name="name">The locale name buffer</param>
        /// <remarks>L"" for local locale name</remarks>
        virtual void GetLocaleName(wchar_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept = 0;
        /// <summary>
        /// Adds the custom control.
        /// </summary>
        /// <remarks>call CUIManager::RegisterControl to add control class</remarks>
        virtual void RegisterSome() noexcept = 0;
        /// <summary>
        /// Chooses the video adapter.
        /// </summary>
        /// <param name="adapters">The adapter array</param>
        /// <param name="length">The length of adapters</param>
        /// <remarks>
        /// if set "Flag_RenderByCPU", you should choose a video card,return the index.
        /// if return code out of range, will set by default(null pointer adapter)
        /// btw, in the adapter list, also include the WARP-adapter
        /// </remarks>
        /// <returns>index of adapters</returns>
        virtual auto ChooseAdapter(const GraphicsAdapterDesc adapters[/*length*/], const size_t length /*<=64*/) noexcept->size_t = 0;
        /// <summary>
        /// Creates the custom window.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="node">The node.</param>
        /// <returns>custom windows pointer, return null for some error</returns>
        //virtual auto CreateCustomWindow(WindowPriorityType type, XmlNodePtr node) noexcept->XUIBaseWindow* = 0;
        /// <summary>
        /// Shows the error.
        /// </summary>
        /// <param name="str_a">String A</param>
        /// <param name="str_b">String B</param>
        /// <returns>return false if user ignore this error</returns>
        virtual bool ShowError(const wchar_t* str_a, const wchar_t* str_b) noexcept = 0;
    /*public:
        // run a section script with event
        virtual auto Evaluation(const ScriptUI&, const UI::EventArgument& arg) noexcept ->bool = 0;
        // alloc the script memory and copy into(may be compiled into byte code), return memory size
        virtual auto AllocScript(const char* utf8) noexcept->UI::ScriptUI = 0;
        // free the script memory
        virtual void FreeScript(ScriptUI&) noexcept = 0;*/
    public:
        // alloc for normal space
        virtual void*NormalAlloc(size_t length) noexcept = 0;
        // free for normal space
        virtual void NormalFree(void* address) noexcept = 0;
        // realloc for normal space
        virtual void*NormalRealloc(void* address, size_t length) noexcept = 0;
        // alloc for small space
        virtual void*SmallAlloc(size_t length) noexcept = 0;
        // free for small space
        virtual void SmallFree(void* address) noexcept = 0;
        // realloc for small space
        virtual void*SmallRealloc(void* address, size_t length) noexcept = 0;
    public:
        /// <summary>
        /// Mains the loop.
        /// </summary>
        /// <returns></returns>
        virtual void MainLoop() noexcept = 0;
        /// <summary>
        /// exit the loop.
        /// </summary>
        /// <returns></returns>
        virtual void Exit() noexcept = 0;
    };
}