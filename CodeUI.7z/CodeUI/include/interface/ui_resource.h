﻿#pragma once
#include "ui_interface.h"

// ui namespace
namespace UI {
    // resource loader
    struct IUIResLoader : IUIInterface {

    };
}