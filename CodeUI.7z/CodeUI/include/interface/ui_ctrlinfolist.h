﻿#pragma once

// VECTOR
#include "../container/pod_vector.h"
#include "../control/ui_ctrlmeta.h"

// ui namespace
namespace UI {
    // control info list
    struct ControlInfoList : POD::Vector<const MetaControl*> {};
}