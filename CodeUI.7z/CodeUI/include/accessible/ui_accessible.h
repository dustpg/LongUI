﻿#pragma once

// config
#include "../luiconf.h"
// c++
#include <cstdint>

// ui namespace
namespace UI {
#ifdef LUI_ACCESSIBLE
    // accessible
    class CUIAccessible;
    // finalize for accessible
    void FinalizeAccessible(CUIAccessible& obj) noexcept;
    // patterns
    enum AccessiblePattern : uint16_t {
        Pattern_None        = 0,
        Pattern_Text        = 1 << 0,
        Pattern_Grid        = 1 << 1,
        Pattern_Table       = 1 << 2,
        Pattern_Value       = 1 << 3,
        Pattern_Range       = 1 << 4,
        Pattern_Invoke      = 1 << 5,
    };
#endif
}