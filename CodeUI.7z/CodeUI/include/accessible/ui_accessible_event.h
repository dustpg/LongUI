﻿#pragma once

// accessible
#include "ui_accessible.h"
// int
#include "../typecheck/int_by_size.h"

// c++
#include <cstdint>

// ui namespace
namespace UI {
#ifdef LUI_ACCESSIBLE
    // | operator
    inline auto operator|(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) | b);
    }
    // & operator
    inline auto operator&(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) & b);
    }
    // accessible event
    enum AccessibleEvent : uint32_t {

    };
#endif
}