﻿#pragma once

// accessible
#include "ui_accessible.h"
#include "../core/ui_core_type.h"
// int
#include "../typecheck/int_by_size.h"

// c++
#include <cstdint>

// ui namespace
namespace UI {
#ifdef LUI_ACCESSIBLE
    // | operator
    inline auto operator|(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) | b);
    }
    // & operator
    inline auto operator&(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) & b);
    }
    // |= operator
    inline auto&operator|=(AccessiblePattern& a, AccessiblePattern b) noexcept {
        a = a | b; return a;
    }
    // &= operator
    inline auto&operator&=(AccessiblePattern& a, AccessiblePattern b) noexcept {
        a = a & b; return a;
    }
#endif
    // accessible type;
    enum class AccessibleControlType : uint32_t;
    // accessible event
    enum AccessibleEvent : uint32_t {
        // get patterns
        Event_GetPatterns = 0,
        // all-get control type
        Event_All_GetControlType,
        // all-get accessible name
        Event_All_GetAccessibleName,
        // all-get description
        Event_All_GetDescription,
    };
    // accessible event args
    struct AccessibleEventArg {
        // event id
        AccessibleEvent     event;
    };
    // accessible event: get patterns
    struct AccessibleGetPatternsArg : AccessibleEventArg {
        // <out> patterns
        mutable AccessiblePattern   patterns;
        // ctor
        AccessibleGetPatternsArg() noexcept {
            this->event = AccessibleEvent::Event_GetPatterns;
            this->patterns = AccessiblePattern::Pattern_None;
        }
    };
    // accessible event: get control type
    struct AccessibleGetCtrlTypeArg : AccessibleEventArg {
        // <out> name
        mutable AccessibleControlType   type;
        // ctor
        AccessibleGetCtrlTypeArg() noexcept {
            this->event = AccessibleEvent::Event_All_GetControlType;
            type = AccessibleControlType(-1);
        }
    };
    // accessible event: get accessible name
    struct AccessibleGetAccNameArg : AccessibleEventArg {
        // <out> name
        CUIString*          name;
        // ctor
        AccessibleGetAccNameArg(CUIString& str) noexcept {
            this->event = AccessibleEvent::Event_All_GetAccessibleName;
            name = &str;
        }
    };
    // accessible event: get description
    struct AccessibleGetDescriptionArg : AccessibleEventArg {
        // <out> name
        CUIString*          description;
        // ctor
        AccessibleGetDescriptionArg(CUIString& str) noexcept {
            this->event = AccessibleEvent::Event_All_GetDescription;
            description = &str;
        }
    };
}