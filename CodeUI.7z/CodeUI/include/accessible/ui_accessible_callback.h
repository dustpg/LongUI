﻿#pragma once

// accessible
#include "ui_accessible.h"

// c++
#include <cstdint>

// ui namespace
namespace UI {
#ifdef LUI_ACCESSIBLE
    // accessible callback
    enum AccessibleCallback : uint32_t {
        // accessible property/name changed
        Callback_PropertyChanged,
    };
    void Accessible(CUIAccessible*, AccessibleCallback) noexcept;
#endif
}