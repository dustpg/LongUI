﻿#pragma once

// c++
#include <cstdint>

// ui namespace
namespace UI {
    // accessible event
    enum class AccessibleControlType : uint32_t {
        // custom type
        Type_Custom = 0,
        // button
        Type_Button,
        // calendar
        Type_Calendar,
        // check-box
        Type_CheckBox,
        // combo-box
        Type_ComboBox,
        // text-edit
        Type_TextEdit,
        // hyperlink
        Type_Hyperlink,
        // image
        Type_Image,
        // list
        Type_List,
        // list item
        Type_ListItem,
        // menu
        Type_Menu,
        // menu bar
        Type_MenuBar,
        // menu item
        Type_MenuItem,
        // progress bar
        Type_ProgressBar,
        // radio button
        Type_RadioButton,
        // scroll bar
        Type_ScrollBar,
        // slider
        Type_Slider,
        // spinner
        Type_Spinner,
        // tab
        Type_Tab,
        // tab item
        Type_TabItem,
        // text
        Type_Text,
        // tool bar
        Type_ToolBar,
        // tooltip
        Type_Tooltip,
        // tree
        Type_Tree,
        // tree item
        Type_TreeItem,
        // group
        Type_Group,
        // thumb
        Type_Thumb,
        // header
        Type_Header,
        // header item
        Type_HeaderItem,
        // table
        Type_Table,
        // NONE
        Type_None,
    };
}