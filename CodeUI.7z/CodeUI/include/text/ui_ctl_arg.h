﻿#pragma once

// decl
#include "ui_ctl_decl.h"
#include "ui_attribute.h"

// ui namespace
namespace UI {
    // text arg
    struct TextArg {
        // font, null for default
        I::Font*        font;
        // string pointer, be carefual about dangling pointer
        const wchar_t*  string;
        // string length
        size_t          length;
        // max width
        float           mwidth;
        // max height
        float           mheight;
    };
    // font arg
    struct FontArg {
        // font family, null for default FontArg
        const wchar_t*          family;
        // font size
        float                   size;
        // weight
        AttributeFontWeight     weight;
        // style
        AttributeFontStyle      style;
        // stretch 
        AttributeFontStretch    stretch;
    };
}
