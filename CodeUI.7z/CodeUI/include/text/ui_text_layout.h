﻿#pragma once

#include "../core/ui_object.h"
#include "../text/ui_ctl_decl.h"
#include "../core/ui_basic_type.h"
#include "../graphics/ui_graphics_decl.h"

// ui namespace
namespace UI {
    // color
    struct ColorF;
    // static text layout
    class CUITextLayout : public CUINoMo {
    public:
        // str_t
        using str_t = const wchar_t*;
        // ctor
        CUITextLayout() noexcept {}
        // dtor
        ~CUITextLayout() noexcept;
        // renderer
        void Render(
            I::Renderer2D& renderer, 
            const ColorF& color,
            Point2F point
        ) const noexcept;
    public:
        // init
        auto Init(const FontArg& arg) noexcept;
        // set font arg
        //void SetFontArg(const FontArg& arg) noexcept;
        // set text
        auto SetText(str_t str, size_t len) noexcept->Result;
        // set text
        auto SetText(str_t bgn, str_t end) noexcept { return SetText(bgn, end-bgn); };
    public:
        // resize
        void Resize(Size2F) noexcept;
        // test text size
        auto GetSize() noexcept->Size2F;
    public:
        // ok
        bool IsOK() const noexcept { return !!m_text; }
        // bool
        operator bool() const noexcept { return !!m_text; }
        // operator !
        bool operator!() const noexcept { return !m_text; }
    private:
        // ctl text data
        I::Text*            m_text = nullptr;
        // half line spacing
        float               m_halfls = 0.f;
    };
}