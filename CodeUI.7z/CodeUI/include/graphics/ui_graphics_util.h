﻿#pragma once

// ui
#include "ui_graphics_decl.h"
#include "../core/ui_basic_type.h"

namespace UI {
    // fill rect with std brush
    void FillRectStdBrush(I::Renderer2D&, I::Brush&, const RectF&) noexcept;
}