﻿#pragma once

// ui::i namespace
namespace UI { namespace I {
    // renderer 2d
    struct Renderer2D;
    // bitmap
    struct Bitmap;
    // brush
    struct Brush;
    // 3d device
    struct Device3D;
    // renderer 3d
    struct Renderer3D;
    // Swapちゃん
    struct Swapchan;
    // graphics factory
    struct FactoryGraphics;
}}