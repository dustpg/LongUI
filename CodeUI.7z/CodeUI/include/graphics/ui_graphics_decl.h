﻿#pragma once

// ui::i namespace
namespace UI { namespace I {
    // renderer 2d
    struct Renderer2D;
    // geometry
    struct Geometry;
    // bitmap
    struct Bitmap;
    // brush
    struct Brush;
    // 3d device
    struct Device3D;
    // renderer 3d
    struct Renderer3D;
    // Swap ちゃん
    struct Swapchan;
    // graphics factory
    struct FactoryGraphics;
}}

