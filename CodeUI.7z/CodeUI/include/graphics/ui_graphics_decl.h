﻿#pragma once

// ui::i namespace
namespace UI { namespace I {
    // renderer
    struct Renderer;
    // bitmap
    struct Bitmap;
    // brush
    struct Brush;
}}