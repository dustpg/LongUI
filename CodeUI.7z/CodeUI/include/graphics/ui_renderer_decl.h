﻿#pragma once

// ui namespace
namespace UI { 
    // background renderer
    class CUIRendererBackground;
    // border renderer
    class CUIBorderRender;
}
