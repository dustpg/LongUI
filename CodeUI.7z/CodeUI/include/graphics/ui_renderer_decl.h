﻿#pragma once


namespace UI { 
    // background renderer
    class CUIRendererBackground;
}