﻿#pragma once

#include "../core/ui_basic_type.h"
#include "ui_graphics_decl.h"
#include "util/ui_unimacro.h"

// D2D
#include <d2d1_1.h>
// D3D
#include <d3d11.h>
// DXGI
#include <dxgi1_2.h>

// ui::i namespace
namespace UI { namespace I {
    // 2d renderer
    struct PCN_NOVTABLE Renderer2D : ID2D1DeviceContext { };
    // bitmap
    struct PCN_NOVTABLE Bitmap : ID2D1Bitmap1 {};
    // brush
    struct PCN_NOVTABLE Brush : ID2D1Brush {};
    // Swap
    struct PCN_NOVTABLE Swapchan : IDXGISwapChain1 {};
    // 3d device
    struct PCN_NOVTABLE Device3D : ID3D11Device {};
    // 3d renderer
    struct PCN_NOVTABLE Renderer3D : ID3D11DeviceContext {};
    // Swap
    struct PCN_NOVTABLE FactoryGraphics : IDXGIFactory2 {};
}}

// ui namespace
namespace UI {
    // safe release
    template<class T> inline void SafeRelease(T *& pi) {
        if (pi) { pi->Release(); pi = nullptr; }
    }
    // safe acquire
    template<class T> inline auto SafeAcquire(T * pi) {
        if (pi)  pi->Release(); return pi;
    }
}


// ui auto cast
namespace UI {
    // ui auto cast: matrix
    inline auto auto_cast(const Matrix3X2F& f) noexcept {
        auto& t = reinterpret_cast<const D2D1_MATRIX_3X2_F&>(f);
        static_assert(sizeof(f) == sizeof(t), "must be same");
        return t;
    }
}

// auto cast
using UI::auto_cast;
