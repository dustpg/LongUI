﻿#pragma once

#include "ui_graphics_decl.h"
#include "util/ui_unimacro.h"

// D2D
#include <d2d1_1.h>

namespace UI { namespace I {
    // renderer
    struct PCN_NOVTABLE Renderer : ID2D1DeviceContext { };
    // bitmap
    struct PCN_NOVTABLE Bitmap : ID2D1Bitmap {};
    // brush
    struct PCN_NOVTABLE Brush : ID2D1Brush {};
}}