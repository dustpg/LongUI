﻿#pragma once

#include "pod_vector.h"

// ui namespace
namespace UI {
    /// <summary>
    /// const string list
    /// </summary>
    /*class CUIConstStringList {
        // node size
        enum { NODE_SIZE = 2048  };
        // list for node
        struct Node {
            // next
            Node*       next;
            // buffer
            char        buf[NODE_SIZE - sizeof(void*)];
        };
    public:
        // 
        using T = wchar_t;
    private:
        // index vector
        POD::Vector<const T*>       m_index;
    };*/
}
