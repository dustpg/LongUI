﻿#pragma once
#include <cstdint>
#include "constexpr\const_bkdr.h"

namespace UI {
    // classes
    struct LogInfo;
    // log level
    enum LogLevel {
        // just display
        Level_Info = 0,
        // log to file
        Level_Log,
        // log to file && warning display
        Level_Warning,
        // log to file && error display
        Level_Error,
        // log to file && fatal display
        Level_Fatal,
    };
    // Logger
    class CUILogger {
    public:
        // log
        //template<LogLevel>
    private:
    };
    // operator << float
    auto operator<<(CUILogger&, float) noexcept->CUILogger&;
    // operator << c-style string
    auto operator<<(CUILogger&, const char*) noexcept->CUILogger&;
    // logger << log
    auto operator<<(CUILogger&, const LogInfo&) noexcept->CUILogger&;
}
