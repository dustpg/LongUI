﻿#pragma once
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// basic type
#include "../core/ui_basic_type.h"
#include "../core/ui_core_type.h"
//#include "../util/ui_ostype.h"

// helper marco
#define _lui_inter_debug UI::CUIDebug::GetInstance()
#ifndef NDEBUG
#define _lui_inter_extra << UI::Interfmt(L"<%4dL@%ls>: ", int(__LINE__), __FUNCTIONW__)
#define longui_debug_hr(hr, msg) if (!hr) LUIDebug(Error) << msg << UI::endl
#else
#define _lui_inter_extra
#define longui_debug_hr(hr, msg) (void)0
#endif
// debug marco
#define LUIDebug(lv) _lui_inter_debug << UI::DebugStringLevel::DLevel_##lv _lui_inter_extra


// ui namespace
namespace UI {
    // debug string level
    enum DebugStringLevel : uint32_t {
        // None level
        DLevel_None = 0,
        // level Log
        DLevel_Log,
        // level Hint
        DLevel_Hint,
        // level Warning
        DLevel_Warning,
        // level Error
        DLevel_Error,
        // level Fatal
        DLevel_Fatal,
        // level's size
        DLEVEL_SIZE
    };
    // endl for longUI
    struct EndL { }; extern EndL const endl;
    // debug
    class CUIDebug {
    public:
        // set unhandled exp handler
        static void InitUnExpHandler() noexcept;
        // output debug string
        void OutputString(
            DebugStringLevel level,
            const wchar_t* str,
            bool flush
        ) noexcept;
#ifdef NDEBUG
        // get debug instance
        static auto GetInstance() noexcept->CUIDebug& {
            return *static_cast<CUIDebug*>(nullptr);
    }
#else
        // get debug instance
        static auto GetInstance() noexcept->CUIDebug&;
#endif
#ifdef NDEBUG
        // overload << operator 重载 << 运算符
        template<typename T>
        inline const CUIDebug& operator<< (const T&) const noexcept { return *this; }
        // output with wide char
        inline void Output(DebugStringLevel, const wchar_t*) const noexcept { }
        // output with utf-8
        inline void Output(DebugStringLevel, const char*) const noexcept { }
#else
        // last DebugStringLevel
        DebugStringLevel        m_lastLevel = DebugStringLevel::DLevel_Log;
        // time tick count
        uint32_t                m_timeTick = 0;
        // log file
        void*                   m_pLogFile = nullptr;
        // overload << operator for DebugStringLevel
        CUIDebug& operator<< (const DebugStringLevel l)  noexcept { m_lastLevel = l; return *this; }
        // overload << operator for float
        CUIDebug& operator<< (const float f) noexcept;
        // overload << operator for long
        CUIDebug& operator<< (const long l) noexcept;
        // overload << operator for bool
        CUIDebug& operator<< (const bool b) noexcept;
        // overload << operator for void*
        CUIDebug& operator<< (const void*) noexcept;
        // overload << operator for control
        CUIDebug& operator<< (const UIControl*) noexcept;
        // overload << operator for controls
        //CUIDebug& operator<< (const ControlVector&) noexcept;
        // overload << operator for endl
        CUIDebug& operator<< (const UI::EndL&) noexcept;
        // overload << operator for DXGI_ADAPTER_DESC*
        CUIDebug& operator<< (const Matrix3X2F& m) noexcept;
        // overload << operator for DXGI_ADAPTER_DESC*
        CUIDebug& operator<< (const GraphicsAdapterDesc& d) noexcept;
        // overload << operator for D2D1_RECT_F
        CUIDebug& operator<< (const RectF& r) noexcept;
        // overload << operator for D2D1_POINT_2F
        CUIDebug& operator<< (const Point2F& p) noexcept;
        // overload << operator for const wchar_t*
        CUIDebug& operator<< (const wchar_t* s) noexcept { this->OutputNoFlush(m_lastLevel, s); return *this; }
        // overload << operator for const char*
        CUIDebug& operator<< (const char* s) noexcept { this->OutputNoFlush(m_lastLevel, s); return *this; }
        // overload << operator for char32_t
        CUIDebug& operator<< (const char32_t ch) noexcept;
        // overload << operator for CUIString
        CUIDebug& operator<< (const CUIString& s) noexcept; 
        // output debug string with flush
        void Output(DebugStringLevel l, const wchar_t* s) noexcept;
        // output debug string with flush
        void Output(DebugStringLevel l, const char* s) noexcept;
    private:
        // output debug (utf-8) string without flush
        void OutputNoFlush(DebugStringLevel l, const char* s) noexcept;
        // output debug string without flush
        void OutputNoFlush(DebugStringLevel l, const wchar_t* s) noexcept;
    public:
#endif
    protected:
        // ctor
        CUIDebug() noexcept = default;
        // dtor
        ~CUIDebug() noexcept = default;
        // ctor
        CUIDebug(const CUIDebug&) noexcept = delete;
        // ctor
        CUIDebug(CUIDebug&&) noexcept = delete;
    };
    // formated buffer
#ifndef NDEBUG
    auto Formated(const wchar_t* format, ...) noexcept -> const wchar_t*;
    auto Interfmt(const wchar_t* format, ...) noexcept -> const wchar_t*;
#else
    static auto Formated(...) noexcept { return static_cast<const wchar_t*>(nullptr); }
#endif
}