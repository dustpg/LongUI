﻿#pragma once

#include <cstdint>


namespace UI {
    /// <summary>
    /// event for longui control event
    /// </summary>
    enum class MouseEvent : uint32_t {
        // mouse wheel in v-dir
        Event_MouseWheelV,
        // mouse wheel in h-dir
        Event_MouseWheelH,
        // mouse enter, send this event even control disabled
        Event_MouseEnter,
        // mouse leave, send this event even control disabled
        Event_MouseLeave,
        // mouse move
        Event_MouseMove,
        // left-button down
        Event_LButtonDown,
        // left-button up
        Event_LButtonUp,
        // right-button down
        Event_RButtonDown,
        // right-button up
        Event_RButtonUp,
        // middle-button down
        Event_MButtonDown,
        // middle-button up
        Event_MButtonUp,
        //--mouse hover for little time
        //--Event_MouseHover,
        // event unknown
        Event_Unknown,
    };
    /// <summary>
    /// Argument for mouse event
    /// </summary>
    struct MouseEventArg {
        // mouse event type
        MouseEvent      type;
        // wheel
        float           wheel;
        // mouse point x
        float           px;
        // mouse point y
        float           py;
    };
}