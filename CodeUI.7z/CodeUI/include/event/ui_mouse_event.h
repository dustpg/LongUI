﻿#pragma once

#include <cstdint>


namespace UI {
    /// <summary>
    /// event for longui control event
    /// </summary>
    enum class MouseEvent : uint32_t {
        // mouse wheel in v, if no child handle this, will send it to marginal control
        Event_MouseWheelV,
        // mouse wheel in h, if no child handle this, will send it to marginal control
        Event_MouseWheelH,
        // mouse enter
        Event_MouseEnter,
        // mouse leave
        Event_MouseLeave,
        // mouse hover
        Event_MouseHover,
        // mouse move
        Event_MouseMove,
        // left-button down
        Event_LButtonDown,
        // left-button up
        Event_LButtonUp,
        // right-button down
        Event_RButtonDown,
        // right-button up
        Event_RButtonUp,
        // middle-button down
        Event_MButtonDown,
        // middle-button up
        Event_MButtonUp,
    };
    /// <summary>
    /// Argument for mouse event
    /// </summary>
    struct MouseEventArg {
        // mouse event type
        MouseEvent      type;
        // wheel
        float           wheel;
        // mouse point x
        float           px;
        // mouse point y
        float           py;
    };
}