﻿#pragma once

#include <cstdint>

namespace UI {
    /// <summary>
    /// notice event type
    /// </summary>
    enum class NoticeEvent : uint32_t {
        // initialize
        Event_Initialize = 0,
        // refresh min size
        Event_RefreshMinSize,
        // do default action
        Event_DoDefaultAction,
        // viewport only
        Event_UIEvent,
    };
    /// <summary>
    /// event argument
    /// </summary>
    struct EventArg {
        // event type
        NoticeEvent     nevent;
        // derived used data
        uint32_t        derived;
    };
}