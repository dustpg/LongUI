﻿#pragma once

#include <cstdint>

namespace UI {
    /// <summary>
    /// notice event type
    /// </summary>
    enum class NoticeEvent : uint32_t {
        // after tree complete
        Event_TreeComplete = 0,
        // refresh min size
        Event_RefreshMinSize,
        // do default action
        Event_DoDefaultAction,
        // for window/viewport only
        Event_UIEvent,
    };
}