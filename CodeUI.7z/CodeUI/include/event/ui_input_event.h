﻿#pragma once

#include <cstdint>


namespace UI {
    /// <summary>
    /// normal input event
    /// </summary>
    enum class InputEvent : uint32_t {
        // event char
        Event_Char = 0,
        // event-cancel
        Event_Cancel,
        // event-ok
        Event_Ok,
        // event-function
        Event_Function,
        // event-action
        Event_Action,
        // event-left
        Event_TurnLeft,
        // event-top
        Event_TurnUp,
        // event-right
        Event_TurnRight,
        // event-down
        Event_TurnDown,
        // event-next
        Event_TurnNext,
        // event-prev
        Event_TurnPrev,
    };
    /// <summary>
    /// Argument for mouse event
    /// </summary>
    struct InputEventArg {
        // input event type
        InputEvent      event;
        // character
        char32_t        character;
    };
}