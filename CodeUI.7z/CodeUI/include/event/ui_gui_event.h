﻿#pragma once

#include <cstdint>

namespace UI {
    /// <summary>
    /// gui event type
    /// </summary>
    enum class GuiEvent : uint32_t {
        // command
        Event_Command = 0,
        // click(mouse-like-device only)
        Event_Click,
    };
}