﻿#pragma once

#include "ui_gui_event.h"
#include "../core/ui_core_type.h"
#include "../util/ui_function.h"
#include <utility>

namespace UI{
    /// <summary>
    /// gui event host
    /// </summary>
    class CUIEventHost {
    public:
        // add gui event listener with ownid
        template<typename E, typename Callable>
        inline bool AddGuiEventListener(E e, uintptr_t ownid, Callable call) {
            static_assert(
                std::is_same<E, const char*>::value ||
                std::is_same<E, GuiEvent>::value,
                "e must be 'const char*' or 'GuiEvent'"
                );
            GuiEventListener listener{ call };
            auto result = this->add_gui_event_listener(ownid, e, std::move(listener));
            assert(result && "this control not support this gui event");
            return result;
        }
        // add gui event listener without ownid(ownid = 0)
        template<typename Callable>
        inline bool AddGuiEventListener(GuiEvent e, Callable call) {
            return AddGuiEventListener(e, 0, call);
        }
        // add gui event listener without ownid(ownid = 0)
        template<typename Callable>
        inline bool AddGuiEventListener(const char* e, Callable call) {
            return AddGuiEventListener(e, 0, call);
        }
        // remove gui event listener with enum-name-event
        void RemoveGuiEventListener(uintptr_t ownid, GuiEvent) noexcept;
        // remove gui event listener with string-name-event
        void RemoveGuiEventListener(uintptr_t ownid, const char* str) noexcept {
            RemoveGuiEventListener(ownid, strtoe(str));
        }
    private:
        // string to event
        static auto strtoe(const char*) noexcept->GuiEvent;
        // add gui event listener
        bool add_gui_event_listener(uintptr_t ownid, GuiEvent, GuiEventListener&&) noexcept;
        // add gui event listener
        bool add_gui_event_listener(uintptr_t ownid, const char* str, GuiEventListener&& l) noexcept {
            return add_gui_event_listener(ownid, strtoe(str), std::move(l));
        }
    };
}