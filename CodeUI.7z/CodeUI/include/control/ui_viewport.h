﻿#pragma once

#include "ui_box_layout.h"
#include "../core/ui_window.h"

namespace UI {
    // viewport, logic window viewport
    class UIViewport : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend window
        friend CUIWindow;
    public:
        // ctor
        UIViewport(CUIWindow* parent = nullptr) noexcept;
        // dtor
        ~UIViewport() noexcept;
    protected:
        // window
        CUIWindow           m_window;
    };
}