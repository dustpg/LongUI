﻿#pragma once

#include "ui_box_layout.h"
#include "../core/ui_window.h"

namespace UI {
    // viewport, logic window viewport
    class UIViewport : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend window
        friend CUIWindow;
    public:
        // recreate/init device(gpu) resource
        auto Recreate() noexcept->Result override;
    public:
        // ctor
        UIViewport(CUIWindow* parent = nullptr) noexcept;
        // dtor
        ~UIViewport() noexcept;
        // ref the window
        auto&RefWindow() noexcept { return m_window; }
    protected:
        // window
        CUIWindow           m_window;
    };
}