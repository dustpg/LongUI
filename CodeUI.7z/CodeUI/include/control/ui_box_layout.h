﻿#pragma once

#include "ui_scroll_area.h"

namespace UI {
    // box layout
    class UIBoxLayout : public UIScrollArea {
        // super class
        using Super = UIScrollArea;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIBoxLayout() noexcept;
        // ctor
        UIBoxLayout(UIControl* parent = nullptr) noexcept;
        // do event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
    private:
        // relayout
        void relayout() noexcept override;
    protected:
        // relayout h
        void relayout_h() noexcept;
        // relayout v
        void relayout_v() noexcept;
    public:
        // set orient
        void SetOrient(AttributeOrient o) noexcept;
        // get orient
        auto GetOrient() const noexcept ->AttributeOrient {
            return static_cast<AttributeOrient>(m_state.layout_orient);
        }
    };
    // v-box layout
    class UIVBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIVBoxLayout(UIControl* parent = nullptr) noexcept;
        // dtor
        ~UIVBoxLayout() noexcept;
    public:
    };
    // h-box layout
    class UIHBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIHBoxLayout(UIControl* parent = nullptr) noexcept;
        // dtor
        ~UIHBoxLayout() noexcept;
    public:
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIBoxLayout);
    // get meta info for UIBBoxLayout
    LUI_DECLARE_METAINFO(UIVBoxLayout);
    // get meta info for UIHBoxLayout
    LUI_DECLARE_METAINFO(UIHBoxLayout);
}