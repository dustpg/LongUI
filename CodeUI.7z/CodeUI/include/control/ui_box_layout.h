﻿#pragma once

#include "ui_scroll_area.h"

namespace UI {
    // box layout
    class UIBoxLayout : public UIScrollArea {
        // super class
        using Super = UIScrollArea;
    public:
        // dtor
        ~UIBoxLayout() noexcept;
        // ctor
        UIBoxLayout(UIControl* parent = nullptr) noexcept;
        // do event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
    private:
        // relayout
        void relayout() noexcept override;
    public:
        // set orient
        void SetOrient(AttributeOrient o) noexcept;
        // get orient
        auto GetOrient() const noexcept ->AttributeOrient {
            return static_cast<AttributeOrient>(m_state.layout_orient);
        }
    };
    // v-box layout
    class UIVBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // ctor
        UIVBoxLayout(UIControl* parent = nullptr) noexcept;
        // dtor
        ~UIVBoxLayout() noexcept;
    public:
    };
    // h-box layout
    class UIHBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // ctor
        UIHBoxLayout(UIControl* parent = nullptr) noexcept;
        // dtor
        ~UIHBoxLayout() noexcept;
    public:
    };
}