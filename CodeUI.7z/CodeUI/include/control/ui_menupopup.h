﻿#pragma once

// ui
#include "ui_viewport.h"

// ui namespace
namespace UI {
    // menu list
    class UIMenuList;
    // menu item
    class UIMenuItem;
    // private data for menupopup
    struct PrivateMenuPopup;
    // menupopup control
    class UIMenuPopup : public UIViewport {
        // super class
        using Super = UIViewport;
        // friend class
        friend UIMenuList;
        // friend class
        friend UIMenuItem;
    protected:
        // ctor
        UIMenuPopup(UIControl* hoster, const MetaControl&) noexcept;
        // init hoster
        void init_hoster(UIControl* hoster) noexcept { m_pHoster = hoster; }
        // set selected
        //void set_selected(UIControl* hoster) noexcept { m_pHoster = hoster; }
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuPopup() noexcept;
        // ctor
        UIMenuPopup(UIControl* hoster) noexcept : UIMenuPopup(hoster, UIMenuPopup::s_meta) {}
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // get hoster
        auto GetHoster() const noexcept { return m_pHoster; }
        // get selected
        auto GetSelected() const noexcept { return m_pSelected; }
    protected:
        // add child
        //void add_child(UIControl& child) noexcept override;
        // hoster
        UIControl*              m_pHoster = nullptr;
        // selected
        UIMenuItem*             m_pSelected = nullptr;
    private:
        // hoster
        // private data
        //PrivateMenuPopup*        m_private = nullptr;
    };
    // get meta info for UIMenuPopup
    LUI_DECLARE_METAINFO(UIMenuPopup);
}