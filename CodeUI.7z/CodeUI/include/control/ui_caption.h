﻿#pragma once

// ui header
#include "ui_label.h"
#include "../style/ui_text.h"
#include "../core/ui_string.h"
#include "../text/ui_text_layout.h"
#include "../core/ui_const_sstring.h"
#include "../util/ui_named_control.h"

// ui namespace
namespace UI {
    // caption
    class UICaption : public UILabel {
        // super class
        using Super = UILabel;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UICaption() noexcept;
        // ctor
        UICaption(UIControl* parent = nullptr) noexcept;
    };
    // get meta info for UICaption
    LUI_DECLARE_METAINFO(UICaption);
}