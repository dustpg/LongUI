﻿#pragma once

namespace UI {
    // control
    class UIControl;
    // control meta info
    struct MetaControl {
        // super class
        const MetaControl*  super_class;
        // element name
        const char*         element_name;
        // create control
        auto (*create_func)(UIControl*) noexcept->UIControl*;
    };
}