﻿#pragma once

namespace UI {
    // control
    class UIControl;
    // control meta info
    struct MetaControl {
        // super class
        const MetaControl*  super_class;
        // element name
        const char*         element_name;
        // create control
        auto (*create_func)(UIControl*) noexcept->UIControl*;
    };
}
// control meta info 
#define LUI_CONTROL_META_INFO(T, ele) \
    static UIControl* create_##T(UIControl* p) noexcept {\
        return new(std::nothrow) T{ p };\
    }\
    const MetaControl T::s_meta = {\
        &T::Super::s_meta,\
        ele,\
        create_##T\
    };

// init meta pointer
#define LUI_INIT_META_POINTER m_pMetaInfo = &s_meta

