﻿#pragma once

// ui header
#include "ui_control.h"
#include "../style/ui_text.h"
#include "../core/ui_string.h"
#include "../text/ui_text_layout.h"
#include "../core/ui_const_sstring.h"
#include "../util/ui_named_control.h"

// TextBC
#include <../TextBC/bc_txtplat.h>

// ui namespace
namespace UI {
    // private data for textbox
    struct PrivateTextBox;
    // textbox
    class UITextBox : public UIControl, 
        protected TextBC::IBCTextPlatform {
        // super class
        using Super = UIControl;
        // text content
        using Text = TextBC::IBCTextContent;
    protected:
        // ctor
        UITextBox(UIControl* parent, const MetaControl&) noexcept;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITextBox() noexcept;
        // ctor
        UITextBox(UIControl* parent = nullptr) noexcept :UITextBox(parent, UITextBox::s_meta) {}
    public:
        // normal event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
        // render
        void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept -> EventAccept override;
    protected:
        // need redraw
        void NeedRedraw() noexcept override;
        // draw caret, TODO: set caret rect
        void DrawCaret(void* ctx, const TextBC::RectWHF& rect) noexcept override;
        // create content
        auto CreateContent(const char16_t*, uint32_t len, Text&& old) noexcept->Text* override;
        // delete content
        void DeleteContent(Text&) noexcept override;
        // draw content
        void DrawContent(Text&, void*, TextBC::Point2F) noexcept override;
        // content metrics event
        void ContentEvent(Text&, MetricsEvent, void*) noexcept override;
    protected:
        // add attribute
        //void add_attribute(const StrAttribute&) noexcept override;
    public:
        // set text
        void SetText(str_t str, size_t len) noexcept;
        // set text
        void SetText(str_t str) noexcept { SetText(str, std::wcslen(str)); };
        // set text
        void SetText(str_t bgn, str_t end) noexcept { SetText(bgn, end - bgn); };
    private:
        // private data
        PrivateTextBox*        m_private = nullptr;
        // create private data
        void create_private() noexcept;
        // delete private data
        void delete_private() noexcept;
        // private mouse down
        void private_mouse_down(Point2F) noexcept;
    public:

    };
    // get meta info for UITextBox
    LUI_DECLARE_METAINFO(UITextBox);
}