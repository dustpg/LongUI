﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private button class
    struct PrivateButton;
    // button
    class UIButton : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateButton;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIButton() noexcept;
        // ctor
        UIButton(UIControl* parent = nullptr) noexcept;
    public:
        // render
        //void Render() const noexcept override;
    private:
        // private data
        PrivateButton*        m_private = nullptr;
    };
    // get meta info for UIButton
    LUI_DECLARE_METAINFO(UIButton);
}