﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private button class
    struct PrivateButton;
    // button
    class UIButton : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateButton;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIButton() noexcept;
        // ctor
        UIButton(UIControl* parent = nullptr) noexcept : UIButton(parent, UIButton::s_meta) {}
    protected:
        // ctor
        UIButton(UIControl* parent, const MetaControl&) noexcept;
    public:
        // clicked event
        static inline auto _clicked() noexcept { return GuiEvent::Event_Click; }
    public:
        // click this
        void Click() noexcept;
        // get text
        auto GetText() const noexcept ->str_t;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& str) noexcept; 
        // set text
        void SetText(str_t str, size_t len) noexcept;
        // set text
        void SetText(str_t str) noexcept { SetText(str, std::wcslen(str)); };
        // set text
        void SetText(str_t bgn, str_t end) noexcept { SetText(bgn, end - bgn); };
    public:
        // do event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    private:
        // private data
        PrivateButton*        m_private = nullptr;
    };
    // get meta info for UIButton
    LUI_DECLARE_METAINFO(UIButton);
}