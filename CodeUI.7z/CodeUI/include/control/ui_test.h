﻿#pragma once

#ifndef DEBUG
#include "ui_control.h"
//#include "../util/ui_double_click.h"

// ui namespace
namespace UI {
    // test control
    class UITest : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UITest(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITest() noexcept;
        // ctor
        UITest(UIControl* parent = nullptr) noexcept : UITest(parent, UITest::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        void Render() const noexcept override;
        // recreate/init device(gpu) resource
        auto Recreate() noexcept->Result override;
    protected:
    private:
    };
    // get meta info for UITest
    LUI_DECLARE_METAINFO(UITest);
}
#endif
