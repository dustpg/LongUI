﻿#pragma once

#include <cstdint>

namespace UI {
    // control state
    struct CtrlState {
        // ctor
        void Init() noexcept;
        // tree level
        uint8_t     level;
        // dirty:   need re-calculate layout,  be set if layout/size changed
        bool        dirty : 1;
        // has been inited
        bool        inited : 1;
        // orientation
        bool        orient : 1;
        // in dtor
        bool        in_dtor : 1;
        // layout direction
        bool        layout_dir : 1;
        // world matrix changed
        bool        world_changed : 1;
        // style state changed
        bool        style_state_changed: 1;
        // layout custom data
        bool        layout_custom : 1;
        // in update list
        bool        in_update_list : 1;
        // child index changed(add child)
        bool        child_i_changed : 1;
        // parent changed
        bool        parent_changed : 1;
        // directly managed
        bool        directly_managed : 1;
        // gui event to parent[true, to parent, false to viewport]
        bool        gui_event_to_parent : 1;
        // attachment 
        bool        attachment : 1;
        // focusable
        bool        focusable : 1;
        // defaultable
        bool        defaultable : 1;
        // public container
        bool        public_container : 1;
        // visible
        bool        visible : 1;
        // atomicity, children just part/component of parent
        bool        atomicity : 1;
        // delete later?
        bool        delete_later : 1;
    };
}