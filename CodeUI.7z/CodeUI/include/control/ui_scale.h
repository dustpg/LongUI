﻿#pragma once

// ui
#include "ui_image.h"

// ui namespace
namespace UI {
    // scale/slider control
    class UIScale : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIScale() noexcept;
        // ctor
        UIScale(UIControl* parent = nullptr) noexcept;
    public:
        // recreate
        //auto Recreate() noexcept->Result override;
        // render
        //void Render() const noexcept override;
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept;
    public:
        // set value
        void SetValue(float value) noexcept;
        // set min
        void SetMin(float value) noexcept;
        // set max
        void SetMax(float value) noexcept;
        // set orient
        //void SetOrient(AttributeOrient o) noexcept;
        // get min value
        auto GetMin() const noexcept { return m_fMin; }
        // get max value
        auto GetMax() const noexcept { return m_fMax; }
        // get value
        auto GetValue() const noexcept { return m_fValue; }
        // decrease
        void Decrease() noexcept { SetValue(m_fValue - increment); }
        // increase
        void Increase() noexcept { SetValue(m_fValue + increment); }
        // decrease page
        void DecreasePage() noexcept { SetValue(m_fValue - page_increment); }
        // increase page
        void IncreasePage() noexcept { SetValue(m_fValue + page_increment); }
        // get orient
        auto GetOrient() const noexcept { return static_cast<AttributeOrient>(m_state.orient); }
    protected:
        // add attribute
        //void add_attribute(const StrAttribute&) noexcept override;
        // refresh thumb postion
        void refresh_thumb_postion() noexcept;
    protected:
        // min value
        float                   m_fMin = 0.f;
        // max value
        float                   m_fMax = 100.0f;
        // now value
        float                   m_fValue = 50.f;
        // int only
        bool                    m_bIntOnly = true;
        // unused
        bool                    m_sldierUnused[3];
    public:
        // increment value
        float                   increment = 1.f;
        // page increment
        float                   page_increment = 10.f;
        // thumb control
        UIImage                 thumb;
    };
    // slider
    using UISlider = UIScale;
    // get meta info for UIImage
    LUI_DECLARE_METAINFO(UIScale);
}