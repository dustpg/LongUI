﻿#pragma once

#include "ui_control.h"

// ui namespace
namespace UI {
    // spacer
    class UISpacer : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UISpacer() noexcept;
        // ctor
        UISpacer(UIControl* parent = nullptr) noexcept;
        // render
        void Render() const noexcept override;
    };
    // get meta info for UISpacer
    LUI_DECLARE_METAINFO(UISpacer);
}