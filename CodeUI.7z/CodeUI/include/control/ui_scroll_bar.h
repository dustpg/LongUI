﻿#pragma once

#include "ui_control.h"

namespace UI {
    // scroll bar private data
    struct PrivateScrollBar;
    // scroll bar
    class UIScrollBar final : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIScrollBar(AttributeOrient o, UIControl* parent = nullptr) noexcept;
        // ctor
        UIScrollBar(UIControl* parent) noexcept : UIScrollBar(Orient_Vertical, parent) {}
        // dtor
        ~UIScrollBar() noexcept;
        // render this control only, [Global rendering and Incremental rendering]
        void Render() const noexcept override;
    public:
        // get value
        auto GetValue() const noexcept -> float { return m_fValue; }
        // get orient
        auto GetOrient() const noexcept -> AttributeOrient { return m_orient; }
    public:
        // set value
        void SetValue(float v) noexcept;
        // set max
        void SetMax(float v) noexcept;
        // set min
        void SetMin(float v) noexcept;
        // set page step
        void SetPageStep(float v) noexcept;
        // set single step
        void SetSingleStep(float v) noexcept;
    protected:
    private:
        // private data
        PrivateScrollBar*   m_private = nullptr;
        // orient
        AttributeOrient     m_orient;
        // min
        float               m_fMin = 0.f;
        // max
        float               m_fMax = 100.f;
        // value
        float               m_fValue = 0.f;
        // page step
        float               m_fPageStep = 10.f;
        // single step
        float               m_fSingleStep = 1.f;
    };
    // get meta info for UIScrollBar
    LUI_DECLARE_METAINFO(UIScrollBar);
}