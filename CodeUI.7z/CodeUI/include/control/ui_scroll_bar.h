﻿#pragma once

#include "ui_box_layout.h"

namespace UI {
    // scroll bar private data
    struct PrivateScrollBar;
    // scroll bar
    class UIScrollBar final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // init bar
        void init_bar() noexcept;
    protected:
        // ctor
        UIScrollBar(AttributeOrient o, UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIScrollBar(AttributeOrient o, UIControl* parent = nullptr) noexcept : UIScrollBar(o, parent, UIScrollBar::s_meta) {}
        // ctor
        UIScrollBar(UIControl* parent) noexcept : UIScrollBar(Orient_Vertical, parent, UIScrollBar::s_meta) {}
        // dtor
        ~UIScrollBar() noexcept;
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept ->EventAccept override;
    public:
        // get value
        auto GetValue() const noexcept -> float;
    public:
        // set value
        void SetValue(float v) noexcept;
        // set max
        void SetMax(float v) noexcept;
        // set page increment
        void SetPageIncrement(float pi) noexcept;
    private:
        // private data
        PrivateScrollBar*   m_private = nullptr;
    };
    // get meta info for UIScrollBar
    LUI_DECLARE_METAINFO(UIScrollBar);
}