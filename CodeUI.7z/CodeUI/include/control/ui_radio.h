﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private radio class
    struct PrivateRadio;
    // redio group
    class UIRadioGroup;
    // radio
    class UIRadio : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateRadio;
        // init radio
        void init_radio() noexcept;
    protected:
        // ctor
        UIRadio(UIControl* parent, const MetaControl&) noexcept;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRadio() noexcept;
        // ctor
        UIRadio(UIControl* parent = nullptr) noexcept : UIRadio(parent, UIRadio::s_meta) {}
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    public:
        // set checked
        void SetChecked(bool);
        // set text
        void SetText(const CUIString& str) noexcept;
        // set text
        void SetText(str_t str, size_t len) noexcept;
        // set text
        void SetText(str_t str) noexcept { SetText(str, std::wcslen(str)); };
        // set text
        void SetText(str_t bgn, str_t end) noexcept { SetText(bgn, end - bgn); };
    private:
        // radio group
        UIRadioGroup*      m_pRadioGroup = nullptr;
        // private data
        PrivateRadio*       m_private = nullptr;
    };
    // get meta info for UIRadio
    LUI_DECLARE_METAINFO(UIRadio);
}