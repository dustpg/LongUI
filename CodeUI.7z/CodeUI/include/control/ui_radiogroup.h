﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private radiogroup class
    struct PrivateRadioGroup;
    // radio control
    class UIRadio;
    // radiogroup
    class UIRadioGroup : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateRadioGroup;
    protected:
        // ctor
        UIRadioGroup(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRadioGroup() noexcept;
        // ctor
        UIRadioGroup(UIControl* parent = nullptr) noexcept : UIRadioGroup(parent, UIRadioGroup::s_meta) {}
        // update
        void Update() noexcept override;
        //// do normal event
        //auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    public:
        // checked changed
        static inline auto _changed() noexcept { return GuiEvent::Event_Change; }
    public:
        // get checked radio
        auto GetChecked() const noexcept { return m_pChecked; }
        // set checked radio
        void SetChecked(UIRadio& radio) noexcept { this->set_checked(&radio); }
        // set checked radio to null
        void SetChecked(std::nullptr_t) noexcept { this->set_checked(nullptr); }
    private:
        // set checked radio
        void set_checked(UIRadio* radio) noexcept;
    protected:
        // checked radio
        UIRadio*            m_pChecked = nullptr;
    };
    // get meta info for UIRadioGroup
    LUI_DECLARE_METAINFO(UIRadioGroup);
}