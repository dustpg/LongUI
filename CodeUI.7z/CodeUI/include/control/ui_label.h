﻿#pragma once

// ui header
#include "ui_control.h"
#include "../text/ui_text_layout.h"
#include "../core/ui_string.h"

// ui namespace
namespace UI {
    // label
    class UILabel : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UILabel() noexcept;
        // ctor
        UILabel(UIControl* parent = nullptr) noexcept;
    public:
        // normal event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
        // render
        void Render() const noexcept override;
    public:
        // set text
        void SetText(str_t str, size_t len) noexcept;
        // set text
        void SetText(str_t str) noexcept { SetText(str, std::wcslen(str)); };
        // set text
        void SetText(str_t bgn, str_t end) noexcept { SetText(bgn, end - bgn); };
    protected:
        // text layout
        CUITextLayout           m_text;
    public:
        // defualt value
        enum : int32_t {
            // defualt margin top
            DEFUALT_MARGIN_TOP = 1,
            // defualt margin left
            DEFUALT_MARGIN_LEFT = 6,
            // defualt margin right
            DEFUALT_MARGIN_RIGHT = 5,
            // defualt margin bottom
            DEFUALT_MARGIN_BOTTOM = 2,
            // defualt text x offset
            DEFUALT_TEXT_X_OFFSET = 1,
            // defualt text y offset
            DEFUALT_TEXT_Y_OFFSET = 0,
        };
    };
    // get meta info for UILabel
    LUI_DECLARE_METAINFO(UILabel);
}