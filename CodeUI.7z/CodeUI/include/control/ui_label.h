﻿#pragma once

// ui header
#include "ui_control.h"
#include "../style/ui_text.h"
#include "../core/ui_string.h"
#include "../text/ui_text_layout.h"
#include "../core/ui_const_sstring.h"
#include "../util/ui_named_control.h"

// ui namespace
namespace UI {
    // label
    class UILabel : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UILabel(UIControl* parent, const MetaControl&) noexcept;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UILabel() noexcept;
        // ctor
        UILabel(UIControl* parent = nullptr) noexcept : UILabel(parent, UILabel::s_meta) {}
    public:
        // normal event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
        // render
        void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(const StrAttribute&) noexcept override;
    public:
        // get text
        auto GetText() const noexcept->str_t { return m_string.c_str(); }
        // get text- string object
        auto&GetTextString() const noexcept { return m_string; }
        // set text, return true if changed
        bool SetText(str_t str, size_t len) noexcept;
        // set text, return true if changed
        bool SetText(str_t str) noexcept { return SetText(str, std::wcslen(str)); };
        // set text, return true if changed
        bool SetText(str_t bgn, str_t end) noexcept { return SetText(bgn, end - bgn); };
        // set text, return true if changed
        bool SetText(const CUIString& str) noexcept { return SetText(str.c_str(), str.length()); };
    protected:
        // connection control
        NamedControl            m_control;
        // text font buffer
        TextFont                m_tfBuffer;
        // href text
        CUIConstShortString     m_href;
        // text layout
        CUITextLayout           m_text;
        // text string
        CUIString               m_string;
        // accesskey
        char                    m_accesskey = 0;
    public:
        // defualt value
        enum : int32_t {
            // defualt margin top
            DEFUALT_MARGIN_TOP = 1,
            // defualt margin left
            DEFUALT_MARGIN_LEFT = 6,
            // defualt margin right
            DEFUALT_MARGIN_RIGHT = 5,
            // defualt margin bottom
            DEFUALT_MARGIN_BOTTOM = 2,
            // defualt text x offset
            DEFUALT_TEXT_X_OFFSET = 1,
            // defualt text y offset
            DEFUALT_TEXT_Y_OFFSET = 0,
        };
    };
    // get meta info for UILabel
    LUI_DECLARE_METAINFO(UILabel);
}