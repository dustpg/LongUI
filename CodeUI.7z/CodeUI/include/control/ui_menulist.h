﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private menulist class
    struct PrivateMenuList;
    // menu popup
    class UIMenuPopup;
    // menulist
    class UIMenuList : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateMenuList;
        // menu list
        void init_menulist();
    protected:
        // ctor
        UIMenuList(UIControl* parent, const MetaControl&) noexcept;
    public:
        // string type
        using str_t = const wchar_t *;
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuList() noexcept;
        // ctor
        UIMenuList(UIControl* parent = nullptr) noexcept : UIMenuList(parent, UIMenuList::s_meta) {}
    public:
        // clicked event
        //static inline auto _clicked() noexcept { return GuiEvent::Event_Click; }
    public:
        // show popup
        void ShowPopup() noexcept;
        // get text
        auto GetText() const noexcept->str_t;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& str) noexcept;
        // set text
        void SetText(str_t str, size_t len) noexcept;
        // set text
        void SetText(str_t str) noexcept { SetText(str, std::wcslen(str)); };
        // set text
        void SetText(str_t bgn, str_t end) noexcept { SetText(bgn, end - bgn); };
    public:
        // update
        //void Update() noexcept override;
        // do event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;

    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible event
        //auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    private:
        // popup
        UIMenuPopup*            m_pMenuPopup = nullptr;
        // private data
        PrivateMenuList*        m_private = nullptr;
    };
    // get meta info for UIMenuList
    LUI_DECLARE_METAINFO(UIMenuList);
}