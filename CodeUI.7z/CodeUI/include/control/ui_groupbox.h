﻿#pragma once

// ui
#include "ui_control.h"

// ui namespace
namespace UI {
    // private data for groupbox
    struct PrivateGroupBox;
    // groupbox
    class UIGroupBox : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIGroupBox() noexcept;
        // ctor
        UIGroupBox(UIControl* parent = nullptr) noexcept;
    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
    private:
        // private data
        PrivateGroupBox*        m_private = nullptr;
    };
    // get meta info for UIGroupBox
    LUI_DECLARE_METAINFO(UIGroupBox);
}