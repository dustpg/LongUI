﻿#pragma once

#include "ui_control.h"

// ui namespace
namespace UI {
    // image
    class UIImage : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIImage() noexcept;
        // ctor
        UIImage(UIControl* parent = nullptr) noexcept;
    };
    // get meta info for UIImage
    LUI_DECLARE_METAINFO(UIImage);
}