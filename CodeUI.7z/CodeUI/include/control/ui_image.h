﻿#pragma once

// ui
#include "ui_control.h"
#include "../resource/ui_resource_id.h"

// ui namespace
namespace UI {
    // image resource
    class CUIImage;
    // image control
    class UIImage : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UIImage(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIImage() noexcept;
        // ctor
        UIImage(UIControl* parent = nullptr) noexcept : UIImage(parent, UIImage::s_meta) {}
    public:
        // recreate
        auto Recreate() noexcept->Result override;
        // render
        void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(const StrAttribute&) noexcept override;
    protected:
        // image id
        CUIResourceID       m_idSrc;
        // shared image
        CUIImage*           m_pSharedSrc = nullptr;
    };
    // get meta info for UIImage
    LUI_DECLARE_METAINFO(UIImage);
}