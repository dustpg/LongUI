﻿#pragma once

#include "ui_control.h"

namespace UI {
        // scroll bar
    class UIScrollBar;
    // scroll area
    class UIScrollArea : public UIControl {
        // super class
        using Super = UIControl;
        // do wheel
        auto do_wheel(int index, float wheel) noexcept ->EventAccept;
    protected:
        // ctor
        UIScrollArea(UIControl* parent, const MetaControl&) noexcept;
    public:
        // meta info
        static const MetaControl    s_meta;
        // dtor
        ~UIScrollArea() noexcept;
        // ctor
        UIScrollArea(UIControl* parent = nullptr) noexcept : UIScrollArea(parent, UIScrollArea::s_meta) {}
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
    private:
        // [NEW] relayout
        virtual void relayout() noexcept;
    protected:
        // get child flex sum
        auto SumChildrenFlex() const noexcept -> float;
    public:
        // get min scroll size
        auto GetMinScrollSize() const noexcept { return m_minScrollSize; }
        // get layout direcition
        auto GetLayoutDirection() const noexcept ->AttributeDir { return AttributeDir(m_state.layout_dir); }
        // get vertical ScrollBar
        auto GetVerticalScrollBar() noexcept -> UIScrollBar* { return m_pVerticalSB; }
        // get horizontal ScrollBar
        auto GetHorizontalScrollBar() noexcept -> UIScrollBar* { return m_pHorizontalSB; }
        // get vertical ScrollBar | const overload
        auto GetVerticalScrollBar() const noexcept -> const UIScrollBar*{ return m_pVerticalSB; }
        // get horizontal ScrollBar | const overload
        auto GetHorizontalScrollBar() const noexcept -> const UIScrollBar*{ return m_pHorizontalSB; }
    protected:
        // synchronize the scroll bar
        void sync_scroll_bar() noexcept;
        // layout the scroll bar
        auto layout_scroll_bar() noexcept->Size2F;
        // get layout position
        auto get_layout_position() const noexcept->Point2F;
    private:
        // create scroll bar
        auto create_scrollbar(AttributeOrient) noexcept->UIScrollBar*;
        // layout the scroll bar - h
        auto layout_vscrollbar(bool notenough) noexcept->float;
        // layout the scroll bar - v
        auto layout_hscrollbar(bool notenough) noexcept->float;
    protected:
        // min scroll size
        Size2F              m_minScrollSize;
        // line size
        Size2F              m_szLine;
        // horizontal scroll bar
        UIScrollBar*        m_pHorizontalSB = nullptr;
        // vertical scroll bar
        UIScrollBar*        m_pVerticalSB = nullptr;
    };
    // get meta info for UIScrollArea
    LUI_DECLARE_METAINFO(UIScrollArea);
}