﻿#pragma once

// super class list
#include "../core/ui_node.h"
#include "../core/ui_object.h"
#include "../core/ui_core_type.h"
#include "../event/ui_event_host.h"
#include "../style/ui_style_value.h"
// id string
#include "../core/ui_const_sstring.h"
// vector
#include "../container/pod_vector.h"
// basic type
#include "../core/ui_basic_type.h"
// event
#include "../event/ui_gui_event.h"
#include "../event/ui_mouse_event.h"
#include "../event/ui_notice_event.h"
// style
#include "../style/ui_style.h"
#include "../style/ui_attribute.h"
// state
#include "ui_control_state.h"
// renderer
#include "../graphics/ui_renderer_decl.h"
// config
#include "../luiconf.h"

// ui namespace
namespace UI {
    // control private data
    struct PrivateControl;
    // meta info
    struct MetaControl;
    // control animation
    struct ControlAnimation;
    // control control
    class CUIControlControl;
    // control
    class UIControl :
        public IUIUpdatable,
        public CUIObject,
        public CUIEventHost,
        public CUIStyleValue,
        protected Node {
        // super class
        using Super = void;
        // friend
        friend PrivateControl;
        // friend
        friend CUIControlControl;
        // friend
        friend Node::Iterator<UIControl>;
        // friend
        friend Node::Iterator<const UIControl>;
        // friend
        friend Node::ReverseIterator<UIControl>;
        // friend
        friend Node::ReverseIterator<const UIControl>;
        // unique classes
        using UniqueClasses = POD::Vector<const char*>;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // safe type cast 
        auto SafeCastTo(const UI::MetaControl&) const noexcept->const UIControl*;
        // safe type cast, none const overload
        auto SafeCastTo(const UI::MetaControl& m) noexcept {
            const auto* p = this; return const_cast<UIControl*>(p->SafeCastTo(m));
        }
#ifndef NDEBUG
        // assert type cast
        void AssertCast(const UI::MetaControl&) const noexcept;
#endif
    public:
        // no copy ctor
        UIControl(const UIControl&) = delete;
        // no move ctor
        UIControl(UIControl&&) = delete;
        // ctor
        UIControl(UIControl* parent = nullptr) noexcept;
        // dtor
        virtual ~UIControl() noexcept;
        // do normal event
        virtual auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept;
        // do mouse event
        virtual auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept;
        // update, postpone change some data
        virtual void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        virtual void Render() const noexcept;
        // recreate/init device(gpu) resource
        virtual auto Recreate() noexcept->Result;
    protected:
        // add attribute
        virtual void add_attribute(const StrAttribute&) noexcept;
        // add/remove gui event listener
        virtual bool set_gui_event_listener(GuiEvent, uintptr_t, GuiEventListener&&) noexcept;
    public:
        // apply value
        //void ApplyValue(const SSValue&) noexcept;
        // need update in this frame
        void NeedUpdate() noexcept;// { L::AddUpdateList(*this); }
        // need update in next frame
        void NextUpdate() noexcept;// { L::AddUpdateList(*this); }
        // need relayout in this freame
        void NeedRelayout() noexcept { m_state.dirty = true; this->NeedUpdate(); }
    public:
        // find child via position 
        auto FindChild(const Point2F& pos) noexcept->UIControl*;
        // swap child index
        void SwapChildren(UIControl& a, UIControl& b) noexcept;
        // get children count
        auto GetCount() const noexcept { return m_cChildrenCount; }
        // invalidate this control
        void Invalidate() noexcept { this->invalidate(nullptr); }
        // invalidate part of control
        void Invalidate(const RectF& rect) noexcept { this->invalidate(&rect); }
        // repaint this control
        void Repaint() noexcept { this->invalidate(nullptr); }
        // repaint part of control
        void Repaint(const RectF& rect) noexcept { this->invalidate(&rect); }
        // is top level of tree? -> no parent
        bool IsTopLevel() const noexcept { return !m_pParent; }
        // get style model
        auto&GetStyle() const noexcept { return m_oStyle; }
        // get box model
        auto&GetBox() const noexcept { return m_oBox; }
    public:
        // get background color
        void GetBackgroundColor(ColorF&) const noexcept;
        // get foreground color
        void GetForegroundColor(ColorF&) const noexcept;
    public:
        // get parent
        auto GetParent() const noexcept { return m_pParent; }
        // get window
        auto GetWindow() const noexcept { return m_pWindow; }
        // set a new parent
        void SetParent(UIControl& parent) noexcept;
        // force update children
        //void ForceUpdateChildren() noexcept;
    public:
        // resize
        bool Resize(Size2F size) noexcept;
        // set visible
        void SetVisible(bool visible) noexcept;
        // get id
        auto GetID() const noexcept { return m_id.c_str(); }
        // set postion of control [Relative to parent]
        void SetPos(const Point2F & pos) noexcept;
        // get postion of control [Relative to parent]
        auto GetPos() const noexcept { return m_oBox.pos; }
        // get world matrix [Relative to window]
        auto&GetWorld() const noexcept { return m_mtWorld; }
        // get tree level
        auto GetLevel() const noexcept { return m_state.level; }
        // is enabled
        bool IsEnabled() const noexcept { return !m_oStyle.state.disabled; }
        // is disabled
        bool IsDisabled() const noexcept { return m_oStyle.state.disabled; }
        // is visible
        bool IsVisible() const noexcept { return m_oStyle.state.visible; }
        // set hidden
        void SetHidden(bool hidden) noexcept { this->SetVisible(!hidden); }
        // get size
        auto GetSize() const noexcept { return m_oBox.size; }
        // get max size
        auto GetMaxSize() const noexcept { return m_oStyle.maxsize; }
        // get min size
        auto GetMinSize() const noexcept { return m_oStyle.minsize; }
        // specify a min size
        void SpecifyMinSize(Size2F size) noexcept;
        // specify a min content size
        void SpecifyMinContectSize(Size2F size) noexcept;
        // specify a max size
        void SpecifyMaxSize(Size2F size) noexcept;
        // is vaild in layout?
        bool IsVaildInLayout() const noexcept;
    public:
        // get style classes
        auto&GetStyleClasses() const noexcept { return m_classesStyle; }
        // add style class
        void AddStyleClass(PodStringView<char>) noexcept;
        // remove style class
        void RemoveStyleClass(PodStringView<char>) noexcept;
    public:
        // map rect to window
        void MapToWindow(RectF& rect) const noexcept;
        // map rect to parent
        void MapToParent(RectF& rect) const noexcept;
        // map point to window
        void MapToWindow(Point2F& point) const noexcept;
        // map point to window
        void MapToParent(Point2F& point) const noexcept;
    protected:
        // init
        auto init() noexcept->Result;
        // add child
        void add_child(UIControl& child) noexcept;
        // invalidate rect of control
        void invalidate(const RectF* rect) noexcept;
        // remove child
        void remove_child(UIControl& child) noexcept;
        // add direct child(not pushed into children list)
        void add_direct_child(UIControl& child) noexcept;
    protected:
        // begin render
        void begin_render() const noexcept;
        // draw background color
        void draw_bkcolor() const noexcept;
        // draw background image
        void draw_bkimage() const noexcept;
        // draw border
        void draw_border() const noexcept;
        // delete renderer
        void delete_renderer() noexcept;
    protected:
        // id of control
        CUIConstShortString     m_id;
        // meta info of control
        const MetaControl*      m_pMetaInfo;
        // animation
        const ControlAnimation* m_pAnimation = nullptr;
        // style model
        Style                   m_oStyle;
        // box model
        Box                     m_oBox;
        // world transform: do mapping
        Matrix3X2F              m_mtWorld;
        // children offset
        Point2F                 m_ptChildOffset;
        // child-control head node
        Node                    m_oHead;
        // child-control tail node
        Node                    m_oTail;
        // parent
        UIControl*              m_pParent;
        // window
        CUIWindow*              m_pWindow = nullptr;
        // hovered child
        UIControl*              m_pHovered = nullptr;
        // style unique classes
        UniqueClasses           m_classesStyle;
    private:
        // bg renderer
        CUIRendererBackground*  m_pBgRender = nullptr;
    protected:
        // state
        CtrlState               m_state;
        // child count
        uint32_t                m_cChildrenCount = 0;
        // parent accessible data
        uint32_t                m_uData4Parent = 0;
        // window accessible data
        uint32_t                m_uData4Window = 0;
    public:
#ifdef LUI_USER_INIPTR_DATA
        // user int data, for user accessing
        std::intptr_t           user_data = 0;
#endif
#ifdef LUI_USER_STRING_DATA
        // user str data, for user accessing
        RegLoadMUIString        user_string;
#endif
#ifndef NDEBUG
        // debug name
        const char*     name_dbg = "";
#endif
    public:
        // end iterator
        auto end() ->Iterator<UIControl> { return{ static_cast<UIControl*>(&m_oTail) }; }
        // begin iterator
        auto begin() ->Iterator<UIControl> { return{ static_cast<UIControl*>(m_oHead.next) }; }
        // rend iterator
        auto rend() ->ReverseIterator<UIControl> { return{ static_cast<UIControl*>(&m_oHead) }; }
        // rbegin iterator
        auto rbegin() ->ReverseIterator<UIControl> { return{ static_cast<UIControl*>(m_oTail.prev) }; }
        // const end iterator
        auto end() const ->Iterator<const UIControl> { return{ static_cast<const UIControl*>(&m_oTail) }; }
        // begin iterator
        auto begin() const->Iterator<const UIControl> { return{ static_cast<const UIControl*>(m_oHead.next) }; }
        // rend iterator
        auto rend() const->ReverseIterator<const UIControl> { return{ static_cast<const UIControl*>(&m_oHead) }; }
        // rbegin iterator
        auto rbegin() const->ReverseIterator<const UIControl> { return{ static_cast<const UIControl*>(m_oTail.prev) }; }
    protected:
        // remove from update list
        void remove_from_update_list() { m_state.in_update_list = false; }
        // add into update list
        void add_into_update_list() { m_state.in_update_list = true; }
        // is inited?
        bool is_inited() const noexcept { return m_state.inited; }
        // is size changed?
        bool is_size_changed() const noexcept { return m_state.dirty; }
        // size change handled
        void size_change_handled() noexcept { m_state.dirty = false; }
        // is in update list?
        bool is_in_update_list() const noexcept { return m_state.in_update_list; }
        // mark child world changed
        static void mark_child_world_changed(UIControl& c) noexcept { c.m_state.world_changed = true; }
        // resize child
        static void resize_child(UIControl& child, Size2F size) noexcept;
        // set child fixed attachment
        static void set_child_fixed_attachment(UIControl& child) noexcept {
            child.m_state.attachment = Attachment_Fixed;
        }
    public: // do not use those function in your code
        // set align
        void SetAlign_test(AttributeAlign align) noexcept { m_oStyle.align = align; }
        // set flex
        void SetFlex_test(float f) noexcept { m_oStyle.flex = f; }
        // set fixed width
        void SetFixedWidth_test(float f) noexcept {
            m_oBox.size.width = f;
            m_oStyle.maxsize.width = f;
            m_oStyle.minsize.width = f;
        }
        // set fixed height
        void SetFixedHeight_test(float f) noexcept {
            m_oBox.size.height = f;
            m_oStyle.maxsize.height = f;
            m_oStyle.minsize.height = f;
        }
        // set border
        void SetBorder_test(const RectF& b) noexcept {
            m_oBox.border = b;
            m_state.world_changed = true;
            this->NeedUpdate();
            this->NeedRelayout();
        }
    };
    // get meta info
    template<typename T> const MetaControl& GetMetaInfo() noexcept;
    // longui type cast
    template<typename T, typename U> inline T* longui_cast(U* ptr) noexcept {
#ifdef NDEBUG
        ptr->AssertCast(GetMetaInfo<T>());
#endif
        return static_cast<T>(ptr);
    }
    // longui safe cast
    template<typename T, typename U> inline T* uisafe_cast(U* ptr) noexcept {
        return ptr->SafeCastTo(GetMetaInfo<T>());
    }
    // decl meta control
#define LUI_DECLARE_METAINFO(C)\
    template<> inline const MetaControl& GetMetaInfo<C>() noexcept {\
        return C::s_meta;\
    }
    // get meta info for UIControl
    LUI_DECLARE_METAINFO(UIControl);
}

// move to top namespace
using UI::longui_cast;
// move to top namespace
using UI::uisafe_cast;

