﻿#pragma once

#include "ui_box_layout.h"

// ui namespace
namespace UI {
    // private menuitem class
    struct PrivateMenuItem;
    // menuitem
    class UIMenuItem : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend PrivateMenuItem;
        // init menuitem
        void init_menuitem() noexcept;
    protected:
        // ctor
        UIMenuItem(UIControl* parent, const MetaControl& ) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuItem() noexcept;
        // ctor
        UIMenuItem(UIControl* parent = nullptr) noexcept : UIMenuItem(parent, UIMenuItem::s_meta) {}
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    public:
        // render
        void Render() const noexcept override;
    private:
        // private data
        PrivateMenuItem*    m_private = nullptr;
    };
    // get meta info for UIMenuItem
    LUI_DECLARE_METAINFO(UIMenuItem);
}