﻿#pragma once
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include "ui_basic_type.h"
#include "../graphics/ui_graphics_decl.h"

// ui namespace
namespace UI {
    // priavte resmgr
    struct PrivateResMgr;
    // config
    struct IUIConfigure;
    // UI Window Manager
    class CUIResMgr {
        // my friend
        friend PrivateResMgr;
        // screen
        struct IScreen;
    public:
        // get graphics factory
        auto&RefGraphicsFactory() noexcept { return *m_pGraphicsFactory; }
        // get 3d device
        auto&Ref3DDevice() noexcept { return *m_p3DDevice; }
        // get 2d renderer
        auto&Ref2DRenderer() noexcept { return *m_p2DRenderer; }
    protected:
        // graphics factory
        I::FactoryGraphics*     m_pGraphicsFactory = nullptr;
        // 3d device
        I::Device3D*            m_p3DDevice = nullptr;
        // 3d renderer
        I::Renderer3D*          m_p3DRenderer = nullptr;
        // 2d renderer
        I::Renderer2D*          m_p2DRenderer = nullptr;
        // main screen
        IScreen*                m_pMainScreen = nullptr;
    private:
        // private data
        void*                   m_private[1];
        // PrivateResMgr data
        auto&rm() noexcept { return *reinterpret_cast<PrivateResMgr*>(m_private); }
        // release device
        void release_device() noexcept;
    protected:
        // recreate
        auto recreate(IUIConfigure*) noexcept->Result;
        // ctor
        CUIResMgr(Result& hr) noexcept;
        // ctor
        CUIResMgr(const CUIResMgr&) noexcept = delete;
        // ctor
        CUIResMgr(CUIResMgr&&) noexcept = delete;
        // dtor
        ~CUIResMgr() noexcept;
    };
}
