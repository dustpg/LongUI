﻿#pragma once
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// debug
#include "../debugger/ui_debug.h"
// locker
#include "../thread/ui_locker.h"
// config
#include "../interface/ui_interface.h"
// window manager
#include "ui_window_manager.h"
// string view
#include "ui_string_view.h"
// ostype
#include "../util/ui_ostype.h"
// type
#include <type_traits>

// longui manager
#define UIManager (UI::CUIManager::GetInstance())

// ui namespace
namespace UI {
    // detail namespace
    namespace detail { 
        // original local name length, LOCALE_NAME_MAX_LENGTH = 85
        enum { olnl = 86 };
        // private data for manager
        template<size_t> struct private_manager;
        // 32bit
        template<> struct private_manager<4> { enum { size = 612, align = 4 }; };
        // 32bit
        template<> struct private_manager<8> { enum { size = 8, align = 8 }; };
    }
    // private
    struct PrivateManager;
    // longui ui-manager
    class CUIManager final 
        : public CUIDebug/*, public CUIResMgr*/, public CUIWndMgr {
    public:
        // time capsules
        //using TimeCapsules = POD::Vector<CUITimeCapsule*>;
        // time capsule call
        //using TimeCapsuleCall = CUITimeCapsule::TimeCallBack;
        // flag
        using ConfigFlag = IUIConfigure::ConfigureFlag;
        // get instance
        static auto GetInstance() noexcept->CUIManager&;
        // initialize
        auto Initialize(IUIConfigure* config) noexcept ->Result;
        // initialize: TODO: default config
        auto Initialize() noexcept { return this->Initialize(nullptr); }
        // uninitialize
        void Uninitialize() noexcept;
    public:
        // get unique style class
        auto GetUniqueStyleClass(U8View pair) noexcept->const char*;
        // get unique element name
        auto GetUniqueElementName(U8View pair) noexcept->const char*;
    public:
        // get delta time for ui
        auto GetDeltaTime() const noexcept { return m_fDeltaTime; }
        // get runed time in ms
        auto GetRunedTime() const noexcept { return m_cNowTick - m_cStartTick; }
        // lock data
        auto DataLock()   noexcept { return m_uiDataLocker.Lock(); }
        // unlock data
        auto DataUnlock() noexcept { return m_uiDataLocker.Unlock(); }
        // lock rendering
        auto DxgiLock()   noexcept { return m_uiDxgiLocker.Lock(); }
        // unlock rendering
        auto DxgiUnlock() noexcept { return m_uiDxgiLocker.Unlock(); }
    public:
        // exit longui main loop
        void Exit() noexcept;
        // call this on kill focus to manage input
        void OnKillFocus() noexcept;
        // show error with result code
        bool ShowError(Result hr, const wchar_t* str_b = nullptr) noexcept;
        // show error with string
        bool ShowError(const wchar_t* str, const wchar_t* str_b = nullptr) noexcept { 
            return this->configure.ShowError(str, str_b); 
        }
    private:
        // ctor
        CUIManager(IUIConfigure* config) noexcept;
        // ctor
        CUIManager(const CUIManager&) noexcept = delete;
        // ctor
        CUIManager(CUIManager&&) noexcept = delete;
        // dtor
        ~CUIManager() noexcept;
    public:
        // script 脚本
        IUIScript&              script;
        // config
        IUIConfigure&           configure;
        // flag for configure
        ConfigFlag      const   flag;
    private:
        // delta time in sec.
        float                   m_fDeltaTime = 0.f;
        // app start tick
        uint32_t                m_cStartTick = 0;
        // app start tick
        uint32_t                m_cNowTick = 0;
        // tool window
        HWND                    m_hToolWnd = nullptr;
        // data locker
        CUILocker               m_uiDataLocker;
        // rendering locker
        CUILocker               m_uiDxgiLocker;
    protected:
        // private manager
        auto&pm() noexcept { return reinterpret_cast<PrivateManager&>(m_private); }
        // private data
        std::aligned_storage<
            detail::private_manager<sizeof(void*)>::size,
            detail::private_manager<sizeof(void*)>::align
        >::type                 m_private;
        // local name
        wchar_t                 m_szLocaleName[detail::olnl];
    };
    // auto data locker
    class CUIDataAutoLocker {
    public:
        // ctor
        CUIDataAutoLocker() noexcept { CUIManager::GetInstance().DataLock(); }
        // dtor
        ~CUIDataAutoLocker() noexcept { CUIManager::GetInstance().DataUnlock(); }
    };
    // auto dxgi(rendering) locker
    class CUIDxgiAutoLocker {
    public:
        // ctor
        CUIDxgiAutoLocker() noexcept { CUIManager::GetInstance().DxgiLock(); }
        // dtor
        ~CUIDxgiAutoLocker() noexcept { CUIManager::GetInstance().DxgiUnlock(); }
    };
}


// helper marco
#define UIManager_DWriteFactory (UIManager.RefDWriteFactory())
#define UIManager_RenderTarget  (UIManager.RefRenderTarget())
#define UIManager_DXGIFactory   (UIManager.RefDXGIFactory())
#define UIManager_DXGIAdapter   (UIManager.RefDXGIAdapter())
#define UIManager_D3DContext    (UIManager.RefD3DContext())
#define UIManager_DXGIDevice    (UIManager.RefDXGIDevice())
#define UIManager_D2DFactory    (UIManager.RefD2DFactory())
#define UIManager_D3DDevice     (UIManager.RefD3DDevice())
#define UIManager_D2DDevice     (UIManager.RefD2DDevice())
