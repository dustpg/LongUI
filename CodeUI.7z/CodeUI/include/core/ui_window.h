﻿#pragma once

#include "ui_basic_type.h"
#include "ui_node.h"
#include "ui_object.h"
#include "../util/ui_ostype.h"

namespace UI {
    // control
    class UIControl;
    // private data for window
    class PrivateWindow;
    // window manager
    class CUIWndMgr;
    /// <summary>
    /// window base class
    /// </summary>
    class CUIWindow final : public CUISmallObject, protected Node {
        // friend class
        friend class UIViewport;
        // friend class
        friend class CUIWndMgr;
        // show type
        enum TypeShow : int32_t {
            Show_Hide   = 0,
            Show_Show   = 1,
            Show_Min    = 2,
            Show_Max    = 3,
            Show_Restore= 9,
        };
        // show window
        void show_window(TypeShow) noexcept;
    public:
        // hide the window
        void HideWindow() noexcept { this->show_window(Show_Hide); }
        // show the window
        void ShowWindow() noexcept { this->show_window(Show_Show); }
        // min the window
        void MinWindow() noexcept { this->show_window(Show_Min); }
        // max the window
        void MaxWindow() noexcept { this->show_window(Show_Max); }
        // restore the window
        void RestoreWindow() noexcept { this->show_window(Show_Restore); }
    public:
        // active window

        // set title name
        void SetTitleName(const wchar_t*) noexcept;
        // set pos of window
        void SetPos(Point2L pos) noexcept;
        // get pos of window
        auto GetPos() const noexcept->Point2L;
    public:
        // control disattached[null this ptr acceptable]
        void ControlDisattached(UIControl& ctrl) noexcept;
        // set captured control
        void SetCapture(UIControl& ctrl) noexcept;
        // release captured control
        void ReleaseCapture(UIControl& ctrl) noexcept;
        // set focus of control,
        bool SetFocus(UIControl& ctrl) noexcept;
        // kill focus of control,
        void KillFocus(UIControl& ctrl) noexcept;
    public:
        // set control world changed
        void SetControlWorldChanged(UIControl&) noexcept;
        // render
        auto Render() const noexcept->Result;
        // get viewport
        auto RefViewport() noexcept ->UIViewport&;
        // get window handle
        HWND GetHwnd() const { return m_hwnd; }
        // is top level window
        bool IsTopLevel() const noexcept { return !m_parent; }
        // is inline window
        bool IsInlineWindow() const noexcept { return !IsTopLevel(); }
    protected:
        // recreate
        auto recreate() noexcept->Result;
        // ctor
        CUIWindow(CUIWindow* parent = nullptr) noexcept;
        // no copy
        CUIWindow(const CUIWindow&) noexcept = delete;
        // dtor
        ~CUIWindow() noexcept;
    protected:
        // window handle
        HWND                m_hwnd = nullptr;
        // parent window
        CUIWindow*          m_parent = nullptr;
        // topest world changed control
        UIControl*          m_pTopestWcc = nullptr;
        // state: under "minsize changed" list
        bool                m_bMinsizeList = false;
        // states
        bool                m_unused[sizeof(void*)-1];
    private:
        // private data
        PrivateWindow*      m_private = nullptr;
    };
}