﻿#pragma once

#include "ui_basic_type.h"
#include "ui_node.h"
#include "ui_object.h"
#include "../util/ui_ostype.h"

namespace UI {
    // private data for window
    class PrivateWindow;
    /// <summary>
    /// window base class
    /// </summary>
    class CUIWindow final : public CUIObject, protected Node {
        // friend class
        friend class UIViewport;
    public:
        // get viewport
        auto GetViewport() noexcept ->UIViewport&;
        // get window handle
        HWND GetHwnd() const { return m_hwnd; }
        // is top level window
        bool IsTopLevel() const noexcept { return !m_parent; }
        // is inline window
        bool IsInlineWindow() const noexcept { return !IsTopLevel(); }
    protected:
        // ctor
        CUIWindow(CUIWindow* parent = nullptr) noexcept;
        // dtor
        ~CUIWindow() noexcept;
    public:
        // set pos of window
        void SetPos(Point2L pos) noexcept;
        // get pos of window
        auto GetPos() const noexcept->Point2L;
    protected:
        // window handle
        HWND                m_hwnd = nullptr;
        // parent window
        CUIWindow*          m_parent = nullptr;
    private:
        // private data
        PrivateWindow*      m_private = nullptr;
    };
}