﻿#pragma once
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// basic type
#include "ui_basic_type.h"
// core type
#include "ui_core_type.h"
// time meter
#include "../util/ui_time_meter.h"
// pod::vector
#include "../container/pod_vector.h" 
// style
//#include <type_traits>

// ui namespace
namespace UI {
    // basic dpi
    enum : uint32_t { BASIC_DPI = 96, };
    // priavte wndmgr
    struct PrivateWndMgr;
    // detail namespace
    /*namespace detail {
        // private data for manager
        template<size_t> struct private_manager;
        // 32bit
        template<> struct private_manager<4> { enum { size = 564, align = 4 }; };
        // 32bit
        template<> struct private_manager<8> { enum { size = 8, align = 8 }; };
    }*/
    // UI Window Manager
    class CUIWndMgr {
        // friend
        friend CUIWindow;
        // windows
        using WindowVector = POD::Vector<CUIWindow*>;
    public:
        // get main dpi x
        auto GetMainDpiX() const noexcept { return m_uMainDpiX; }
        // get main dpi y
        auto GetMainDpiY() const noexcept { return m_uMainDpiY; }
        // add system window
        void AddWindow(CUIWindow&) noexcept;
        // remove system window
        void RemoveWindow(CUIWindow&) noexcept;
    protected:
    protected:
        // high time-meter
        CUITimeMeterH           m_uiTimeMeter;
        // main monitor dpi x
        uint16_t                m_uMainDpiX = 96;
        // main monitor dpi y
        uint16_t                m_uMainDpiY = 96;
        // ununsed
        uint32_t                m_dwDisplayFrequency = 0;
        // vsync count
        uint32_t                m_dwWaitVSCount = 0;
        // vsync start time
        uint32_t                m_dwWaitVSStartTime = 0;
        // windows list
        WindowVector            m_vWindows;
    private:
    protected:
        // initialize
        auto init() noexcept ->Result;
        // uninitialize
        void uninit() noexcept;
        // refresh display frequency
        void refresh_display_frequency() noexcept;
        // ctor
        CUIWndMgr() noexcept;
        // ctor
        CUIWndMgr(const CUIWndMgr&) noexcept = delete;
        // ctor
        CUIWndMgr(CUIWndMgr&&) noexcept = delete;
        // dtor
        ~CUIWndMgr() noexcept;
    };
}
