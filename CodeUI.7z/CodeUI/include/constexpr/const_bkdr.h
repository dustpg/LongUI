﻿#pragma once
#include <cstdint>
#include "../util/ui_unimacro.h"

// ui namespace
namespace UI {
    // detail namespace
    namespace detail {
        template<uint32_t SEED>
        constexpr uint32_t const_bkdr(uint32_t hash, const char* str) noexcept {
            return *str ? const_bkdr<SEED>(hash * SEED + (*str), str + 1) : hash;
        }
    }
    // Typical BKDR hash function
    constexpr uint32_t inline TypicalBKDR(const char* str) noexcept {
        return detail::const_bkdr<131>(0, str);
    }
}