﻿#pragma once

#include "ui_ssvalue_list.h"
#include "ui_attribute.h"
#include "../core/ui_color.h"

namespace UI {
    /// <summary>
    /// atring attribute table
    /// </summary>
    struct StrAttr {

    };
}