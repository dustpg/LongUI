﻿#pragma once

// c++
#include <cstdint>

namespace UI {
    // typeof StyleState
    enum class StyleStateType : uint8_t {
        Type_None = 0,
        Type_OddIndex,
        Type_Selected,
        Type_Defualt,
        Type_Disabled,
        Type_Hover,
        Type_Active,
        Type_Focus,
        Type_Checked,
        Type_Indeterminate,
    };
    // state change
    struct StyleStateTypeChange { StyleStateType type; bool change; };
    // style state
    struct alignas(uint32_t) StyleState {
        // ctor
        void Init() noexcept;
        // change, return true if changed
        bool Change(StyleStateTypeChange) noexcept;
        // none flag, index 0
        bool        none        : 1;
        // ui-odd index
        bool        odd_index   : 1;
        // ui-selected
        bool        selected    : 1;
        // [enter to trigger] defualt command control
        bool        default_    : 1;
        // disable
        bool        disabled    : 1;
        // hover
        bool        hover       : 1;
        // active, higher than hover
        bool        active      : 1;
        // [space to trigger] focus
        bool        focus       : 1;
        // checked
        bool        checked     : 1;
        // indeterminate, higher than checked
        bool        indeterminate : 1;
    };
}