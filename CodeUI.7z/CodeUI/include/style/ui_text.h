﻿#pragma once

// ui
#include "../core/ui_color.h"
#include "../text/ui_ctl_arg.h"

// ui namepsace
namespace UI {
    // style.text
    struct StyleText {
        // color
        ColorF          color;
    };
    // style.text/font
    struct TextFont {
        // text
        StyleText       text;
        // font
        FontArg         font;
    };
}