﻿#pragma once

#include "../core/ui_basic_type.h"
#include "ui_ssvalue.h"
// text
#include "../text/ui_ctl_arg.h"

namespace UI {
    // Box Model
    struct Box {
        // visible rect[world border edge]
        RectF       visible;
        // box position
        Point2F     pos;
        // box rect
        Size2F      size;
        // margin
        RectF       margin;
        // border
        RectF       border;
        // padding
        RectF       padding;
        // ctor
        void Init() noexcept;
        // get Non-content rect
        auto GetNonContect() const noexcept { RectF rc; GetNonContect(rc); return rc; }
        // get margin edge
        auto GetMarginEdge() const noexcept { RectF rc; GetMarginEdge(rc); return rc; }
        // get border edge
        auto GetBorderEdge() const noexcept { RectF rc; GetBorderEdge(rc); return rc; }
        // get padding edge
        auto GetPaddingEdge() const noexcept { RectF rc; GetPaddingEdge(rc); return rc; }
        // get content edge
        auto GetContentEdge() const noexcept { RectF rc; GetContentEdge(rc); return rc; }
        // get contect size
        auto GetContentSize() const noexcept->Size2F;
        // get Non-content rect
        void GetNonContect(RectF&) const noexcept;
        // get margin edge
        void GetMarginEdge(RectF&) const noexcept;
        // get border edge
        void GetBorderEdge(RectF&) const noexcept;
        // get padding edge
        void GetPaddingEdge(RectF&) const noexcept;
        // get content edge
        void GetContentEdge(RectF&) const noexcept;
    };
    // style state
    struct alignas(sizeof(uint32_t)) StyleState {
        // ctor
        void Init() noexcept;
        // visible
        bool        visible : 1;
        // focusable
        bool        focusable : 1;
        // disable
        bool        disabled : 1;
        // hover
        bool        hover : 1;
        // active, higher than hover
        bool        active : 1;
        // focus
        bool        focus : 1;
        // checked
        bool        checked : 1;
        // indeterminate, higher than checked
        bool        indeterminate : 1;
        // unused
        char unused_[2];
    };
    // Style model
    struct Style {
        // ctor
        Style() noexcept;
        // dtor
        ~Style() noexcept;
        // state
        StyleState      state;
        // flex
        float           flex;
        // specified min size 
        Size2F          minsize_sp;
        // min size
        Size2F          minsize;
        // font
        FontArg         font;
        // max size
        Size2F          maxsize;
        // fixed style
        SSBlocks        fixed;
    };
}