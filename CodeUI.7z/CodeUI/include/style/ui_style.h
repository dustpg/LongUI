﻿#pragma once

// ui
#include "ui_ssvalue.h"
#include "ui_attribute.h"
#include "ui_style_state.h"
#include "../core/ui_basic_type.h"
// c++
#include <cassert>

namespace UI {
    // Box Model
    struct Box {
        // visible rect[world border edge]
        RectF       visible;
        // box position
        Point2F     pos;
        // box rect
        Size2F      size;
        // margin
        RectF       margin;
        // border
        RectF       border;
        // padding
        RectF       padding;
        // ctor
        void Init() noexcept;
        // get Non-content rect
        auto GetNonContect() const noexcept { RectF rc; GetNonContect(rc); return rc; }
        // get margin edge
        auto GetMarginEdge() const noexcept { RectF rc; GetMarginEdge(rc); return rc; }
        // get border edge
        auto GetBorderEdge() const noexcept { RectF rc; GetBorderEdge(rc); return rc; }
        // get padding edge
        auto GetPaddingEdge() const noexcept { RectF rc; GetPaddingEdge(rc); return rc; }
        // get content edge
        auto GetContentEdge() const noexcept { RectF rc; GetContentEdge(rc); return rc; }
        // get contect size
        auto GetContentSize() const noexcept->Size2F;
        // get border size
        auto GetBorderSize() const noexcept->Size2F;
        // get contect pos
        auto GetContentPos() const noexcept->Point2F;
        // get Non-content rect
        void GetNonContect(RectF&) const noexcept;
        // get margin edge
        void GetMarginEdge(RectF&) const noexcept;
        // get border edge
        void GetBorderEdge(RectF&) const noexcept;
        // get padding edge
        void GetPaddingEdge(RectF&) const noexcept;
        // get content edge
        void GetContentEdge(RectF&) const noexcept;
    };
    // text/font
    struct TextFont;
    // Style model
    struct Style {
        // get TextFont
        auto GetTextFont() noexcept {
            assert(offset_tf && "bad offset");
            const auto ptr = reinterpret_cast<char*>(this) + offset_tf;
            return reinterpret_cast<TextFont*>(ptr);
        }
        // ctor
        Style() noexcept;
        // dtor
        ~Style() noexcept;
        // no copy
        Style(const Style&) noexcept = delete;
        // state
        StyleState          state;
        // pack
        AttributePack       pack;
        // align
        AttributeAlign      align;
        // appearance tpye
        AttributeAppearance appearance;
        // overflow-x
        AttributeOverflow   overflow_x : 4;
        // overflow-y
        AttributeOverflow   overflow_y : 4;
        // offset in byte for text font, set this if support text
        uint16_t            offset_tf;

        uint16_t            unused;
        // flex
        float               flex;
        // specified min size 
        Size2F              minsize_sp;
        // min size
        Size2F              minsize;
        // max size
        Size2F              maxsize;
        // fixed style
        SSBlocks            fixed;
    };
}