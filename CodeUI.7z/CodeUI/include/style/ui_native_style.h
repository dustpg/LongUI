﻿#pragma once

#include "ui_style.h"
#include "ui_attribute.h"
#include "../core/ui_basic_type.h"

// ui namespace
namespace UI {
    // sub element type
    enum class SubElement : uint8_t {

    };
    // sub element pos

    // adjust sub element rect in native style
    void NativeStyleAdjustSubElement(SubElement sube, RectF& rect) noexcept;
    // draw native style
    void NativeStyleDraw(
        AttributeAppearance appearance,
        StyleState state,
        float opacity,
        const RectF& rect
    ) noexcept;
    // init native style
    void NativeStyleInit(
        AttributeAppearance appearance,
        Style& style,
        Box&    Box
    ) noexcept;
}