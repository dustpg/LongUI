﻿#pragma once
#include <cstdint>
#include <cassert>



namespace UI {
    /// <summary>
    /// pseudo
    /// </summary>
    enum class PseudoType : uint8_t {
        Type_NoPseudo = 0,
        Type_Disabled,
        Type_Active,
        Type_Hover,
        Type_Focus,
        Type_Checked,
        Type_Indeterminate,
    };
    /// <summary>
    /// repeat 
    /// </summary>
    enum AttributeRepeat : uint8_t {
        Repeat_Repeat = 0,
        Repeat_RepeatX,
        Repeat_RepeatY,
        Repeat_NoRepeat,
        REPEAT_COUNT,
    };
    /// <summary>
    /// repeat for image
    /// </summary>
    enum AttributeImageRepeat : uint8_t {
        IRepeat_Stretch = 0,
        IRepeat_Repeat,
        IRepeat_Round,
        IRepeat_Space,
    };
    /// <summary>
    /// aligned box 
    /// </summary>
    enum AttributeBox : uint8_t {
        Box_BorderBox = 0,
        Box_PaddingBox,
        Box_ContentBox,
        BOX_COUNT,
    };
    /// <summary>
    /// border style 
    /// </summary>
    enum AttributeBStyle : uint8_t {
        Style_Node = 0,
        Style_Hidden,
        Style_Dotted,
        Style_Dashed,
        Style_Solid,
        Style_Double,
        Style_Groove,
        Style_Ridge,
        Style_Inset,
        Style_OutSet,
    };
    /// <summary>
    /// unit of value
    /// </summary>
    enum class ValueUnit : uint32_t {
        // unknown
        Unit_Unknown = 0,
        // auto
        Unit_Auto,
        // argb
        Unit_ARGB,
        // pixels
        Unit_Pixels,
        // percentage%
        Unit_Percentage,
    };
    /// <summary>
    /// type of value
    /// </summary>
    enum class ValueType : uint32_t {
        // unknown
        Type_Unknown = 0,

        // [Position] cursor 
        Type_PositionCursor,
        // [Position] left 
        Type_PositionLeft,
        // [Position] right 
        Type_PositionRight,
        // [Position] overflow
        Type_PositionOverflow,
        // [Position] z-index
        Type_PositionZindex,

        // [Margin] top
        Type_MarginTop,
        // [Margin] right
        Type_MarginRight,
        // [Margin] bottom
        Type_MarginBottom,
        // [Margin] left
        Type_MarginLeft,

        // [Padding] top
        Type_PaddingTop,
        // [Padding] right
        Type_PaddingRight,
        // [Padding] bottom
        Type_PaddingBottom,
        // [Padding] left
        Type_PaddingLeft,

        // [Border] top
        Type_BorderTop,
        // [Border] right
        Type_BorderRight,
        // [Border] bottom
        Type_BorderBottom,
        // [Border] left
        Type_BorderLeft,
        // [Border] top-color
        Type_BorderTopColor,
        // [Border] right-color
        Type_BorderRightColor,
        // [Border] bottom-color
        Type_BorderBottomColor,
        // [Border] left-color
        Type_BorderLeftColor,
        // [Border] top-width
        Type_BorderTopWidth,
        // [Border] right-width
        Type_BorderRightWidth,
        // [Border] bottom-width
        Type_BorderBottomWidth,
        // [Border] left-width
        Type_BorderLeftWidth,

        // [Border] top-style
        Type_BorderTopStyle,
        // [Border] right-style
        Type_BorderRightStyle,
        // [Border] bottom-style
        Type_BorderBottomStyle,
        // [Border] left-style
        Type_BorderLeftStyle,
        // [Border] top-left-radius
        Type_BorderTopLeftRadius,
        // [Border] top-right-radius
        Type_BorderTopRightRadius,
        // [Border] bottom-left-radius
        Type_BorderBottomLeftRadius,
        // [Border] bottom-right-radius
        Type_BorderBottomRightRadius,
        // [Border] image-source
        Type_BorderImageSource,
        // [Border] image-slice
        //Type_BorderBottomRightRadius,
        // [Border] image-width
        //Type_BorderLeftWidth,
        
        // [Background] color
        Type_BackgroundColor,
        // [Background] image
        Type_BackgroundImage,
        // [Background] attachment
        Type_BackgroundAttachment,
        // [Background] repeat
        Type_BackgroundRepeat,
        // [Background] clip
        Type_BackgroundClip,
        // [Background] origin 
        Type_BackgroundOrigin,
    };
}



// selector
namespace UI {

}