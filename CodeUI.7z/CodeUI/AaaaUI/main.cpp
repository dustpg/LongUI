﻿#include <core/ui_string.h>
#include <core/ui_manager.h>
#include <core/ui_malloc.h>
#include <debugger/ui_debug.h>
#include <control/ui_viewport.h>

#include <Windows.h>
void main_inited();
#pragma comment(lib, "CodeUI")

struct MemoryLeakDetector {
#ifndef NDEBUG
    // ctor
    MemoryLeakDetector() {
        ::_CrtMemCheckpoint(memstate + 0);
        constexpr int sa = sizeof(_CrtMemState);
    }
    // dtor
    ~MemoryLeakDetector() {
        ::_CrtMemCheckpoint(memstate + 1);
        if (::_CrtMemDifference(memstate + 2, memstate + 0, memstate + 1)) {
            ::_CrtDumpMemoryLeaks();
            assert(!"OOps! Memory leak detected");
        }
    }
    // mem state
    _CrtMemState memstate[3];
#else
    ~MemoryLeakDetector() noexcept {}
#endif
};

int CALLBACK WinMain(HINSTANCE, HINSTANCE, char*, int) {
    MemoryLeakDetector dtr;
    if (UIManager.Initialize()) {
        LUIDebug(Hint)
            << L"Battle Control Online..."
            << UI::endl;

        const auto ptr1 = UI::SmallAlloc(1024);
        const auto ptr2 = UI::SmallRealloc(ptr1, 2048);
        UI::SmallFree(ptr2);
        {
            UI::UIViewport viewport1;
            UI::UIViewport viewport2;
            viewport1.RefWindow().ShowWindow();
            viewport1.RefWindow().SetTitleName(L"viewport1");
            viewport2.RefWindow().ShowWindow();
            viewport2.RefWindow().SetTitleName(L"viewport2");
            main_inited();

            LUIDebug(Hint)
                << L"Battle Control Terminated."
                << UI::endl;
        }
        UIManager.Uninitialize();
    }
    else assert(!"error");
    return 0;
}

void main_inited() {
    UI::CUIString str;
    str.format(L"%f", 1.f);
    UI::POD::Vector<double> a = { 32.f };
    UIManager.MainLoop();
}
