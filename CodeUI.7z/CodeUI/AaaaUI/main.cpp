﻿#include <core/ui_string.h>
#include <core/ui_manager.h>
#include <core/ui_malloc.h>
#include <debugger/ui_debug.h>
#include <control/ui_viewport.h>
#include <graphics/ui_matrix3x2.h>

#include <container/nonpod_vector.h>

#include <vector>
#include <string>

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
void main_inited(UI::UIViewport&, int) noexcept;
void object_test() noexcept;

namespace UI { void NativeStyle() noexcept {}; }


#pragma comment(lib, "CodeUI")

struct MemoryLeakDetector {
#ifndef NDEBUG
    // mem state
    _CrtMemState memstate[3];
    // ctor
    MemoryLeakDetector() noexcept { ::_CrtMemCheckpoint(memstate + 0); }
    // dtor
    ~MemoryLeakDetector() noexcept {
        ::_CrtMemCheckpoint(memstate + 1);
        if (::_CrtMemDifference(memstate + 2, memstate + 0, memstate + 1)) {
            ::_CrtDumpMemoryLeaks();
            assert(!"OOps! Memory leak detected");
        }
    }
#else
    ~MemoryLeakDetector() noexcept {}
#endif
};

extern "C" int CALLBACK WinMain(HINSTANCE, HINSTANCE, char*, int) {
    MemoryLeakDetector dtr;
    if (UIManager.Initialize()) {
        LUIDebug(Hint) << "Battle Control Online..." << UI::endl;
        ::object_test();
        const auto ptr1 = UI::NormalAlloc(1024);
        const auto ptr2 = UI::NormalRealloc(ptr1, 2048);
        UI::NormalFree(ptr2);
        UI::NativeStyle();
        {
            UI::UIViewport viewport1;
            main_inited(viewport1, 2);
        }
        LUIDebug(Hint) << "Battle Control Terminated." << UI::endl;
        UIManager.Uninitialize();
    }
    else assert(!"error");
    return 0;
}

#include <core/ui_color_list.h>
#include <control/ui_checkbox.h>
#include <control/ui_textbox.h>
#include <control/ui_button.h>
#include <control/ui_spacer.h>
#include <control/ui_scale.h>
#include <control/ui_image.h>
#include <control/ui_label.h>
#include <control/ui_test.h>

UI::UIControl* vv;

#include <util/ui_lastsort.h>


void main_inited(UI::UIViewport& viewport, int switch_on) noexcept {
    vv = &viewport;
    auto& style = const_cast<UI::Style&>(viewport.GetStyle());
    style.overflow_y = UI::Overflow_Auto;
    {
        auto a = UI::Matrix::Matrix3x2F::Scale({ 2, 2 });
        auto b = UI::Matrix::Matrix3x2F::Translation({ 100, 100 });
        auto c = a * b;
        auto d = b * a;
        int bk = 9;
    }
    viewport.RefWindow().ShowWindow();
    viewport.RefWindow().SetTitleName(L"Window");
    //auto z = new(std::nothrow) UI::UIVBoxLayout;
    //set_root(z); z->user_data = reinterpret_cast<uintptr_t>(ptr);
    viewport.SetBgColor({ UI::RGBA_White });
    viewport.SetDebugName("root");
    UI::UISlider* slider = nullptr;
    auto add_spacer = [](UI::UIControl* p) noexcept {
        new(std::nothrow) UI::UISpacer{ p };
    };
    auto add_vbox = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIVBoxLayout{ p };
        c->SetBgColor({ color }); c->SetDebugName(name);
        return c;
    };
    auto add_btn = [](UI::UIControl* p, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIButton{ p };
        c->SetDebugName(name);
        return c;
    };
    auto add_ctrl = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIControl{ p };
        c->SetBgColor({ color }); c->SetDebugName(name);
        return c;
    };
    auto add_img= [](UI::UIControl* p, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIImage{ p };
        c->SetDebugName(name);
        return c;
    };
    auto add_slider = [](UI::UIControl* p, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIScale{ p };
        c->SetDebugName(name);
        return c;
    };
    auto add_label = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UILabel{ p };
        c->SetBgColor({ color }); 
        c->SetDebugName(name);
        return c;
    };
    auto add_txtbox = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UITextBox{ p };
        c->SetBgColor({ color });
        c->SetDebugName(name);
        return c;
    };
    auto add_checkbox = [](UI::UIControl* p, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UICheckBox{ p };
        c->SetDebugName(name);
        return c;
    };
    auto add_test = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
#ifdef NDEBUG
        auto c = new(std::nothrow) UI::UIControl{ p };
#else
        auto c = new(std::nothrow) UI::UITest{ p };
#endif
        c->SetBgColor({ color }); c->SetDebugName(name);
        return c;
    };
    switch (switch_on)
    {
    case 0:
    {
        auto vbox = new(std::nothrow) UI::UIVBoxLayout{ &viewport };
        vbox->SetDebugName("root-vbox");
        vbox->SetBgColor({ UI::RGBA_Cyan });
        //vbox->SetFlex_test(1.f);

        auto lbl1 = add_label(vbox, UI::RGBA_Red, "vbox-label1");
        lbl1->SetText(L"hello world!-x-");


        auto vbox2 = add_vbox(vbox, UI::RGBA_Cyan, "vbox-vbox2");

        auto vbox3 = add_vbox(vbox2, UI::RGBA_Cyan, "vbox2-vbox3");

        auto ctrl = add_ctrl(vbox3, UI::RGBA_Blue, "vbox3-ctrl");
        ctrl->SpecifyMinSize({ 0, 30 });
        break;
    }
    case 1:
        
    {
        auto vbox = new(std::nothrow) UI::UIVBoxLayout{ &viewport };
        vbox->SetDebugName("root-vbox");
        vbox->SetFlex_test(1.f);

        auto hbox1 = new(std::nothrow) UI::UIHBoxLayout{ vbox };
        hbox1->SetDebugName("vbox-hbox1");
        hbox1->SetFlex_test(1.f);
        // hbox1->SpecifyMinSize({ 640, 0 });
        {
            //hbox1->SetDebugName("hbox1")
            auto a = add_test(hbox1, UI::RGBA_Green, "hbox1-a");
            auto b = add_btn (hbox1, "hbox1-b");
            auto c = add_ctrl(hbox1, UI::RGBA_Blue,  "hbox1-c");

            a->SpecifyMinSize({ 50, 30 });
            b->SpecifyMinSize({ 100, 30 });
            c->SpecifyMinSize({ 200, 1000 });
            c->SetFlex_test(1.f);
        }
        //auto hbox2 = new(std::nothrow) UI::UIHBoxLayout{ vbox };
        //auto hbox3 = new(std::nothrow) UI::UIHBoxLayout{ vbox };

        
        //hbox2->Init(); hbox2->color = 0x00ffff;
        //hbox3->Init();
        break;
    }
    case 2:
    {
        auto box = new(std::nothrow) UI::UIHBoxLayout{ &viewport };
        box->SetDebugName("root-box");
        box->Set_test(UI::Align_Center);

        auto a = add_ctrl(box, UI::RGBA_Red, "box-a");
        a->SpecifyMinSize({ 20, 20 });

        auto b = add_btn(box, "box-b{btn}");
        b->AddGuiEventListener(b->_clicked(), [](UI::UIControl& ctrl) {
            auto& s = static_cast<UI::UIButton&>(ctrl);
            volatile auto value = s.GetText();
            return UI::Event_Accept;
        });
        b->SpecifyMinSize({ 0, 30 });
        b->SetFlex_test(1.f);

        auto c = add_ctrl(box, UI::RGBA_Red, "box-c");
        c->Set_test(UI::Appearance_ScrollBarButtonLeft);

        auto d = add_ctrl(box, UI::RGBA_Red, "box-d");
        d->Set_test(UI::Appearance_ScrollBarButtonDown);

        auto e = add_ctrl(box, UI::RGBA_Red, "box-e");
        e->Set_test(UI::Appearance_ScrollBarButtonRight);

        auto f = add_ctrl(box, UI::RGBA_Red, "box-f");
        f->Set_test(UI::Appearance_ScrollBarButtonUp);

        auto g = add_img(box, "box-g");
        g->Set_test(UI::Appearance_Radio);


        auto box2 = new(std::nothrow) UI::UIHBoxLayout{ &viewport };
        box2->SetDebugName("root-box2");
        //box2->Set_test(UI::Align_Center);

        auto h = add_slider(box2, "box2-h");
        h->AddGuiEventListener(h->_changed(), [](UI::UIControl& ctrl) {
            auto& s = static_cast<UI::UIScale&>(ctrl);
            volatile auto value = s.GetValue();
            return UI::Event_Accept;
        });
        slider = h;
        slider->SetValue(1.f);
        h->SetFlex_test(1.f);


        auto j = add_ctrl(box2, UI::RGBA_Red, "box-j");
        j->Set_test(UI::Appearance_ScrollBarButtonDown);

        auto box3 = new(std::nothrow) UI::UIHBoxLayout{ &viewport };
        box3->SetDebugName("root-box3");
        box3->SetFlex_test(1.f);

        auto tb = add_txtbox(box3, UI::RGBA_Cyan, "box-j");
        tb->SetFlex_test(1.f);
        //tb->Set_test(UI::Appearance_ScrollBarButtonDown);

        break;
    }
    case 3:
    {
        auto checkbox = add_checkbox(&viewport, "root-checkbox");
        break;
    }
    }






    UI::StyleState state;
    state.Init();
    int bk = 9;
    state.Change({ UI::StyleStateType::Type_Checked, true });
    bk = 9;;
    state.Change({ UI::StyleStateType::Type_Checked, false });
    bk = 9;

    UI::CUIString str;
    str.format(L"%f%ls", 1.f, L"𪚥");
    UI::POD::Vector<double> a = { 32.f, 16.f, 8.f, 7.f };
    auto longx4x4 = UI::CUIString::FromUtf8(u8"𪚥𪚥𪚥𪚥");
    longx4x4 += longx4x4;
    auto c = UI::CUIStringEx::FromUtf8(u8"𪚥𪚥𪚥𪚥");
    //UI::CUIStringU8 str;
    //auto len2 = U::GetBufferLength<U::UTF16>(str.view());
    //auto len3 = U::GetBufferLength<U::UTF32>(str.view());
    UIManager.MainLoop();
}

#include <chrono>

void object_test() noexcept {
    UI::CUIStringEx c = L"壕";
    UI::CUIString aaaa;
    UI::NonPOD::Vector<UI::CUIStringEx> a, b;
    a.reserve(10);
    a.emplace_back_ex()->assign(L"SAD");
    a.emplace_back_ex()->assign(L"POI");
    a.emplace_back_ex()->assign(L"OK!");
    a.push_back(c);
    a.pop_back();
    auto& str = a[1];
    for (int i = 0; i != 40; ++i)
        a[2].append(L"喔喔窝");
    a.erase(1);
    str.append(L" DESU!");
    str.shrink_to_fit();
    //a.emplace_ex(2, 2)->assign(L"OK!");
    b = a;
    b = std::move(a);
    b.resize(9);

    std::free(std::realloc(std::malloc(100), 128));
    volatile int bk = 9;
}