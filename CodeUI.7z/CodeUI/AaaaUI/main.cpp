﻿#include <core/ui_string.h>
#include <core/ui_manager.h>
#include <core/ui_malloc.h>
#include <debugger/ui_debug.h>
#include <control/ui_viewport.h>

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
void main_inited(UI::UIViewport&) noexcept;

namespace UI { void NativeStyle() noexcept {}; }


#pragma comment(lib, "CodeUI")

struct MemoryLeakDetector {
#ifndef NDEBUG
    // mem state
    _CrtMemState memstate[3];
    // ctor
    MemoryLeakDetector() noexcept { ::_CrtMemCheckpoint(memstate + 0); }
    // dtor
    ~MemoryLeakDetector() noexcept {
        ::_CrtMemCheckpoint(memstate + 1);
        if (::_CrtMemDifference(memstate + 2, memstate + 0, memstate + 1)) {
            ::_CrtDumpMemoryLeaks();
            assert(!"OOps! Memory leak detected");
        }
    }
#else
    ~MemoryLeakDetector() noexcept {}
#endif
};

int CALLBACK WinMain(HINSTANCE, HINSTANCE, char*, int) {
    MemoryLeakDetector dtr;
    if (UIManager.Initialize()) {
        LUIDebug(Hint) << "Battle Control Online..." << UI::endl;

        const auto ptr1 = UI::NormalAlloc(1024);
        const auto ptr2 = UI::NormalRealloc(ptr1, 2048);
        UI::NormalFree(ptr2);
        UI::NativeStyle();
        {
            UI::UIViewport viewport1;
            main_inited(viewport1);
        }
        LUIDebug(Hint) << "Battle Control Terminated." << UI::endl;
        UIManager.Uninitialize();
    }
    else assert(!"error");
    return 0;
}

#include <core/ui_color_list.h>
#include <control/ui_button.h>
#include <control/ui_spacer.h>
#include <control/ui_label.h>
#include <control/ui_test.h>

UI::UIControl* vv;

#include <util/ui_lastsort.h>


void main_inited(UI::UIViewport& viewport) noexcept {
    vv = &viewport;
    viewport.RefWindow().ShowWindow();
    viewport.RefWindow().SetTitleName(L"Window");
    //auto z = new(std::nothrow) UI::UIVBoxLayout;
    //set_root(z); z->user_data = reinterpret_cast<uintptr_t>(ptr);
    viewport.SetBgColor({ UI::RGBA_White });
    viewport.name_dbg = "root";
    auto add_spacer = [](UI::UIControl* p) noexcept {
        new(std::nothrow) UI::UISpacer{ p };
    };
    auto add_vbox = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIVBoxLayout{ p };
        c->SetBgColor({ color }); c->name_dbg = name;
        return c;
    };
    auto add_btn = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIButton{ p };
        c->SetBgColor({ color }); c->name_dbg = name;
        return c;
    };
    auto add_ctrl = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UIControl{ p };
        c->SetBgColor({ color }); c->name_dbg = name;
        return c;
    };
    auto add_label = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
        auto c = new(std::nothrow) UI::UILabel{ p };
        c->SetBgColor({ color }); 
        c->name_dbg = name;
        return c;
    };
    auto add_test = [](UI::UIControl* p, uint32_t color, const char* name) noexcept {
#ifdef NDEBUG
        auto c = new(std::nothrow) UI::UIControl{ p };
#else
        auto c = new(std::nothrow) UI::UITest{ p };
#endif
        c->SetBgColor({ color }); c->name_dbg = name;
        return c;
    };
    int switch_on = 2;
    switch (switch_on)
    {
    case 0:
    {
        auto vbox = new(std::nothrow) UI::UIVBoxLayout{ &viewport };
        vbox->name_dbg = "root-vbox";
        vbox->SetBgColor({ UI::RGBA_Cyan });
        //vbox->SetFlex_test(1.f);

        auto lbl1 = add_label(vbox, UI::RGBA_Red, "vbox-label1");
        lbl1->SetText(L"hello world!-x-");


        auto vbox2 = add_vbox(vbox, UI::RGBA_Cyan, "vbox-vbox2");

        auto vbox3 = add_vbox(vbox2, UI::RGBA_Cyan, "vbox2-vbox3");

        auto ctrl = add_ctrl(vbox3, UI::RGBA_Blue, "vbox3-ctrl");
        ctrl->SpecifyMinSize({ 0, 30 });
        break;
    }
    case 1:
        
    {
        auto vbox = new(std::nothrow) UI::UIVBoxLayout{ &viewport };
        vbox->name_dbg = "root-vbox";
        vbox->SetFlex_test(1.f);

        auto hbox1 = new(std::nothrow) UI::UIHBoxLayout{ vbox };
        hbox1->name_dbg = "vbox-hbox1";
        hbox1->SetFlex_test(1.f);
        // hbox1->SpecifyMinSize({ 640, 0 });
        {
            //hbox1->name_dbg = "hbox1";
            auto a = add_test(hbox1, UI::RGBA_Green, "hbox1-a");
            auto b = add_btn (hbox1, UI::RGBA_Cyan,  "hbox1-b");
            auto c = add_ctrl(hbox1, UI::RGBA_Blue,  "hbox1-c");

            a->SpecifyMinSize({ 50, 30 });
            b->SpecifyMinSize({ 100, 30 });
            c->SpecifyMinSize({ 200, 1000 });
            c->SetFlex_test(1.f);
        }
        //auto hbox2 = new(std::nothrow) UI::UIHBoxLayout{ vbox };
        //auto hbox3 = new(std::nothrow) UI::UIHBoxLayout{ vbox };

        
        //hbox2->Init(); hbox2->color = 0x00ffff;
        //hbox3->Init();
        break;
    }
    case 2:
    {
        auto box = new(std::nothrow) UI::UIHBoxLayout{ &viewport };
        box->name_dbg = "root-box";
        box->SetAlign_test(UI::Align_Center);
        auto a = add_ctrl(box, UI::RGBA_Red, "box-a");
        a->SpecifyMinSize({ 20, 20 });
        auto b = add_btn(box, UI::RGBA_Transparent, "box-b");
        b->SpecifyMinSize({ 0, 30 });
        b->SetFlex_test(1.f);
        break;
    }
    }






    UI::StyleState state;
    state.Init();
    int bk = 9;
    state.Change({ UI::StyleStateType::Type_Checked, true });
    bk = 9;;
    state.Change({ UI::StyleStateType::Type_Checked, false });
    bk = 9;;



    UI::CUIString str;
    str.format(L"%f%ls", 1.f, L"𪚥");
    UI::POD::Vector<double> a = { 32.f, 16.f, 8.f, 7.f };
    auto longx4x4 = UI::CUIString::FromUtf8(u8"𪚥𪚥𪚥𪚥");
    longx4x4 += longx4x4;
    auto c = UI::CUIStringWL::FromUtf8(u8"𪚥𪚥𪚥𪚥");
    //UI::CUIStringU8 str;
    //auto len2 = U::GetBufferLength<U::UTF16>(str.view());
    //auto len3 = U::GetBufferLength<U::UTF32>(str.view());
    UIManager.MainLoop();
}
