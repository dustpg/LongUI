﻿#include "tb_txtdoc.h"
#include <cassert>

/// <summary>
/// Initializes a new instance of the <see cref="CTBTextCell"/> class.
/// </summary>
/// <param name="doc">The document.</param>
RichTB::CTBTextCell::CTBTextCell(CTBTextDocument& doc) noexcept:m_document(doc) {
    sizeof(*this);
    m_bCRLF = true;
    m_bDirty = false;
    m_bBeginOfLine = false;
    m_bEndOfLine = false;
#ifndef NDEBUG
    m_bInLayout = false;
#endif
}


/// <summary>
/// Finalizes an instance of the <see cref="CTBTextCell"/> class.
/// </summary>
/// <returns></returns>
RichTB::CTBTextCell::~CTBTextCell() noexcept {

}

#ifndef NDEBUG
/// <summary>
/// [TB] the assert move eol.
/// </summary>
/// <param name="cell">The cell.</param>
/// <returns></returns>
void tb_assert_move_eol(RichTB::CTBTextCell& cell) noexcept {
    assert(!"UNTESTED");
    assert(!cell.IsLastCell());
    const auto next = static_cast<RichTB::CTBTextCell*>(cell.next);
    assert(cell.IsEOL() || next->IsLastCell());
}
#endif


/// <summary>
/// News the after this.
/// </summary>
/// <returns></returns>
auto RichTB::CTBTextCell::NewAfterThis() noexcept -> CTBTextCell* {
    // 创建新的对象
    if (auto node = new(std::nothrow) CTBTextCell{ m_document }) {
        // 添加到后面
        node->prev = this;
        node->next = this->next;
        this->next = node;
        return node;
    }
    // 内存不足
    return nullptr;
}

/// <summary>
/// Sleeps this instance.
/// </summary>
/// <returns></returns>
void RichTB::CTBTextCell::Sleep() noexcept {
    assert(m_pContent);
    auto& platform = m_document.platform;
    platform.DeleteContent(*m_pContent);
    m_pContent = nullptr;
}


/// <summary>
/// Awakes this instance.
/// </summary>
/// <param name="str">The string.</param>
/// <param name="len">The length.</param>
/// <returns></returns>
void RichTB::CTBTextCell::Awake(const char16_t* str, uint32_t len) noexcept {
    assert(!m_pContent);
    auto& platform = m_document.platform;
    auto& last = *m_pContent;
    m_pContent = platform.CreateContent(str, len, std::move(last));
    /* 
        TODO: 两种策略
        m_bDirty:
          是否需要重新布局, 获取新的测量数据
        m_pContent:
          是否需要创建内容, 重新布局, 但是不需要重新获取数据
    */
}

/// <summary>
/// Removes the text.
/// </summary>
/// <param name="range">The range.</param>
/// <returns>return <c>true</c> if CR/LF deleted</returns>
bool RichTB::CTBTextCell::RemoveText(TextRange range) noexcept {
    // 不允许删除0长度
    assert(range.length && "bad arg");
    assert(this->GetStringLen() > range.pos);
    assert(this->GetStringLen() >= range.pos + range.length);
    // 返回码
    bool rv = false;
    // 回车换行做为整体看待
    if (range.pos + range.length == this->GetStringLen()) {
        rv = this->IsEOL();
        // 只要把最后一个字符删了, 不管任何情况都不是EOL
        this->clear_eol();
        // 下一个也不会是BOL
        auto node = this->next;
        // 不是结尾的话
        if (node->next) {
            static_cast<CTBTextCell*>(node)->clear_bol();
        }
    }
    // 直接删完
    if (range.pos == 0 && range.length == this->GetStringLen()) {
        // 唯一的节点?
        if (this->IsFirstCell() && this->IsLastCell()) {
            // 不删除唯一的节点
        }
        // 直接删除节点
        else {
            assert(!"UNTESTED: rv");
            this->RemoveFromListOnly();
            delete this;
            return rv;
        }
    }
    // 仅删除文本
    this->RemoveTextOnly(range);
    return rv;
}


/// <summary>
/// Inserts the text.
/// </summary>
/// <param name="">The .</param>
/// <param name="view">The view.</param>
/// <returns></returns>
void RichTB::CTBTextCell::InsertText(uint32_t pos, U16View view) noexcept {
    // 不允许插入空字符
    assert(view.second != view.first);
    // 最后一个是 \r?
    if (view.second[-1] == '\r') {
        --view.second;
        // 只有一个\r就什么也不做
        if (view.second == view.first) return;
    }
    // 插入长度
    const auto len = view.second - view.first;
    // TODO: 错误处理
    try { m_text.insert(pos, view.first, len); } catch(...) {}
    // 标记为脏
    m_bDirty = true;
    // TODO: 字符个数 != 字符串长
    m_cCharCount += len;
}

/// <summary>
/// Removes the text only.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void RichTB::CTBTextCell::RemoveTextOnly(TextRange range) noexcept {
    assert(range.length + range.pos <= this->GetStringLen());
    // TODO: 错误处理
    try { m_text.erase(range.pos, range.length); } catch (...) {}
    // 标记为脏
    m_bDirty = true;
    // TODO: 字符个数 != 字符串长
    m_cCharCount -= range.length;
}


/// <summary>
/// Begins the layout.
/// </summary>
/// <returns></returns>
void RichTB::CTBTextCell::BeginLayout() noexcept {
#ifndef NDEBUG
    assert(m_bInLayout == false);
    m_bInLayout = true;
#endif
    // 居然不脏?!
    assert(m_bDirty);
    // 设置文本
    //auto& platform = m_document.platform;
    const uint32_t len = m_text.size() - (this->IsEOL() ? m_bCRLF + 1 : 0);
    this->Awake(m_text.c_str(), len);
}

/// <summary>
/// Ends the layout.
/// </summary>
/// <returns></returns>
void RichTB::CTBTextCell::EndLayout() noexcept {
#ifndef NDEBUG
    assert(m_bInLayout == true);
    m_bInLayout = false;
#endif
    assert(m_bDirty);
    assert(m_pContent);
    auto& platform = m_document.platform;
    const auto get_size = ITBTextPlatform::Event_GetSize;
    const auto get_base = ITBTextPlatform::Event_GetBaseline;
    // 获取大小
    platform.ContentEvent(*m_pContent, get_size, &m_size);
    // 获取基线偏移
    platform.ContentEvent(*m_pContent, get_base, &m_fBaseline);
    // 标记已经干净
    m_bDirty = false;
}


/// <summary>
/// Marks as eol.
/// </summary>
/// <returns></returns>
void RichTB::CTBTextCell::MarkAsEOL() noexcept {
    assert(IsEOL() == false && "already EOL");
    m_bEndOfLine = true;
    const int crlf = m_bCRLF;
    // 获取长度
    const auto index = this->GetStringLen();
    // 增加字符数量
    m_cCharCount += crlf + 1;
    // TODO: 错误处理
    try { m_text.resize(index + 2); } catch (...) {}
    // 添加换行符号
    if (crlf) m_text[index] = '\r';
    m_text[index + crlf] = '\n';
}