﻿#pragma once

#include <cstdint>

// RichTB namespace
namespace RichTB {
    // text cell
    class CTBTextCell;
    // text line data
    struct TextLineData {
        // y offset
        double          offset;
        // first cell
        CTBTextCell*    first;
        // last cell
        CTBTextCell*    last;
        // char count to here
        uint32_t        char_count;
        // string len to here
        uint32_t        string_len;
        // max item height
        float           max_height;

        // clear line data
        void Clear(const TextLineData& lastline) noexcept;
        // add cell
        void operator +=(CTBTextCell&) noexcept;
    };
    
}