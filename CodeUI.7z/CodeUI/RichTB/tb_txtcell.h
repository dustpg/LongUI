﻿#pragma once

#include <cstdint>
#include "tb_txtplat.h"

#include <string>


// RichTB namespace
namespace RichTB {
    // string
    using CTBString = std::u16string;
#ifdef NDEBUG
    enum { TEXT_CELL_NICE_LENGTH = 64, TEXT_CELL_NICE_MAX = 80 };
#else
    enum { TEXT_CELL_NICE_LENGTH = 10, TEXT_CELL_NICE_MAX = 20 };
#endif
    // text range
    struct TextRange { uint32_t pos, length; };
    // text content
    struct ITBTextContent;
    // text document
    class CTBTextDocument;
    // text cell
    class CTBTextCell : public CTBSmallObject, public Node {
        // friend class
        //friend CTBTextDocument;
    public:
        // ctor
        CTBTextCell(CTBTextDocument& doc) noexcept;
        // dtor
        ~CTBTextCell() noexcept;
#if _MSC_VER < 1900
        // get content
        ITBTextContent* GetContent() const noexcept { return m_pContent; }
#else
        // get content
        auto GetContent() const noexcept { return m_pContent; }
#endif
    public:
        // sleep
        void Sleep() noexcept;
        // awake
        void Awake(const char16_t*, uint32_t len) noexcept;
        // begin layout
        void BeginLayout() noexcept;
        // end layout
        void EndLayout() noexcept;
        // remove text, return true if CR/LF deleted
        bool RemoveText(TextRange) noexcept;
        // insert text
        void InsertText(uint32_t, U16View) noexcept;
        // remove text obly
        void RemoveTextOnly(TextRange) noexcept;
        // create new cell after this
        auto NewAfterThis() noexcept ->CTBTextCell*;
    public:
        // just remove from list
        inline void RemoveFromListOnly() noexcept;
        // move EOL to next node
        inline void MoveEOL2Next() noexcept;
    public:
        // mark as eol
        void MarkAsEOL() noexcept;
        // mark as bol
        void MarkAsBOL() noexcept { m_bBeginOfLine = true; };
        // is eol?
        bool IsEOL() const noexcept { return m_bEndOfLine; }
        // is bol?
        bool IsBOL() const noexcept { return m_bBeginOfLine; }
        // is dirty
        bool IsDirty() const noexcept { return m_bDirty; }
        // is last cell?
        bool IsLastCell() const noexcept { return !this->next->next; }
        // is first cell?
        bool IsFirstCell() const noexcept { return !this->prev->prev; }
#if _MSC_VER < 1900
        // get size
        SizeF GetSize() const noexcept { return m_size; }
        // get string length
        uint32_t GetStringLen() const noexcept { return m_text.size(); }
        // get char count
        uint32_t GetCharCount() const noexcept { return m_cCharCount; }
        // get string ptr
        const char16_t* GetStringPtr() const noexcept { return m_text.c_str(); }
#else
        // get size
        auto GetSize() const noexcept { return m_size; }
        // get string length
        auto GetStringLen() const noexcept { return m_text.size(); }
        // get char count
        auto GetCharCount() const noexcept { return m_cCharCount; }
        // get string ptr
        auto GetStringPtr() const noexcept { return m_text.c_str(); }
#endif
    protected:
        // clear bol
        void clear_bol() noexcept { m_bBeginOfLine = false; }
        // clear eol
        void clear_eol() noexcept { m_bEndOfLine = false; }
    protected:
        // document
        CTBTextDocument&            m_document;
        // content
        ITBTextContent*             m_pContent = nullptr;
        // unit size of this cell
        SizeF                       m_size = SizeF{ 0 };
        // baseline offset
        float                       m_fBaseline = 0.f;
        // char count(char count != string len)
        uint16_t                    m_cCharCount = 0;
        // is crlf end for line
        bool                        m_bCRLF : 1;
        // dirty
        bool                        m_bDirty : 1;
        // begin of line
        bool                        m_bBeginOfLine : 1;
        // end of line
        bool                        m_bEndOfLine : 1;
#ifndef NDEBUG
        // in layout
        bool                        m_bInLayout : 1;
#endif
        // text
        CTBString                   m_text;
    };
}



/// <summary>
/// Removes from list only.
/// </summary>
/// <returns></returns>
inline void RichTB::CTBTextCell::RemoveFromListOnly() noexcept {
    this->prev->next = this->next;
    this->next->prev = this->prev;
#ifndef NDEBUG
    this->prev = nullptr;
    this->next = nullptr;
#endif
}

/// <summary>
/// Moves the eo l2 next.
/// </summary>
/// <returns></returns>
inline void RichTB::CTBTextCell::MoveEOL2Next() noexcept {
#ifndef NDEBUG
    void tb_assert_move_eol(CTBTextCell&) noexcept;
    tb_assert_move_eol(*this);
#endif
    const auto next_cell = static_cast<CTBTextCell*>(this->next);
    next_cell->m_bEndOfLine = m_bEndOfLine;
    m_bEndOfLine = false;

}