﻿#pragma once

#include "tb_txtcell.h"
#include "tb_txtplat.h"
#include "tb_txtline.h"

#include <vector>

// RichTB namespace
namespace RichTB {
    // Dirty rectangles
    using DirtyRects = std::vector<uint32_t[4]>;
    // text document
    class CTBTextDocument {
        // lines_t
        using lines_t = std::vector<TextLineData>;
        // until call
        struct until_call {
            // function ptr
            bool (*func)(void* this_ptr, uint64_t) noexcept;
        };
    protected:
        // find func return value
        struct find_rv {
            // line data
            const TextLineData*     line;
            // cell data
            CTBTextCell*            cell;
            // char count to the cell
            uint32_t                char_count;
            // string len to the cell
            uint32_t                string_len;
        };
    public:
        // ctor
        CTBTextDocument(ITBTextPlatform&) noexcept;
        // dtor
        ~CTBTextDocument();
        // render
        void Render(void* context, DirtyRects*) noexcept;
    public:
        // remove text
        void RemoveText(TextRange) noexcept;
        // insert text
        void InsertText(uint32_t pos, U16View view) noexcept;
        // hit test
        auto HitTest(Point2F) noexcept ->uint32_t;
    protected:
        // remove text
        void remove_text(TextRange) noexcept;
        // insert text
        void insert_text(uint32_t pos, U16View view) noexcept;
        // relayout cell
        void relayout_cell(CTBTextCell& cell);
        // sync cache until <T>
        void sync_cache_until(until_call call, uint64_t) noexcept;
        // sync cache to length
        void sync_cache_to_length(uint32_t pos) noexcept;
        // sync cache to offset
        void sync_cache_to_offset(double offset);
        // split cell
        void split_cell(TextLineData& line, CTBTextCell& node, uint32_t pos);
    protected:
        // find cell or after cell or last cell by pos
        auto find_cell_or_la_by_pos(uint32_t pos) const noexcept->find_rv;
        // find last valid cell
        auto find_last_valid_cell() const noexcept->find_rv;
    private:
        // valid length
        inline auto cache_valid_length() const noexcept->uint32_t;
        // valid offset
        inline auto cache_valid_offset() const noexcept->double;
        // add line data
        inline auto add_line(TextLineData&, const TextLineData&, CTBTextCell* node) noexcept->CTBTextCell*;
    public:
        // platform
        ITBTextPlatform&    platform;
    protected:
        // text cell head
        Node                m_head = Node{ nullptr, &m_tail };
        // text cell tail
        Node                m_tail = Node{ &m_head, nullptr};
        // total string len
        uint32_t            m_cTotalLen = 0;
        // total char count
        uint32_t            m_cTotalCount = 0;
        // line data
        lines_t             m_lines;
        // valid line count
        uint32_t            m_cValidLine = 0;

        // XXX:caret
        RectWHF             m_rcCaret = RectWHF{};
        bool                m_bDrawCaret = false;


        // TODO: finish below

        // unused line u32 data
        uint32_t            m_lineUnused = 0;
        // free list
        CTBTextCell*        m_pFreeList = nullptr;
        // LIMITED BUFFER begin
        Node*               m_pBufferBegin = &m_tail;
        // LIMITED BUFFER end
        Node*               m_pBufferEnd = &m_tail;
        // LIMITED BUFFER max count
        uint32_t            m_cBufferMax = 128;
        // LIMITED BUFFER cell count
        uint32_t            m_cBufferCount = 0;
        // undo/redo stack
        void*               m_pUndoStack = nullptr;
    public:
        enum {
            // init reserve line count
            INIT_RESERVE_LINE = 10,
        };
    };
}
