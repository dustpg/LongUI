﻿#include <control/ui_spacer.h>
#include <control/ui_ctrlmeta.h>


// ui namespace
namespace UI {
    // UISpacer类 元信息
    LUI_CONTROL_META_INFO(UISpacer, "spacer");
}


/// <summary>
/// Finalizes an instance of the <see cref="UISpacer"/> class.
/// </summary>
/// <returns></returns>
UI::UISpacer::~UISpacer() noexcept {
}


/// <summary>
/// Initializes a new instance of the <see cref="UISpacer"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UISpacer::UISpacer(UIControl* parent) noexcept : Super(parent) {

}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UISpacer::Render() const noexcept {

}
