﻿// Gui
#include <debugger/ui_debug.h>
#include <control/ui_menupopup.h>
#include <control/ui_ctrlmeta.h>
// 子控件

// Private
#include "../private/ui_private_control.h"


// ui namespace
namespace UI {
    // UIMenuPopup类 元信息
    LUI_CONTROL_META_INFO(UIMenuPopup, "menupopup");
    // Menu Popup私有信息
//    struct PrivateMenuPopup : CUIObject {
//        // 构造函数
//        PrivateMenuPopup(UIMenuPopup& btn) noexcept;
//#ifndef NDEBUG
//        // 调试占位
//        void*               placeholder_debug1 = nullptr;
//#endif
//    };
}


/// <summary>
/// Finalizes an instance of the <see cref="UIMenuPopup"/> class.
/// </summary>
/// <returns></returns>
UI::UIMenuPopup::~UIMenuPopup() noexcept {
}

/// <summary>
/// Initializes a new instance of the <see cref="UIMenuPopup" /> class.
/// </summary>
/// <param name="hoster">The hoster.</param>
/// <param name="meta">The meta.</param>
UI::UIMenuPopup::UIMenuPopup(UIControl* hoster, const MetaControl& meta) noexcept
    : Super(hoster, CUIWindow::Config_Popup, meta), m_pHoster(hoster) {
}


/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="arg">The argument.</param>
/// <returns></returns>
auto UI::UIMenuPopup::DoEvent(
    UIControl * sender, const EventArg & arg) noexcept -> EventAccept {
    // 初始化
    if (arg.nevent == NoticeEvent::Event_WindowClosed) {
        if (m_pHoster) 
            return m_pHoster->DoEvent(this, { NoticeEvent::Event_PopupClosed, 0 });
    }
    return Super::DoEvent(sender, arg);
}