﻿// Gui
#include <util/ui_ctordtor.h>
#include <debugger/ui_debug.h>
#include <control/ui_menulist.h>
#include <control/ui_ctrlmeta.h>
#include <control/ui_menupopup.h>
// 子控件
#include <control/ui_box_layout.h>
#include <control/ui_image.h>
#include <control/ui_label.h>
// Private
#include "../private/ui_private_control.h"

#include <algorithm>

// ui namespace
namespace UI {
    // UIMenuList类 元信息
    LUI_CONTROL_META_INFO(UIMenuList, "button");
    // UIMenuList私有信息
    struct PrivateMenuList : CUIObject {
        // 构造函数
        PrivateMenuList(UIMenuList& btn) noexcept;
#ifndef NDEBUG
        // 调试占位
        void*               placeholder_debug1 = nullptr;
#endif
        // 图像控件
        UIImage             image;
        // 标签控件
        UILabel             label;
        // 下拉标记
        UIImage             marker;
        
    };
    /// <summary>
    /// button privates data/method
    /// </summary>
    /// <param name="btn">The BTN.</param>
    /// <returns></returns>
    UI::PrivateMenuList::PrivateMenuList(UIMenuList& btn) noexcept
        : image(&btn), label(&btn), marker(&btn) {
        PrivateControl::SetFlex(label, 1.f);
        //PrivateControl::SetFocusable(image, false);
        //PrivateControl::SetFocusable(label, false);
        //PrivateControl::SetFocusable(marker, false);
#ifndef NDEBUG
        image.name_dbg = "menulist::image";
        label.name_dbg = "menulist::label";
        marker.name_dbg= "menulist::marker";
        assert(image.IsFocusable() == false);
        assert(label.IsFocusable() == false);
        assert(marker.IsFocusable() == false);
#endif
    }
}

/// <summary>
/// Gets the text.
/// </summary>
/// <returns></returns>
auto UI::UIMenuList::GetText() const noexcept -> str_t {
    assert(m_private && "bad action");
    return m_private->label.GetText();
}

/// <summary>
/// Gets the text string.
/// </summary>
/// <returns></returns>
auto UI::UIMenuList::GetTextString() const noexcept -> const CUIString&{
    assert(m_private && "bad action");
    return m_private->label.GetTextString();
}


/// <summary>
/// Initializes a new instance of the <see cref="UIMenuList" /> class.
/// </summary>
/// <param name="parent">The parent.</param>
/// <param name="meta">The meta.</param>
UI::UIMenuList::UIMenuList(UIControl* parent, const MetaControl& meta) noexcept
    : Super(parent, meta) {
    m_state.focusable = true;
    m_state.defaultable = true;
    // 原子性, 子控件为本控件的组成部分
    m_state.atomicity = true;
    // 布局方向
    m_oStyle.align = Align_Center;
    // 垂直布局
    this->SetOrient(Orient_Horizontal);
    // TODO: 延迟构造对象
    m_oBox.margin = { 5, 5, 5, 5 };
    m_oBox.padding.right = 5;
    m_private = new(std::nothrow) PrivateMenuList{ *this };
    // TODO: OOM处理
    m_private->label.SetText(L"确定");
}


/// <summary>
/// Finalizes an instance of the <see cref="UIMenuList"/> class.
/// </summary>
/// <returns></returns>
UI::UIMenuList::~UIMenuList() noexcept {
    // 存在提前释放子控件, 需要标记"在析构中"
    m_state.in_dtor = true;
    // XXX: 无需(?)释放弹出菜单
    //if (m_pMenuPopup) delete m_pMenuPopup;
    // 释放私有数据
    if (m_private) delete m_private;
}


/// <summary>
/// Sets the text.
/// </summary>
/// <param name="str">The string.</param>
/// <returns></returns>
void UI::UIMenuList::SetText(const CUIString & str) noexcept {
    assert(m_private && "BUG");
    m_private->label.SetText(str);
}


/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIMenuList::DoMouseEvent(const MouseEventArg& e) noexcept -> EventAccept {
    // 处理消息
    switch (e.type)
    {
    case UI::MouseEvent::Event_LButtonDown:
        //m_pWindow->SetCapture(*this);
        this->ShowPopup();
        [[fallthrough]];
    default:
        return Super::DoMouseEvent(e);
    }
}


/// <summary>
/// Initializes the menulist.
/// </summary>
void UI::UIMenuList::init_menulist() {
    PrivateControl::SetAppearanceIfNotSet(*this, Appearance_Button);
    auto& marker = m_private->marker;
    PrivateControl::SetAppearanceIfNotSet(marker, Appearance_DropDownMarker);
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIMenuList::DoEvent(UIControl * sender,
    const EventArg & e) noexcept -> EventAccept {
    switch (e.nevent)
    {
    case NoticeEvent::Event_Initialize:
        // 初始化
        this->init_menulist();
        return Event_Accept;
    case NoticeEvent::Event_PopupClosed:
        // 关闭了弹出窗口
        if (sender == m_pMenuPopup) {
            int bk = 9;
        }
        return Event_Accept;
    default:
        // 基类处理
        return Super::DoEvent(sender, e);
    }
}


#ifdef LUI_ACCESSIBLE
#include <accessible/ui_accessible_callback.h>
#include <accessible/ui_accessible_event.h>
#include <accessible/ui_accessible_type.h>
#include <core/ui_string.h>
#endif


/// <summary>
/// Sets the text.
/// </summary>
/// <param name="txt">The text.</param>
/// <param name="len">The length.</param>
/// <returns></returns>
void UI::UIMenuList::SetText(const wchar_t* txt, size_t len) noexcept {
    assert(m_private && "bad action");
    if (m_private->label.SetText(txt, len)) {
#ifdef LUI_ACCESSIBLE
        UI::Accessible(m_pAccessible, Callback_PropertyChanged);
#endif
    }
}


/// <summary>
/// Adds the child.
/// </summary>
/// <param name="child">The child.</param>
/// <returns></returns>
void UI::UIMenuList::add_child(UIControl& child) noexcept {
    // 检查是不是 Menu Popup
    if (const auto ptr = uisafe_cast<UIMenuPopup>(&child)) {
        m_pMenuPopup = ptr;
        ptr->init_hoster(this);
        return;
    }
    return Super::add_child(child);
}

/// <summary>
/// Shows the popup.
/// </summary>
/// <returns></returns>
void UI::UIMenuList::ShowPopup() noexcept {
    // 有窗口?
    if (m_pMenuPopup) {
        auto& window = m_pMenuPopup->RefWindow();
        const auto this_window = this->GetWindow();
        assert(this_window);
        // 计算大小
        auto& popup = m_pMenuPopup->RefWindow();
        // 边框
        auto size = this->GetBox().GetBorderSize();
        // 高度
        size.height = m_pMenuPopup->GetMinSize().height;
        // TODO: DPI缩放

        // 姿势
        const int32_t w = static_cast<int32_t>(size.width);
        const int32_t h = static_cast<int32_t>(size.height);
        popup.Resize({ w, h });
        // 计算位置
        const auto edge = this->GetBox().GetBorderEdge();
        const auto y = this->GetSize().height - edge.top;
        auto pos = this->MapToWindowEx({ edge.left, y });
        this_window->MapToScreen(pos);
        window.SetPos({ 
            static_cast<int32_t>(pos.x), 
            static_cast<int32_t>(pos.y) 
        });
        window.ShowWindow();
    }

    // 触发修改GUI事件
    //this->TriggrtEvent(_clicked());
#ifdef LUI_ACCESSIBLE
    // TODO: 调用 accessible 接口
#endif
}

#ifdef LUI_ACCESSIBLE


#endif
