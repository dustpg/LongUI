﻿// ui
#include <core/ui_manager.h>
#include <text/ui_ctl_impl.h>
#include <core/ui_color_list.h>
#include <control/ui_textbox.h>
#include <graphics/ui_graphics_impl.h>

// RichTB
#include <../RichTB/tb_txtdoc.h>

// uinamespace
namespace UI {
    // auto cst RichTB -> LongUI
    auto auto_cast(RichTB::ITBTextContent* ptr) noexcept {
        return reinterpret_cast<I::Text*>(ptr);
    }
    // auto cst LongUI -> RichTB
    auto auto_cast(I::Text* ptr) noexcept {
        return reinterpret_cast<RichTB::ITBTextContent*>(ptr);
    }
    // private text box
    struct PrivateTextBox {
        // ctor
        PrivateTextBox(RichTB::ITBTextPlatform& obj) noexcept;
        // dtor
        ~PrivateTextBox() noexcept {}
        // document
        RichTB::CTBTextDocument             document;
        // cluster buffer 
        POD::Vector<DWRITE_CLUSTER_METRICS> cluster_buffer;
    };
    /// <summary>
    /// Privates the text box.
    /// </summary>
    /// <param name="obj">The object.</param>
    /// <returns></returns>
    PrivateTextBox::PrivateTextBox(RichTB::ITBTextPlatform & obj)
        noexcept : document(obj) {
    }
}

/// <summary>
/// Deletes the private.
/// </summary>
/// <returns></returns>
void UI::UITextBox::delete_private() noexcept {
    if (m_private) delete m_private;
}

/// <summary>
/// Creates the private.
/// </summary>
/// <returns></returns>
void UI::UITextBox::create_private() noexcept {
    assert(!m_private);
    m_private = new(std::nothrow) PrivateTextBox{ *this };
}


/// <summary>
/// Privates the mouse down.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::UITextBox::private_mouse_down(Point2F pos) noexcept {
    m_private->document.HitTest({ pos.x, pos.y });
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UITextBox::Render() const noexcept {
    Super::Render();
    auto& ctx = UIManager.Ref2DRenderer();
    m_private->document.Render(&ctx, nullptr);
}

/// <summary>
/// Needs the redraw.
/// </summary>
/// <returns></returns>
void UI::UITextBox::NeedRedraw() noexcept {

}

/// <summary>
/// Draws the caret.
/// </summary>
/// <param name="ctx">The CTX.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::UITextBox::DrawCaret(void* ctx, const RichTB::RectWHF& rect) noexcept {
    assert(ctx && "bad context");
    const auto renderer = static_cast<I::Renderer2D*>(ctx);
    const auto red = ColorF::FromRGBA_CT<RGBA_Red>();
    renderer->FillRectangle({
        rect.x, rect.y, rect.x + rect.width, rect.y + rect.height
    }, &UIManager.RefCCBrush(red));
}


/// <summary>
/// Creates the content.
/// </summary>
/// <param name="str">The string.</param>
/// <param name="len">The length.</param>
/// <param name="old">The old ptr.</param>
/// <returns></returns>
auto UI::UITextBox::CreateContent(
    const char16_t* str,
    uint32_t len,
    Text&& old
) noexcept -> Text* {
    const auto last_text = auto_cast(&old);
    I::Text* text = nullptr;
    TextArg arg;
    static_assert(sizeof(*arg.string) == sizeof(char16_t), "unsupprted platform");
    // 参数调整
    arg.string = reinterpret_cast<decltype(arg.string)>(str);
    arg.length = len;
    arg.font = I::FontFromText(last_text);
    arg.mwidth = DEFAULT_CONTROL_MAX_SIZE;
    arg.mheight = DEFAULT_CONTROL_MAX_SIZE;
    // TODO: 错误处理
    UIManager.CreateCtlText(arg, luiref text);
    // 释放旧数据
    if (last_text) last_text->Release();
    return auto_cast(text);
}


/// <summary>
/// Deletes the content.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::UITextBox::DeleteContent(Text& text) noexcept {
    const auto ptr = auto_cast(&text);
    ptr->Release();
}

/// <summary>
/// Draws the content.
/// </summary>
/// <param name="txt">The text.</param>
/// <param name="ctx">The CTX.</param>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::UITextBox::DrawContent(Text& txt, void* ctx, RichTB::Point2F pos) noexcept {
    const auto ptr = auto_cast(&txt);
    assert(ctx && "bad context");
    const auto renderer = static_cast<I::Renderer2D*>(ctx);
    // 错误场合处理
    if (ptr) {
        const auto color = ColorF::FromRGBA_CT<RGBA_Black>();
        auto& brush = UIManager.RefCCBrush(color);
        renderer->DrawTextLayout({ pos.x, pos.y }, ptr, &brush);
    }
}


/// <summary>
/// Contents the event.
/// </summary>
/// <param name="txt">The text.</param>
/// <param name="event">The event.</param>
/// <param name="arg">The argument.</param>
/// <returns></returns>
void UI::UITextBox::ContentEvent(Text& txt, MetricsEvent event, void* arg) noexcept {
    const auto ptr = auto_cast(&txt);
    switch (event)
    {
    case RichTB::ITBTextPlatform::Event_GetSize:
        // 获取内容大小
        *static_cast<RichTB::SizeF*>(arg) = { 0 };
        if (ptr) {
            // 利用文本测量结构体获取大小
            DWRITE_TEXT_METRICS tm;
            ptr->GetMetrics(&tm);
            static_cast<RichTB::SizeF*>(arg)->width = tm.width;
            static_cast<RichTB::SizeF*>(arg)->height = tm.height;
        }
        break;
    case RichTB::ITBTextPlatform::Event_GetBaseline:
        *static_cast<float*>(arg) = 0.;
        if (ptr) {
            // 利用行测量结构体获取基线偏移量
            DWRITE_LINE_METRICS lm; uint32_t count = 1;
            ptr->GetLineMetrics(&lm, 1, &count);
            *static_cast<float*>(arg) = lm.baseline;
        }
        break;
    case RichTB::ITBTextPlatform::Event_HitTest:
        // 点击检测
        static_assert(sizeof(float) == sizeof(uint32_t), "unsupported plat");
        {
            const auto px = *static_cast<float*>(arg);
            auto& out = *static_cast<uint32_t*>(arg);
            out = 0;
            if (ptr) {
                BOOL hint = false, inside = false;
                DWRITE_HIT_TEST_METRICS htm;
                ptr->HitTestPoint(px, 0, &hint, &inside, &htm);
                out = htm.textPosition;
            }
        }
        break;
    case RichTB::ITBTextPlatform::Event_CharMetrics:
        union cm_data { RichTB::CharMetrics cm; uint32_t pos; };
        {
            const auto pos = static_cast<cm_data*>(arg)->pos;
            auto& out = static_cast<cm_data*>(arg)->cm;
            out = {};
            if (ptr) {
                auto& buf = m_private->cluster_buffer;
                const auto size = pos + 1;
                buf.resize(size);
                // TODO: 错误处理
                if (buf.is_ok()) {
                    uint32_t max_count = 0;
                    ptr->GetClusterMetrics(buf.data(), size, &max_count);
                    assert(size <= max_count);
                    float width = 0, last_width = 0;
                    for (const auto& x : buf) width += last_width = x.width;
                    out.width = last_width;
                    out.x = width - last_width;
                }
            }
        }
        break;
    default:
        assert(!"bad case");
    }
}


