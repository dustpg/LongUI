﻿#include <core/ui_color_list.h>
#include <control/ui_control.h>
#include <graphics/ui_bg_renderer.h>
// Graphics API
#include <graphics/ui_graphics_impl.h>
#include <core/ui_manager.h>


/// <summary>
/// Deletes the renderer.
/// </summary>
/// <returns></returns>
void UI::UIControl::delete_renderer() noexcept {
    if (m_pBgRender) delete m_pBgRender;
}

/// <summary>
/// Draws the color of the background.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_bkcolor() const noexcept {
    if (m_pBgRender) {
        if (!std::strcmp("hbox1-c", name_dbg)) {
            int bk = 9;
        }
        m_pBgRender->RenderColor(this->GetBox());
    }
}

/// <summary>
/// Draws the background image.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_bkimage() const noexcept {

}

/// <summary>
/// Draws the border.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_border() const noexcept {

}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIControl::Render() const noexcept {
    assert(m_state.inited && "must init control first");
    this->begin_render();
    this->draw_bkcolor();
}


/// <summary>
/// Begins the render.
/// </summary>
/// <returns></returns>
void UI::UIControl::begin_render() const noexcept {
    // 做一些渲染前的准备
    auto& painter = UIManager.Ref2DRenderer();
    painter.SetTransform(auto_cast(m_mtWorld));
}

PCN_NOINLINE
/// <summary>
/// Gets the color of the background.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::UIControl::GetBackgroundColor(ColorF& color) const noexcept {
    if (m_pBgRender) color = m_pBgRender->GetColor();
    else color = ColorF::FromRGBA_CT<RGBA_Transparent>();
}

PCN_NOINLINE
/// <summary>
/// Gets the color of the foreground.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::UIControl::GetForegroundColor(ColorF& color) const noexcept {
    color = ColorF::FromRGBA_CT<RGBA_Black>();
}