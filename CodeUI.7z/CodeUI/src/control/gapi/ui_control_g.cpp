﻿// ui
#include <core/ui_manager.h>
#include <util/ui_aniamtion.h>
#include <core/ui_color_list.h>
#include <control/ui_control.h>
#include <style/ui_native_style.h>
#include <graphics/ui_bg_renderer.h>
#include <graphics/ui_bd_renderer.h>
#include <graphics/ui_graphics_impl.h>

/// <summary>
/// Deletes the renderer.
/// </summary>
/// <returns></returns>
void UI::UIControl::delete_renderer() noexcept {
    if (m_pBgRender) delete m_pBgRender;
    if (m_pBdRender) delete m_pBdRender;
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIControl::Render() const noexcept {
    assert(m_state.inited && "must init control first");
    this->begin_render();
    if (this->native_style_render()) {
        this->custom_style_render();
    }
}

/// <summary>
/// Natives the style render.
/// </summary>
/// <returns></returns>
bool UI::UIControl::native_style_render() const noexcept {
    const auto type = this->GetStyle().appearance;
    // 使用自定义风格渲染
    if (type == AttributeAppearance::Appearance_None) return true;
    // 使用本地风格渲染
    NativeDrawArgs arg;
    arg.border = this->GetBox().GetBorderEdge();
    arg.from = this->GetStyle().state;
    arg.progress = 0.f;
    arg.appearance = type;
    // 存在动画
    if (m_pAnimation) {
        arg.to = m_pAnimation->basic.target;
        arg.progress = m_pAnimation->basic.GetRate();
    }
    // 渲染本地风格
    UI::NativeStyleDraw(arg);
    // 表示已经渲染
    return false;
}

/// <summary>
/// Customs the style render.
/// </summary>
/// <returns></returns>
void UI::UIControl::custom_style_render() const noexcept {
    /*
        栈顺序:
        - 这里实现
           A.background color
           B.background image
           C.border
        - 外面实现
           A.children
           B.outline
    */
    // 背景渲染
    if (m_pBgRender) {
        // A.
        m_pBgRender->RenderColor(this->GetBox());
        // B.
        m_pBgRender->RenderImage(this->GetBox());
    }
    // 边框渲染

}

/// <summary>
/// Begins the render.
/// </summary>
/// <returns></returns>
void UI::UIControl::begin_render() const noexcept {
    // 做一些渲染前的准备
    auto& painter = UIManager.Ref2DRenderer();
    painter.SetTransform(auto_cast(m_mtWorld));
}

PCN_NOINLINE
/// <summary>
/// Gets the color of the background.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::UIControl::GetBackgroundColor(ColorF& color) const noexcept {
    if (m_pBgRender) color = m_pBgRender->GetColor();
    else color = ColorF::FromRGBA_CT<RGBA_Transparent>();
}

PCN_NOINLINE
/// <summary>
/// Gets the color of the foreground.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::UIControl::GetForegroundColor(ColorF& color) const noexcept {
    color = ColorF::FromRGBA_CT<RGBA_Black>();
}