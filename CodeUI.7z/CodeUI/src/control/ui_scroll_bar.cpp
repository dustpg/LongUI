﻿#include <control/ui_scroll_bar.h>
#include <core/ui_color_list.h>
#include <cassert>


/// <summary>
/// Initializes a new instance of the <see cref="UIScrollBar"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIScrollBar::UIScrollBar(AttributeOrient o, 
    UIControl* parent) noexcept : Super(parent), m_orient(o) {
    this->SetBgColor({ RGBA_Red });
    // TODO: 最小大小
    this->SpecifyMinSize({ 30, 30 });
}

/// <summary>
/// Finalizes an instance of the <see cref="UIScrollBar"/> class.
/// </summary>
/// <returns></returns>
UI::UIScrollBar::~UIScrollBar() noexcept {

}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollBar::Render() const noexcept {
    assert(m_state.inited && "must init control first");
    return Super::Render();
    /*this->begin_render();
    auto& painter = UI::Private::renderer();
    if (this->color) {
        QColor bgcolor{ Qt::white };
        QColor color{ QRgb{ this->color } };
        RectF rect = this->GetBox().GetContentEdge();
        Size2F csize = {
            rect.right - rect.left,
            rect.bottom - rect.top
        };
        painter.fillRect(
            QRectF{ rect.left, rect.top, csize.width, csize.height },
            bgcolor
        );
        const auto len = m_fMax - m_fMin + m_fPageStep;
        const auto www = m_orient == Orient_Horizontal ? csize.width : csize.height;
        const auto x = m_fValue / len * www;
        const auto l = m_fPageStep / len * www;
        if (m_orient == Orient_Horizontal) {
            painter.fillRect(QRectF{
                x, rect.top,
                l,
                csize.height
            }, color);
        }
        else {
            painter.fillRect(QRectF{
                rect.left, x,
                csize.width,
                l
            }, color);

        }
    }*/
}


/// <summary>
/// Sets the value.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetValue(float v) noexcept {
    if (IsSameInGuiLevel(m_fValue, v)) return;
    m_fValue = v;
    this->Repaint();
}


/// <summary>
/// Sets the maximum.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetMax(float v) noexcept {
    if (IsSameInGuiLevel(m_fMax, v)) return;
    m_fMax = v;
    this->Repaint();
}

/// <summary>
/// Sets the minimum.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetMin(float v) noexcept {
    if (IsSameInGuiLevel(m_fMin, v)) return;
    m_fMin = v;
    this->Repaint();
}

/// <summary>
/// Sets the page step.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetPageStep(float v) noexcept {
    if (IsSameInGuiLevel(m_fPageStep, v)) return;
    m_fPageStep = v;
    this->Repaint();
}

/// <summary>
/// Sets the page step.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetSingleStep(float v) noexcept {
    if (IsSameInGuiLevel(m_fSingleStep, v)) return;
    m_fSingleStep = v;
    this->Repaint();
}
