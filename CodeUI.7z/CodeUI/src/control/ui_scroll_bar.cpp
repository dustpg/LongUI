﻿// Gui
#include <control/ui_scale.h>
#include <util/ui_aniamtion.h>
#include <control/ui_image.h>
#include <core/ui_color_list.h>
#include <control/ui_ctrlmeta.h>
#include <control/ui_scroll_bar.h>
// C++
#include <cassert>
// Private
#include "../private/ui_private_control.h"

// ui namespace
namespace UI {
    // UIScrollBar类 元信息
    LUI_CONTROL_META_INFO(UIScrollBar, "scrollbar");
    // ScrollBar 私有数据
    struct PrivateScrollBar : CUIObject {
        // 控件类型
        enum ControlType : uint32_t {
            Type_UpTop = 0,
            Type_DownTop,
            Type_Slider,
            Type_UpBottom,
            Type_DownBottom,
            TYPE_COUNT,
        };
        // 按钮类
        using SBButton = UIImage;
        // 滑条类
        using SBSlider = UIScale;
        // 构造函数
        PrivateScrollBar(UIControl* parent) noexcept;
#ifndef NDEBUG
        // 占位指针位 调试
        void*               placeholder_debug1 = nullptr;
#endif
        // 滚动条按钮 顶上
        SBButton            up_top;
        // 滚动条按钮 顶下
        SBButton            down_top;
        // 滑动条控件 中央
        SBSlider            slider;
        // 滚动条按钮 底上
        SBButton            up_bottom;
        // 滚动条按钮 底下
        SBButton            down_bottom;
    };
    /// <summary>
    /// Privates the scroll bar.
    /// </summary>
    /// <param name="parent">The parent.</param>
    /// <returns></returns>
    UI::PrivateScrollBar::PrivateScrollBar(UIControl* parent) noexcept
        : up_top(parent), down_top(parent), slider(parent)
        , up_bottom(parent), down_bottom(parent) {
#ifndef NDEBUG
        up_top.name_dbg     = "scrollbar::up_top";
        down_top.name_dbg   = "scrollbar::down_top";
        slider.name_dbg     = "scrollbar::slider";
        up_bottom.name_dbg  = "scrollbar::up_bottom";
        down_bottom.name_dbg= "scrollbar::down_bottom";
#endif
        //PrivateControl::SetGuiEvent2Parent(up_top);
        //PrivateControl::SetGuiEvent2Parent(down_top);
        PrivateControl::SetGuiEvent2Parent(slider);
        //PrivateControl::SetGuiEvent2Parent(up_bottom);
        //PrivateControl::SetGuiEvent2Parent(down_bottom);

        PrivateControl::SetParentData(up_top,   Type_UpTop);
        PrivateControl::SetParentData(down_top, Type_DownTop);
        PrivateControl::SetParentData(slider,   Type_Slider);
        PrivateControl::SetParentData(up_bottom, Type_UpBottom);
        PrivateControl::SetParentData(down_bottom, Type_DownBottom);
        PrivateControl::SetFlex(slider, 1.f);

        down_top.SetVisible(false);
        up_bottom.SetVisible(false);
        slider.SetMin(0.f);
    }
}


/// <summary>
/// Initializes a new instance of the <see cref="UIScrollBar" /> class.
/// </summary>
/// <param name="o">The o.</param>
/// <param name="parent">The parent.</param>
/// <param name="meta">The meta.</param>
UI::UIScrollBar::UIScrollBar(AttributeOrient o, UIControl* parent,
    const MetaControl& meta) noexcept : Super(parent, meta) {
    // 非公共容器
    m_state.public_container = false;
    // 原子性, 子控件为本控件的组成部分
    m_state.atomicity = true;
    // 创建私有数据
    constexpr auto sizeof_private = sizeof(*m_private);
    m_private = new(std::nothrow) PrivateScrollBar{ this };
    // TODO: OOM处理
    const bool orient = o & 1;
    m_state.orient = orient;
    PrivateControl::SetOrient(m_private->slider, orient);
    //this->SetBgColor({ RGBA_Red });
    // TODO: 最小大小
    //this->SpecifyMinSize({ 30, 30 });
}

// super helper
//#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIScrollBar"/> class.
/// </summary>
/// <returns></returns>
UI::UIScrollBar::~UIScrollBar() noexcept {
    m_state.in_dtor = true;
    if (m_private) delete m_private;
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollBar::Update() noexcept {
    // TODO: disabled 状态修改? 广播给子控件
    if (m_state.style_state_changed) {
        m_state.style_state_changed = false;
        if (m_pAnimation) {

        }
    }
    return Super::Update();
}

/// <summary>
/// Gets the value.
/// </summary>
/// <returns></returns>
auto UI::UIScrollBar::GetValue() const noexcept -> float {
    return m_private->slider.GetValue();
}


/// <summary>
/// Sets the value.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetValue(float v) noexcept {
    m_private->slider.SetValue(v);
}


/// <summary>
/// Sets the maximum.
/// </summary>
/// <param name="v">The v.</param>
/// <returns></returns>
void UI::UIScrollBar::SetMax(float v) noexcept {
    m_private->slider.SetMax(v);
}

/// <summary>
/// Sets the page increment.
/// </summary>
/// <param name="pi">The pi.</param>
/// <returns></returns>
void UI::UIScrollBar::SetPageIncrement(float pi) noexcept {
    m_private->slider.SetPageIncrement(pi);
}

/// <summary>
/// Initializes the bar.
/// </summary>
/// <returns></returns>
void UI::UIScrollBar::init_bar() noexcept {
    AttributeAppearance aut, adt, asd, ast, aub, adb;
    // 根据方向确定初始化类型
    if (this->GetOrient() == Orient_Horizontal) {
        aut = Appearance_ScrollBarButtonLeft;
        adt = Appearance_ScrollBarButtonRight;
        asd = Appearance_None;
        ast = Appearance_ScrollbarThumbH;
        aub = Appearance_ScrollBarButtonLeft;
        adb = Appearance_ScrollBarButtonRight;
    }
    // 垂直方向
    else {
        aut = Appearance_ScrollBarButtonUp;
        adt = Appearance_ScrollBarButtonDown;
        asd = Appearance_None;
        ast = Appearance_ScrollbarThumbV;
        aub = Appearance_ScrollBarButtonUp;
        adb = Appearance_ScrollBarButtonDown;
    }
    // 设置Appearance类型
    PrivateControl::SetAppearanceIfNotSet(m_private->up_top, aut);
    PrivateControl::SetAppearanceIfNotSet(m_private->down_top, adt);
    PrivateControl::SetAppearanceIfNotSet(m_private->slider, asd);
    PrivateControl::SetAppearanceIfNotSet(m_private->slider.thumb, ast);
    PrivateControl::SetAppearanceIfNotSet(m_private->up_bottom, aub);
    PrivateControl::SetAppearanceIfNotSet(m_private->down_bottom, adb);
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIScrollBar::DoEvent(UIControl * sender,
    const EventArg & e) noexcept -> EventAccept {
    // 初始化
    if (e.nevent == NoticeEvent::Event_Initialize) {
        this->init_bar();
    }
    // Gui事件
    else if (e.nevent == NoticeEvent::Event_UIEvent) {
        // 数据修改事件向上传递
        const auto ge = static_cast<const EventGuiArg&>(e).GetEvent();
        assert(sender == &m_private->slider);
        return this->TriggrtEvent(ge);
    }
    // 基类处理
    return Super::DoEvent(sender, e);
}
