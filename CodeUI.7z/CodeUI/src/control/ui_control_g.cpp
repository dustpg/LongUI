﻿#include <control/ui_control.h>
#include <graphics/ui_bg_renderer.h>


/// <summary>
/// Deletes the renderer.
/// </summary>
/// <returns></returns>
void UI::UIControl::delete_renderer() noexcept {
    if (m_pBgRender) delete m_pBgRender;
}

/// <summary>
/// Draws the color of the background.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_bkcolor() const noexcept {
    if (m_pBgRender) {
        m_pBgRender->RenderColor(this->GetBox());
    }
}

/// <summary>
/// Draws the background image.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_bkimage() const noexcept {

}

/// <summary>
/// Draws the border.
/// </summary>
/// <returns></returns>
void UI::UIControl::draw_border() const noexcept {

}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIControl::Render() const noexcept {
    assert(m_state.inited && "must init control first");
    this->begin_render();
    this->draw_bkcolor();
}