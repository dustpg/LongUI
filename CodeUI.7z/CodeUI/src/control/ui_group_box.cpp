﻿// Gui
#include <control/ui_caption.h>
#include <control/ui_ctrlmeta.h>
#include <control/ui_groupbox.h>
#include <control/ui_box_layout.h>
// Debug
#include <debugger/ui_debug.h>
// Private
#include "../private/ui_private_control.h"


// ui namespace
namespace UI {
    // UIGroupBox类 元信息
    LUI_CONTROL_META_INFO(UIGroupBox, "groupbox");
    // PrivateGroupBox
    struct PrivateGroupBox : CUIObject {
        // ctor
        PrivateGroupBox(UIControl* parent) noexcept;
#ifndef NDEBUG
        // 占位指针位 调试
        void*               placeholder_debug1 = nullptr;
#endif
        // 头布局
        UIHBoxLayout        head;
        // 体布局
        UIVBoxLayout        body;
    };
    /// <summary>
    /// Privates the group box.
    /// </summary>
    /// <param name="parent">The parent.</param>
    /// <returns></returns>
    UI::PrivateGroupBox::PrivateGroupBox(UIControl * parent) noexcept:
        head(parent), body(parent) {
    }
}


/// <summary>
/// Initializes a new instance of the <see cref="UICaption" /> class.
/// </summary>
/// <param name="parent">The parent.</param>
/// <param name="meta">The meta.</param>
UI::UIGroupBox::UIGroupBox(UIControl* parent, const MetaControl& meta) noexcept
    : Super(parent, meta) {
    // XXX: OOM处理
    m_private = new(std::nothrow) PrivateGroupBox{ this };
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIGroupBox"/> class.
/// </summary>
/// <returns></returns>
UI::UIGroupBox::~UIGroupBox() noexcept {
    m_state.in_dtor = true;
    if (m_private) delete m_private;
}


/// <summary>
/// Adds the child.
/// </summary>
/// <param name="child">The child.</param>
/// <returns></returns>
void UI::UIGroupBox::add_child(UIControl& child) noexcept {
    // 已经连接好
    if (m_private) {
        // caption控件?
        UIControl* target;
        assert(!"[unfinished]uisafe_cast under add_child?");
        if (uisafe_cast<UICaption>(&child))
            target = &m_private->head;
        else 
            target = &m_private->body;
        PrivateControl::CallAddChild(*target, child);
    }
    // 还未连接好
    else Super::add_child(child);
}
