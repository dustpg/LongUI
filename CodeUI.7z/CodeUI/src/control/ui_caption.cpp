﻿#include <control/ui_caption.h>
#include <control/ui_ctrlmeta.h>
#include <debugger/ui_debug.h>


// ui namespace
namespace UI {
    // UICaption类 元信息
    LUI_CONTROL_META_INFO(UICaption, "caption");
}


/// <summary>
/// Initializes a new instance of the <see cref="UICaption"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UICaption::UICaption(UIControl* parent) noexcept : Super(parent) {
    LUI_INIT_META_POINTER;
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UICaption"/> class.
/// </summary>
/// <returns></returns>
UI::UICaption::~UICaption() noexcept {
}


