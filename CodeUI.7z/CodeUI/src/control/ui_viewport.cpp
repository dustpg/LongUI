﻿#include <control/ui_viewport.h>
#include <cassert>


/// <summary>
/// Initializes a new instance of the <see cref="UIViewport"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIViewport::UIViewport(CUIWindow* parent) noexcept 
    : Super(nullptr), m_window(nullptr) {
    m_pWindow = &m_window;
    this->SetOrient(Orient_Vertical);
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIViewport"/> class.
/// </summary>
/// <returns></returns>
UI::UIViewport::~UIViewport() noexcept {
    //m_state.in_dtor = true;

}

/// <summary>
/// Gets the viewport.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::RefViewport() noexcept -> UIViewport& {
    assert(this && "null this pointer");
    const auto ptr = reinterpret_cast<char*>(this);
    const auto offset = offsetof(UIViewport, m_window);
    const auto viewport = ptr - offset;
    return *reinterpret_cast<UIViewport*>(viewport);
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::UIViewport::Recreate() noexcept -> Result {
    return m_window.recreate();
}

