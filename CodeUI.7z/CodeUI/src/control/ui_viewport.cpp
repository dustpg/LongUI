﻿#include <control/ui_viewport.h>
#include <cassert>


/// <summary>
/// Initializes a new instance of the <see cref="UIViewport"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIViewport::UIViewport(CUIWindow* parent) noexcept 
    : Super(nullptr), m_window(nullptr) {
    this->SetOrient(Orient_Vertical);
}

/// <summary>
/// Finalizes an instance of the <see cref="UIViewport"/> class.
/// </summary>
/// <returns></returns>
UI::UIViewport::~UIViewport() noexcept {
}

/// <summary>
/// Gets the viewport.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::GetViewport() noexcept -> UIViewport& {
    assert(this && "null this pointer");
    const auto ptr = reinterpret_cast<char*>(this);
    const auto offset = offsetof(UIViewport, m_window);
    const auto viewport = ptr - offset;
    return *reinterpret_cast<UIViewport*>(viewport);
}