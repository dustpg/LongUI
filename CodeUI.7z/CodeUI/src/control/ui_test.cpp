﻿#include <control/ui_test.h>
#ifndef NDEBUG
#include <control/ui_ctrlmeta.h>
#include <debugger/ui_debug.h>


// ui namespace
namespace UI {
    // UITest类 元信息
    LUI_CONTROL_META_INFO(UITest, "test");
}


/// <summary>
/// Finalizes an instance of the <see cref="UITest"/> class.
/// </summary>
/// <returns></returns>
UI::UITest::~UITest() noexcept {
}


/// <summary>
/// Initializes a new instance of the <see cref="UITest"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UITest::UITest(UIControl* parent) noexcept : Super(parent) {
    LUI_INIT_META_POINTER;

}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UITest::DoEvent(UIControl* sender, 
    const EventArg& e) noexcept -> EventAccept {
    return Super::DoEvent(sender, e);
}

/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UITest::DoMouseEvent(const MouseEventArg & e) noexcept -> EventAccept {
    switch (e.type)
    {
    case UI::MouseEvent::Event_MouseWheelV:
        //LUIDebug(Hint) LUI_FRAMEID << e.type << endl;
        //return Event_Accept;
        break;
    case UI::MouseEvent::Event_MouseWheelH:
        LUIDebug(Hint) LUI_FRAMEID << e.type << endl;
        break;
    case UI::MouseEvent::Event_MouseEnter:
        break;
    case UI::MouseEvent::Event_MouseLeave:
        break;
    case UI::MouseEvent::Event_MouseMove:
        break;
    case UI::MouseEvent::Event_LButtonDown:
    {
        //int* ptr = nullptr;
        //ptr[12] = 0;
    }
        break;
    case UI::MouseEvent::Event_LButtonUp:
        break;
    case UI::MouseEvent::Event_RButtonDown:
        break;
    case UI::MouseEvent::Event_RButtonUp:
        break;
    case UI::MouseEvent::Event_MButtonDown:
        break;
    case UI::MouseEvent::Event_MButtonUp:
        break;
    }
    return Super::DoMouseEvent(e);
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UITest::Render() const noexcept {
    return Super::Render();
}

/// <summary>
/// update this instance.
/// </summary>
/// <returns></returns>
void UI::UITest::Update() noexcept {
    return Super::Update();
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::UITest::Recreate() noexcept -> Result {
    return Super::Recreate();
}

#endif