﻿#include <control/ui_control_state.h>


/// <summary>
/// Initializes a new instance of the <see cref="CtrlState"/> struct.
/// </summary>
void UI::CtrlState::Init() noexcept {
    static_assert(sizeof(CtrlState) == sizeof(uint32_t), "bad size");
    directly_managed = false;
    child_i_changed = true;
    in_update_list = false;
    world_changed = false;
    layout_orient = false;
    layout_custom = false;
    attachment = false;
    layout_dir = false;
    //updated = false;
    dirty = false;
    level = 0;
    inited = false;
    in_dtor = false;

    defaultable = false;
    focusable = false;
    /*
    minsize_changed:
    子控件增删换位
    子控件最小大小修改
    */
}