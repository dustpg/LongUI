﻿#include <control/ui_control_state.h>


/// <summary>
/// Initializes a new instance of the <see cref="CtrlState"/> struct.
/// </summary>
void UI::CtrlState::Init() noexcept {
    visible = true;
    level = 0;
    static_assert(sizeof(CtrlState) == sizeof(uint32_t), "bad size");
    directly_managed = false;
    child_i_changed = true;
    in_update_list = false;
    world_changed = false;
    layout_custom = false;
    gui_event_to_parent = false;
    style_state_changed = false;
    attachment = false;
    layout_dir = false;
    //updated = false;
    dirty = false;
    orient = false;
    inited = false;
    in_dtor = false;
    atomicity = false;

    focusable = false;
    defaultable = false;
    public_container = false;
    delete_later = false;
    /*
    minsize_changed:
    子控件增删换位
    子控件最小大小修改
    */
}