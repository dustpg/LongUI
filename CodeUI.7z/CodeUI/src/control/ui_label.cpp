﻿#include <control/ui_label.h>
#include <control/ui_ctrlmeta.h>
#include <debugger/ui_debug.h>


// ui namespace
namespace UI {
    // UILabel类 元信息
    LUI_CONTROL_META_INFO(UILabel, "label");
}



/// <summary>
/// Initializes a new instance of the <see cref="UILabel"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UILabel::UILabel(UIControl* parent) noexcept : Super(parent) {
    // 初始化文本属性
    m_tfBuffer.text = {};
    m_tfBuffer.text.color.a = 1.f;
    m_tfBuffer.font = {};
    // 链接缓存
    UILabel* const nilobj = nullptr;
    const auto style_offset = reinterpret_cast<char*>(&nilobj->m_oStyle);
    const auto tfbuf_offset = reinterpret_cast<char*>(&nilobj->m_tfBuffer);
    const auto offset_tf = tfbuf_offset - style_offset;
    m_oStyle.offset_tf = static_cast<uint16_t>(offset_tf);
    // 写入默认外间距
    m_oBox.margin.top = DEFUALT_MARGIN_TOP;
    m_oBox.margin.left = DEFUALT_MARGIN_LEFT;
    m_oBox.margin.right = DEFUALT_MARGIN_RIGHT;
    m_oBox.margin.bottom = DEFUALT_MARGIN_BOTTOM;
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UILabel"/> class.
/// </summary>
/// <returns></returns>
UI::UILabel::~UILabel() noexcept {
}


/// <summary>
/// Updates this instance.
/// </summary>
/// <returns></returns>
void  UI::UILabel::Update() noexcept {
    // TODO: 处理BOX修改 SpecifyMinContectSize

    // 检查到大小修改
    if (this->is_size_changed()) {
        m_text.Resize(this->GetBox().GetContentSize());
    }
    // 父类修改
    Super::Update();
    // 次帧刷新
    //this->NextUpdate();
    // 处理大小修改
    this->size_change_handled();
}

#if 0
/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UILabel::DoEvent(
    UIControl* sender, 
    const EventArg& e) noexcept -> EventAccept {
    // 初始化
    if (e.nevent == NoticeEvent::Event_Initialize) {
        // 无效尝试使用空字符串初始化
        if (!m_text) this->SetText(L"", size_t{});
    }
    // 基类处理
    return Super::DoEvent(sender, e);
}
#endif

/// <summary>
/// Sets the text.
/// </summary>
/// <param name="str">The string.</param>
/// <param name="len">The length.</param>
void UI::UILabel::SetText(str_t str, size_t len) noexcept {
    auto hr = m_text.SetText(str, len);
    const auto size = m_text.GetSize();
    this->SpecifyMinContectSize({
        std::ceil(size.width),
        std::ceil(size.height)
    });
    // TODO: 1.是否需要std::ceil, 2.hr错误处理
    assert(hr);
}

/// <summary>
/// Adds the attribute.
/// </summary>
/// <param name="attr">The attribute.</param>
/// <returns></returns>
void UI::UILabel::add_attribute(const StrAttribute& attr) noexcept {
    // 新增属性列表
    constexpr auto BKDR_ACCESSKEY   = 0xba56ab7b_ui32;
    assert(!"UIControl already BKDR_ACCESSKEY");
    // 分类讨论
    switch (attr.bkdr_key)
    {
    case BKDR_ACCESSKEY:
        // 访问按键, 仅支持ASCII(严格情况A-Z)
        if (attr.value.begin() != attr.value.end()) {
            const int8_t akey = *attr.value.begin();
            m_accesskey = akey >= 0 ? akey : 0;
        }
        return;
    default:
        // 其他情况, 交给基类处理
        return Super::add_attribute(attr);
    }
}

