﻿#include <control/ui_box_layout.h>
#include <control/ui_ctrlmeta.h>

#include <algorithm>
#include <cassert>



// ui namespace
namespace UI {
    // UIVBoxLayout类 元信息
    LUI_CONTROL_META_INFO(UIVBoxLayout, "vbox");
    // UIHBoxLayout类 元信息
    LUI_CONTROL_META_INFO(UIHBoxLayout, "hbox");
    // UIBoxLayout类 元信息
    LUI_CONTROL_META_INFO(UIBoxLayout, "box");
    // impl
    namespace impl {
        PCN_NOINLINE
        /// <summary>
        /// Gets the align factor.
        /// </summary>
        /// <param name="align">The align.</param>
        /// <returns></returns>
        auto get_align_factor(AttributeAlign align) noexcept {
            switch (align)
            {
            case UI::Align_Stretcht:
                return -1.0f;
            default: assert(!"error"); [[fallthrough]]
            case UI::Align_Baseline:[[fallthrough]]
            case UI::Align_Start:[[fallthrough]]
                return 0.0f;
            case UI::Align_Center:
                return 0.5f;
            case UI::Align_End:
                return 1.0f;
            }
        }
    }
}


/*/// <summary>
/// Refreshes the minimum size of the content.
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::refresh_min_content_size() noexcept {

}*/

PCN_NOINLINE
/// <summary>
/// Relayouts the vbox
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::relayout_v() noexcept {
    // - 获取剩余长度
    auto get_remain_length = [this](Size2F sb) noexcept {
        return sb.height - m_minScrollSize.height;
    };
    // - 位置下移
    auto pos_move_next = [](Point2F& pos, Size2F size) noexcept {
        pos.y += size.height;
    };
    // - 添加弹性
    auto add_flex = [](Size2F& size, float length) noexcept {
        size.height += length;
    };
    // - 尽可能扩大侧轴:
    auto try_fill_other = [](Size2F& size, Size2F maxs) noexcept {
        if (maxs.width > size.width) size.width = maxs.width;
    };
    // - 调整主轴对齐
    auto adjust_align = []() noexcept {
    };
    // - 调整侧轴对齐

    // - 对齐
    // 1. 遍历子控件, 将有效可变权重加起来
    const float flex_sum = this->SumChildrenFlex();
    // 2. 加入SB布局
    const auto remaining = this->layout_scroll_bar();
    // 3. 计算每权重长度
    const float len_in_unit = flex_sum > 0.f ?
        get_remain_length(remaining) / flex_sum : 0.f;
    Point2F pos = this->get_layout_position();
    // 4. 遍历控件
    for (auto& child : *this) {
        // 有效才处理
        if (child.IsVaildInLayout()) {
            // 先考虑使用最小尺寸
            auto size = child.GetMinSize();
            // 对应方向分别使用弹性布局
            add_flex(size, child.GetStyle().flex * len_in_unit);
            // 另一方方向尽可能扩大长度
            try_fill_other(size, remaining);
            // 但是不能超过本身限制
            size.width = std::min(child.GetMaxSize().width, size.width);
            size.height = std::min(child.GetMaxSize().height, size.height);
            // 调整位置大小
            child.SetPos(pos); this->resize_child(child, size);
            // 移动到下一个位置
            pos_move_next(pos, size);
        }
    }
}

PCN_NOINLINE
/// <summary>
/// Relayouts the h.
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::relayout_h() noexcept {
    // - 获取剩余长度
    auto get_remain_length = [this](Size2F sb) noexcept {
        return sb.width - m_minScrollSize.width;
    };
    // - 位置下移
    auto pos_move_next = [](Point2F& pos, Size2F size) noexcept {
        pos.x += size.width;
    };
    // - 添加弹性
    auto add_flex = [](Size2F& size, float length) noexcept {
        size.width += length;
    };
    // - 调整对齐
    auto adjust_align = [](Size2F& size, Size2F maxs, float f) noexcept {
        // 仅仅调整位置
        if (f >= 0.0f) {
            return Point2F{ 0.f, (maxs.height - size.height) * f };
        }
        // 仅仅调整大小
        else {
            if (maxs.height > size.height) size.height = maxs.height;
            return Point2F{ 0.f, 0.f };
        }
    };
    // 0. 计算预备数据
    const float align_factor = impl::get_align_factor(m_oStyle.attr.align);
    // 1. 遍历子控件, 将有效可变权重加起来
    const float flex_sum = this->SumChildrenFlex();
    // 2. 加入SB布局
    const auto remaining = this->layout_scroll_bar();
    // 3. 计算每权重长度
    const float len_in_unit = flex_sum > 0.f ?
        get_remain_length(remaining) / flex_sum : 0.f;
    Point2F pos = this->get_layout_position();
    // 4. 遍历控件
    for (auto& child : *this) {
        // 有效才处理
        if (child.IsVaildInLayout()) {
            // 先考虑使用最小尺寸
            auto size = child.GetMinSize();
            // 对应方向分别使用弹性布局
            add_flex(size, child.GetStyle().flex * len_in_unit);
            // 调整对齐
            const auto opos = adjust_align(size, remaining, align_factor);
            // 但是不能超过本身限制
            size.width = std::min(child.GetMaxSize().width, size.width);
            size.height = std::min(child.GetMaxSize().height, size.height);
            // 调整位置大小
            child.SetPos(pos + opos); this->resize_child(child, size);
            // 移动到下一个位置
            pos_move_next(pos, size);
        }
    }
}

/// <summary>
/// Relayouts this instance.
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::relayout() noexcept {

    /*
        偏向于小的大小进行布局

        A(0)__B(0)__C(0)    布局A时, 只有B, B权重0, 
                |___D(0)    没有设置最小, 则B设为0
                |___E(1)     

        B(0)__C(0)          布局B时, 有B,C,D, E权重1,
          |___D(0)          没有设置最小, 则E设为B一
          |___E(1)          样大小, 其余设为0

    */
    const auto ishor = m_state.layout_orient == Orient_Horizontal;
    return ishor ? this->relayout_h() : this->relayout_v();
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIBoxLayout::DoEvent(
    UIControl* sender, const EventArg& e) noexcept -> EventAccept {
    // ---------------- 刷新最小大小
    auto refresh_min = [this]() noexcept {
        // TODO: 添加滚动条判断???
        RectF nonc = this->GetBox().GetNonContect();
        Size2F edge = { nonc.left + nonc.right, nonc.top + nonc.bottom };
        const bool ishor = m_state.layout_orient == Orient_Horizontal;
        Size2F minsize = {};
        // 遍历控件
        for (auto& child : *this) {
            // 可见即可
            if (child.IsVaildInLayout()) {
                const auto ms = child.GetMinSize();
                // 水平布局
                if (ishor) {
                    minsize.width += ms.width;
                    minsize.height = std::max(minsize.height, ms.height);
                }
                // 垂直布局
                else {
                    minsize.height += ms.height;
                    minsize.width = std::max(minsize.width, ms.width);
                }
            }
        }
        m_minScrollSize = minsize;
        // 添加边界值
        minsize.width += edge.width;
        minsize.height += edge.height;
        // 更新值
        m_oStyle.minsize = minsize;
    };

    // ---------------- 事件处理分支
    switch (e.nevent)
    {
    case UI::NoticeEvent::Event_RefreshMinSize:
        refresh_min();
        return UI::Event_Accept;
    }
    return Super::DoEvent(sender, e);
}


/// <summary>
/// Initializes a new instance of the <see cref="UIBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIBoxLayout::UIBoxLayout(UIControl* parent) noexcept : Super(parent) {
}

/// <summary>
/// Finalizes an instance of the <see cref="UIBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIBoxLayout::~UIBoxLayout() noexcept {
}

/// <summary>
/// Sets the orient.
/// </summary>
/// <param name="o">The o.</param>
/// <returns></returns>
void UI::UIBoxLayout::SetOrient(AttributeOrient o) noexcept {
    const auto booooool = (o & 1) == 1;
    if (booooool != m_state.layout_orient) {
        m_state.layout_orient = booooool;
        this->NeedRelayout();
    }
}


/// <summary>
/// Initializes a new instance of the <see cref="UIVBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIVBoxLayout::UIVBoxLayout(UIControl* parent) noexcept : Super(parent) {
    m_state.layout_orient = Orient_Vertical;
}


/// <summary>
/// Finalizes an instance of the <see cref="UIVBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIVBoxLayout::~UIVBoxLayout() noexcept {
}

/// <summary>
/// Initializes a new instance of the <see cref="UIHBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIHBoxLayout::UIHBoxLayout(UIControl* parent) noexcept : Super(parent) {
    m_state.layout_orient = Orient_Horizontal;
}


/// <summary>
/// Finalizes an instance of the <see cref="UIHBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIHBoxLayout::~UIHBoxLayout() noexcept {
}
