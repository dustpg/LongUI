﻿#include <control/ui_box_layout.h>

#include <algorithm>
#include <cassert>

/*/// <summary>
/// Refreshes the minimum size of the content.
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::refresh_min_content_size() noexcept {

}*/

/// <summary>
/// Relayouts this instance.
/// </summary>
/// <returns></returns>
void UI::UIBoxLayout::relayout() noexcept {
    /*
        偏向于小的大小进行布局

        A(0)__B(0)__C(0)    布局A时, 只有B, B权重0, 
                |___D(0)    没有设置最小, 则B设为0
                |___E(1)     

        B(0)__C(0)          布局B时, 有B,C,D, E权重1,
          |___D(0)          没有设置最小, 则E设为B一
          |___E(1)          样大小, 其余设为0

    */
    // 1. 遍历子控件, 将有效可变权重加起来
    float flex_sum = 0.f;
    for (auto& child : *this)
        if (child.IsVaildInLayout())
            flex_sum += child.GetStyle().flex;
    // 2. 加入SB布局
    const bool horlay = m_state.layout_orient == Orient_Horizontal;
    const auto remaining = this->layout_scroll_bar();
    const auto remainw = remaining.width - m_minContentSize.width;
    const auto remainh = remaining.height - m_minContentSize.height;
    // 3. 计算每权重宽度
    Size2F per_unit = {};
    if (flex_sum > 0.f) {
        if (remainw > 0.f) per_unit.width = remainw / flex_sum;
        if (remainh > 0.f) per_unit.height = remainh / flex_sum;
    }
    Point2F pos = this->get_layout_position();
    // 遍历控件
    UIControl* last = nullptr;
    for (auto& child : *this) {
        // 可见才处理
        if (child.IsVaildInLayout()) {
            last = &child;
            auto size = child.GetMinSize();
            size.width += child.GetStyle().flex * per_unit.width;
            size.height += child.GetStyle().flex * per_unit.height;
            size.width = std::min(child.GetMaxSize().width, size.width);
            size.height = std::min(child.GetMaxSize().height, size.height);
            child.SetPos(pos); this->resize_child(child, size);
            horlay ? pos.x += size.width : pos.y += size.height;
        }
    }
    // XUL兼容: 垂直布局中, 宽度尽可能大
    if (!horlay && last && remainw > 0.f) {
        this->resize_child(*last, {
            last->GetSize().width + remainw, last->GetSize().height
        });
    }
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIBoxLayout::DoEvent(
    UIControl* sender, const EventArg& e) noexcept -> EventAccept {
    // ---------------- 刷新最小大小
    auto refresh_min = [this]() noexcept {
        // TODO: 添加滚动条判断???
        RectF nonc = this->GetBox().GetNonContect();
        Size2F edge = { nonc.left + nonc.right, nonc.top + nonc.bottom };
        const bool ishor = m_state.layout_orient == Orient_Horizontal;
        Size2F minsize = {};
        // 遍历控件
        for (auto& child : *this) {
            // 可见即可
            if (child.IsVaildInLayout()) {
                const auto ms = child.GetMinSize();
                // 水平布局
                if (ishor) {
                    minsize.width += ms.width;
                    minsize.height = std::max(minsize.height, ms.height);
                }
                // 垂直布局
                else {
                    minsize.height += ms.height;
                    minsize.width = std::max(minsize.width, ms.width);
                }
            }
        }
        m_minContentSize = minsize;
        // 添加边界值
        minsize.width += edge.width;
        minsize.height += edge.height;
        // 更新值
        m_oStyle.minsize = minsize;
    };

    // ---------------- 事件处理分支
    switch (e.nevent)
    {
    case UI::NoticeEvent::Event_RefreshMinSize:
        refresh_min();
        return UI::Event_Accept;
    }
    return Super::DoEvent(sender, e);
}


/// <summary>
/// Initializes a new instance of the <see cref="UIBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIBoxLayout::UIBoxLayout(UIControl* parent) noexcept : Super(parent) {
}

/// <summary>
/// Finalizes an instance of the <see cref="UIBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIBoxLayout::~UIBoxLayout() noexcept {
}

/// <summary>
/// Sets the orient.
/// </summary>
/// <param name="o">The o.</param>
/// <returns></returns>
void UI::UIBoxLayout::SetOrient(AttributeOrient o) noexcept {
    const auto booooool = (o & 1) == 1;
    if (booooool != m_state.layout_orient) {
        m_state.layout_orient = booooool;
        this->NeedRelayout();
    }
}


/// <summary>
/// Initializes a new instance of the <see cref="UIVBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIVBoxLayout::UIVBoxLayout(UIControl* parent) noexcept : Super(parent) {
    m_state.layout_orient = Orient_Vertical;
}


/// <summary>
/// Finalizes an instance of the <see cref="UIVBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIVBoxLayout::~UIVBoxLayout() noexcept {
}

/// <summary>
/// Initializes a new instance of the <see cref="UIHBoxLayout"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIHBoxLayout::UIHBoxLayout(UIControl* parent) noexcept : Super(parent) {
    m_state.layout_orient = Orient_Horizontal;
}


/// <summary>
/// Finalizes an instance of the <see cref="UIHBoxLayout"/> class.
/// </summary>
/// <returns></returns>
UI::UIHBoxLayout::~UIHBoxLayout() noexcept {
}
