﻿// Gui
#include <control/ui_scale.h>
#include <control/ui_image.h>
#include <resource/ui_image.h>
#include <container/pod_hash.h>
#include <control/ui_ctrlmeta.h>
// C++
#include <cassert>
#include <algorithm>


// ui namespace
namespace UI {
    // UIImage类 元信息
    LUI_CONTROL_META_INFO(UIScale, "scale");
}

/// <summary>
/// Initializes a new instance of the <see cref="UIScale"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIScale::UIScale(UIControl* parent) noexcept 
    : Super(parent), thumb(this) {
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIScale"/> class.
/// </summary>
/// <returns></returns>
UI::UIScale::~UIScale() noexcept {
    // 额外处理
    m_state.in_dtor = true;
}

/// <summary>
/// Updates this instance.
/// </summary>
/// <returns></returns>
void UI::UIScale::Update() noexcept {
    // 污了
    if (m_state.dirty) {
        // 本类只能存在唯一的子元素(thumb)
        assert(this->GetCount() == 1 && "thumb ony");
        assert(*this->begin() == this->thumb && "thumb ony");
        this->refresh_thumb_postion();
        m_state.dirty = true;
    }
    return Super::Update();
}

/// <summary>
/// Updates the thumb postion.
/// </summary>
/// <returns></returns>
void UI::UIScale::refresh_thumb_postion() noexcept {
    const auto csize = this->GetBox().GetContentSize();
    const auto ssize = this->thumb.GetSize();
    assert(m_fValue >= m_fMin && m_fValue <= m_fMax && "out of range");
    const auto normalization = (m_fValue - m_fMin) / (m_fMax - m_fMin);
    Point2F pos{ 0 };
    // 水平方向
    if (this->GetOrient() == Orient_Horizontal) {
        const auto width = csize.width - ssize.width;
        pos.x = width * normalization;
    }
    // 垂直方向
    else {
        const auto height = csize.height - ssize.height;
        pos.y = height * normalization;
    }
    // 设置位置
    this->thumb.SetPos(pos);
}

/// <summary>
/// Sets the value.
/// </summary>
/// <param name="value">The value.</param>
/// <returns></returns>
void UI::UIScale::SetValue(float value) noexcept {
    const auto newv = std::max(std::min(value, m_fMax), m_fMin);
    // 差不多?
    if (IsSameInGuiLevel(value, m_fValue)) return;
    // TODO: VALUE CHANGED
    m_fValue = value;
    this->refresh_thumb_postion();
    // TODO: 需要更新
}

/// <summary>
/// Sets the minimum.
/// </summary>
/// <param name="value">The value.</param>
/// <returns></returns>
void UI::UIScale::SetMin(float value) noexcept {
    m_fMin = value;
    // 越界检查
    if (value > m_fValue) this->SetValue(value);
    // TODO: 需要更新
}

/// <summary>
/// Sets the maximum.
/// </summary>
/// <param name="value">The value.</param>
/// <returns></returns>
void UI::UIScale::SetMax(float value) noexcept {
    m_fMax = value;
    // 越界检查
    if (value < m_fValue) this->SetValue(value);
    // TODO: 需要更新
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIScale::DoEvent(UIControl * sender,
                          const EventArg & e) noexcept -> EventAccept {
    // 初始化
    if (e.nevent == NoticeEvent::Event_Initialize) {
        // 还未指定的情况下
        if (m_oStyle.appearance == Appearance_None) {
            // 根据方向确定初始化类型
            if (this->GetOrient() == Orient_Horizontal) {
                m_oStyle.appearance = Appearance_ScaleH;
                this->thumb.Set_test(Appearance_ScaleThumbH);
            }
            // 垂直方向
            else {
                m_oStyle.appearance = Appearance_ScaleV;
                this->thumb.Set_test(Appearance_ScaleThumbV);
            }
        }
    }
    // 基类处理
    return Super::DoEvent(sender, e);
}
