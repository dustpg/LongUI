﻿// Gui
/*#include <input/ui_kminput.h>
#include <control/ui_scale.h>
#include <control/ui_image.h>
#include <resource/ui_image.h>
#include <container/pod_hash.h>*/
#include <core/ui_manager.h>
#include <control/ui_textbox.h>
#include <control/ui_ctrlmeta.h>
// Private
//#include "../private/ui_private_control.h"
// C++
#include <cassert>
#include <algorithm>

#ifndef NDEBUG
#include <debugger/ui_debug.h>
#endif

// TextBC
#include <../TextBC/bc_txtdoc.h>

// ui namespace
namespace UI {
    // UITextBox类 元信息
    LUI_CONTROL_META_INFO(UITextBox, "textbox");
}

/// <summary>
/// Initializes a new instance of the <see cref="UITextBox" /> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UITextBox::UITextBox(UIControl* parent) noexcept : Super(parent) {
    LUI_INIT_META_POINTER;
    this->create_private();
}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UITextBox"/> class.
/// </summary>
/// <returns></returns>
UI::UITextBox::~UITextBox() noexcept {
    this->delete_private();
}

/// <summary>
/// Updates this instance.
/// </summary>
/// <returns></returns>
void UI::UITextBox::Update() noexcept {
    // 污了
    return Super::Update();
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UITextBox::DoEvent(UIControl * sender,
                          const EventArg & e) noexcept -> EventAccept {
    // 初始化
    if (e.nevent == NoticeEvent::Event_Initialize) {
    }
    // 基类处理
    return Super::DoEvent(sender, e);
}


/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UITextBox::DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept {
    Point2F pos = { e.px, e.py }; this->MapFromWindow(pos);
    switch (e.type)
    {
    case UI::MouseEvent::Event_MouseWheelV:
        break;
    case UI::MouseEvent::Event_MouseWheelH:
        break;
    case UI::MouseEvent::Event_MouseEnter:
        break;
    case UI::MouseEvent::Event_MouseLeave:
        break;
    case UI::MouseEvent::Event_MouseMove:
        break;
    case UI::MouseEvent::Event_LButtonDown:
        this->private_mouse_down(pos);
        return Event_Accept;
    case UI::MouseEvent::Event_LButtonUp:
        break;
    case UI::MouseEvent::Event_RButtonDown:
        break;
    case UI::MouseEvent::Event_RButtonUp:
        break;
    case UI::MouseEvent::Event_MButtonDown:
        break;
    case UI::MouseEvent::Event_MButtonUp:
        break;
    default:
        break;
    }
    return Event_Ignore;
}


#if 0
/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UITextBox::DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept {
    // 鼠标相对本控件位置
    Point2F pt_this = { e.px, e.py };
    this->MapFromWindow(pt_this);

    // 移动滑块
    auto hold_lbtn_move = [this, &pt_this]() noexcept->EventAccept {
        if (m_pHovered) {
            assert(m_pHovered == &this->thumb);
            const auto csize = this->GetBox().GetContentSize();
            const auto ssize = this->thumb.GetSize();
            const int i = this->GetOrient() == Orient_Horizontal ? 0 : 1;
            const auto width = i[&csize.width] - i[&ssize.width];
            const auto x = i[&pt_this.x] - m_fClickOffset;
            const auto value = (x / width) * (m_fMax - m_fMin) + m_fMin;
            this->SetValue(value);
            return Event_Accept;
        }
        else return Event_Ignore;
    };


    // 基类处理基本消息
    switch (e.type)
    {
    case MouseEvent::Event_MouseMove:
        // 鼠标移动 + 左键按下
        if (CUIInputKM::Instance().IsMbPressed(CUIInputKM::MB_L)) {
            return hold_lbtn_move();
        }
        break;
    case MouseEvent::Event_LButtonDown:
        this->mouse_click(pt_this);
        break;
    }
    // 基类处理剩余消息
    return Super::DoMouseEvent(e);
}

/// <summary>
/// Mouses the click.
/// </summary>
/// <returns></returns>
void UI::UITextBox::mouse_click(Point2F pt) noexcept {
    const auto thumb_pos = this->thumb.GetPos();
    // 在滑块的上方
    if (m_pHovered) {
        assert(*m_pHovered == this->thumb);
        if (this->GetOrient() == Orient_Horizontal)
            m_fClickOffset = pt.x - thumb_pos.x;
        else
            m_fClickOffset = pt.y - thumb_pos.y;
    }
    // 在逻辑前方
    else if (pt.x < thumb_pos.x || pt.y < thumb_pos.y) {
        this->DecreasePage();
    }
    // 在逻辑后方
    else {
        this->IncreasePage();
    }
}
#endif

