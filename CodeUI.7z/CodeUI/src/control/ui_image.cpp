﻿#include <control/ui_image.h>
#include <control/ui_ctrlmeta.h>


// ui namespace
namespace UI {
    // UIImage类 元信息
    LUI_CONTROL_META_INFO(UIImage, "image");
}


/// <summary>
/// Finalizes an instance of the <see cref="UIImage"/> class.
/// </summary>
/// <returns></returns>
UI::UIImage::~UIImage() noexcept {
}


/// <summary>
/// Initializes a new instance of the <see cref="UIImage"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIImage::UIImage(UIControl* parent) noexcept : Super(parent) {

}
