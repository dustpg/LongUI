﻿// ui
#include <core/ui_manager.h>
#include <control/ui_image.h>
#include <resource/ui_image.h>
#include <container/pod_hash.h>
#include <control/ui_ctrlmeta.h>


// ui namespace
namespace UI {
    // UIImage类 元信息
    LUI_CONTROL_META_INFO(UIImage, "image");
}

/// <summary>
/// Initializes a new instance of the <see cref="UIImage"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIImage::UIImage(UIControl* parent) noexcept : Super(parent) {

}

// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIImage"/> class.
/// </summary>
/// <returns></returns>
UI::UIImage::~UIImage() noexcept {
}


/// <summary>
/// Adds the attribute.
/// </summary>
/// <param name="attr">The attribute.</param>
/// <returns></returns>
void UI::UIImage::add_attribute(const StrAttribute& attr) noexcept {
    // 本控件添加属性
    constexpr auto BKDR_SRC = 0x001E57C4_ui32;
    // 计算HASH
    const auto code = UI::BKDRHash(attr.key.first, attr.key.second);
    // 图片源属性
    if (code == BKDR_SRC) {
        const auto b = attr.value.begin();
        const auto e = attr.value.end();
        const auto t = ResourceType::Type_Image;
        const auto id = UIManager.LoadResource(b, e, t);
        // TODO: 错误处理
        assert(id && "bad id");
        m_idSrc.SetId(id);
    }
    else Super::add_attribute(attr);
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::UIImage::Recreate() noexcept->Result {
    // 获取Image对象
    if (m_idSrc.GetId()) {
        const auto obj = m_idSrc.GetResoureceObj();
        m_pSharedSrc = static_cast<CUIImage*>(obj);
        assert(m_pSharedSrc && "bug");
    }
    // 基类处理
    return Super::Recreate();
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
void UI::UIImage::Render() const noexcept {
    // 渲染背景
    Super::Render();
    // 图像有效
    if (m_idSrc.GetId()) {
        assert(m_pSharedSrc && "bug");
        m_pSharedSrc->Render(
            UIManager.Ref2DRenderer()
        );
    }
}

