﻿#include <control/ui_scroll_area.h>
#include <control/ui_scroll_bar.h>
#include <control/ui_ctrlmeta.h>
#include <algorithm>


// ui namespace
namespace UI {
    // UIScrollArea类 元信息
    LUI_CONTROL_META_INFO(UIScrollArea, "scrollrea");
}

/// <summary>
/// Initializes a new instance of the <see cref="UIScrollArea"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIScrollArea::UIScrollArea(UIControl* parent) noexcept : Super(parent) {
    // overflow: auto, 滚动条会显示在布局中
    // overflow: scroll, 滚动条会显示在布局外
    m_szSingleStep = { 16, 16 };
    m_minScrollSize = {};
}


/// <summary>
/// Finalizes an instance of the <see cref="UIScrollArea"/> class.
/// </summary>
/// <returns></returns>
UI::UIScrollArea::~UIScrollArea() noexcept {
#ifndef NDEBUG
    m_pVerticalSB = nullptr;
    m_pVerticalSB++;
    m_pHorizontalSB = nullptr;
    m_pHorizontalSB++;
#endif
}

/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIScrollArea::DoMouseEvent(const MouseEventArg & e) noexcept -> EventAccept {
    // -------------- 滚动
    auto wheel = [&, this](int index) noexcept ->EventAccept {
        // 检查内容区域是否满足
        const auto content_size = this->GetBox().GetContentSize();
        const auto cremainw = index[&m_minScrollSize.width] - index[&content_size.width];
        if (cremainw <= 0.f) return Event_Ignore;
        // 位置变动检查
        auto& pos_o = index[&m_ptChildOffset.x];
        auto pos = pos_o - index[&m_szSingleStep.width] * e.wheel;
        pos = std::max(std::min(pos, cremainw), 0.f);
        // 已经修改
        EventAccept accept = Event_Ignore;
        if (pos != pos_o) {
            pos_o = pos;
            accept = Event_Accept;
            /*if (this->GetCount()) {
                auto&first = *this->begin();
                this->mark_child_world_changed(first);
                first.NeedUpdate();
            }*/
            m_state.world_changed = true;
            this->NeedUpdate();
        }
        // 同步SB
        this->sync_scroll_bar();
        return accept;
    };
    // -------------- 分类判断
    switch (e.type)
    {
    case UI::MouseEvent::Event_MouseWheelV:
        // 检查是否有子控件处理(super有, 也可以现写)
        return Super::DoMouseEvent(e) == Event_Ignore ?
            wheel(1) : Event_Accept;
    case UI::MouseEvent::Event_MouseWheelH:
        // 检查是否有子控件处理(super有, 也可以现写)
        return Super::DoMouseEvent(e) == Event_Ignore ?
            wheel(0) : Event_Accept;
    }
    // 其他未处理事件交给super处理
    return Super::DoMouseEvent(e);
}

/// <summary>
/// Updates this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::Update() noexcept {
    // 污了?
    if (m_state.dirty) {
        // 存在子控件才计算
        if (this->GetCount()) {
            // 更新布局
            this->relayout();
            // 更新子控件
            for (auto& child : *this)
                child.NeedUpdate();
        }
        // 不污
        m_state.dirty = false;
        // 这里, 世界不再改变
        //assert(m_state.world_changed == false);
    }
    // 链式调用
    Super::Update();
}

/// <summary>
/// Relayouts this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::relayout() noexcept {
    // TODO: 基本布局
}

/// <summary>
/// Sums the children flex.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::SumChildrenFlex() const noexcept -> float {
    float sum = 0.f;
    for (auto& child : *this) if (child.IsVaildInLayout())
        sum += child.GetStyle().flex;
    return sum;
}

/// <summary>
/// Synchronizes the scroll bar.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::sync_scroll_bar() noexcept {
    const bool hok = m_pHorizontalSB && m_pHorizontalSB->IsVisible();
    const bool vok = m_pVerticalSB && m_pVerticalSB->IsVisible();
    // 交界区
    Size2F cross_zone;
    cross_zone.width = vok ? m_pVerticalSB->GetMinSize().width : 0.f;
    cross_zone.height = hok ? m_pHorizontalSB->GetMinSize().height : 0.f;
    auto csize = m_oBox.GetContentSize();
    // 水平滚动条
    if (hok) {
        m_pHorizontalSB->SetValue(m_ptChildOffset.x);
        m_pHorizontalSB->SetPageStep(csize.width - cross_zone.width);
        m_pHorizontalSB->SetSingleStep(m_szSingleStep.width);
        m_pHorizontalSB->SetMax(m_minScrollSize.width - csize.width);
    }
    // 垂直滚动条
    if (vok) {
        m_pVerticalSB->SetValue(m_ptChildOffset.y);
        m_pVerticalSB->SetPageStep(csize.height - cross_zone.height);
        m_pVerticalSB->SetSingleStep(m_szSingleStep.height);
        m_pVerticalSB->SetMax(m_minScrollSize.height - csize.height);
    }
}

/// <summary>
/// Layouts the size of the content.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::layout_scroll_bar() noexcept -> Size2F {
    const auto scroll = m_minScrollSize;
    // 创建SB
    auto create_sb = [this](AttributeOrient o) noexcept ->UIScrollBar* {
        if (auto bar = new(std::nothrow) UIScrollBar{ o, nullptr }) {
#ifndef NDEBUG
            bar->name_dbg = "sbar";
#endif
            this->add_direct_child(*bar);
            this->set_child_fixed_attachment(*bar);
            //bar->Init();
            return bar;
        }
        return nullptr;
    };
    // 水平SB大小/高度
    auto get_hsb_size = [this]() noexcept ->float {
        if (m_pHorizontalSB && m_pHorizontalSB->IsVisible()) {
            return m_pHorizontalSB->GetMinSize().height;
        }
        return 0.0f;
    };
    // 垂直SB大小/宽度
    auto get_vsb_size = [this]() noexcept ->float {
        if (m_pVerticalSB && m_pVerticalSB->IsVisible()) {
            return m_pVerticalSB->GetMinSize().width;
        }
        return 0.0f;
    };
    // 设置SB不可视
    auto set_sb_visible = [](UIScrollBar* sb_ptr, bool visible) noexcept {
        if (sb_ptr) sb_ptr->SetVisible(visible);
    };
    // 保证垂直SB
    auto ensure_vsb = [=]() noexcept {
        // TODO: 看情况是不是创建
        if (!m_pVerticalSB) m_pVerticalSB = create_sb(Orient_Vertical);
    };
    // 保证水平SB
    auto ensure_hsb = [=]() noexcept {
        // TODO: 看情况是不是创建
        if (!m_pHorizontalSB) m_pHorizontalSB = create_sb(Orient_Horizontal);
    };
    // 内容大小
    const auto content_size = this->GetBox().GetContentSize();
    constexpr float MDW = MIN_SCROLLBAR_DISPLAY_SIZE;
    constexpr float MDH = MIN_SCROLLBAR_DISPLAY_SIZE;
    set_sb_visible(m_pHorizontalSB, false);
    set_sb_visible(m_pVerticalSB, false);
    // 太小不显示
    if (content_size.width > MDW && content_size.height > MDH) {
        // 4种情况
        if (scroll.width <= content_size.width) {
            // 1. SW <= CW && SH <= CH
            if (scroll.height <= content_size.height) {
                // HSB-X    VSB-X
                set_sb_visible(m_pHorizontalSB, false);
                set_sb_visible(m_pVerticalSB, false);
            }
            // 2. SW <= CW && SH > CH
            else {
                ensure_vsb();
                // VSB-O
                set_sb_visible(m_pVerticalSB, true);
                // 2-1: SW + SB > CW : HSB-O/X
                set_sb_visible(m_pHorizontalSB, scroll.width + get_vsb_size() > content_size.width);
            }
        }
        else {
            // 3. SW > CW && SH > CW
            if (scroll.height > content_size.height) {
                // HSB-O    VSB-O
                ensure_hsb();  ensure_vsb();
                set_sb_visible(m_pVerticalSB, true);
                set_sb_visible(m_pHorizontalSB, true);
            }
            // 4  SW > CW && SH <= CW
            else {
                ensure_hsb();
                // HSB-O
                set_sb_visible(m_pHorizontalSB, true);
                // 2-1: SW + SB > CW : HSB-O/X
                set_sb_visible(m_pVerticalSB, scroll.height + get_hsb_size() > content_size.height);
            }
        }
    }
    const bool hok = m_pHorizontalSB && m_pHorizontalSB->IsVisible();
    const bool vok = m_pVerticalSB && m_pVerticalSB->IsVisible();
    // 交界区
    Size2F cross_zone;
    cross_zone.width = vok ? m_pVerticalSB->GetMinSize().width : 0.f;
    cross_zone.height = hok ? m_pHorizontalSB->GetMinSize().height : 0.f;
    //const bool cross_zone = false;
    // 设置HSB位置: 底部
    if (hok) {
        m_pHorizontalSB->Resize({ 
            content_size.width - cross_zone.width,
            cross_zone.height 
        });
        m_pHorizontalSB->SetPos({ 
            m_state.layout_dir == Dir_Normal ? 0.f : cross_zone.width,
            content_size.height - cross_zone.height 
        });
    }
    // 设置VSB位置: 正向-右侧 反向-左侧
    if (vok) {
        m_pVerticalSB->Resize({ 
            cross_zone.width, 
            content_size.height - cross_zone.height,
        });
        Point2F pos = {};
        if (m_state.layout_dir == Dir_Normal)
            pos.x = content_size.width - cross_zone.width;
        m_pVerticalSB->SetPos(pos);
    }
    // 同步
    this->sync_scroll_bar();
    return { content_size.width - get_vsb_size() , content_size.height - get_hsb_size() };
}

/// <summary>
/// Gets the layout position.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::get_layout_position() const noexcept -> Point2F {
    const auto base = this->GetBox().GetContentPos();
    //const auto base = Point2F{};
    // 正向- 左上角
    if (m_state.layout_dir == Dir_Normal) {

    }
    // 反向- 左上角+[VSB, 0]
    else {
        if (m_pVerticalSB && m_pVerticalSB->IsVisible()) {
            return base + Point2F{ m_pVerticalSB->GetSize().width, 0.f };
        }
    }
    return base;
}