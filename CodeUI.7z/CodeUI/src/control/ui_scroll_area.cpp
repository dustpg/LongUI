﻿// Gui
#include <control/ui_scroll_area.h>
#include <control/ui_scroll_bar.h>
#include <control/ui_ctrlmeta.h>
#include <core/ui_manager.h>
#include <luiconf.h>
// C++
#include <algorithm>
// Private
#include "../private/ui_private_control.h"


// ui namespace
namespace UI {
    // UIScrollArea类 元信息
    LUI_CONTROL_META_INFO(UIScrollArea, "scrollarea");
}

/// <summary>
/// Initializes a new instance of the <see cref="UIScrollArea"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIScrollArea::UIScrollArea(UIControl* parent) noexcept : Super(parent) {
    LUI_INIT_META_POINTER;
    m_szLine = { 16, 16 };
    m_minScrollSize = {};
}


// super helper
#include "../private/ui_super.h"

/// <summary>
/// Finalizes an instance of the <see cref="UIScrollArea"/> class.
/// </summary>
/// <returns></returns>
UI::UIScrollArea::~UIScrollArea() noexcept {
#ifndef NDEBUG
    m_pVerticalSB = nullptr;
    m_pVerticalSB++;
    m_pHorizontalSB = nullptr;
    m_pHorizontalSB++;
#endif
}

/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="arg">The argument.</param>
/// <returns></returns>
auto UI::UIScrollArea::DoEvent(
    UIControl* sender, const EventArg& arg) noexcept -> EventAccept {
    if (arg.nevent == NoticeEvent::Event_UIEvent) {
        assert(sender && "sender in gui event cannot be null");
        switch (static_cast<const EventGuiArg&>(arg).GetEvent())
        {
        return_changed:
            // SB修改之后调用
            m_state.world_changed = true;
            this->NeedUpdate();
            return Event_Accept;
        case GuiEvent::Event_Change:
            if (sender == m_pHorizontalSB) {
                m_ptChildOffset.x = m_pHorizontalSB->GetValue();
                goto return_changed;
            }
            else if (sender == m_pVerticalSB) {
                m_ptChildOffset.y = m_pVerticalSB->GetValue();
                goto return_changed;
            }
        }
    }
    // 基类处理消息
    return Super::DoEvent(sender, arg);
}

/// <summary>
/// Does the wheel.
/// </summary>
/// <param name="index">The index.</param>
/// <param name="wheel">The wheel.</param>
/// <returns></returns>
auto UI::UIScrollArea::do_wheel(int index, float wheel) noexcept ->EventAccept {
    // 检查内容区域是否满足
    const auto content_size = this->GetBox().GetContentSize();
    const auto cremainw = index[&m_minScrollSize.width] - index[&content_size.width];
    if (cremainw <= 0.f) return Event_Ignore;
    // 位置变动检查
    auto& pos_o = index[&m_ptChildOffset.x];
    const auto line_height = UIManager.GetWheelScrollLines();
    auto pos = pos_o - index[&m_szLine.width] * wheel * line_height;
    pos = std::max(std::min(pos, cremainw), 0.f);
    EventAccept accept = Event_Ignore;
    // 已经修改
    if (pos != pos_o) {
        pos_o = pos;
        accept = Event_Accept;
        m_state.world_changed = true;
        this->NeedUpdate();
    }
    // 同步SB
    this->sync_scroll_bar();
    return accept;
}

/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIScrollArea::DoMouseEvent(const MouseEventArg & e) noexcept -> EventAccept {
    // 分类判断
    switch (e.type)
    {
    case UI::MouseEvent::Event_MouseWheelV:
        // 检查是否有子控件处理(super有, 也可以现写)
        return Super::DoMouseEvent(e) == Event_Ignore ?
            this->do_wheel(1, e.wheel) : Event_Accept;
    case UI::MouseEvent::Event_MouseWheelH:
        // 检查是否有子控件处理(super有, 也可以现写)
        return Super::DoMouseEvent(e) == Event_Ignore ?
            this->do_wheel(0, e.wheel) : Event_Accept;
    }
    // 其他未处理事件交给super处理
    return Super::DoMouseEvent(e);
}

/// <summary>
/// Updates this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::Update() noexcept {
    // 污了?
    if (m_state.dirty) {
        // 不污
        m_state.dirty = false;
        // 存在子控件才计算
        if (this->GetCount()) {
            // 更新布局
            this->relayout();
            // 更新子控件
            for (auto& child : *this)
                child.NeedUpdate();
        }
        // 这里, 世界不再改变
        //assert(m_state.world_changed == false);
    }
    // 链式调用
    Super::Update();
}

/// <summary>
/// Relayouts this instance.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::relayout() noexcept {
    // TODO: 基本布局
}

/// <summary>
/// Sums the children flex.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::SumChildrenFlex() const noexcept -> float {
    float sum = 0.f;
    for (auto& child : *this) if (child.IsVaildInLayout())
        sum += child.GetStyle().flex;
    return sum;
}

/// <summary>
/// Synchronizes the scroll bar.
/// </summary>
/// <returns></returns>
void UI::UIScrollArea::sync_scroll_bar() noexcept {
    const bool hok = m_pHorizontalSB && m_pHorizontalSB->IsVisible();
    const bool vok = m_pVerticalSB && m_pVerticalSB->IsVisible();
    // 交界区
    Size2F cross_zone;
    cross_zone.width = vok ? m_pVerticalSB->GetMinSize().width : 0.f;
    cross_zone.height = hok ? m_pHorizontalSB->GetMinSize().height : 0.f;
    auto csize = m_oBox.GetContentSize();
    // 水平滚动条
    if (hok) {
        m_pHorizontalSB->SetPageIncrement(csize.width - cross_zone.width);
        m_pHorizontalSB->SetMax(m_minScrollSize.width - csize.width);
        m_pHorizontalSB->SetValue(m_ptChildOffset.x);
        //m_pHorizontalSB->SetSingleStep(m_szSingleStep.width);
    }
    // 垂直滚动条
    if (vok) {
        m_pVerticalSB->SetPageIncrement(csize.height - cross_zone.height);
        m_pVerticalSB->SetMax(m_minScrollSize.height - csize.height);
        m_pVerticalSB->SetValue(m_ptChildOffset.y);
        //m_pVerticalSB->SetSingleStep(m_szSingleStep.height);
    }
}

/// <summary>
/// Layouts the hscrollbar.
/// </summary>
/// <param name="notenough">if set to <c>true</c> [notenough].</param>
/// <returns></returns>
auto UI::UIScrollArea::layout_hscrollbar(bool notenough) noexcept -> float {
    const auto overflow = this->GetStyle().overflow_x;
    // 检查绝不可能的情况
    const bool nosb = overflow & 1;
    if (nosb) return 0.0f;
    // 可能存在滚动条
    if (overflow == Overflow_Auto) {
        // 不够用就显示
        if (!notenough) {
            if (m_pHorizontalSB) m_pHorizontalSB->SetVisible(false);
            return 0.f;
        }
    }
    // 需要滚动条
    if (!m_pHorizontalSB) m_pHorizontalSB = this->create_scrollbar(Orient_Horizontal);
    return m_pHorizontalSB ? m_pHorizontalSB->GetStyle().minsize.height : 0.0f;
}

/// <summary>
/// Layouts the vscrollbar.
/// </summary>
/// <param name="notenough">if set to <c>true</c> [notenough].</param>
/// <returns></returns>
auto UI::UIScrollArea::layout_vscrollbar(bool notenough) noexcept -> float {
    const auto overflow = this->GetStyle().overflow_y;
    // 检查绝不可能的情况
    const bool nosb = overflow & 1;
    if (nosb) return 0.0f;
    // 可能存在滚动条
    if (overflow == Overflow_Auto) {
        // 不够用就显示
        if (!notenough) {
            if (m_pVerticalSB) m_pVerticalSB->SetVisible(false);
            return 0.f; 
        }
    }
    // 需要滚动条
    if (!m_pVerticalSB) m_pVerticalSB = this->create_scrollbar(Orient_Vertical);
    return m_pVerticalSB ? m_pVerticalSB->GetStyle().minsize.width : 0.0f;
}

/// <summary>
/// Creates the scrollbar.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::create_scrollbar(AttributeOrient o) noexcept -> UIScrollBar * {
    if (auto bar = new(std::nothrow) UIScrollBar{ o, nullptr }) {
#ifndef NDEBUG
        if (o == Orient_Horizontal)
            bar->name_dbg = "scrollarea::hscrollbar";
        else
            bar->name_dbg = "scrollarea::vscrollbar";
#endif
        this->add_direct_child(*bar);
        this->resize_child(*bar, {});
        this->set_child_fixed_attachment(*bar);
        PrivateControl::SetGuiEvent2Parent(*bar);
        //bar->Init();
        return bar;
    }
    return nullptr;
}

/// <summary>
/// Layouts the size of the content.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::layout_scroll_bar() noexcept -> Size2F {
    Size2F rv;
    constexpr float MDW = MIN_SCROLLBAR_DISPLAY_SIZE;
    constexpr float MDH = MIN_SCROLLBAR_DISPLAY_SIZE;
    // 内容大小
    const auto content_size = this->GetBox().GetContentSize();
    // 内容显示
    const auto scroll = m_minScrollSize;
    // 需要显示VSB
    const bool vsbdisplay = content_size.width > MDW &&
        scroll.height > content_size.height;
    // 需要显示HSB
    const bool hsbdisplay = content_size.height > MDW &&
        scroll.width > content_size.width;
    // 获取VSB长度
    const auto vsbar = this->layout_vscrollbar(vsbdisplay);
    // 获取HSB长度
    const auto hsbar = this->layout_hscrollbar(hsbdisplay);
    // 需要再次布局
    if (this->is_need_relayout()) return content_size;
    // 设置VSB位置: 正向-右侧 反向-左侧
    if (vsbar > 0.f) {
        resize_child(*m_pVerticalSB, { vsbar, content_size.height - hsbar });
        Point2F pos = {};
        const bool normaldir = m_state.layout_dir == Dir_Normal;
        if (normaldir) pos.x = content_size.width - vsbar;
        m_pVerticalSB->SetPos(pos);
    }
    // 设置HSB位置: 正向-下侧 反向-上侧
    if (hsbar > 0.f) {
        resize_child(*m_pHorizontalSB, { content_size.width - vsbar, hsbar });
        Point2F pos = {};
        const bool normaldir = m_state.layout_dir == Dir_Normal;
        if (normaldir) pos.y = content_size.height - hsbar;
        m_pVerticalSB->SetPos(pos);
    }
    // 同步SB显示
    this->sync_scroll_bar();
    // 返回剩余大小
    rv.width = content_size.width - vsbar;
    rv.height = content_size.height - hsbar;
    return rv;
}

/// <summary>
/// Gets the layout position.
/// </summary>
/// <returns></returns>
auto UI::UIScrollArea::get_layout_position() const noexcept -> Point2F {
    const auto base = this->GetBox().GetContentPos();
    //const auto base = Point2F{};
    // 正向- 左上角
    if (m_state.layout_dir == Dir_Normal) {

    }
    // 反向- 左上角+[VSB, 0]
    else {
        if (m_pVerticalSB && m_pVerticalSB->IsVisible()) {
            return base + Point2F{ m_pVerticalSB->GetSize().width, 0.f };
        }
    }
    return base;
}