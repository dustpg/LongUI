﻿// Gui
#include <debugger/ui_debug.h>
#include <control/ui_button.h>
#include <control/ui_ctrlmeta.h>
// 子控件
#include <control/ui_box_layout.h>
#include <control/ui_image.h>
#include <control/ui_label.h>
// Private
#include "../private/ui_private_control.h"

// ui namespace
namespace UI {
    // UIButton类 元信息
    LUI_CONTROL_META_INFO(UIButton, "button");
    // UIButton私有信息
    struct PrivateButton : CUIObject {
        // 构造函数
        PrivateButton(UIButton& btn) noexcept;
#ifndef NDEBUG
        // 调试占位
        void*               placeholder_debug1 = nullptr;
#endif
        // 图像控件
        UIImage             image;
        // 标签控件
        UILabel             label;
    };
    /// <summary>
    /// button privates data/method
    /// </summary>
    /// <param name="btn">The BTN.</param>
    /// <returns></returns>
    UI::PrivateButton::PrivateButton(UIButton& btn) noexcept 
        : image(&btn), label(&btn) {
        //PrivateControl::SetFocusable(image, false);
        //PrivateControl::SetFocusable(label, false);
#ifndef NDEBUG
        image.name_dbg = "button::image";
        label.name_dbg = "button::label";
        assert(image.IsFocusable() == false);
        assert(label.IsFocusable() == false);
#endif
    }
}

/// <summary>
/// Gets the text.
/// </summary>
/// <returns></returns>
auto UI::UIButton::GetText() const noexcept -> str_t {
    assert(m_private && "bad action");
    return m_private->label.GetText();
}

/// <summary>
/// Gets the text string.
/// </summary>
/// <returns></returns>
auto UI::UIButton::GetTextString() const noexcept -> const CUIString&{
    assert(m_private && "bad action");
    return m_private->label.GetTextString();
}


/// <summary>
/// Initializes a new instance of the <see cref="UIButton"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIButton::UIButton(UIControl* parent) noexcept : Super(parent) {
    LUI_INIT_META_POINTER;
    m_state.focusable = true;
    m_state.defaultable = true;
    // 原子性, 子控件为本控件的组成部分
    m_state.atomicity = true;
    // 默认为按钮样式
    m_oStyle.appearance = Appearance_Button;
    // XXX: init中设置 appearance样式

    // 水平布局
    this->SetOrient(Orient_Horizontal);
    // TODO: 延迟构造对象
    m_oBox.margin = { 5, 5, 5, 5 };
    m_private = new(std::nothrow) PrivateButton{ *this };
    // TODO: OOM处理
    m_private->label.SetText(L"确定");
}


/// <summary>
/// Finalizes an instance of the <see cref="UIButton"/> class.
/// </summary>
/// <returns></returns>
UI::UIButton::~UIButton() noexcept {
    // 存在提前释放子控件, 需要标记"在析构中"
    m_state.in_dtor = true;
    // 释放私有数据
    if (m_private) delete m_private;
}


/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UIButton::DoMouseEvent(const MouseEventArg& e) noexcept -> EventAccept {
    switch (e.type)
    {
    default:
        return Super::DoMouseEvent(e);
    case UI::MouseEvent::Event_LButtonUp:
        // 忽略?
        if (Super::DoMouseEvent(e) == Event_Ignore) return Event_Ignore;
        // 接受
        this->Click();
        return Event_Accept;
    }
}

#ifdef LUI_ACCESSIBLE
#include <accessible/ui_accessible_callback.h>
#include <accessible/ui_accessible_event.h>
#include <accessible/ui_accessible_type.h>
#include <core/ui_string.h>
#endif


/// <summary>
/// Sets the text.
/// </summary>
/// <param name="txt">The text.</param>
/// <param name="len">The length.</param>
/// <returns></returns>
void UI::UIButton::SetText(const wchar_t* txt, size_t len) noexcept {
    assert(m_private && "bad action");
    if (m_private->label.SetText(txt, len)) {
#ifdef LUI_ACCESSIBLE
        UI::Accessible(m_pAccessible, Callback_PropertyChanged);
#endif
    }
}

/// <summary>
/// Clicks this instance.
/// </summary>
/// <returns></returns>
void UI::UIButton::Click() noexcept {
    assert(m_private && "bad action");
    // 触发修改GUI事件
    this->TriggrtEvent(_clicked());
#ifdef LUI_ACCESSIBLE
    // TODO: 调用 accessible 接口
#endif
}

#ifdef LUI_ACCESSIBLE

/// <summary>
/// Accessibles the specified .
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
auto UI::UIButton::accessible(const AccessibleEventArg& args) noexcept -> EventAccept {
    switch (args.event)
    {
        using get0_t = AccessibleGetPatternsArg;
        using get1_t = AccessibleGetCtrlTypeArg;
        using get2_t = AccessibleGetAccNameArg;
    case AccessibleEvent::Event_GetPatterns:
        // + 继承基类行为模型
        Super::accessible(args);
        static_cast<const get0_t&>(args).patterns |=
            // + 可调用的行为模型
            Pattern_Invoke
            // + 读写值的行为模型
            | Pattern_Value
            ;
        return Event_Accept;
    case AccessibleEvent::Event_All_GetControlType:
        // 获取控件类型
        static_cast<const get1_t&>(args).type =  
            AccessibleControlType::Type_Button;
        return Event_Accept;
    case AccessibleEvent::Event_All_GetAccessibleName:
        // 获取Acc名称
        *static_cast<const get2_t&>(args).name = 
            m_private->label.GetTextString();
        return Event_Accept;
    case AccessibleEvent::Event_Value_SetValue:
        // 设置值
        this->SetText(
            static_cast<const AccessibleVSetValueArg&>(args).string,
            static_cast<const AccessibleVSetValueArg&>(args).length
        );
        return Event_Accept;
    case AccessibleEvent::Event_Value_GetValue:
        // 读取值
        *static_cast<const AccessibleVGetValueArg&>(args).value =
            this->GetTextString();
        return Event_Accept;
    case AccessibleEvent::Event_Invoke_Invoke:
        this->Click();
        return Event_Accept;
    }
    return Super::accessible(args);
}

#endif
