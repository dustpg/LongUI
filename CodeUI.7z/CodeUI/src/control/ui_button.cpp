﻿// Gui
#include <debugger/ui_debug.h>
#include <control/ui_button.h>
#include <control/ui_ctrlmeta.h>
// 子控件
#include <control/ui_box_layout.h>
#include <control/ui_image.h>
#include <control/ui_label.h>

// ui namespace
namespace UI {
    // UIButton类 元信息
    LUI_CONTROL_META_INFO(UIButton, "button");
    // UIButton私有信息
    struct PrivateButton : CUIObject {
        // 构造函数
        PrivateButton(UIButton& btn) noexcept;
#ifndef NDEBUG
        // 调试占位
        void*               placeholder_debug1 = nullptr;
#endif
        // 图像控件
        UIImage             image;
        // 标签控件
        UILabel             label;
    };
    /// <summary>
    /// button privates data/method
    /// </summary>
    /// <param name="btn">The BTN.</param>
    /// <returns></returns>
    UI::PrivateButton::PrivateButton(UIButton& btn) noexcept 
        : image(&btn), label(&btn) {
    }
}



/// <summary>
/// Initializes a new instance of the <see cref="UIButton"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::UIButton::UIButton(UIControl* parent) noexcept : Super(parent) {
    // 默认为按钮样式
    m_oStyle.appearance = Appearance_Button;
    // 水平布局
    this->SetOrient(Orient_Horizontal);
    // TODO: 延迟构造对象
    m_oBox.margin = { 5, 5, 5, 5 };
    m_private = new(std::nothrow) PrivateButton{ *this };
    // TODO: OOM处理
    m_private->label.SetText(L"确认");
}


/// <summary>
/// Finalizes an instance of the <see cref="UIButton"/> class.
/// </summary>
/// <returns></returns>
UI::UIButton::~UIButton() noexcept {
    // 存在提前释放子控件, 需要标记"在析构中"
    m_state.in_dtor = true;
    // 释放私有数据
    if (m_private) delete m_private;
}
