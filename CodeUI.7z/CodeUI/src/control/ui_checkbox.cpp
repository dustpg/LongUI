﻿// Gui
#include <debugger/ui_debug.h>
#include <control/ui_checkbox.h>
#include <control/ui_ctrlmeta.h>
// 子控件
#include <control/ui_box_layout.h>
#include <control/ui_image.h>
#include <control/ui_label.h>
// Private
#include "../private/ui_private_control.h"

// ui namespace
namespace UI {
    // UICheckBox类 元信息
    LUI_CONTROL_META_INFO(UICheckBox, "checkbox");
    // UICheckBox私有信息
    struct PrivateCheckBox : CUIObject {
        // 构造函数
        PrivateCheckBox(UICheckBox& btn) noexcept;
#ifndef NDEBUG
        // 调试占位
        void*               placeholder_debug1 = nullptr;
#endif
        // 图像控件
        UIImage             image;
        // 标签控件
        UILabel             label;
    };
    /// <summary>
    /// button privates data/method
    /// </summary>
    /// <param name="btn">The BTN.</param>
    /// <returns></returns>
    UI::PrivateCheckBox::PrivateCheckBox(UICheckBox& btn) noexcept 
        : image(&btn), label(&btn) {
        //PrivateControl::SetFocusable(image, false);
        //PrivateControl::SetFocusable(label, false);
#ifndef NDEBUG
        image.name_dbg = "checkbox::image";
        label.name_dbg = "checkbox::label";
        assert(image.IsFocusable() == false);
        assert(label.IsFocusable() == false);
        label.SetText(L"复选框");
#endif
    }
}

/// <summary>
/// Initializes a new instance of the <see cref="UICheckBox" /> class.
/// </summary>
/// <param name="parent">The parent.</param>
/// <param name="meta">The meta.</param>
UI::UICheckBox::UICheckBox(UIControl* parent, const MetaControl& meta) noexcept 
    : Super(parent, meta) {
    m_state.focusable = true;
    // 原子性, 子控件为本控件的组成部分
    m_state.atomicity = true;
    this->SetOrient(Orient_Horizontal);
    m_oStyle.align = AttributeAlign::Align_Center;
    // XXX: OOM 处理
    m_private = new(std::nothrow) PrivateCheckBox{ *this };
    // XXX: 硬编码
    m_oBox.margin = { 4, 2, 4, 2 };
    m_oBox.padding = { 4, 1, 2, 1 };
}


/// <summary>
/// Finalizes an instance of the <see cref="UICheckBox"/> class.
/// </summary>
/// <returns></returns>
UI::UICheckBox::~UICheckBox() noexcept {
    // 存在提前释放子控件, 需要标记"在析构中"
    m_state.in_dtor = true;
    // 释放私有数据
    if (m_private) delete m_private;
}


/// <summary>
/// Does the event.
/// </summary>
/// <param name="sender">The sender.</param>
/// <param name="arg">The argument.</param>
/// <returns></returns>
auto UI::UICheckBox::DoEvent(
    UIControl * sender, const EventArg & arg) noexcept -> EventAccept {
    // 初始化
    if (arg.nevent == NoticeEvent::Event_Initialize) {
        this->init_checkbox();
    }
    return Super::DoEvent(sender, arg);
}

/// <summary>
/// Initializes the checkbox.
/// </summary>
/// <returns></returns>
void UI::UICheckBox::init_checkbox() noexcept {
    if (!m_private) return;
    constexpr auto iapp = Appearance_CheckBox;
    PrivateControl::SetAppearanceIfNotSet(m_private->image, iapp);
}


/// <summary>
/// Does the mouse event.
/// </summary>
/// <param name="e">The e.</param>
/// <returns></returns>
auto UI::UICheckBox::DoMouseEvent(const MouseEventArg & e) noexcept -> EventAccept {
    // 左键弹起 修改状态
    switch (e.type)
    {
    case UI::MouseEvent::Event_LButtonUp:
        {
            const auto statetp = StyleStateType::Type_Checked;
            const auto checked = !this->GetStyle().state.checked;
            this->StartAnimation({ statetp , checked });
            m_private->image.StartAnimation({ statetp , checked });
        }
        [[fallthrough]];
    default:
        return Super::DoMouseEvent(e);
    }
}