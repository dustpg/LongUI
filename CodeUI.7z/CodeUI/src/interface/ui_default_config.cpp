﻿#include <interface/ui_default_config.h>
#include <core/ui_manager.h>
#include <cassert>
#include <cstdlib>


/// <summary>
/// Adds the reference.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::AddRef() noexcept -> uint32_t {
    return 2;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::Release() noexcept -> uint32_t {
    return 1;
}


/// <summary>
/// Gets the configure flag.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::GetConfigureFlag() noexcept ->ConfigureFlag {
    return IUIConfigure::Flag_OutputDebugString; 
}

/// <summary>
/// Chooses the adapter.
/// </summary>
/// <param name="adapters">The adapters.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
auto UI::CUIDefaultConfigure::ChooseAdapter(
    const GraphicsAdapterDesc /*adapters*/[], const size_t length) noexcept -> size_t {
    return length;
}

/// <summary>
/// Shows the error.
/// </summary>
/// <param name="a">a.</param>
/// <param name="b">The b.</param>
/// <returns></returns>
bool UI::CUIDefaultConfigure::ShowError(
    const wchar_t* a, const wchar_t* b) noexcept {
    assert(!"error");
    return false;
}

/// <summary>
/// Gets the name of the locale.
/// </summary>
/// <param name="name">The name.</param>
/// <returns></returns>
void UI::CUIDefaultConfigure::GetLocaleName(wchar_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept {
    name[0] = 0;
}


/// <summary>
/// Registers some.
/// </summary>
/// <returns></returns>
void UI::CUIDefaultConfigure::RegisterSome() noexcept {

}


// ui namespace
namespace UI { enum { DEBUG_SMALL = 32 }; }

/// <summary>
/// malloc for normal space
/// </summary>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultConfigure::NormalAlloc(size_t length) noexcept {
    assert(length && "cannot alloc 0 byte at here");
    return std::malloc(length);
}

/// <summary>
/// free for normal space
/// </summary>
/// <param name="address">The address.</param>
/// <returns></returns>
void UI::CUIDefaultConfigure::NormalFree(void* address) noexcept {
    return std::free(address);
}

/// <summary>
/// realloc for normal space
/// </summary>
/// <param name="address">The address.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultConfigure::NormalRealloc(void* address, size_t length) noexcept {
    assert((address || length) && "cannot call std::realloc(nullptr, 0)");
    return std::realloc(address, length);
}

/// <summary>
/// malloc for small space
/// </summary>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultConfigure::SmallAlloc(size_t length) noexcept {
    assert(length && "cannot alloc 0 byte at here");
#ifdef NDEBUG
    return std::malloc(length);
#else
    const auto ptr = reinterpret_cast<char*>(
        std::malloc(length + DEBUG_SMALL));
    return ptr ? DEBUG_SMALL + ptr : nullptr;
#endif
}

/// <summary>
/// free for small space
/// </summary>
/// <param name="address">The address.</param>
/// <returns></returns>
void UI::CUIDefaultConfigure::SmallFree(void* address) noexcept {
#ifdef NDEBUG
    return std::free(address);
#else
    return std::free(
        address 
        ? reinterpret_cast<char*>(address) - DEBUG_SMALL
        : nullptr);
#endif
}

/// <summary>
/// realloc for small space
/// </summary>
/// <param name="address">The address.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultConfigure::SmallRealloc(void* address, size_t length) noexcept {
    assert((address || length) && "cannot call std::realloc(nullptr, 0)");
#ifdef NDEBUG
    return std::realloc(address, length);
#else
    const auto addr = address
        ? reinterpret_cast<char*>(address) - DEBUG_SMALL
        : nullptr;
    const auto ptr = reinterpret_cast<char*>(
        std::realloc(addr, length ? length + DEBUG_SMALL : 0));
    return ptr ? DEBUG_SMALL + ptr : nullptr;
#endif
}






// atomic
#include <atomic>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <process.h>

/// <summary>
/// Exits the main loop
/// </summary>
/// <returns></returns>
void UI::CUIDefaultConfigure::Exit() noexcept {
    ::PostQuitMessage(0);
}


/// <summary>
/// Mains the loop.
/// </summary>
/// <returns></returns>
void UI::CUIDefaultConfigure::MainLoop() noexcept {
    // 退出flag
    std::atomic_bool flag{ false };
    // 渲染线程
    const auto thr = ::_beginthread([](void* ptr) noexcept {
        const auto flag = reinterpret_cast<std::atomic_bool*>(ptr);
        while (!flag->load(std::memory_order_relaxed)) {
            UIManager.OneFrame();
            UIManager.WaitForVBlank();
            // TODO: sleep
            ::Sleep(10);
        }
        ::_endthread();
    }, 0, &flag);
    // 创建失败
    if (thr == -1) return;
    // 消息循环
    MSG msg;
    while (::GetMessageW(&msg, nullptr, 0, 0)) {
        ::TranslateMessage(&msg);
        ::DispatchMessageW(&msg);
    }
    // 退出
    flag.store(true, std::memory_order_relaxed);
    // 等待设置
    const auto hthr = reinterpret_cast<HANDLE>(thr);
    constexpr uint32_t try_wait_time = 1000;
    // 等待线程退出
    if (::WaitForSingleObject(hthr, try_wait_time) != WAIT_OBJECT_0) {
        // TODO: 超时处理
    }
}