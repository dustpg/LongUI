﻿#include <interface/ui_default_config.h>
/*#define WIN32_LEAN_AND_MEAN
#include <Windows.h>*/
#include <cassert>


/// <summary>
/// Adds the reference.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::AddRef() noexcept -> uint32_t {
    return 2;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::Release() noexcept -> uint32_t {
    return 1;
}

/// <summary>
/// Creates the interface.
/// </summary>
/// <param name="iid">The iid.</param>
/// <param name="obj">The object.</param>
/// <returns></returns>
auto UI::CUIDefaultConfigure::CreateInterface(
    const IID & /*iid*/, void ** /*obj*/) noexcept -> Result {
    return{ Result::RE_NOTIMPL };
}

/// <summary>
/// Gets the configure flag.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultConfigure::GetConfigureFlag() noexcept ->ConfigureFlag {
    return IUIConfigure::Flag_OutputDebugString; 
}

/// <summary>
/// Chooses the adapter.
/// </summary>
/// <param name="adapters">The adapters.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
auto UI::CUIDefaultConfigure::ChooseAdapter(
    const GraphicsAdapterDesc /*adapters*/[], const size_t length) noexcept -> size_t {
    return length;
}

/// <summary>
/// Shows the error.
/// </summary>
/// <param name="a">a.</param>
/// <param name="b">The b.</param>
/// <returns></returns>
bool UI::CUIDefaultConfigure::ShowError(
    const wchar_t* a, const wchar_t* b) noexcept {
    assert(!"error");
    return false;
}

/// <summary>
/// Gets the name of the locale.
/// </summary>
/// <param name="name">The name.</param>
/// <returns></returns>
void UI::CUIDefaultConfigure::GetLocaleName(wchar_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept {
    name[0] = 0;
}


/// <summary>
/// Registers some.
/// </summary>
/// <returns></returns>
void UI::CUIDefaultConfigure::RegisterSome() noexcept {

}