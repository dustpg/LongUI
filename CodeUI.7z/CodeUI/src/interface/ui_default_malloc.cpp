﻿#include <interface/ui_default_malloc.h>
#include <cstdlib>


/// <summary>
/// Adds the reference.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultMAllc::AddRef() noexcept -> uint32_t {
    return 2;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultMAllc::Release() noexcept -> uint32_t {
    return 1;
}

// ui namespace
namespace UI { enum { DEBUG_SMALL = 32 }; }

/// <summary>
/// malloc for normal space
/// </summary>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultMAllc::NormalAlloc(size_t length) noexcept {
    return std::malloc(length);
}

/// <summary>
/// free for normal space
/// </summary>
/// <param name="address">The address.</param>
/// <returns></returns>
void UI::CUIDefaultMAllc::NormalFree(void* address) noexcept {
    return std::free(address);
}

/// <summary>
/// realloc for normal space
/// </summary>
/// <param name="address">The address.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultMAllc::NormalRealloc(void* address, size_t length) noexcept {
    return std::realloc(address, length);
}

/// <summary>
/// malloc for small space
/// </summary>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultMAllc::SmallAlloc(size_t length) noexcept {
#ifdef NDEBUG
    return std::malloc(length);
#else
    const auto ptr = reinterpret_cast<char*>(
        std::malloc(length + DEBUG_SMALL));
    return ptr ? DEBUG_SMALL + ptr : nullptr;
#endif
}

/// <summary>
/// free for small space
/// </summary>
/// <param name="address">The address.</param>
/// <returns></returns>
void UI::CUIDefaultMAllc::SmallFree(void* address) noexcept {
#ifdef NDEBUG
    return std::free(address);
#else
    return std::free(
        address 
        ? reinterpret_cast<char*>(address) - DEBUG_SMALL
        : nullptr);
#endif
}

/// <summary>
/// realloc for small space
/// </summary>
/// <param name="address">The address.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
void*UI::CUIDefaultMAllc::SmallRealloc(void* address, size_t length) noexcept {
#ifdef NDEBUG
    return std::realloc(address, length);
#else
    const auto addr = address
        ? reinterpret_cast<char*>(address) - DEBUG_SMALL
        : nullptr;
    const auto ptr = reinterpret_cast<char*>(
        std::realloc(addr, length + DEBUG_SMALL));
    return ptr ? DEBUG_SMALL + ptr : nullptr;
#endif
}