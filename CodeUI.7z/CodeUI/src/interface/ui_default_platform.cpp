﻿#include <interface/ui_default_platform.h>
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <cassert>


/// <summary>
/// Adds the reference.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultPlatform::AddRef() noexcept -> uint32_t {
    return 2;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIDefaultPlatform::Release() noexcept -> uint32_t {
    return 1;
}


/// <summary>
/// Mains the loop.
/// </summary>
/// <returns></returns>
void UI::CUIDefaultPlatform::MainLoop() noexcept {
    // 消息响应
    MSG msg;
    while (::GetMessageW(&msg, nullptr, 0, 0)) {
        ::TranslateMessage(&msg);
        ::DispatchMessageW(&msg);
    }
}