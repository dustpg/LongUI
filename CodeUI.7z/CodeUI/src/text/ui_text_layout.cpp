﻿// UI HREADER
#include <text/ui_text_layout.h>
#include <core/ui_color_list.h>
#include <core/ui_manager.h>
#include <luiconf.h>
// OS IMPL
#include <graphics/ui_graphics_impl.h>
#include <text/ui_ctl_arg.h>
#include <text/ui_ctl_impl.h>

/// <summary>
/// Finalizes an instance of the <see cref="CUITextLayout"/> class.
/// </summary>
/// <returns></returns>
UI::CUITextLayout::~CUITextLayout() noexcept {
    if (m_text) m_text->Release();
}

/// <summary>
/// Renders the specified renderer.
/// </summary>
/// <param name="renderer">The renderer.</param>
/// <param name="point">The point.</param>
/// <returns></returns>
void UI::CUITextLayout::Render(
    I::Renderer2D& renderer, 
    const ColorF& color,
    Point2F point) const noexcept {
    // 布局有效
    if (m_text) {
        point.y -= m_halfls;
        renderer.DrawTextLayout(
            auto_cast(point),
            m_text,
            &UIManager.RefCCBrush(color)
        );
    }
    // 布局无效
    else {
        /*LUIDebug(Error) LUI_FRAMEID
            << "I::Text pointer null, won't draw any"
            << endl;*/
    }
}

/// <summary>
/// Initializes the specified argument.
/// </summary>
/// <param name="arg">The argument.</param>
/// <returns></returns>
auto UI::CUITextLayout::Init(const FontArg & arg) noexcept {
}

/// <summary>
/// Sets the text.
/// </summary>
/// <param name="str">The string.</param>
/// <param name="len">The length.</param>
/// <returns></returns>
auto UI::CUITextLayout::SetText(str_t str, size_t len) noexcept -> Result {
    // 参数调整
    TextArg arg;
    arg.string = str;
    arg.length = len;
    arg.font = I::FontFromText(m_text);
    arg.mwidth = DEFAULT_CONTROL_MAX_SIZE;
    arg.mheight = DEFAULT_CONTROL_MAX_SIZE;
    // 获取之前的大小
    if (m_text) {
        DWRITE_TEXT_METRICS metrice;
        m_text->GetMetrics(&metrice);
        arg.mwidth = metrice.layoutWidth;
        arg.mheight = metrice.layoutHeight;
        m_text = nullptr;
    }
    // 创建布局
    const auto hr = UIManager.CreateCtlText(arg, m_text);
    // 获取首行测量值计算半行距
    if (hr) {
        DWRITE_LINE_METRICS lm; uint32_t c;
        m_text->GetLineMetrics(&lm, 1, &c);
        m_halfls = (lm.height - lm.baseline) * 0.5f;
    }
    // 检查字体
    if (arg.font) arg.font->Release();
    // 返货结果
    return hr;
}

/// <summary>
/// Resizes the specified size.
/// </summary>
/// <param name="size">The size.</param>
/// <returns></returns>
void UI::CUITextLayout::Resize(Size2F size) noexcept {
    if (m_text) {
        m_text->SetMaxWidth(size.width);
        m_text->SetMaxHeight(size.height);
    }
    else {
        LUIDebug(Error) LUI_FRAMEID
            << L"resize null"
            << endl;
    }
}

/// <summary>
/// Gets the size.
/// </summary>
/// <returns></returns>
auto UI::CUITextLayout::GetSize() noexcept -> Size2F {
    if (m_text) {
#ifndef NDEBUG
        float min_width = 0.f;
        m_text->DetermineMinWidth(&min_width);
        DWRITE_LINE_SPACING_METHOD sm;
        float linesp, lineht;
        m_text->GetLineSpacing(&sm, &linesp, &lineht);
        DWRITE_OVERHANG_METRICS om; 
        m_text->GetOverhangMetrics(&om);
        DWRITE_LINE_METRICS lm; uint32_t c = 0;
        m_text->GetLineMetrics(&lm, 1, &c);
#endif
        // 获取整体测量值
        DWRITE_TEXT_METRICS   metrics;
        m_text->GetMetrics(&metrics);
        return{ metrics.widthIncludingTrailingWhitespace, metrics.height };
    }
    else {
        return{};
    }
}