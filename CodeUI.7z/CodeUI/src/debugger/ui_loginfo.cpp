﻿#include <cstdio>
#include <debugger/ui_loginfo.h>
#include <debugger/ui_logger.h>

/// <summary>
/// log info to logger
/// </summary>
/// <param name="loggrt">The loggrt.</param>
/// <param name="info">The information.</param>
/// <returns></returns>
auto UI::operator<<(
    CUILogger& logger, 
    const LogInfo& info
    ) noexcept ->CUILogger& {
    std::printf(
        "LogInfo {\n"
        "}\n"
    );
    return logger;
}