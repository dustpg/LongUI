﻿#include <cstdio>
#include <debugger/ui_logger.h>


/// <summary>
/// Operators the specified logger.
/// </summary>
/// <param name="logger">The logger.</param>
/// <param name="f">The f.</param>
/// <returns></returns>
auto UI::operator<<(CUILogger& logger, float f) noexcept -> CUILogger& {
    std::printf("%f", f);
    return logger;
}

/// <summary>
/// Operators the specified logger.
/// </summary>
/// <param name="logger">The logger.</param>
/// <param name="str">The string.</param>
/// <returns></returns>
auto UI::operator<<(CUILogger& logger, const char* str) noexcept -> CUILogger& {
    std::printf("%s", str);
    return logger;
}