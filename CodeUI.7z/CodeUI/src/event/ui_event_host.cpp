﻿#include <event/ui_event_host.h>
#include "../private/ui_private_control.h"



/// <summary>
/// string to gui event id
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
auto UI::CUIEventHost::strtoe(const char*) noexcept -> GuiEvent {
    assert(!"NOT IMPL");
    // 惯例hash
    return GuiEvent(-1);
}

/// <summary>
/// Adds the GUI event listener.
/// </summary>
/// <param name="ownid">The ownid.</param>
/// <param name="e">The e.</param>
/// <param name="listener">The listener.</param>
/// <returns></returns>
bool UI::CUIEventHost::add_gui_event_listener(
    uintptr_t ownid,
    GuiEvent e,
    GuiEventListener&& listener) noexcept {
    const auto ctrl = static_cast<UIControl*>(this);
    const auto a = reinterpret_cast<void*>(this);
    const auto b = reinterpret_cast<void*>(ctrl);
    assert(a == b && "must be same");
    return PrivateControl::AddGuiEL(*ctrl, ownid, e, std::move(listener));
}

/// <summary>
/// Removes the GUI event listener.
/// </summary>
/// <param name="ownid">The ownid.</param>
/// <param name="">The .</param>
/// <returns></returns>
void UI::CUIEventHost::RemoveGuiEventListener(uintptr_t ownid, GuiEvent e) noexcept {
    const auto ctrl = static_cast<UIControl*>(this);
    return PrivateControl::RemoveGuiEL(*ctrl, ownid, e);
}



