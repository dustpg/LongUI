﻿#include <core/ui_malloc.h>
#include <core/ui_manager.h>
#include <util/ui_unimacro.h>
#include <interface/ui_default_config.h>
#include <cassert>


// function Setting
namespace UI {
    // IMM
    struct CUIManager::IMM {
        // get malloc inteface
        static inline auto Get() noexcept { return UIManager.config; }
    };
    // alloc for normal space
    PCN_NOINLINE void*NormalAlloc(size_t length) noexcept {
        using M = CUIManager::IMM;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalAlloc(length); 
    }
    // free for normal space
    PCN_NOINLINE void NormalFree(void* address) noexcept {
        using M = CUIManager::IMM;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalFree(address);
    }
    // realloc for normal space
    PCN_NOINLINE void*NormalRealloc(void* address, size_t length) noexcept {
        using M = CUIManager::IMM;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalRealloc(address, length);
    }
    // alloc for small space
    PCN_NOINLINE void*SmallAlloc(size_t length) noexcept {
        using M = CUIManager::IMM;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->SmallAlloc(length);
    }
    // free for small space
    PCN_NOINLINE void SmallFree(void* address) noexcept {
        using M = CUIManager::IMM;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->SmallFree(address);
    }
}


