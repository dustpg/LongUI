﻿#include <core/ui_malloc.h>
#include <core/ui_manager.h>
#include <util/ui_unimacro.h>
#include <interface/ui_imalloc.h>
#include <cassert>


// function Setting
namespace UI {
    // IMA
    struct CUIManager::IMA {
        // get malloc inteface
        static inline auto Get() noexcept { return UIManager.m_pMAlloc; }
    };
    // alloc for normal space
    PCN_NOINLINE void*NormalAlloc(size_t length) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalAlloc(length); 
    }
    // free for normal space
    PCN_NOINLINE void NormalFree(void* address) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalFree(address);
    }
    // realloc for normal space
    PCN_NOINLINE void*NormalRealloc(void* address, size_t length) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->NormalRealloc(address, length);
    }
    // alloc for small space
    PCN_NOINLINE void*SmallAlloc(size_t length) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->SmallAlloc(length);
    }
    // free for small space
    PCN_NOINLINE void SmallFree(void* address) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->SmallFree(address);
    }
    // realloc for small space
    PCN_NOINLINE void*SmallRealloc(void* address, size_t length) noexcept {
        using M = CUIManager::IMA;
        assert(M::Get() && "must call UIManager.Initialize() first");
        return M::Get()->SmallRealloc(address, length);
    }
}


