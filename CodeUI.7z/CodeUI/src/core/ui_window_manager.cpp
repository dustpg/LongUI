﻿#define WIN32_LEAN_AND_MEAN
#include <core/ui_window_manager.h>
#include <debugger/ui_debug.h>
#include <Windows.h>

/// <summary>
/// Initializes this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIWndMgr::init() noexcept -> Result {
    m_vWindows.clear();
    // 开始计时
    m_uiTimeMeter.Start();
    // 更新显示频率
    this->refresh_display_frequency();
    return Result();
}


/// <summary>
/// Refresh_display_frequencies this instance.
/// 刷新屏幕刷新率
/// </summary>
/// <returns></returns>
void UI::CUIWndMgr::refresh_display_frequency() noexcept {
    // 获取屏幕刷新率
    DEVMODEW mode; std::memset(&mode, 0, sizeof(mode));
    ::EnumDisplaySettingsW(nullptr, ENUM_CURRENT_SETTINGS, &mode);
    m_dwDisplayFrequency = static_cast<uint32_t>(mode.dmDisplayFrequency);
    // 稍微检查
    if (!m_dwDisplayFrequency) {
        LUIDebug(Error)
            << L"EnumDisplaySettingsW failed: got zero for DEVMODEW::dmDisplayFrequency"
            << L", now assume as 60Hz"
            << UI::endl;
        m_dwDisplayFrequency = 60;
    }
}


/// <summary>
/// Initializes a new instance of the <see cref="CUIWndMgr"/> class.
/// </summary>
UI::CUIWndMgr::CUIWndMgr() noexcept {
    m_vWindows.reserve(16);
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWndMgr"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWndMgr::~CUIWndMgr() noexcept {

}

/// <summary>
/// Uninits this instance.
/// </summary>
/// <returns></returns>
void UI::CUIWndMgr::uninit() noexcept {

}