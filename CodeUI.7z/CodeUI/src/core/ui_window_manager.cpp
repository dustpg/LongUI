﻿#include <core/ui_window.h>
#include <debugger/ui_debug.h>
#include <util/ui_time_meter.h>
#include <container/pod_vector.h> 
#include <core/ui_window_manager.h>

#include <cassert>
#include <algorithm>

/// <summary>
/// private data/func for WndMgr
/// </summary>
struct UI::PrivateWndMgr {
    // windows
    using WindowVector = POD::Vector<CUIWindow*>;
    // ctor
    PrivateWndMgr() {};
    // dtor
    ~PrivateWndMgr() {}
    // high time-meter
    CUITimeMeterH           timemeter;
    // windows list
    WindowVector            windows;
};


/// <summary>
/// Initializes a new instance of the <see cref="CUIWndMgr"/> class.
/// </summary>
UI::CUIWndMgr::CUIWndMgr(Result& out) noexcept {
    // 静态检查
    enum {
        wm_size = sizeof(PrivateWndMgr),
        pw_size = detail::private_wndmgr<sizeof(void*)>::size,

        wm_align = alignof(PrivateWndMgr),
        pw_align = detail::private_wndmgr<sizeof(void*)>::align,
    };
    static_assert(wm_size == pw_size, "must be same");
    static_assert(wm_align == pw_align, "must be same");
    // 已经发生错误
    if (!out) return;
    new(&wm()) PrivateWndMgr;
    Result hr = { Result::RS_OK };
    // 尝试扩展窗口列表
    if (hr) {
        wm().windows.reserve(16);
        // 内存不足
        if (!wm().windows.is_ok())
            hr = { Result::RE_OUTOFMEMORY };
    }
    // 初始化其他
    if (hr) {
        wm().windows.clear();
        // 开始计时
        wm().timemeter.Start();
        // 更新显示频率
        this->refresh_display_frequency();
    }
    out = hr;
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWndMgr"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWndMgr::~CUIWndMgr() noexcept {
    assert(wm().windows.empty() && "exsited!");
    wm().~PrivateWndMgr();
}

/// <summary>
/// Updates the delta time.
/// </summary>
/// <returns></returns>
auto UI::CUIWndMgr::update_delta_time() noexcept -> float {
    // TODO: 固定时间更新频率
    auto& meter = wm().timemeter;
    const auto time = meter.Delta_ms<double>();
    meter.MovStartEnd();
    return static_cast<float>(time);
}

/// <summary>
/// Adds the window.
/// </summary>
/// <param name="window">The window.</param>
/// <returns></returns>
void UI::CUIWndMgr::add_window(CUIWindow& window) noexcept {
    auto& wnds = wm().windows;
    const auto ptr = &window;
#ifndef NDEBUG
    // 检查是否在里面
    auto itr = std::find(wnds.begin(), wnds.end(), ptr);
    assert(itr == wnds.end() && "bug");
#endif
    wnds.push_back(ptr);
    // TODO: OOM处理
    int bk = 9;
}


/// <summary>
/// Removes the window.
/// </summary>
/// <param name="window">The window.</param>
/// <returns></returns>
void UI::CUIWndMgr::remove_window(CUIWindow & window) noexcept {
    auto& wnds = wm().windows;
    const auto ptr = &window;
    // 检查是否在里面
    auto itr = std::find(wnds.begin(), wnds.end(), ptr);
    assert(itr != wnds.end() && "bug");
    wnds.erase(itr);
}

/// <summary>
/// Renders the windows.
/// </summary>
/// <returns></returns>
auto UI::CUIWndMgr::render_windows() noexcept -> Result {
    // XXX: 线程安全(渲染中增删窗口)
    for (auto window : wm().windows) {
        const auto hr = window->Render();
        if (!hr) return hr;
    }
    return{ Result::RS_OK };
}

// ----------------------------------------------------------------------------
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

/// <summary>
/// Refresh_display_frequencies this instance.
/// 刷新屏幕刷新率
/// </summary>
/// <returns></returns>
void UI::CUIWndMgr::refresh_display_frequency() noexcept {
    // 获取屏幕刷新率
    DEVMODEW mode; std::memset(&mode, 0, sizeof(mode));
    ::EnumDisplaySettingsW(nullptr, ENUM_CURRENT_SETTINGS, &mode);
    m_dwDisplayFrequency = static_cast<uint32_t>(mode.dmDisplayFrequency);
    // 稍微检查
    if (!m_dwDisplayFrequency) {
        LUIDebug(Error)
            << L"EnumDisplaySettingsW failed: "
            << L"got zero for DEVMODEW::dmDisplayFrequency"
            << L", now assume as 60Hz"
            << UI::endl;
        m_dwDisplayFrequency = 60;
    }
}

/// <summary>
/// Sleeps for vblank.
/// </summary>
/// <returns></returns>
void UI::CUIWndMgr::sleep_for_vblank() noexcept {
    // XXX: vblank
    ::Sleep(15);
}
