﻿#include <core/ui_resource_manager.h>
#include <graphics/ui_adapter_desc.h>
#include <interface/ui_iconfig.h>
#include <container/pod_hash.h>
#include <debugger/ui_debug.h>
#include <core/ui_string.h>
#include <luiconf.h>

#include <cassert>
#include <cstring>

#define WIN32_LEAN_AND_MEAN
#include <graphics/ui_graphics_impl.h>
#include <text/ui_ctl_arg.h>
#include <text/ui_ctl_impl.h>

#pragma comment(lib, "dxgi")
#pragma comment(lib, "d3d11")
#pragma comment(lib, "d2d1")
#pragma comment(lib, "dwrite")

// ui namespace
namespace UI {
    /// <summary>
    /// The iid identifier write factory1
    /// </summary>
    const GUID IID_IDWriteFactory1 = {
        0x30572f99, 0xdac6, 0x41db,
        { 0xa1, 0x6e, 0x04, 0x86, 0x30, 0x7e, 0x60, 0x6a }
    };
    /// <summary>
    /// The iid identifier write text layout1
    /// </summary>
    const GUID IID_IDWriteTextLayout1 = {
        0x9064d822, 0x80a7, 0x465c,
        { 0xa9, 0x86, 0xdf, 0x65, 0xf7, 0x8b, 0x8f, 0xeb }
    };
}

/// <summary>
/// private data/func for resmgr
/// </summary>
struct UI::PrivateResMgr {
    // init
    inline auto init() noexcept->Result;
    // release
    inline void release() noexcept;
    // d2d factroy
    ID2D1Factory1*      d2dfactroy;
    // dwrite factroy
    IDWriteFactory1*    dwritefactroy;
    // default font
    I::Font*            deffont;
};


// ----------------------------------------------------------------------------
// ---------------------  CTL - Complex Text Layout  --------------------------
// ----------------------------------------------------------------------------

PCN_NOINLINE
/// <summary>
/// Creates the CTL text.
/// </summary>
/// <param name="arg">The argument.</param>
/// <param name="text">The text.</param>
/// <returns></returns>
auto UI::CUIResMgr::CreateCtlText(
    const TextArg& arg, I::Text *& text) noexcept -> Result {
    assert(text == nullptr && "check for releasing");
    IDWriteTextLayout* layout = nullptr;
    // 创建基本布局
    Result hr = { rm().dwritefactroy->CreateTextLayout(
        arg.string,
        static_cast<uint32_t>(arg.length),
        arg.font ? arg.font : rm().deffont,
        arg.mwidth,
        arg.mheight,
        &layout
    ) };
    longui_debug_hr(hr, L"CreateTextLayout faild");
    // 查询继承类接口
    if (hr) {
        hr = { layout->QueryInterface(
            IID_IDWriteTextLayout1,
            reinterpret_cast<void**>(&text)
        ) };
        longui_debug_hr(hr, L"QueryInterface 'IDWriteTextLayout1' faild");
    }
    // 释放数据
    if (layout) layout->Release();
    return hr;
}

PCN_NOINLINE
/// <summary>
/// Creates the control font.
/// </summary>
/// <param name="arg">The argument.</param>
/// <param name="font">The font.</param>
/// <returns></returns>
auto UI::CUIResMgr::CreateCtlFont(
    const FontArg& arg, I::Font *& font) noexcept -> Result {
    // 使用默认的?
    assert(arg.family && "NOT IMPL");
    // 创建文本格式
    Result hr = { rm().dwritefactroy->CreateTextFormat(
        arg.family,
        // TODO: 字体集
        nullptr,
        auto_cast(arg.weight),
        auto_cast(arg.style),
        auto_cast(arg.stretch),
        arg.size,
        m_szLocaleName,
        reinterpret_cast<IDWriteTextFormat**>(&font)
    ) };
    // 直接断言方便检查
    assert(hr);
    // 设置
    if (hr) {
        // 初始
        const auto format = font; auto tmp = hr;
        // 设置自动换行
        tmp = { format->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP) };
        longui_debug_hr(tmp, L"failed format->SetWordWrapping - NO_WRAP" );
        // 设置 Tab宽度
        //tmp = { format->SetIncrementalTabStop(arg.tab == 0.f ? arg.size * 4.f : arg.tab) };
        //longui_debug_hr(tmp, L"failed format->SetIncrementalTabStop  " << arg.tab);
        // 设置段落排列方向
        /*tmp = format->SetFlowDirection(static_cast<DWRITE_FLOW_DIRECTION>(prop.flow));
        longui_debug_hr(tmp, L"failed format->SetFlowDirection  " << long(prop.flow));
        // 设置段落(垂直)对齐
        tmp = format->SetParagraphAlignment(static_cast<DWRITE_PARAGRAPH_ALIGNMENT>(prop.valign));
        longui_debug_hr(tmp, L"failed format->SetParagraphAlignment  " << long(prop.valign));
        // 设置文本(水平)对齐
        tmp = format->SetTextAlignment(static_cast<DWRITE_TEXT_ALIGNMENT>(prop.halign));
        longui_debug_hr(tmp, L"failed format->SetTextAlignmen  t" << long(prop.halign));
        // 设置阅读进行方向
        tmp = format->SetReadingDirection(static_cast<DWRITE_READING_DIRECTION>(prop.reading));
        longui_debug_hr(tmp, L"failed format->SetReadingDirection  " << long(prop.reading));*/
    }
    return hr;
}

// ----------------------------------------------------------------------------
// -------------------------------  Graphics  ---------------------------------
// ----------------------------------------------------------------------------

PCN_NOINLINE
/// <summary>
/// References the cc brush.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
auto UI::CUIResMgr::RefCCBrush(
    const ColorF& color) noexcept -> I::Brush& {
    ID2D1Brush* const brush = m_pCommonBrush;
    const auto scb = static_cast<ID2D1SolidColorBrush*>(brush);
    scb->SetColor(auto_cast(color));
    return *m_pCommonBrush;
}

// DXGI DEBUG
#ifndef NDEBUG

#include <core/ui_object.h>
#include <dxgidebug.h>
/// <summary>
/// debug data
/// </summary>
struct UI::CUIResMgr::Debug : UI::CUIObject {
    // ctor
    Debug() noexcept;
    // dtor
    ~Debug() noexcept;
    // debug dll
    HMODULE             dxgidebug_dll = nullptr;
    // dxgi debug interface
    IDXGIDebug*         dxgidebug = nullptr;
    // d3d11 debug interface
    ID3D11Debug*        d3d11debug = nullptr;
};

/// <summary>
/// Initializes a new instance of the <see cref="Debug"/> struct.
/// </summary>
UI::CUIResMgr::Debug::Debug() noexcept {
    // 载入调试DLL文件
    dxgidebug_dll = ::LoadLibraryA("dxgidebug.dll");
    // 未找到
    if (!dxgidebug_dll) return;
    // 定义接口GUID
    const GUID iid_IDXGIDebug = {
        0x119E7452, 0xDE9E, 0x40fe, 0x88, 0x06, 0x88,
        0xF9, 0x0C, 0x12, 0xB4, 0x41
    };
    // 万能union转换
    const auto name = "DXGIGetDebugInterface";
    union {
        HRESULT(WINAPI* func) (REFIID riid, void **ppDebug) noexcept;
        FARPROC     addr;
    };
    // 加载函数
    if ((addr = ::GetProcAddress(dxgidebug_dll, name))) {
        const auto code = func(
            iid_IDXGIDebug, 
            reinterpret_cast<void**>(&dxgidebug)
        );
    }
}

/// <summary>
/// Finalizes an instance of the <see cref="Debug"/> class.
/// </summary>
/// <returns></returns>
UI::CUIResMgr::Debug::~Debug() noexcept {
    const GUID debug_all = {
        0xe48ae283, 0xda80, 0x490b, 0x87, 0xe6,
        0x43, 0xe9, 0xa9, 0xcf, 0xda, 0x8
    };
    if (dxgidebug) {
        ::OutputDebugStringW(L"----> ALL ReportLiveObjects\r\n");
        dxgidebug->ReportLiveObjects(
            debug_all,
            DXGI_DEBUG_RLO_ALL
        );
        ::OutputDebugStringW(L"<----\r\n");
        dxgidebug->Release();
    }
    if (dxgidebug) ::FreeLibrary(dxgidebug_dll);
    assert(!d3d11debug && "must be nullptr");
}


#endif

/// <summary>
/// screen iterface
/// </summary>
struct PCN_NOVTABLE UI::CUIResMgr::IScreen : IDXGIOutput {};

/// <summary>
/// Waits for vblank.
/// </summary>
/// <returns></returns>
bool UI::CUIResMgr::wait_for_vblank() noexcept {
    // 存在显示输出?
    if (!m_pMainScreen) return false;
    // 等待垂直同步
    m_pMainScreen->WaitForVBlank();
    return true;
}

/// <summary>
/// Initializes this instance.
/// </summary>
/// <returns></returns>
inline auto UI::PrivateResMgr::init() noexcept -> Result {
    Result hr = { Result::RS_OK };
    // 创建D2D工厂
    if (hr) {
        D2D1_FACTORY_OPTIONS options = { D2D1_DEBUG_LEVEL_NONE };
#ifndef NDEBUG
        options.debugLevel = D2D1_DEBUG_LEVEL_INFORMATION;
#endif
        hr = { ::D2D1CreateFactory(
            D2D1_FACTORY_TYPE_SINGLE_THREADED,
            IID_ID2D1Factory1,
            &options,
            reinterpret_cast<void**>(&this->d2dfactroy)
        )};
        longui_debug_hr(hr, L"D2D1CreateFactory faild");
    }
    // 创建DWrite工厂
    if (hr) {
        hr = { ::DWriteCreateFactory(
            DWRITE_FACTORY_TYPE_SHARED,
            IID_IDWriteFactory1,
            reinterpret_cast<IUnknown**>(&this->dwritefactroy)
        ) };
        longui_debug_hr(hr, L"DWriteCreateFactory faild");
    }
    return hr;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
inline void UI::PrivateResMgr::release() noexcept {
    UI::SafeRelease(this->d2dfactroy);
    UI::SafeRelease(this->dwritefactroy);
    UI::SafeRelease(this->deffont);
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIResMgr" /> class.
/// </summary>
/// <param name="out">The out hr.</param>
UI::CUIResMgr::CUIResMgr(IUIConfigure* cfg, Result& out) noexcept {
    if (!out) return;
    // 初始化私有数据
    std::memset(&m_private, 0, sizeof(m_private));
#ifndef NDEBUG
    m_pDebug = new(std::nothrow) Debug;
    if (!m_pDebug) { 
        out = { Result::RE_OUTOFMEMORY };
        return;
    }
#endif
    // 初始化一些东西
    m_szLocaleName[0] = L'\0';
    // 本地字符集名称
    cfg->GetLocaleName(m_szLocaleName);
    // 初始化无关资源
    Result hr = rm().init();
    // 创建默认字体
    if (hr) {
        // 配置默认字体
        CUIString family; FontArg arg = {
            L"Arial",
            12.5f,
            Weight_Normal,
            Style_Normal,
            Stretch_Normal
        };
        // 获取配置的默认字体
        cfg->DefualtFontArg(arg, family);
        // 字体名称有设置
        if (family.length()) arg.family = family.c_str();
        // 创建默认字体
        hr = this->CreateCtlFont(arg, rm().deffont);
    }
    // 返回结果
    out = hr;
}


/// <summary>
/// Finalizes an instance of the <see cref="CUIResMgr"/> class.
/// </summary>
/// <returns></returns>
UI::CUIResMgr::~CUIResMgr() noexcept {
    // 释放无关资源
    rm().release();
    // 释放设备资源
    this->release_device();
#ifndef NDEBUG
    delete m_pDebug;
#endif
}


/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIResMgr::recreate(IUIConfigure* cfg) noexcept -> Result {
    constexpr auto same_s = sizeof(PrivateResMgr) == sizeof(m_private);
    constexpr auto same_a = alignof(PrivateResMgr) == alignof(void*);
    static_assert(same_s && same_a, "must be same");
    this->release_device();
    const auto flag = cfg->GetConfigureFlag();
    // 待用适配器
    IDXGIAdapter1* adapter = nullptr;
    // 枚举显示适配器
    if (!(flag & IUIConfigure::Flag_RenderByCPU)) {
        IDXGIFactory1* dxgifactory = nullptr;
        const auto idd = IID_IDXGIFactory1;
        const auto add = reinterpret_cast<void**>(&dxgifactory);
        // 创建一个临时工厂
        const Result tmp = { ::CreateDXGIFactory1(idd, add) };
        // 第一次失败直接返回
        if (!tmp) return tmp;
        IDXGIAdapter1* apAdapters[MAX_GRAPHICS_ADAPTERS];
        DXGI_ADAPTER_DESC1 descs[MAX_GRAPHICS_ADAPTERS];
        GraphicsAdapterDesc gas[MAX_GRAPHICS_ADAPTERS];
        uint32_t adnum = 0;
        // 枚举适配器
        for (adnum = 0; adnum < MAX_GRAPHICS_ADAPTERS; ++adnum) {
            constexpr HRESULT nf = DXGI_ERROR_NOT_FOUND;
            if (dxgifactory->EnumAdapters1(adnum, apAdapters + adnum) == nf) {
                break;
            }
            auto desc = descs + adnum;
            apAdapters[adnum]->GetDesc1(descs + adnum);
            gas[adnum].friend_name = desc->Description;
            gas[adnum].shared_system = desc->SharedSystemMemory;
            gas[adnum].dedicated_video = desc->DedicatedVideoMemory;
            gas[adnum].dedicated_system = desc->DedicatedSystemMemory;
        }
        // 选择适配器
        const auto index = cfg->ChooseAdapter(gas, adnum);
        if (index < adnum) {
            adapter = UI::SafeAcquire(apAdapters[index]);
        }
        // 释放适配器
        for (size_t i = 0; i < adnum; ++i) {
            UI::SafeRelease(apAdapters[i]);
        }
        UI::SafeRelease(dxgifactory);
    }
    Result hr = { Result::RS_OK };
    // 创建 D3D11设备与设备上下文 
    if (hr) {
        // D3D11 创建flag 
        // 一定要有D3D11_CREATE_DEVICE_BGRA_SUPPORT
        // 否则创建D2D设备上下文会失败
        UINT creationFlags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#if !defined(NDEBUG)
        // Debug状态 有D3D DebugLayer就可以取消注释
        creationFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
        D3D_FEATURE_LEVEL featureLevels[] = {
            D3D_FEATURE_LEVEL_11_1,
            D3D_FEATURE_LEVEL_11_0,
            D3D_FEATURE_LEVEL_10_1,
            D3D_FEATURE_LEVEL_10_0,
            D3D_FEATURE_LEVEL_9_3,
            D3D_FEATURE_LEVEL_9_2,
            D3D_FEATURE_LEVEL_9_1
        };
        constexpr uint32_t fl_size = sizeof(featureLevels) / sizeof(featureLevels[0]);
        // 根据情况检查驱动类型
        const auto dtype = flag & IUIConfigure::Flag_RenderByCPU ? 
            D3D_DRIVER_TYPE_WARP : (adapter ? 
                D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE);
        D3D_DRIVER_TYPE types[] = { dtype, D3D_DRIVER_TYPE_WARP };
        HRESULT tmp;
        // 两次尝试
        for (auto type : types) {
            ID3D11Device* dev = nullptr;
            ID3D11DeviceContext* ctx = nullptr;
            // 创建设备
            tmp = ::D3D11CreateDevice(
                // 设置为渲染
                adapter,
                // 驱动类型
                dtype,
                // 没有软件接口
                nullptr,
                // 创建flag
                creationFlags,
                // 欲使用的特性等级列表
                featureLevels,
                // 特性等级列表长度
                fl_size,
                // SDK 版本
                D3D11_SDK_VERSION,
                // 返回的D3D11设备指针
                &dev,
                // 返回的特性等级
                nullptr,
                // 返回的D3D11设备上下文指针
                &ctx
            );
            m_p3DDevice = static_cast<I::Device3D*>(dev);
            m_p3DRenderer = static_cast<I::Renderer3D*>(ctx);
            // 成功就退出
            if (SUCCEEDED(tmp)) break;
        }
        // 再次检查错误
        if (FAILED(tmp)) {
            hr = { tmp };
            LUIDebug(Error) 
                << " create d3d11-device in twice, but failed."
                << UI::endl;
        }
    }
    // 释放选择的图像适配器
    UI::SafeRelease(adapter);
    // 创建 ID3D11Debug对象
#if !defined(NDEBUG)
    if (hr) {
        const Result tmp = { m_p3DDevice->QueryInterface(
            IID_ID3D11Debug,
            reinterpret_cast<void**>(&m_pDebug->d3d11debug)
        ) };
        longui_debug_hr(tmp, L"m_pd3dDevice->QueryInterface(m_pd3dDebug) faild");
    }
#endif
    // TODO: MMF
    IDXGIDevice1* dxgidev = nullptr;
    ID2D1Device* device2d = nullptr;
    IDXGIAdapter* dxgiadapter = nullptr;
    // 创建 IDXGIDevice
    if (hr) {
        hr = { m_p3DDevice->QueryInterface(
           IID_IDXGIDevice1,
           reinterpret_cast<void**>(&dxgidev)
        ) };
        longui_debug_hr(hr, L"m_pd3dDevice->QueryInterface(m_pd3dDebug) faild");
    }
    // 创建 D2D设备
    if (hr) {
        hr = { rm().d2dfactroy->CreateDevice(dxgidev, &device2d) };
        longui_debug_hr(hr, L"d2dfactroy->CreateDevice faild");
    }
    // 创建 D2D设备上下文
    if (hr) {
        ID2D1DeviceContext* d2ddc = nullptr;
        hr = { device2d->CreateDeviceContext(
            D2D1_DEVICE_CONTEXT_OPTIONS_NONE,
            &d2ddc
        ) };
        m_p2DRenderer = static_cast<I::Renderer2D*>(d2ddc);
        longui_debug_hr(hr, L"device2d->CreateDeviceContext faild");
    }
    // 创建公共颜色笔刷
    if (hr) {
        ID2D1SolidColorBrush* brush = nullptr;
        hr = { m_p2DRenderer->CreateSolidColorBrush(
            D2D1_COLOR_F{},
            &brush
        ) };
        const auto b = static_cast<ID2D1Brush*>(brush);
        m_pCommonBrush = static_cast<I::Brush*>(b);
    }
    // 获取 Dxgi适配器 可以获取该适配器信息
    if (hr) {
        // 顺带使用像素作为单位
        m_p2DRenderer->SetUnitMode(D2D1_UNIT_MODE_PIXELS);
        // 获取适配器
        hr = { dxgidev->GetAdapter(&dxgiadapter) };
        longui_debug_hr(hr, L"m_pDxgiDevice->GetAdapter faild");
    }
#ifndef NDEBUG
    // 输出显卡信息
    if (hr) {
        DXGI_ADAPTER_DESC desc = { 0 };
        dxgiadapter->GetDesc(&desc);
        GraphicsAdapterDesc d;
        d.friend_name = desc.Description;
        d.shared_system = desc.SharedSystemMemory;
        d.dedicated_video = desc.DedicatedVideoMemory;
        d.dedicated_system = desc.DedicatedSystemMemory;
        LUIDebug(Hint) << d << UI::endl;
    }
#endif
    // 获取 Dxgi工厂
    if (hr) {
        IDXGIFactory2* fc = nullptr;
        hr = { dxgiadapter->GetParent(
            IID_IDXGIFactory2,
            reinterpret_cast<void**>(&fc)
        ) };
        m_pGraphicsFactory = static_cast<I::FactoryGraphics*>(fc);
    }
    // 重定向主显示器
    if (hr) {
        this->redirect_screen();
    }
    // 释放选择的DXGI设备
    UI::SafeRelease(dxgidev);
    UI::SafeRelease(device2d);
    UI::SafeRelease(dxgiadapter);
    return hr;
}


/// <summary>
/// Redirects the screen.
/// </summary>
/// <returns></returns>
void UI::CUIResMgr::redirect_screen() noexcept {
    UI::SafeRelease(m_pMainScreen);
    assert(m_pGraphicsFactory && "bad action");
    // 初始化
    IDXGIAdapter1* adapter = nullptr;
    UINT ia = 0;
    // 枚举适配器
    while (m_pGraphicsFactory->EnumAdapters1(ia, &adapter) != DXGI_ERROR_NOT_FOUND) {
        assert(adapter && "bad action");
#ifndef NDEBUG
        DXGI_ADAPTER_DESC1 desca;
        adapter->GetDesc1(&desca);
#endif
        IDXGIOutput* output;
        // 枚举显示输出
        while (adapter->EnumOutputs(0, &output) != DXGI_ERROR_NOT_FOUND) {
            DXGI_OUTPUT_DESC desco;
            output->GetDesc(&desco);
            //UI::GetMonitorDpi(desco.Monitor, m_uMainDpiX, m_uMainDpiY);
            m_pMainScreen = static_cast<IScreen*>(output);
            adapter->Release();
            return;
        }
        ++ia;
        adapter->Release();
    }
    // 检查
    assert(!adapter && "bad action");
}


/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
void UI::CUIResMgr::release_device() noexcept {
#ifndef NDEBUG
    const auto d3d = m_p3DDevice;
#endif
    UI::SafeRelease(m_pMainScreen);
    UI::SafeRelease(m_pCommonBrush);
    UI::SafeRelease(m_p2DRenderer);
    UI::SafeRelease(m_p3DRenderer);
    UI::SafeRelease(m_p3DDevice);
    UI::SafeRelease(m_pGraphicsFactory);
#ifndef NDEBUG
    if (auto inf = m_pDebug->d3d11debug) {
        ::OutputDebugStringW(L"----> SUMMARY ReportLiveDeviceObjects\r\n");
        inf->ReportLiveDeviceObjects(D3D11_RLDO_SUMMARY);
        ::OutputDebugStringW(L"<----\r\n");
        if (false) {
            ::OutputDebugStringW(L"----> DETAIL ReportLiveDeviceObjects\r\n");
            inf->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
            ::OutputDebugStringW(L"<----\r\n");
        }
        auto c = inf->Release();
        c = c;
        m_pDebug->d3d11debug = nullptr;
    }
#endif
}

