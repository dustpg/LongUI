﻿#include <core/ui_resource_manager.h>
#include <graphics/ui_adapter_desc.h>
#include <interface/ui_iconfig.h>
#include <debugger/ui_debug.h>
#include <luiconf.h>

#include <cassert>

#define WIN32_LEAN_AND_MEAN
#include <graphics/ui_graphics_impl.h>
#pragma comment(lib, "dxgi")
#pragma comment(lib, "d3d11")
#pragma comment(lib, "d2d1")

/// <summary>
/// private data/func for resmgr
/// </summary>
struct UI::PrivateResMgr {
    // init
    inline auto init() noexcept->Result;
    // release
    inline void release() noexcept;
    // d2d factroy
    ID2D1Factory1*      d2dfactroy;
};



// DXGI DEBUG
#ifndef NDEBUG
#include <core/ui_object.h>
#include <dxgidebug.h>
/// <summary>
/// debug data
/// </summary>
struct UI::CUIResMgr::Debug : UI::CUIObject {
    // ctor
    Debug() noexcept { 
        // https://github.com/ajweeks/ApexEngine/blob/ff1a8d4accf55b109416bbfd1db590c1f92e63af/src/APEX/main.cpp
        dxgidebug = ::LoadLibraryA;
    }
    // debug dll
    HMODULE         dxgidebug;
};

#endif

/// <summary>
/// screen iterface
/// </summary>
struct PCN_NOVTABLE UI::CUIResMgr::IScreen : IDXGIOutput {};

/// <summary>
/// Waits for vblank.
/// </summary>
/// <returns></returns>
bool UI::CUIResMgr::wait_for_vblank() noexcept {
    // 存在显示输出?
    if (!m_pMainScreen) return false;
    // 等待垂直同步
    m_pMainScreen->WaitForVBlank();
    return true;
}

/// <summary>
/// Initializes this instance.
/// </summary>
/// <returns></returns>
inline auto UI::PrivateResMgr::init() noexcept -> Result {
    Result hr = { Result::RS_OK };
    // 创建D2D工厂
    if (hr) {
        D2D1_FACTORY_OPTIONS options = { D2D1_DEBUG_LEVEL_NONE };
#ifndef NDEBUG
        options.debugLevel = D2D1_DEBUG_LEVEL_INFORMATION;
#endif
        hr = { ::D2D1CreateFactory(
            D2D1_FACTORY_TYPE_SINGLE_THREADED,
            IID_ID2D1Factory1,
            &options,
            reinterpret_cast<void**>(&this->d2dfactroy)
        )};
        longui_debug_hr(hr, L"D2D1CreateFactory faild");
    }
    return hr;
}

/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
inline void UI::PrivateResMgr::release() noexcept {
    UI::SafeRelease(this->d2dfactroy);
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIResMgr" /> class.
/// </summary>
/// <param name="out">The out hr.</param>
UI::CUIResMgr::CUIResMgr(Result& out) noexcept {
    if (!out) return;
#ifndef NDEBUG
    m_pDebug = new(std::nothrow) Debug;
    if (!m_pDebug) { 
        out = { Result::RE_OUTOFMEMORY };
        return;
    }
#endif
    // 初始化无关资源
    Result hr = rm().init();
    out = hr;
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIResMgr"/> class.
/// </summary>
/// <returns></returns>
UI::CUIResMgr::~CUIResMgr() noexcept {
    // 释放设备资源
    this->release_device();
    // 释放无关资源
    rm().release();
#ifndef NDEBUG
    delete m_pDebug;
#endif
}


/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIResMgr::recreate(IUIConfigure* cfg) noexcept -> Result {
    static_assert(sizeof(PrivateResMgr) == sizeof(m_private), "must be same");
    this->release_device();
    const auto flag = cfg->GetConfigureFlag();
    // 待用适配器
    IDXGIAdapter1* adapter = nullptr;
    // 枚举显示适配器
    if (!(flag & IUIConfigure::Flag_RenderByCPU)) {
        IDXGIFactory1* dxgifactory = nullptr;
        const auto idd = IID_IDXGIFactory1;
        const auto add = reinterpret_cast<void**>(&dxgifactory);
        // 创建一个临时工厂
        const Result tmp = { ::CreateDXGIFactory1(idd, add) };
        // 第一次失败直接返回
        if (!tmp) return tmp;
        IDXGIAdapter1* apAdapters[MAX_GRAPHICS_ADAPTERS];
        DXGI_ADAPTER_DESC1 descs[MAX_GRAPHICS_ADAPTERS];
        GraphicsAdapterDesc gas[MAX_GRAPHICS_ADAPTERS];
        uint32_t adnum = 0;
        // 枚举适配器
        for (adnum = 0; adnum < MAX_GRAPHICS_ADAPTERS; ++adnum) {
            constexpr HRESULT nf = DXGI_ERROR_NOT_FOUND;
            if (dxgifactory->EnumAdapters1(adnum, apAdapters + adnum) == nf) {
                break;
            }
            auto desc = descs + adnum;
            apAdapters[adnum]->GetDesc1(descs + adnum);
            gas[adnum].friend_name = desc->Description;
            gas[adnum].shared_system = desc->SharedSystemMemory;
            gas[adnum].dedicated_video = desc->DedicatedVideoMemory;
            gas[adnum].dedicated_system = desc->DedicatedSystemMemory;
        }
        // 选择适配器
        const auto index = cfg->ChooseAdapter(gas, adnum);
        if (index < adnum) {
            adapter = UI::SafeAcquire(apAdapters[index]);
        }
        // 释放适配器
        for (size_t i = 0; i < adnum; ++i) {
            UI::SafeRelease(apAdapters[i]);
        }
        UI::SafeRelease(dxgifactory);
    }
    Result hr = { Result::RS_OK };
    // 创建 D3D11设备与设备上下文 
    if (hr) {
        // D3D11 创建flag 
        // 一定要有D3D11_CREATE_DEVICE_BGRA_SUPPORT
        // 否则创建D2D设备上下文会失败
        UINT creationFlags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#if !defined(NDEBUG)
        // Debug状态 有D3D DebugLayer就可以取消注释
        creationFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
        D3D_FEATURE_LEVEL featureLevels[] = {
            D3D_FEATURE_LEVEL_11_1,
            D3D_FEATURE_LEVEL_11_0,
            D3D_FEATURE_LEVEL_10_1,
            D3D_FEATURE_LEVEL_10_0,
            D3D_FEATURE_LEVEL_9_3,
            D3D_FEATURE_LEVEL_9_2,
            D3D_FEATURE_LEVEL_9_1
        };
        constexpr uint32_t fl_size = sizeof(featureLevels) / sizeof(featureLevels[0]);
        // 根据情况检查驱动类型
        const auto dtype = flag & IUIConfigure::Flag_RenderByCPU ? 
            D3D_DRIVER_TYPE_WARP : (adapter ? 
                D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE);
        D3D_DRIVER_TYPE types[] = { dtype, D3D_DRIVER_TYPE_WARP };
        HRESULT tmp;
        // 两次尝试
        for (auto type : types) {
            ID3D11Device* dev = nullptr;
            ID3D11DeviceContext* ctx = nullptr;
            // 创建设备
            tmp = ::D3D11CreateDevice(
                // 设置为渲染
                adapter,
                // 驱动类型
                dtype,
                // 没有软件接口
                nullptr,
                // 创建flag
                creationFlags,
                // 欲使用的特性等级列表
                featureLevels,
                // 特性等级列表长度
                fl_size,
                // SDK 版本
                D3D11_SDK_VERSION,
                // 返回的D3D11设备指针
                &dev,
                // 返回的特性等级
                nullptr,
                // 返回的D3D11设备上下文指针
                &ctx
            );
            m_p3DDevice = static_cast<I::Device3D*>(dev);
            m_p3DRenderer = static_cast<I::Renderer3D*>(ctx);
            // 成功就退出
            if (SUCCEEDED(tmp)) break;
        }
        // 再次检查错误
        if (FAILED(tmp)) {
            hr = { tmp };
            LUIDebug(Error) 
                << L" create d3d11-device in twice, but failed."
                << UI::endl;
        }
    }
    // 释放选择的图像适配器
    UI::SafeRelease(adapter);
    // 创建 ID3D11Debug对象
#if !defined(NDEBUG)
    if (hr) {
        ::DXGIGetDebugInterface()

        const Result tmp = { m_p3DDevice->QueryInterface(
            IID_ID3D11Debug,
            &m_pDebug3D
        ) };
        longui_debug_hr(tmp, L"m_pd3dDevice->QueryInterface(m_pd3dDebug) faild");
    }
#endif
    // TODO: MMF
    IDXGIDevice1* dxgidev = nullptr;
    ID2D1Device* device2d = nullptr;
    IDXGIAdapter* dxgiadapter = nullptr;
    // 创建 IDXGIDevice
    if (hr) {
        hr = { m_p3DDevice->QueryInterface(
           IID_IDXGIDevice1,
           reinterpret_cast<void**>(&dxgidev)
        ) };
        longui_debug_hr(hr, L"m_pd3dDevice->QueryInterface(m_pd3dDebug) faild");
    }
    // 创建 D2D设备
    if (hr) {
        hr = { rm().d2dfactroy->CreateDevice(dxgidev, &device2d) };
        longui_debug_hr(hr, L"d2dfactroy->CreateDevice faild");
    }
    // 创建 D2D设备上下文
    if (hr) {
        ID2D1DeviceContext* d2ddc = nullptr;
        hr = { device2d->CreateDeviceContext(
            D2D1_DEVICE_CONTEXT_OPTIONS_NONE,
            &d2ddc
        ) };
        m_p2DRenderer = static_cast<I::Renderer2D*>(d2ddc);
        longui_debug_hr(hr, L"device2d->CreateDeviceContext faild");
    }
    // 获取 Dxgi适配器 可以获取该适配器信息
    if (hr) {
        // 顺带使用像素作为单位
        m_p2DRenderer->SetUnitMode(D2D1_UNIT_MODE_PIXELS);
        // 获取适配器
        hr = { dxgidev->GetAdapter(&dxgiadapter) };
        longui_debug_hr(hr, L"m_pDxgiDevice->GetAdapter faild");
    }
#ifndef NDEBUG
    // 输出显卡信息
    if (hr) {
        DXGI_ADAPTER_DESC desc = { 0 };
        dxgiadapter->GetDesc(&desc);
        GraphicsAdapterDesc d;
        d.friend_name = desc.Description;
        d.shared_system = desc.SharedSystemMemory;
        d.dedicated_video = desc.DedicatedVideoMemory;
        d.dedicated_system = desc.DedicatedSystemMemory;
        LUIDebug(Hint) << d << UI::endl;
    }
#endif
    // 获取 Dxgi工厂
    if (hr) {
        IDXGIFactory2* fc = nullptr;
        hr = { dxgiadapter->GetParent(
            IID_IDXGIFactory2,
            reinterpret_cast<void**>(&fc)
        ) };
        m_pGraphicsFactory = static_cast<I::FactoryGraphics*>(fc);
    }
    // 重定向主显示器
    if (hr) {
        this->redirect_screen();
    }
    // 释放选择的DXGI设备
    UI::SafeRelease(dxgidev);
    UI::SafeRelease(device2d);
    UI::SafeRelease(dxgiadapter);
    return hr;
}


/// <summary>
/// Releases this instance.
/// </summary>
/// <returns></returns>
void UI::CUIResMgr::release_device() noexcept {
#ifndef NDEBUG
    const auto d3d = m_p3DDevice;
#endif
    UI::SafeRelease(m_pMainScreen);
    UI::SafeRelease(m_p2DRenderer);
    UI::SafeRelease(m_p3DRenderer);
    UI::SafeRelease(m_p3DDevice);
    UI::SafeRelease(m_pGraphicsFactory);
#ifndef NDEBUG
    /*if (auto inf = reinterpret_cast<ID3D11Debug*>(m_pDebug3D)) {
        ::OutputDebugStringW(L"----> SUMMARY ReportLiveDeviceObjects\r\n");
        inf->ReportLiveDeviceObjects(D3D11_RLDO_SUMMARY);
        ::OutputDebugStringW(L"<----\r\n");
        if (false) {
            ::OutputDebugStringW(L"----> DETAIL ReportLiveDeviceObjects\r\n");
            inf->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
            ::OutputDebugStringW(L"<----\r\n");
        }
        inf->Release();
        m_pDebug3D = nullptr;
    }*/
#endif
}


/// <summary>
/// Redirects the screen.
/// </summary>
/// <returns></returns>
void UI::CUIResMgr::redirect_screen() noexcept {
    UI::SafeRelease(m_pMainScreen);
    assert(m_pGraphicsFactory && "bad action");
    // 调试
#ifndef NDEBUG
    /*m_vFpsCalculator.reserve(m_dDisplayFrequency);
    if (!m_vFpsCalculator.isok()) return E_OUTOFMEMORY;
    m_vFpsCalculator.clear();*/

#endif
    // 初始化
    IDXGIAdapter1* adapter = nullptr;
    UINT ia = 0;
    // 枚举适配器
    while (m_pGraphicsFactory->EnumAdapters1(ia, &adapter) != DXGI_ERROR_NOT_FOUND) {
        assert(adapter && "bad action");
#ifndef NDEBUG
        DXGI_ADAPTER_DESC1 desca;
        adapter->GetDesc1(&desca);
#endif
        IDXGIOutput* output;
        // 枚举显示输出
        while (adapter->EnumOutputs(0, &output) != DXGI_ERROR_NOT_FOUND) {
            DXGI_OUTPUT_DESC desco;
            output->GetDesc(&desco);
            //UI::GetMonitorDpi(desco.Monitor, m_uMainDpiX, m_uMainDpiY);
            m_pMainScreen = static_cast<IScreen*>(output);
            return;
        }
        ++ia;
        adapter->Release();
    }
    // 检查
    assert(!adapter && "bad action");
}