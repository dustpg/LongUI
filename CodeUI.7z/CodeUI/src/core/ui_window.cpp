﻿#define WIN32_LEAN_AND_MEAN
#include <core/ui_window.h>
#include <style/ui_ssvalue.h>
#include <cassert>


// ui namespace
namespace UI {
    /// <summary>
    /// private data for CUIWindow
    /// </summary>
    class PrivateWindow : public CUIObject {
    public:
        // ctor
        PrivateWindow() noexcept;
        // dtor
        ~PrivateWindow() noexcept;
    private:
    public:
        // position of window
        Point2L         pos = {};
        // stylesheets: values
        SSValues        values;
        // stylesheets: selectors
        SSSelectors     selectors;
    };
    /// <summary>
    /// Xuis the window private.
    /// </summary>
    /// <returns></returns>
    UI::PrivateWindow::PrivateWindow() noexcept {
        UI::ParseStylesheet("", values, selectors);
    }
    /// <summary>
    /// Finalizes an instance of the <see cref=""/> class.
    /// </summary>
    /// <returns></returns>
    UI::PrivateWindow::~PrivateWindow() noexcept {
    }
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::CUIWindow::CUIWindow(CUIWindow* parent) noexcept :
m_pParent(parent), m_private(new(std::nothrow) PrivateWindow) {
    // TODO: 致命错误: 内存不足
    //if (!m_private)
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWindow::~CUIWindow() noexcept {
    delete m_private;
}
