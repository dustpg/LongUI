﻿#define WIN32_LEAN_AND_MEAN
#include <core/ui_window.h>
#include <style/ui_ssvalue.h>
#include <cassert>


// ui namespace
namespace UI {
    /// <summary>
    /// private data for CUIWindow
    /// </summary>
    class PrivateWindow : public CUIObject {
    public:
        // ctor
        PrivateWindow() noexcept;
        // dtor
        ~PrivateWindow() noexcept;
    private:
    public:
        // position of window
        Point2L         pos = {};
        // stylesheets: values
        SSValues        values;
        // stylesheets: selectors
        SSSelectors     selectors;
    };
    /// <summary>
    /// Xuis the window private.
    /// </summary>
    /// <returns></returns>
    UI::PrivateWindow::PrivateWindow() noexcept {
        UI::ParseStylesheet("", values, selectors);
    }
    /// <summary>
    /// Finalizes an instance of the <see cref=""/> class.
    /// </summary>
    /// <returns></returns>
    UI::PrivateWindow::~PrivateWindow() noexcept {
    }
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::CUIWindow::CUIWindow(CUIWindow* parent) noexcept :
m_parent(parent), m_private(new(std::nothrow) PrivateWindow) {
    // TODO: 致命错误: 内存不足
    //if (!m_private)
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWindow::~CUIWindow() noexcept {
    delete m_private;
}

#include <Windows.h>


/// <summary>
/// Sets the position.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::CUIWindow::SetPos(Point2L pos) noexcept {
    assert(m_private && "bug: you shall not pass");
    auto& this_pos = m_private->pos;
    // 无需移动窗口
    if (this_pos.x == pos.x && this_pos.y == pos.y) return; this_pos = pos;
    // 内联窗口
    if (this->IsInlineWindow()) {
        assert(!"NOT IMPL");
    }
    // 系统窗口
    else {
        ::SetWindowPos(m_hwnd, nullptr, pos.x, pos.y, 0, 0, SWP_NOSIZE);
    }
}


/// Gets the position.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::GetPos() const noexcept -> Point2L {
    return m_private->pos;
}