﻿// Gui
#include <luiconf.h>
#include <core/ui_window.h>
#include <util/ui_unicode.h>
#include <core/ui_manager.h>
#include <input/ui_kminput.h>
#include <style/ui_ssvalue.h>
#include <container/pod_hash.h>
#include <graphics/ui_cursor.h>
#include <control/ui_viewport.h>
#include <graphics/ui_graphics_decl.h>
// C++
#include <cassert>
// Windows
#include <Windows.h>
#include <Dwmapi.h>

#ifndef NDEBUG
#include <core/ui_color_list.h>
#include <util/ui_time_meter.h>
#include "../private/ui_private_control.h"
#endif

/// <summary>
/// Sets the control world changed.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::SetControlWorldChanged(UIControl& ctrl) noexcept {
    assert(PrivateControl::TestWorldChanged(ctrl));
    assert(ctrl.GetWindow() == this);
    if (m_pTopestWcc && m_pTopestWcc->GetLevel() < ctrl.GetLevel()) return;
    m_pTopestWcc = &ctrl;
}

// ui namespace
namespace UI {
    // private msg
    struct PrivateMsg;
    /// <summary>
    /// Gets the size of the client.
    /// </summary>
    /// <param name="hwnd">The HWND.</param>
    /// <returns></returns>
    auto GetClientSize(HWND hwnd) noexcept -> Size2U {
        RECT client_rect; ::GetClientRect(hwnd, &client_rect);
        return {
            uint32_t(client_rect.right - client_rect.left),
            uint32_t(client_rect.bottom - client_rect.top)
        };
    }
    /// <summary>
    /// private data for CUIWindow
    /// </summary>
    class PrivateWindow : public CUIObject {
        // control map
        using CtrlMap = POD::HashMap<UIControl*>;
        // release data
        void release_data() noexcept;
        // begin render
        void begin_render() const noexcept;
        // begin render
        auto end_render() const noexcept->Result;
        // clean up
        //void cleanup() noexcept;
    public:
        // ctor
        PrivateWindow() noexcept;
        // dtor
        ~PrivateWindow() noexcept { this->release_data(); }
        // init
        HWND Init(HWND parent) noexcept;
        // recreate
        auto Recreate(HWND hwnd) noexcept->Result;
        // render
        auto Render(const UIViewport& v) const noexcept->Result;
    public:
        // mouse event
        void DoMouseEvent(const MouseEventArg& args) noexcept;
        // do msg
        auto DoMsg(const PrivateMsg&) noexcept ->intptr_t;
        // when create
        void OnCreate(HWND) noexcept {}
        // when close
        void OnClose() noexcept;
        // when resize[thread safe]
        void OnResizeTs(Size2U) noexcept;
        // when key down
        void OnKeyDown(CUIInputKM::KB key) noexcept;
        // when system key down
        void OnSystemKeyDown(CUIInputKM::KB key) noexcept;
        // when input a utf-16 char
        void OnChar(char16_t ch) noexcept;
        // when input a utf-32 char[thread safe]
        void OnCharTs(char32_t ch) noexcept;
    private: // TODO: is_xxxx
        // full render this frame?
        inline bool is_full_render_at_rendering() const noexcept { return true; }
        // using direct composition?
        inline bool is_direct_composition() const noexcept { return false; }
        // is skip render?
        inline bool is_skip_render() const noexcept { return false; }
        // is popup window?
        inline bool is_popup() const noexcept { return false; }
    public:
        // register the window class
        static void RegisterWindowClass() noexcept;
    public:
        // swap chian
        I::Swapchan*    swapchan = nullptr;
        // bitmap buffer
        I::Bitmap*      bitmap = nullptr;
    public:
        // mouse track data
        TRACKMOUSEEVENT track_mouse;
    public:
        // viewport
        UIViewport*     viewport = nullptr;
        // now cursor
        CUICursor       cursor = { CUICursor::Cursor_Arrow };
        // rect of window
        RectWHL         rect = {};
        // stylesheets: values
        SSValues        values;
        // stylesheets: selectors
        SSSelectors     selectors;
#ifndef NDEBUG
        // full render counter
        uint32_t        dbg_full_render_counter = 0;
        // dirty render counter
        uint32_t        dbg_dirty_render_counter = 0;
#endif
    public:
        // named control map
        CtrlMap         ctrl_map;
        // focused control
        UIControl*      focused = nullptr;
        // TODO: focused control - saved 
        UIControl*      saved_focused = nullptr;
        // captured control
        UIControl*      captured = nullptr;
        // now defualt control
        UIControl*      now_defualt = nullptr;
        // window defualt control
        UIControl*      wnd_defualt = nullptr;
    public:
        // save utf-16 char
        char16_t        saved_utf16 = 0;
        // borderless
        bool            borderless : 1;
        // sized
        bool            flag_sized : 1;
        // mouse enter
        bool            mouse_enter : 1;
        //  moving or resizing
        bool            moving_resizing : 1;
    private:
        // resize window buffer
        void resize_window_buffer() noexcept;
        // forece resize
        void force_resize_window_buffer() const noexcept {
            const_cast<PrivateWindow*>(this)->
                resize_window_buffer();
        }
    };
    /// <summary>
    /// Privates the window.
    /// </summary>
    /// <returns></returns>
    UI::PrivateWindow::PrivateWindow() noexcept {
        flag_sized = false;
        borderless = false;
        mouse_enter = false;
        moving_resizing = false;
    }
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::CUIWindow::CUIWindow(CUIWindow* parent) noexcept :
m_parent(parent), m_private(new(std::nothrow) PrivateWindow) {
    // XXX: OOM 处理
    if (!m_private) return;
    // 初始化
    m_private->viewport = &this->RefViewport();
    m_hwnd = m_private->Init(parent ? parent->GetHwnd() : nullptr);
    UIManager.add_window(*this);
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWindow::~CUIWindow() noexcept {
#ifdef LUI_ACCESSIBLE
    if (m_pAccessible) {
        UI::FinalizeAccessible(*m_pAccessible);
        m_pAccessible = nullptr;
    }
#endif
    if (m_private) {
        UIManager.remove_window(*this);
        delete m_private;
    }
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::Render() const noexcept -> Result {
    assert(m_private && "bug: you shall not pass");
    auto&v = const_cast<CUIWindow*>(this)->RefViewport();
    return m_private->Render(v);
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::recreate() noexcept -> Result {
    assert(m_private && "bug: you shall not pass");
    return m_private->Recreate(m_hwnd);
}

/// Gets the position.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::GetPos() const noexcept -> Point2L {
    return{ m_private->rect.left , m_private->rect.top };
}

/// <summary>
/// Finds the control.
/// </summary>
/// <param name="id">The identifier.</param>
/// <returns></returns>
auto UI::CUIWindow::FindControl(const char* id) noexcept -> UIControl* {
    assert(id && "bad id");
    auto& map = m_private->ctrl_map;
    const auto itr = map.find(id);
    return itr != map.end() ? itr->second : nullptr;
}

/// <summary>
/// Controls the attached.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::ControlAttached(UIControl& ctrl) noexcept {
    this->AddNamedControl(ctrl);
}

/// <summary>
/// Adds the named control.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::AddNamedControl(UIControl& ctrl) noexcept {
    // 注册命名控件
    if (this && *ctrl.GetID()) {
        // 必须没有被注册过
        assert(!this->FindControl(ctrl.GetID()) && "id exist!");
        // XXX: 错误处理
        m_private->ctrl_map.insert({ ctrl.GetID(), &ctrl });
    }
}

/// <summary>
/// Controls the disattached.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <remarks>
/// null this ptr acceptable
/// </remarks>
/// <returns></returns>
void UI::CUIWindow::ControlDisattached(UIControl& ctrl) noexcept {
    if (!this) return;
    // XXX: ControlDisattached
    // TODO: 这几个移动到CUIWindow厘里面, 方便Get
    assert(m_private->focused);
    assert(m_private->captured);
    assert(m_private->saved_focused);
    // 移除映射表中的引用
    if (*ctrl.GetID()) {
        assert(!"NOT IMPL");
    }
}

/// <summary>
/// Sets the focus.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
bool UI::CUIWindow::SetFocus(UIControl& ctrl) noexcept {
    // 不可聚焦
    if (!ctrl.IsFocusable()) return false;
    // 焦点控件
    auto& focused = m_private->focused;
    // 当前焦点不能是待聚焦控件的祖先控件
#ifndef DEBUG
    if (focused) {
        assert(
            !ctrl.IsAncestorForThis(*focused) && 
            "cannot set focus to control that ancestor was focused"
        );
    }
#endif
    // 已为焦点
    if (focused == &ctrl) return true;
    // 释放之前焦点
    if (focused) this->KillFocus(*focused);
    // 设为焦点
    focused = &ctrl;
    ctrl.StartAnimation({ StyleStateType::Type_Focus, true });
    return true;
}


/// <summary>
/// Sets the capture.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::SetCapture(UIControl& ctrl) noexcept {
    m_private->captured = &ctrl;
    //LUIDebug(Hint) << ctrl << endl;
}

/// <summary>
/// Releases the capture.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
bool UI::CUIWindow::ReleaseCapture(UIControl& ctrl) noexcept {
    if (&ctrl == m_private->captured) {
        //LUIDebug(Hint) << ctrl << endl;
        assert(m_private->captured);
        m_private->captured = nullptr;
        return true;
    }
    return false;
}

/// <summary>
/// Kills the focus.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::KillFocus(UIControl& ctrl) noexcept {
    if (m_private->focused == &ctrl) {
        m_private->focused = nullptr;
        m_private->saved_focused = nullptr;
        ctrl.StartAnimation({ StyleStateType::Type_Focus, false });
    }
}

/// <summary>
/// Resets the defualt.
/// </summary>
/// <returns></returns>
void UI::CUIWindow::ResetDefualt() noexcept {
    if (m_private->wnd_defualt) {
        this->SetDefualt(*m_private->wnd_defualt);
    }
}

/// <summary>
/// Sets the defualt.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::SetDefualt(UIControl& ctrl) noexcept {
    assert(this && "null this ptr");
    if (!ctrl.IsDefaultable()) return;
    constexpr auto dtype = StyleStateType::Type_Defualt;
    auto& nowc = m_private->now_defualt;
    if (nowc) nowc->StartAnimation({ dtype , false });
    (nowc = &ctrl)->StartAnimation({ dtype , true });
}


/// <summary>
/// Raises the Close event.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::OnClose() noexcept {

}

/// <summary>
/// Called when [resize].
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::PrivateWindow::OnResizeTs(Size2U size) noexcept {
    assert(size.width && size.height && "bad size");
    // 不一样才处理
    const auto samew = this->rect.width == size.width;
    const auto sameh = this->rect.height == size.height;
    if (samew && sameh) return;
    CUIDataAutoLocker locker;
    // 修改
    this->rect.width = size.width;
    this->rect.height = size.height;
    // 重置大小
    this->viewport->Resize({
        static_cast<float>(size.width),
        static_cast<float>(size.height)
    });
    // 修改窗口缓冲帧大小
    this->flag_sized = true;
}

// ----------------------------------------------------------------------------
// ------------------- Windows
// ----------------------------------------------------------------------------


/// <summary>
/// Maps to screen.
/// </summary>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUIWindow::MapToScreen(RectF& rect) const noexcept {
    // 内联窗口
    if (this->IsInlineWindow()) {
        assert(!"NOT IMPL");
    }
    // 系统窗口
    else {
        POINT pt{ 0, 0 };
        ::ClientToScreen(m_hwnd, &pt);
        const auto px = static_cast<float>(pt.x);
        const auto py = static_cast<float>(pt.y);
        rect.top += py;
        rect.left += px;
        rect.right += px;
        rect.bottom += py;
    }
}

/// <summary>
/// Maps to screen.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::CUIWindow::MapToScreen(Point2F& pos) const noexcept {
    RectF rect = { pos.x, pos.y, pos.x, pos.y };
    this->MapToScreen(rect);
    pos = { rect.left, rect.top };
}


/// <summary>
/// Maps from screen.
/// </summary>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUIWindow::MapFromScreen(Point2F& pos) const noexcept {
    // 内联窗口
    if (this->IsInlineWindow()) {
        assert(!"NOT IMPL");
    }
    // 系统窗口
    else {
        POINT pt{ 0, 0 };
        ::ScreenToClient(m_hwnd, &pt);
        const auto px = static_cast<float>(pt.x);
        const auto py = static_cast<float>(pt.y);
        pos.x += px;
        pos.y += py;
    }
}

/// <summary>
/// Shows the window.
/// </summary>
/// <param name="sw">The sw type.</param>
/// <returns></returns>
void UI::CUIWindow::show_window(TypeShow sw) noexcept {
    assert(m_hwnd && "bad window");
    ::ShowWindow(m_hwnd, sw);
}

/// <summary>
/// Sets the name of the title.
/// </summary>
/// <param name="name">The name.</param>
/// <returns></returns>
void UI::CUIWindow::SetTitleName(const wchar_t* name) noexcept {
    assert(name && "bad name");
    assert(m_hwnd && "bad window");
    ::DefWindowProcW(m_hwnd, WM_SETTEXT, WPARAM(0), LPARAM(name));
}

/// <summary>
/// Sets the position.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::CUIWindow::SetPos(Point2L pos) noexcept {
    assert(m_private && "bug: you shall not pass");
    auto& this_pos = reinterpret_cast<Point2L&>(m_private->rect.left);
    // 无需移动窗口
    if (this_pos.x == pos.x && this_pos.y == pos.y) return; this_pos = pos;
    // 内联窗口
    if (this->IsInlineWindow()) {
        assert(!"NOT IMPL");
    }
    // 系统窗口
    else {
        ::SetWindowPos(m_hwnd, nullptr, pos.x, pos.y, 0, 0, SWP_NOSIZE);
    }
}

/// <summary>
/// Called when [key down].
/// </summary>
/// <param name="vk">The vk.</param>
/// <returns></returns>
void UI::PrivateWindow::OnKeyDown(CUIInputKM::KB key) noexcept {

}

/// <summary>
/// Called when [system key down].
/// </summary>
/// <param name="key">The key.</param>
/// <returns></returns>
void UI::PrivateWindow::OnSystemKeyDown(CUIInputKM::KB key) noexcept {
    // 检查访问键

}

// c
extern "C" {
    // char16 -> char32
    char32_t impl_char16x2_to_char32(char16_t lead, char16_t trail);
}

/// <summary>
/// Called when [character].
/// </summary>
/// <param name="ch">The ch.</param>
/// <returns></returns>
void UI::PrivateWindow::OnChar(char16_t ch) noexcept {
    char32_t ch32;
    // UTF16 第一字
    if (Unicode::IsHighSurrogate(ch)) { this->saved_utf16 = ch; return; }
    // UTF16 第二字
    else if (Unicode::IsLowSurrogate(ch)) {
        ch32 = impl_char16x2_to_char32(this->saved_utf16, ch);
        this->saved_utf16 = 0;
    }
    // UTF16 仅一字
    else ch32 = static_cast<char32_t>(ch);
    // 处理输入
    this->OnCharTs(ch32);
}

/// <summary>
/// Called when [character].
/// </summary>
/// <param name="ch">The ch.</param>
/// <returns></returns>
void UI::PrivateWindow::OnCharTs(char32_t ch) noexcept {

}

// ui::detail
namespace UI { namespace detail {
    // window style
    enum style : DWORD {
        windowed         = WS_OVERLAPPEDWINDOW | WS_THICKFRAME | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
        aero_borderless  = WS_POPUP            | WS_THICKFRAME | WS_CAPTION | WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX,
        basic_borderless = WS_POPUP            | WS_THICKFRAME              | WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX
    };
}}

/// <summary>
/// Initializes this instance.
/// </summary>
/// <param name="parent">The parent.</param>
/// <returns></returns>
HWND UI::PrivateWindow::Init(HWND parent) noexcept {
    // 尝试注册
    this->RegisterWindowClass();
    // 初始化
    HWND hwnd = nullptr;
    UI::ParseStylesheet("", this->values, this->selectors);
    // 标题名称
    const wchar_t* titlename = nullptr;
    // 窗口
    {
        // 检查样式样式
        const DWORD window_style = WS_OVERLAPPEDWINDOW;

        // 设置窗口大小
        RECT client_rect {
            0, 0, 
            DEFAULT_WINDOW_WIDTH / 2, 
            DEFAULT_WINDOW_HEIGHT / 2
        };
        // 调整大小
        ::AdjustWindowRect(&client_rect, window_style, FALSE);
        // 窗口
        RectWHL window_rect;
        window_rect.width = (client_rect.right - client_rect.left);
        window_rect.height = (client_rect.bottom - client_rect.top);
        // 屏幕大小
        const auto scw = ::GetSystemMetrics(SM_CXFULLSCREEN);
        const auto sch = ::GetSystemMetrics(SM_CYFULLSCREEN);
        // 居中显示
        window_rect.left = (scw - window_rect.width) / 2;
        window_rect.top = (sch - window_rect.height) / 2;
        // 创建窗口
        hwnd = ::CreateWindowExW(
            //WS_EX_NOREDIRECTIONBITMAP | WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT,
            this->is_direct_composition() ? WS_EX_NOREDIRECTIONBITMAP : 0,
            this->is_popup() ?
            Attribute::WindowClassNameP : Attribute::WindowClassNameN,
            titlename,
            window_style,
            window_rect.left, window_rect.top,
            window_rect.width, window_rect.height,
            parent,
            nullptr,
            ::GetModuleHandleA(nullptr),
            this
        );
        // TODO: 禁止 Alt + Enter 全屏
        //UIManager_DXGIFactory.MakeWindowAssociation(hwnd, DXGI_MWA_NO_WINDOW_CHANGES | DXGI_MWA_NO_ALT_ENTER);
    }
    // 创建成功
    if (hwnd) {

        //MARGINS shadow_state{ 1,1,1,1 };
        //::DwmExtendFrameIntoClientArea(hwnd, &shadow_state);
        //::SetWindowPos(hwnd, nullptr, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE);

        this->track_mouse.cbSize = sizeof(this->track_mouse);
        this->track_mouse.dwFlags = TME_HOVER | TME_LEAVE;
        this->track_mouse.hwndTrack = hwnd;
        this->track_mouse.dwHoverTime = HOVER_DEFAULT;
    }
    return hwnd;
}


/// <summary>
/// private msg
/// </summary>
struct UI::PrivateMsg { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; };


/// <summary>
/// Registers the window class.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::RegisterWindowClass() noexcept {
    const auto ins = ::GetModuleHandleW(nullptr);
    WNDCLASSEXW wcex;
    auto code = ::GetClassInfoExW(ins, Attribute::WindowClassNameN, &wcex);
    if (!code) {
        // 处理
        auto proc = [](HWND hwnd, 
            UINT message, 
            WPARAM wParam, 
            LPARAM lParam
            ) noexcept -> LRESULT {
            // 创建窗口时设置指针
            if (message == WM_CREATE) {
                // 获取指针
                auto* window = reinterpret_cast<PrivateWindow*>(
                    (reinterpret_cast<LPCREATESTRUCT>(lParam))->lpCreateParams
                    );
                // 设置窗口指针
                ::SetWindowLongPtrW(hwnd, GWLP_USERDATA, LONG_PTR(window));
                // TODO: 创建完毕
                window->OnCreate(hwnd);
                // 返回1
                return 1;
            }
            // 其他情况则获取储存的指针
            else {
                const PrivateMsg msg { hwnd, message, wParam, lParam };
                const auto lptr = ::GetWindowLongPtrW(hwnd, GWLP_USERDATA);
                const auto window = reinterpret_cast<PrivateWindow*>(lptr);
                if (!window) return ::DefWindowProcW(hwnd, message, wParam, lParam);
                return window->DoMsg(msg);
            }
        };
        // 注册一般窗口类
        wcex = { 0 };
        wcex.cbSize = sizeof(WNDCLASSEXW);
        wcex.style = 0;
        wcex.lpfnWndProc = proc;
        wcex.cbClsExtra = 0;
        wcex.cbWndExtra = sizeof(void*);
        wcex.hInstance = ins;
        wcex.hCursor = nullptr;
        wcex.hbrBackground = nullptr;
        wcex.lpszMenuName = nullptr;
        wcex.lpszClassName = Attribute::WindowClassNameN;
        wcex.hIcon = nullptr; // ::LoadIconW(ins, MAKEINTRESOURCEW(101));
        ::RegisterClassExW(&wcex);
        // 注册弹出窗口类
        wcex.style = CS_DROPSHADOW;
        wcex.lpszClassName = Attribute::WindowClassNameP;
        ::RegisterClassExW(&wcex);
    }
}

// ui namespace
namespace UI {
    // mouse event map(use char to avoid unnecessary memory-waste)
    const uint8_t MEMAP[] = {
        // WM_MOUSEMOVE                 0x0200
        static_cast<uint8_t>(MouseEvent::Event_MouseMove),
        // WM_LBUTTONDOWN               0x0201
        static_cast<uint8_t>(MouseEvent::Event_LButtonDown),
        // WM_LBUTTONUP                 0x0202
        static_cast<uint8_t>(MouseEvent::Event_LButtonUp),
        // WM_LBUTTONDBLCLK             0x0203
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_RBUTTONDOWN               0x0204
        static_cast<uint8_t>(MouseEvent::Event_RButtonDown),
        // WM_RBUTTONUP                 0x0205
        static_cast<uint8_t>(MouseEvent::Event_RButtonUp),
        // WM_RBUTTONDBLCLK             0x0206
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MBUTTONDOWN               0x0207
        static_cast<uint8_t>(MouseEvent::Event_MButtonDown),
        // WM_MBUTTONUP                 0x0208
        static_cast<uint8_t>(MouseEvent::Event_MButtonUp),
        // WM_MBUTTONDBLCLK             0x0209
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MOUSEWHEEL                0x020A
        static_cast<uint8_t>(MouseEvent::Event_MouseWheelV),
        // WM_XBUTTONDOWN               0x020B
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_XBUTTONUP                 0x020C
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_XBUTTONDBLCLK             0x020D
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MOUSEHWHEEL               0x020E
        static_cast<uint8_t>(MouseEvent::Event_MouseWheelH),
    };
}

/// <summary>
/// Mouses the event.
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
void UI::PrivateWindow::DoMouseEvent(const MouseEventArg & args) noexcept {
    CUIDataAutoLocker locker;
    UIControl* ctrl = this->captured;
    if (!ctrl) ctrl = this->viewport;
    ctrl->DoMouseEvent(args);
}

#ifdef LUI_ACCESSIBLE
#include <accessible/ui_accessible_win.h>

#endif

/// <summary>
/// Does the MSG.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
auto UI::PrivateWindow::DoMsg(const PrivateMsg& prmsg) noexcept -> intptr_t {
    MouseEventArg arg;
    const auto hwnd = prmsg.hwnd;
    const auto message = prmsg.message;
    const auto lParam = prmsg.lParam;
    const auto wParam = prmsg.wParam;
    // 鼠标离开
    if (message == WM_MOUSELEAVE) {
        arg.px = -1.f; arg.py = -1.f;
        arg.wheel = 0.f;
        arg.type = MouseEvent::Event_MouseLeave;
        this->mouse_enter = false;
        this->DoMouseEvent(arg);
    }
    // 一般鼠标消息处理
    else if (message >= WM_MOUSEFIRST && message <= WM_MOUSELAST) {
        // 检查映射表长度
        constexpr size_t ARYLEN = sizeof(MEMAP) / sizeof(MEMAP[0]);
        constexpr size_t MSGLEN = WM_MOUSELAST - WM_MOUSEFIRST + 1;
        static_assert(ARYLEN == MSGLEN, "must be same");
        // 初始化参数
        arg.type = static_cast<MouseEvent>(MEMAP[message - WM_MOUSEFIRST]);
        arg.wheel = 0.f;
        arg.px = static_cast<float>(int16_t(LOWORD(lParam)));
        arg.py = static_cast<float>(int16_t(HIWORD(lParam)));
        // shift+滚轮自动映射到水平方向
        if (message == WM_MOUSEWHEEL && (wParam & MK_SHIFT)) {
            arg.type = MouseEvent::Event_MouseWheelH;
        }
        switch (arg.type)
        {
            float delta;
        case MouseEvent::Event_MouseWheelV:
        case MouseEvent::Event_MouseWheelH:
            // 滚轮消息则修改滚轮数据
            delta = static_cast<float>(int16_t(HIWORD(wParam)));
            arg.wheel = delta / static_cast<float>(WHEEL_DELTA);
            break;
        case MouseEvent::Event_MouseMove:
            // 第一次进入
            if (!this->mouse_enter) {
                arg.type = MouseEvent::Event_MouseEnter;
                this->mouse_enter = true;
                this->DoMouseEvent(arg);
                arg.type = MouseEvent::Event_MouseMove;
            };
            // 鼠标跟踪
            ::TrackMouseEvent(&this->track_mouse);
            break;
        case MouseEvent::Event_LButtonDown:
            ::SetCapture(hwnd);
            //LUIDebug(Hint) << "\r\n\t\tDown: " << this->captured << endl;
            break;
        case MouseEvent::Event_LButtonUp:
            //LUIDebug(Hint) << "\r\n\t\tUp  : " << this->captured << endl;
            ::ReleaseCapture();
            break;
        }
        this->DoMouseEvent(arg);
    }
    // 其他消息处理
    else
        WM_NCCALCSIZE;
        switch (message)
        {
        case WM_SETCURSOR:
            ::SetCursor(reinterpret_cast<HCURSOR>(this->cursor.GetHandle()));
            break;
#ifdef LUI_ACCESSIBLE
        case WM_DESTROY:
            ::UiaReturnRawElementProvider(hwnd, 0, 0, nullptr);
            return 1;
        case WM_GETOBJECT:
            if (static_cast<long>(lParam) == static_cast<long>(UiaRootObjectId)) {
                const auto window = this->viewport->GetWindow();
                assert(window && "cannot be null");
                const auto root = CUIAccessibleWnd::FromWindow(*window);
                return ::UiaReturnRawElementProvider(hwnd, wParam, lParam, root);
            }
            return 0;
#endif
        case WM_ENTERSIZEMOVE:
            this->moving_resizing = true;
            break;
        case WM_EXITSIZEMOVE:
            // TODO: flag检查是否允许拖动时缩放
            this->moving_resizing = false;
            this->OnResizeTs(UI::GetClientSize(hwnd));
            break;
        //case WM_NCCALCSIZE:
        //    if (wParam) return 0;
        //    break;
        case WM_SIZE:
            // 最小化不算
            switch (wParam) { case SIZE_MINIMIZED: return 0; }
            // 拖拽重置不算
            if (this->moving_resizing) return 0;
            // 重置大小
            this->OnResizeTs({ LOWORD(lParam), HIWORD(lParam) });
            return 1;
        case WM_KEYDOWN:
            UIManager.DataLock();
            this->OnKeyDown(static_cast<CUIInputKM::KB>(wParam));
            UIManager.DataUnlock();
            return 1;
        case WM_SYSKEYDOWN:
            UIManager.DataLock();
            this->OnSystemKeyDown(static_cast<CUIInputKM::KB>(wParam));
            UIManager.DataUnlock();
            return 1;
        //case WM_GETMINMAXINFO:
        //    ::DefWindowProcW(hwnd, message, wParam, lParam);
        //    {
        //        const auto info = reinterpret_cast<MINMAXINFO*>(lParam);
        //        int bk = 9;
        //    }
        //    break;
        case WM_CHAR:
            // LOCK: 加锁?
            this->OnChar(static_cast<char16_t>(wParam));
            return 1;
        case WM_UNICHAR:
            this->OnCharTs(static_cast<char32_t>(wParam));
            return 1;
        case WM_MOVING:
            // LOCK: 加锁?
            this->rect.top = reinterpret_cast<RECT*>(lParam)->top;
            this->rect.left = reinterpret_cast<RECT*>(lParam)->left;
            return 1;
        case WM_CLOSE:
            ::PostQuitMessage(0);
            break;
        }
    // 未处理消息
    return ::DefWindowProcW(hwnd, message, wParam, lParam);
}


// ----------------------------------------------------------------------------
// ------------------- Graphics
// ----------------------------------------------------------------------------
#include <core/ui_manager.h>
#include <graphics/ui_graphics_impl.h>

#pragma comment(lib, "dxguid")
//#pragma comment(lib, "dwmapi")

/// <summary>
/// Recreates this instance.
/// </summary>
/// <param name="hwnd">The HWND.</param>
/// <returns></returns>
auto UI::PrivateWindow::Recreate(HWND hwnd) noexcept -> Result {
    if (this->is_skip_render()) return{ Result::RS_OK };
    CUIRenderAutoLocker locker;
    this->release_data();
    Result hr = { Result::RS_OK };
    // 创建交换酱
    if (hr) {
        // 获取窗口大小
        RECT client_rect; ::GetClientRect(hwnd, &client_rect);
        const Size2U wndsize = {
            uint32_t(client_rect.right - client_rect.left),
            uint32_t(client_rect.bottom - client_rect.top)
        };
        // 交换链信息
        DXGI_SWAP_CHAIN_DESC1 swapChainDesc = { 0 };
        // TODO: DComp
        if (this->is_direct_composition()) {
            assert(!"NOTIMPL");
            swapChainDesc.Width = wndsize.width;
            swapChainDesc.Height = wndsize.height;
        }
        else {
            swapChainDesc.Width = wndsize.width;
            swapChainDesc.Height = wndsize.height;
        }
        swapChainDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        swapChainDesc.Stereo = FALSE;
        swapChainDesc.SampleDesc.Count = 1;
        swapChainDesc.SampleDesc.Quality = 0;
        swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        swapChainDesc.BufferCount = 2;
        swapChainDesc.Scaling = DXGI_SCALING_STRETCH;
        // TODO: 延迟等待
        swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT;
        swapChainDesc.Flags = 0;
        // SWAP酱
        IDXGISwapChain1* sc = nullptr;
        // TODO: DComp
        if (this->is_direct_composition()) {

        }
        else {
            // 一般桌面应用程序
            swapChainDesc.AlphaMode = DXGI_ALPHA_MODE_UNSPECIFIED;
            swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
            // 利用窗口句柄创建交换链
            hr = { UIManager.RefGraphicsFactory().CreateSwapChainForHwnd(
                &UIManager.Ref3DDevice(),
                hwnd,
                &swapChainDesc,
                nullptr,
                nullptr,
                &sc
            ) };
            longui_debug_hr(hr, L"GraphicsFactory.CreateSwapChainForHwnd faild");
        }
        // 设置 SWAP酱
        this->swapchan = static_cast<I::Swapchan*>(sc);
    }
    IDXGISurface* backbuffer = nullptr;
    // 利用交换链获取Dxgi表面
    if (hr) {
        hr = { this->swapchan->GetBuffer(
            0, IID_IDXGISurface, reinterpret_cast<void**>(&backbuffer)
        ) };
        longui_debug_hr(hr, L"swapchan->GetBuffer faild");
    }
    // 利用Dxgi表面创建位图
    if (hr) {
        D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
            D2D1_BITMAP_OPTIONS_TARGET | D2D1_BITMAP_OPTIONS_CANNOT_DRAW,
            D2D1::PixelFormat(DXGI_FORMAT_R8G8B8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED)
        );
        ID2D1Bitmap1* bmp = nullptr;
        hr = { UIManager.Ref2DRenderer().CreateBitmapFromDxgiSurface(
            backbuffer,
            &bitmapProperties,
            &bmp
        ) };
        this->bitmap = static_cast<I::Bitmap*>(bmp);
        longui_debug_hr(hr, L"2DRenderer.CreateBitmapFromDxgiSurface faild");
    }
    UI::SafeRelease(backbuffer);
    // TODO: 使用DComp
    if (this->is_direct_composition()) {

    }
    return hr;
}


/// <summary>
/// Releases the data.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::release_data() noexcept {
    UI::SafeRelease(this->swapchan);
    UI::SafeRelease(this->bitmap);
}

/// <summary>
/// Resizes the window buffer.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::resize_window_buffer() noexcept {
    this->flag_sized = false;
    assert(this->rect.width && this->rect.height);
    // 检测是否无需修改
    const auto olds = this->bitmap->GetPixelSize();
    const auto samew = olds.width == this->rect.width;
    const auto sameh = olds.height == this->rect.height;
    if (samew && sameh) return;
    // 渲染区
    CUIRenderAutoLocker locker;
    // 取消引用
    UIManager.Ref2DRenderer().SetTarget(nullptr);
    // 强行重置flag
    bool force_resize = true;
    // DComp
    if (this->is_direct_composition()) {
        assert(!"NOT IMPL");
        force_resize = false;
    }
    // 重置缓冲帧大小
    if (force_resize) {
        IDXGISurface* dxgibuffer = nullptr;
        UI::SafeRelease(this->bitmap);
        // TODO: 延迟等待
        Result hr = { this->swapchan->ResizeBuffers(
            2, this->rect.width, this->rect.height,
            DXGI_FORMAT_B8G8R8A8_UNORM,
            // DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT
            0
        ) };
        longui_debug_hr(hr, L"m_pSwapChain->ResizeBuffers faild");
        // TODO: RecreateResources 检查
        if (hr.code == DXGI_ERROR_DEVICE_REMOVED || 
            hr.code == DXGI_ERROR_DEVICE_RESET) {
            //UIManager.RecreateResources();
            LUIDebug(Hint) << L"Recreate device" << UI::endl;
        }
        // 利用交换链获取Dxgi表面
        if (hr) {
            hr = { this->swapchan->GetBuffer(
                0,
                IID_IDXGISurface,
                reinterpret_cast<void**>(&dxgibuffer)
            ) };
            longui_debug_hr(hr, L"m_pSwapChain->GetBuffer faild");
        }
        // 利用Dxgi表面创建位图
        if (hr) {
            D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
                D2D1_BITMAP_OPTIONS_TARGET | D2D1_BITMAP_OPTIONS_CANNOT_DRAW,
                D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED)
            );
            ID2D1Bitmap1* bmp = nullptr;
            hr = { UIManager.Ref2DRenderer().CreateBitmapFromDxgiSurface(
                dxgibuffer,
                &bitmapProperties,
                &bmp
            ) };
            this->bitmap = static_cast<I::Bitmap*>(bmp);
            longui_debug_hr(hr, L"UIManager_RenderTarget.CreateBitmapFromDxgiSurface faild");
        }
        // 重建失败?
        UI::SafeRelease(dxgibuffer);
        LUIDebug(Hint)
            << "resize to"
            << this->rect.width
            << 'x'
            << this->rect.height
            << UI::endl;
        // TODO: 错误处理
        if (!hr) {
            LUIDebug(Error) << L" Recreate FAILED!" << UI::endl;
            UIManager.ShowError(hr);
        }
    }
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
auto UI::PrivateWindow::Render(const UIViewport& v) const noexcept->Result {
    // 跳过该帧?
    if (this->is_skip_render()) return{ Result::RS_OK };
    // 重置窗口缓冲帧大小
    if (this->flag_sized) this->force_resize_window_buffer();
    this->begin_render();
    CUIControlControl::RecursiveRender(v, nullptr, 0);
    return this->end_render();
}

/// <summary>
/// Begins the render.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::begin_render() const noexcept {
    // TODO: 完成
    auto& renderer = UIManager.Ref2DRenderer();
    // 设置文本渲染策略
    //renderer.SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_CLEARTYPE);
    // 设为当前渲染对象
    renderer.SetTarget(this->bitmap);
    // 开始渲染
    renderer.BeginDraw();
    // 设置转换矩阵
#if 1
    renderer.SetTransform(D2D1::Matrix3x2F::Identity());
#else
    renderer.SetTransform(&impl::d2d(m_pViewport->box.world));
#endif
    // 清空背景
    renderer.Clear(D2D1::ColorF{ 0x66ccff });
}

/// <summary>
/// Ends the render.
/// </summary>
/// <returns></returns>
auto UI::PrivateWindow::end_render() const noexcept->Result {
    auto& renderer = UIManager.Ref2DRenderer();
    renderer.SetTransform({ 1.f,0.f,0.f,1.f,0.f,0.f });
    // TODO: 渲染插入符号

#ifndef NDEBUG
    // 水平扫描线: 全局渲染
    if (false) {
        assert(this->rect.height);
        const float y = float(dbg_full_render_counter % this->rect.height);
        renderer.PushAxisAlignedClip(
            D2D1_RECT_F{ 0, y, float(rect.width), y+1 },
            D2D1_ANTIALIAS_MODE_ALIASED
        );
        renderer.Clear(D2D1::ColorF{ 0x000000 });
        renderer.PopAxisAlignedClip();
    }
#endif
    // 结束渲染
    Result hr = { renderer.EndDraw() };
    // 完全渲染
    if (this->is_full_render_at_rendering()) {
#ifndef NDEBUG
        CUITimeMeterH meter;
        meter.Start();
        hr = { this->swapchan->Present(0, 0) };
        const auto time = meter.Delta_ms<float>();
        if (time > 9.f) {
            LUIDebug(Hint)
                << "present time: "
                << time
                << "ms"
                << UI::endl;
        }
        //assert(time < 1000.f && "took too much time, check plz.");
#else
        hr = { this->swapchan->Present(0, 0) };
#endif
        longui_debug_hr(hr, L"swapchan->Present full rendering faild");
    }
    // TODO: 增量渲染
    else {
        assert(!"NOTIMPL");
    }
    // 收到重建消息/设备丢失时 重建UI
    constexpr int32_t DREMOVED = DXGI_ERROR_DEVICE_REMOVED;
    constexpr int32_t DRESET = DXGI_ERROR_DEVICE_RESET;
    // TODO: UIManager.RecreateResources
#ifdef NDEBUG
    if (hr.code == DREMOVED || hr.code == DRESET) {
        //hr = { UIManager.RecreateResources() };
    }
#else
    // TODO: 测试 test_D2DERR_RECREATE_TARGET
    if (hr.code == DREMOVED || hr.code == DRESET ) {
        assert(!"NOTIMPL");
        LUIDebug(Hint) << "D2DERR_RECREATE_TARGET!" << UI::endl;
        //hr = UIManager.RecreateResources();
        /*if (FAILED(hr)) {
            LUIDebug(Hint) << "But, Recreate Failed!!!" << UI::endl;
            LUIDebug(Error) << "Recreate Failed!!!" << UI::endl;
        }*/
    }
    assert(hr);
    // 调试
    if (this->is_full_render_at_rendering())
        ++const_cast<uint32_t&>(dbg_full_render_counter);
    else
        ++const_cast<uint32_t&>(dbg_dirty_render_counter);
    // 更新调试信息
    wchar_t buffer[1024];
    std::swprintf(
        buffer, 1024,
        L"<%ls>: FRC: %d\nDRC: %d\nDRRC: %d",
        L"NAMELESS",
        int(dbg_full_render_counter),
        int(dbg_dirty_render_counter),
        int(0)
    );
    // 设置显示
    /*UIManager.RenderUnlock();
    this->dbg_uiwindow->SetTitleName(buffer);
    UIManager.RenderLock();*/
#endif
    return hr;
}