﻿// ui
#include <luiconf.h>
#include <core/ui_window.h>
#include <core/ui_manager.h>
#include <style/ui_ssvalue.h>
#include <graphics/ui_cursor.h>
#include <control/ui_viewport.h>
#include <graphics/ui_graphics_decl.h>
// c++
#include <cassert>

#ifndef NDEBUG
#include <core/ui_color_list.h>
#include <util/ui_time_meter.h>
#include "../private/ui_private_control.h"


#endif

/// <summary>
/// Sets the control world changed.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIWindow::SetControlWorldChanged(UIControl& ctrl) noexcept {
    assert(PrivateControl::TestWorldChanged(ctrl));
    assert(ctrl.GetWindow() == this);
    if (m_pTopestWcc && m_pTopestWcc->GetLevel() < ctrl.GetLevel()) return;
    m_pTopestWcc = &ctrl;
}

// ui namespace
namespace UI {
    // private msg
    struct PrivateMsg;
    /// <summary>
    /// private data for CUIWindow
    /// </summary>
    class PrivateWindow : public CUIObject {
        // release data
        void release_data() noexcept;
        // begin render
        void begin_render() const noexcept;
        // begin render
        auto end_render() const noexcept->Result;
    public:
        // ctor
        PrivateWindow() noexcept {}
        // dtor
        ~PrivateWindow() noexcept { this->release_data(); }
        // init
        HWND Init(HWND parent) noexcept;
        // recreate
        auto Recreate(HWND hwnd) noexcept->Result;
        // render
        auto Render(const UIViewport& v) const noexcept->Result;
    public:
        // do msg
        auto DoMsg(const PrivateMsg&) noexcept ->intptr_t;
        // when create
        void OnCreate(HWND) noexcept {}
        // when close
        void OnClose() noexcept;
        // when resize
        void OnResize(Size2U) noexcept;
    private: // TODO: is_xxxx
        // full render this frame?
        inline bool is_full_render_at_rendering() const noexcept { return true; }
        // using direct composition?
        inline bool is_direct_composition() const noexcept { return false; }
        // is skip render?
        inline bool is_skip_render() const noexcept { return false; }
        // is popup window?
        inline bool is_popup() const noexcept { return false; }
    public:
        // register the window class
        static void RegisterWindowClass() noexcept;
    public:
        // swap chian
        I::Swapchan*    swapchan = nullptr;
        // bitmap buffer
        I::Bitmap*      bitmap = nullptr;
    public:
        // viewport
        UIViewport*     viewport = nullptr;
        // now cursor
        CUICursor       cursor = { CUICursor::Cursor_Arrow };
        // rect of window
        RectWHL         rect = {};
        // stylesheets: values
        SSValues        values;
        // stylesheets: selectors
        SSSelectors     selectors;
#ifndef NDEBUG
        // full render counter
        uint32_t        dbg_full_render_counter = 0;
        // dirty render counter
        uint32_t        dbg_dirty_render_counter = 0;
#endif
    public:
        // sized
        bool            flag_sized = false;
    private:
        // resize window buffer
        void resize_window_buffer() noexcept;
        // forece resize
        void force_resize_window_buffer() const noexcept {
            const_cast<PrivateWindow*>(this)->
                resize_window_buffer();
        }
    };
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <param name="parent">The parent.</param>
UI::CUIWindow::CUIWindow(CUIWindow* parent) noexcept :
m_parent(parent), m_private(new(std::nothrow) PrivateWindow) {
    // XXX: OOM 处理
    if (!m_private) return;
    // 初始化
    m_private->viewport = &this->RefViewport();
    m_hwnd = m_private->Init(parent ? parent->GetHwnd() : nullptr);
    UIManager.add_window(*this);
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIWindow"/> class.
/// </summary>
/// <returns></returns>
UI::CUIWindow::~CUIWindow() noexcept {
    if (m_private) {
        UIManager.remove_window(*this);
        delete m_private;
    }
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::Render() const noexcept -> Result {
    assert(m_private && "bug: you shall not pass");
    auto&v = const_cast<CUIWindow*>(this)->RefViewport();
    return m_private->Render(v);
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::recreate() noexcept -> Result {
    assert(m_private && "bug: you shall not pass");
    return m_private->Recreate(m_hwnd);
}

/// Gets the position.
/// </summary>
/// <returns></returns>
auto UI::CUIWindow::GetPos() const noexcept -> Point2L {
    return{ m_private->rect.left , m_private->rect.top };
}


/// <summary>
/// Raises the Close event.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::OnClose() noexcept {

}

/// <summary>
/// Called when [resize].
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
void UI::PrivateWindow::OnResize(Size2U size) noexcept {
    // 不一样才处理
    const auto samew = this->rect.width == size.width;
    const auto sameh = this->rect.height == size.height;
    if (samew && sameh) return;
    // 修改
    this->rect.width = size.width;
    this->rect.height = size.height;
    // 重置大小
    this->viewport->Resize({
        static_cast<float>(size.width),
        static_cast<float>(size.height)
    });
    // 修改窗口缓冲帧大小
    this->flag_sized = true;
}

// ----------------------------------------------------------------------------
// ------------------- Windows
// ----------------------------------------------------------------------------
#include <Windows.h>

/// <summary>
/// Shows the window.
/// </summary>
/// <param name="sw">The sw type.</param>
/// <returns></returns>
void UI::CUIWindow::show_window(TypeShow sw) noexcept {
    assert(m_hwnd && "bad window");
    ::ShowWindow(m_hwnd, sw);
}

/// <summary>
/// Sets the name of the title.
/// </summary>
/// <param name="name">The name.</param>
/// <returns></returns>
void UI::CUIWindow::SetTitleName(const wchar_t* name) noexcept {
    assert(name && "bad name");
    assert(m_hwnd && "bad window");
    ::DefWindowProcW(m_hwnd, WM_SETTEXT, WPARAM(0), LPARAM(name));
}

/// <summary>
/// Sets the position.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void UI::CUIWindow::SetPos(Point2L pos) noexcept {
    assert(m_private && "bug: you shall not pass");
    auto& this_pos = reinterpret_cast<Point2L&>(m_private->rect.left);
    // 无需移动窗口
    if (this_pos.x == pos.x && this_pos.y == pos.y) return; this_pos = pos;
    // 内联窗口
    if (this->IsInlineWindow()) {
        assert(!"NOT IMPL");
    }
    // 系统窗口
    else {
        ::SetWindowPos(m_hwnd, nullptr, pos.x, pos.y, 0, 0, SWP_NOSIZE);
    }
}

/// <summary>
/// Initializes this instance.
/// </summary>
/// <param name="parent">The parent.</param>
/// <returns></returns>
HWND UI::PrivateWindow::Init(HWND parent) noexcept {
    // 尝试注册
    this->RegisterWindowClass();
    // 初始化
    HWND hwnd = nullptr;
    UI::ParseStylesheet("", this->values, this->selectors);
    // 标题名称
    const wchar_t* titlename = nullptr;
    // 窗口
    {
        // 检查样式样式
        const DWORD window_style = WS_OVERLAPPEDWINDOW;
        // 设置窗口大小
        RECT client_rect {
            0, 0, 
            DEFAULT_WINDOW_WIDTH, 
            DEFAULT_WINDOW_HEIGHT
        };
        // 调整大小
        ::AdjustWindowRect(&client_rect, window_style, FALSE);
        // 窗口
        RectWHL window_rect;
        window_rect.width = (client_rect.right - client_rect.left);
        window_rect.height = (client_rect.bottom - client_rect.top);
        // 屏幕大小
        const auto scw = ::GetSystemMetrics(SM_CXFULLSCREEN);
        const auto sch = ::GetSystemMetrics(SM_CYFULLSCREEN);
        // 居中显示
        window_rect.left = (scw - window_rect.width) / 2;
        window_rect.top = (sch - window_rect.height) / 2;
        // 创建窗口
        hwnd = ::CreateWindowExW(
            //WS_EX_NOREDIRECTIONBITMAP | WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT,
            this->is_direct_composition() ? WS_EX_NOREDIRECTIONBITMAP : 0,
            this->is_popup() ?
            Attribute::WindowClassNameP : Attribute::WindowClassNameN,
            titlename,
            window_style,
            window_rect.left, window_rect.top,
            window_rect.width, window_rect.height,
            parent,
            nullptr,
            ::GetModuleHandleA(nullptr),
            this
        );
        // TODO: 禁止 Alt + Enter 全屏
        //UIManager_DXGIFactory.MakeWindowAssociation(hwnd, DXGI_MWA_NO_WINDOW_CHANGES | DXGI_MWA_NO_ALT_ENTER);
    }
    // 创建成功
    if (hwnd) {
    }
    return hwnd;
}


/// <summary>
/// private msg
/// </summary>
struct UI::PrivateMsg { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; };


/// <summary>
/// Registers the window class.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::RegisterWindowClass() noexcept {
    const auto ins = ::GetModuleHandleW(nullptr);
    WNDCLASSEXW wcex;
    auto code = ::GetClassInfoExW(ins, Attribute::WindowClassNameN, &wcex);
    if (!code) {
        // 处理
        auto proc = [](HWND hwnd, 
            UINT message, 
            WPARAM wParam, 
            LPARAM lParam
            ) noexcept -> LRESULT {
            // 创建窗口时设置指针
            if (message == WM_CREATE) {
                // 获取指针
                auto* window = reinterpret_cast<PrivateWindow*>(
                    (reinterpret_cast<LPCREATESTRUCT>(lParam))->lpCreateParams
                    );
                // 设置窗口指针
                ::SetWindowLongPtrW(hwnd, GWLP_USERDATA, LONG_PTR(window));
                // TODO: 创建完毕
                window->OnCreate(hwnd);
                // 返回1
                return 1;
            }
            // 其他情况则获取储存的指针
            else {
                const PrivateMsg msg { hwnd, message, wParam, lParam };
                const auto lptr = ::GetWindowLongPtrW(hwnd, GWLP_USERDATA);
                const auto window = reinterpret_cast<PrivateWindow*>(lptr);
                if (!window) return ::DefWindowProcW(hwnd, message, wParam, lParam);
                return window->DoMsg(msg);
            }
        };
        // 注册一般窗口类
        wcex = { 0 };
        wcex.cbSize = sizeof(WNDCLASSEXW);
        wcex.style = 0;
        wcex.lpfnWndProc = proc;
        wcex.cbClsExtra = 0;
        wcex.cbWndExtra = sizeof(void*);
        wcex.hInstance = ins;
        wcex.hCursor = nullptr;
        wcex.hbrBackground = nullptr;
        wcex.lpszMenuName = nullptr;
        wcex.lpszClassName = Attribute::WindowClassNameN;
        wcex.hIcon = nullptr; // ::LoadIconW(ins, MAKEINTRESOURCEW(101));
        ::RegisterClassExW(&wcex);
        // 注册弹出窗口类
        wcex.style = CS_DROPSHADOW;
        wcex.lpszClassName = Attribute::WindowClassNameP;
        ::RegisterClassExW(&wcex);
    }
}

// ui namespace
namespace UI {
    // mouse event map(use char to avoid unnecessary mempry-waste)
    const uint8_t MEMAP[] = {
        // WM_MOUSEMOVE                 0x0200
        static_cast<uint8_t>(MouseEvent::Event_MouseMove),
        // WM_LBUTTONDOWN               0x0201
        static_cast<uint8_t>(MouseEvent::Event_LButtonDown),
        // WM_LBUTTONUP                 0x0202
        static_cast<uint8_t>(MouseEvent::Event_LButtonUp),
        // WM_LBUTTONDBLCLK             0x0203
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_RBUTTONDOWN               0x0204
        static_cast<uint8_t>(MouseEvent::Event_RButtonDown),
        // WM_RBUTTONUP                 0x0205
        static_cast<uint8_t>(MouseEvent::Event_RButtonUp),
        // WM_RBUTTONDBLCLK             0x0206
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MBUTTONDOWN               0x0207
        static_cast<uint8_t>(MouseEvent::Event_MButtonDown),
        // WM_MBUTTONUP                 0x0208
        static_cast<uint8_t>(MouseEvent::Event_MButtonUp),
        // WM_MBUTTONDBLCLK             0x0209
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MOUSEWHEEL                0x020A
        static_cast<uint8_t>(MouseEvent::Event_MouseWheelV),
        // WM_XBUTTONDOWN               0x020B
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_XBUTTONUP                 0x020C
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_XBUTTONDBLCLK             0x020D
        static_cast<uint8_t>(MouseEvent::Event_Unknown),
        // WM_MOUSEHWHEEL               0x020E
        static_cast<uint8_t>(MouseEvent::Event_MouseWheelH),
    };
}

/// <summary>
/// Does the MSG.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
auto UI::PrivateWindow::DoMsg(const PrivateMsg& prmsg) noexcept -> intptr_t {
    const auto msg = prmsg;
    // 鼠标消息处理
    if (msg.message >= WM_MOUSEFIRST && msg.message <= WM_MOUSELAST) {
        // 检查映射表长度
        constexpr size_t ARYLEN = sizeof(MEMAP) / sizeof(MEMAP[0]);
        constexpr size_t MSGLEN = WM_MOUSELAST - WM_MOUSEFIRST + 1;
        static_assert(ARYLEN == MSGLEN, "must be same");
        // 初始化参数
        MouseEventArg arg;
        arg.type = static_cast<MouseEvent>(MEMAP[msg.message - WM_MOUSEFIRST]);
        arg.wheel = 0.f;
        arg.px = static_cast<float>(int16_t(LOWORD(msg.lParam)));
        arg.py = static_cast<float>(int16_t(HIWORD(msg.lParam)));
        // shift+滚轮自动映射到水平方向
        if (msg.message == WM_MOUSEWHEEL && (msg.wParam & MK_SHIFT)) {
            arg.type = MouseEvent::Event_MouseWheelH;
        }
        // 滚轮消息则修改滚轮数据
        if (arg.type <= MouseEvent::Event_MouseWheelH) {
            const auto delta = static_cast<float>(int16_t(HIWORD(msg.wParam)));
            arg.wheel = delta / static_cast<float>(WHEEL_DELTA);
        }
        // 处理消息
        CUIDataAutoLocker locker;
        this->viewport->DoMouseEvent(arg);
    }
    // 其他消息处理
    else
        switch (msg.message)
        {
        case WM_SETCURSOR:
            ::SetCursor(reinterpret_cast<HCURSOR>(this->cursor.GetHandle()));
            break;
        case WM_SIZE:
            if (LOWORD(msg.lParam) && HIWORD(msg.lParam)) {
                CUIDataAutoLocker locker;
                this->OnResize({ LOWORD(msg.lParam), HIWORD(msg.lParam) });
            }
            return 1;
        case WM_MOVING:
            // XXX: 加锁?
            this->rect.top = reinterpret_cast<RECT*>(msg.lParam)->top;
            this->rect.left = reinterpret_cast<RECT*>(msg.lParam)->left;
            return 1;
        case WM_CLOSE:
            ::PostQuitMessage(0);
            break;
        }
    // 未处理消息
    return ::DefWindowProcW(msg.hwnd, msg.message, msg.wParam, msg.lParam);
}


// ----------------------------------------------------------------------------
// ------------------- Graphics
// ----------------------------------------------------------------------------
#include <core/ui_manager.h>
#include <graphics/ui_graphics_impl.h>

#pragma comment(lib, "dxguid")

/// <summary>
/// Recreates this instance.
/// </summary>
/// <param name="hwnd">The HWND.</param>
/// <returns></returns>
auto UI::PrivateWindow::Recreate(HWND hwnd) noexcept -> Result {
    if (this->is_skip_render()) return{ Result::RS_OK };
    CUIRenderAutoLocker locker;
    this->release_data();
    Result hr = { Result::RS_OK };
    // 创建交换酱
    if (hr) {
        // 获取窗口大小
        RECT client_rect; ::GetClientRect(hwnd, &client_rect);
        const Size2U wndsize = {
            uint32_t(client_rect.right - client_rect.left),
            uint32_t(client_rect.bottom - client_rect.top)
        };
        // 交换链信息
        DXGI_SWAP_CHAIN_DESC1 swapChainDesc = { 0 };
        // TODO: DComp
        if (this->is_direct_composition()) {
            assert(!"NOTIMPL");
            swapChainDesc.Width = wndsize.width;
            swapChainDesc.Height = wndsize.height;
        }
        else {
            swapChainDesc.Width = wndsize.width;
            swapChainDesc.Height = wndsize.height;
        }
        swapChainDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        swapChainDesc.Stereo = FALSE;
        swapChainDesc.SampleDesc.Count = 1;
        swapChainDesc.SampleDesc.Quality = 0;
        swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        swapChainDesc.BufferCount = 2;
        swapChainDesc.Scaling = DXGI_SCALING_STRETCH;
        // TODO: 延迟等待
        swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT;
        swapChainDesc.Flags = 0;
        // SWAP酱
        IDXGISwapChain1* sc = nullptr;
        // TODO: DComp
        if (this->is_direct_composition()) {

        }
        else {
            // 一般桌面应用程序
            swapChainDesc.AlphaMode = DXGI_ALPHA_MODE_UNSPECIFIED;
            swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
            // 利用窗口句柄创建交换链
            hr = { UIManager.RefGraphicsFactory().CreateSwapChainForHwnd(
                &UIManager.Ref3DDevice(),
                hwnd,
                &swapChainDesc,
                nullptr,
                nullptr,
                &sc
            ) };
            longui_debug_hr(hr, L"GraphicsFactory.CreateSwapChainForHwnd faild");
        }
        this->swapchan = static_cast<I::Swapchan*>(sc);
    }
    IDXGISurface* backbuffer = nullptr;
    // 利用交换链获取Dxgi表面
    if (hr) {
        hr = { this->swapchan->GetBuffer(
            0, IID_IDXGISurface, reinterpret_cast<void**>(&backbuffer)
        ) };
        longui_debug_hr(hr, L"swapchan->GetBuffer faild");
    }
    // 利用Dxgi表面创建位图
    if (hr) {
        D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
            D2D1_BITMAP_OPTIONS_TARGET | D2D1_BITMAP_OPTIONS_CANNOT_DRAW,
            D2D1::PixelFormat(DXGI_FORMAT_R8G8B8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED)
        );
        ID2D1Bitmap1* bmp = nullptr;
        hr = { UIManager.Ref2DRenderer().CreateBitmapFromDxgiSurface(
            backbuffer,
            &bitmapProperties,
            &bmp
        ) };
        this->bitmap = static_cast<I::Bitmap*>(bmp);
        longui_debug_hr(hr, L"2DRenderer.CreateBitmapFromDxgiSurface faild");
    }
    UI::SafeRelease(backbuffer);
    // TODO: 使用DComp
    if (this->is_direct_composition()) {

    }
    return hr;
}


/// <summary>
/// Releases the data.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::release_data() noexcept {
    UI::SafeRelease(this->swapchan);
    UI::SafeRelease(this->bitmap);
}

/// <summary>
/// Resizes the window buffer.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::resize_window_buffer() noexcept {
    this->flag_sized = false;
    assert(this->rect.width && this->rect.height);
    // 检测是否无需修改
    const auto olds = this->bitmap->GetPixelSize();
    const auto samew = olds.width == this->rect.width;
    const auto sameh = olds.height == this->rect.height;
    if (samew && sameh) return;
    // 渲染区
    CUIRenderAutoLocker locker;
    // 取消引用
    UIManager.Ref2DRenderer().SetTarget(nullptr);
    // 强行重置flag
    bool force_resize = true;
    // DComp
    if (this->is_direct_composition()) {
        assert(!"NOT IMPL");
        force_resize = false;
    }
    // 重置缓冲帧大小
    if (force_resize) {
        IDXGISurface* dxgibuffer = nullptr;
        UI::SafeRelease(this->bitmap);
        // TODO: 延迟等待
        Result hr = { this->swapchan->ResizeBuffers(
            2, this->rect.width, this->rect.height,
            DXGI_FORMAT_B8G8R8A8_UNORM,
            // DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT
            0
        ) };
        longui_debug_hr(hr, L"m_pSwapChain->ResizeBuffers faild");
        // TODO: RecreateResources 检查
        if (hr.code == DXGI_ERROR_DEVICE_REMOVED || 
            hr.code == DXGI_ERROR_DEVICE_RESET) {
            //UIManager.RecreateResources();
            LUIDebug(Hint) << L"Recreate device" << UI::endl;
        }
        // 利用交换链获取Dxgi表面
        if (hr) {
            hr = { this->swapchan->GetBuffer(
                0,
                IID_IDXGISurface,
                reinterpret_cast<void**>(&dxgibuffer)
            ) };
            longui_debug_hr(hr, L"m_pSwapChain->GetBuffer faild");
        }
        // 利用Dxgi表面创建位图
        if (hr) {
            D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
                D2D1_BITMAP_OPTIONS_TARGET | D2D1_BITMAP_OPTIONS_CANNOT_DRAW,
                D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED)
            );
            ID2D1Bitmap1* bmp = nullptr;
            hr = { UIManager.Ref2DRenderer().CreateBitmapFromDxgiSurface(
                dxgibuffer,
                &bitmapProperties,
                &bmp
            ) };
            this->bitmap = static_cast<I::Bitmap*>(bmp);
            longui_debug_hr(hr, L"UIManager_RenderTarget.CreateBitmapFromDxgiSurface faild");
        }
        // 重建失败?
        UI::SafeRelease(dxgibuffer);
        LUIDebug(Hint)
            << "resize to"
            << this->rect.width
            << 'x'
            << this->rect.height
            << UI::endl;
        // TODO: 错误处理
        if (!hr) {
            LUIDebug(Error) << L" Recreate FAILED!" << UI::endl;
            UIManager.ShowError(hr);
        }
    }
}

/// <summary>
/// Renders this instance.
/// </summary>
/// <returns></returns>
auto UI::PrivateWindow::Render(const UIViewport& v) const noexcept->Result {
    // 跳过该帧?
    if (this->is_skip_render()) return{ Result::RS_OK };
    // 重置窗口缓冲帧大小
    if (this->flag_sized) this->force_resize_window_buffer();
    this->begin_render();
    CUIControlControl::RecursiveRender(v, nullptr, 0);
    return this->end_render();
}

/// <summary>
/// Begins the render.
/// </summary>
/// <returns></returns>
void UI::PrivateWindow::begin_render() const noexcept {
    // TODO: 完成
    auto& renderer = UIManager.Ref2DRenderer();
    // 设置文本渲染策略
    //renderer.SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE(m_textAntiMode));
    // 设为当前渲染对象
    renderer.SetTarget(this->bitmap);
    // 开始渲染
    renderer.BeginDraw();
    // 设置转换矩阵
#if 1
    renderer.SetTransform(D2D1::Matrix3x2F::Identity());
#else
    renderer.SetTransform(&impl::d2d(m_pViewport->box.world));
#endif
    // 清空背景
    renderer.Clear(D2D1::ColorF{ 0x66ccff });
}

/// <summary>
/// Ends the render.
/// </summary>
/// <returns></returns>
auto UI::PrivateWindow::end_render() const noexcept->Result {
    auto& renderer = UIManager.Ref2DRenderer();
    renderer.SetTransform({ 1.f,0.f,0.f,1.f,0.f,0.f });
    // TODO: 渲染插入符号

#ifndef NDEBUG
    // 水平扫描线: 全局渲染
    {
        assert(this->rect.height);
        const float y = float(dbg_full_render_counter % this->rect.height);
        renderer.PushAxisAlignedClip(
            D2D1_RECT_F{ 0, y, float(rect.width), y+1 },
            D2D1_ANTIALIAS_MODE_ALIASED
        );
        renderer.Clear(D2D1::ColorF{ 0x000000 });
        renderer.PopAxisAlignedClip();
    }
#endif
    // 结束渲染
    Result hr = { renderer.EndDraw() };
    // 完全渲染
    if (this->is_full_render_at_rendering()) {
#ifndef NDEBUG
        CUITimeMeterH meter;
        meter.Start();
        hr = { this->swapchan->Present(0, 0) };
        const auto time = meter.Delta_ms<float>();
        if (time > 5.f) {
            LUIDebug(Hint)
                << "present time: "
                << time
                << "ms"
                << UI::endl;
        }
        //assert(time < 1000.f && "took too much time, check plz.");
#else
        hr = { this->swapchan->Present(0, 0) };
#endif
        longui_debug_hr(hr, L"swapchan->Present full rendering faild");
    }
    // TODO: 增量渲染
    else {
        assert(!"NOTIMPL");
    }
    // 收到重建消息/设备丢失时 重建UI
    constexpr int32_t DREMOVED = DXGI_ERROR_DEVICE_REMOVED;
    constexpr int32_t DRESET = DXGI_ERROR_DEVICE_RESET;
    // TODO: UIManager.RecreateResources
#ifdef NDEBUG
    if (hr.code == DREMOVED || hr.code == DRESET) {
        //hr = { UIManager.RecreateResources() };
    }
#else
    // TODO: 测试 test_D2DERR_RECREATE_TARGET
    if (hr.code == DREMOVED || hr.code == DRESET ) {
        assert(!"NOTIMPL");
        LUIDebug(Hint) << "D2DERR_RECREATE_TARGET!" << UI::endl;
        //hr = UIManager.RecreateResources();
        /*if (FAILED(hr)) {
            LUIDebug(Hint) << "But, Recreate Failed!!!" << UI::endl;
            LUIDebug(Error) << "Recreate Failed!!!" << UI::endl;
        }*/
    }
    assert(hr);
    // 调试
    if (this->is_full_render_at_rendering())
        ++const_cast<uint32_t&>(dbg_full_render_counter);
    else
        ++const_cast<uint32_t&>(dbg_dirty_render_counter);
    // 更新调试信息
    wchar_t buffer[1024];
    std::swprintf(
        buffer, 1024,
        L"<%ls>: FRC: %d\nDRC: %d\nDRRC: %d",
        L"NAMELESS",
        int(dbg_full_render_counter),
        int(dbg_dirty_render_counter),
        int(0)
    );
    // 设置显示
    /*UIManager.RenderUnlock();
    this->dbg_uiwindow->SetTitleName(buffer);
    UIManager.RenderLock();*/
#endif
    return hr;
}