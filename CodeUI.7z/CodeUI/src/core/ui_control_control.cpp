﻿#include <core/ui_control_control.h>
#include <container/pod_vector.h>
#include <control/ui_control.h>

#include "../private/ui_private_control.h"

#include <cassert>
#include <algorithm>

/// <summary>
/// private data/func for controlcontrol
/// </summary>
struct UI::PrivateCC {
    // ctor
    inline PrivateCC() noexcept { }
    // ctor
    inline ~PrivateCC() noexcept { }
    // update list
    POD::Vector<UIControl*> update_list;
    // 2nd update list
    POD::Vector<UIControl*> update_list_dofor;
    // clear list
    POD::Vector<UIControl*> update_clear_list;
};


/// <summary>
/// Initializes a new instance of the <see cref="CUIControlControl"/> class.
/// </summary>
UI::CUIControlControl::CUIControlControl() noexcept {
    new(&cc()) PrivateCC;
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIControlControl"/> class.
/// </summary>
/// <returns></returns>
UI::CUIControlControl::~CUIControlControl() noexcept {
    cc().~PrivateCC();
}

// ui namespace
namespace UI {
    enum {
        pc_size = sizeof(PrivateCC),
        cc_size = detail::cc<sizeof(void*)>::size,
        cc_align = detail::cc<sizeof(void*)>::align,
    };
    static_assert(pc_size == cc_size, "must be same");
    static_assert(alignof(PrivateCC) == cc_align, "must be same");
}

/// <summary>
/// Controls the attached.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIControlControl::ControlAttached(UIControl& ctrl) noexcept {
    int b = 9;
    // 1.为控件链接新的样式表(有的话)
    ctrl;
}

/// <summary>
/// Removes the reference.
/// </summary>
void UI::CUIControlControl::ControlDisattached(UIControl& ctrl) noexcept {
    int b = 9;
    /*assert(!ll.is_in_update() && "remove in updated");
    ll.update_list.erase(std::remove(
        ll.update_list.begin(), ll.update_list.end(), &ctrl),
        ll.update_list.end()
    );*/
}

/// <summary>
/// Marks the minimum size changed.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIControlControl::MarkMinSizeChanged(UIControl& ctrl) noexcept {
    int b = 9;
    // TODO: O(1)优化
    /*auto ptr = &ctrl; while (!ptr->IsTopLevel()) ptr = ptr->GetParent();
    ll.min_size_root = ptr;*/
}

/// <summary>
/// Adds the update list.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::AddUpdateList(UIControl& ctrl) noexcept {
    // TODO: [优化] 将越接近根节点的控件放在前面
    if (!ctrl.is_in_update_list()) {
        ctrl.add_into_update_list();
        cc().update_list.push_back(&ctrl);
    }
}

/// <summary>
/// Invalidates the control.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUIControlControl::InvalidateControl(UIControl& ctrl, const RectF& rect) noexcept {
    int b = 9;
    ctrl; rect;
    //Private::update_window(reinterpret_cast<void*>(ll.root->user_data));
}



/// <summary>
/// Updates the control in list.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::update_control_in_list() noexcept {
    // TODO: min size
    /*if (ll.min_size_root) {
        PrivateControl::RefreshMinSize(*ll.min_size_root);
        ll.min_size_root = nullptr;
    }*/
    // 不为空就继续刷新
    while (!cc().update_list.empty()) {
        // 交换两者
        cc().update_list_dofor.clear();
        cc().update_list.swap(cc().update_list_dofor);
        // 单独刷新
        for (auto* ctrl : cc().update_list_dofor) {
            cc().update_clear_list.push_back(ctrl);
            // 尝试初始化
            if (!ctrl->is_inited()) {
                const auto hr = ctrl->init();
                // TODO: 错误处理
                assert(hr);
            }
            // 正常刷新
            ctrl->Update();
        }
    }
    // 清理状态
    UIControl* top = nullptr;
    for (auto ctrl : cc().update_clear_list) {
        if (ctrl->m_state.world_changed) {
            if (!top || top->GetLevel() > ctrl->GetLevel()) {
                top = ctrl;
            }
        }
        ctrl->remove_from_update_list();
    }
    // 更新世界
    if (top) {
        auto toptop = top->IsTopLevel() ? top : top->GetParent();
        PrivateControl::UpdateWorld(*toptop);
    }
    // 扫尾
    cc().update_clear_list.clear();
}