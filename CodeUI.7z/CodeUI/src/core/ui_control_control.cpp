﻿// ui
#include <core/ui_control_control.h>
#include <style/ui_native_style.h>
#include <container/pod_vector.h>
#include <control/ui_control.h>
#include <util/ui_time_meter.h>
#include <util/ui_aniamtion.h>
// c++
#include <cassert>
#include <algorithm>


/// <summary>
/// private data/func for controlcontrol
/// </summary>
struct UI::PrivateCC {
    // control animation
    using CtrlAnima = ControlAnimation;
    // ctor
    inline PrivateCC() noexcept;
    // ctor
    inline ~PrivateCC() noexcept { }
    // update list
    POD::Vector<UIControl*> update_list;
    // 2nd update list
    POD::Vector<UIControl*> update_dofor;
    // next frame update list
    POD::Vector<UIControl*> next_update;
    // init list
    POD::Vector<UIControl*> init_list;
    // animation list
    POD::Vector<CtrlAnima>  animaitons;
};

/// <summary>
/// Initializes a new instance of the <see cref="PrivateCC"/> struct.
/// </summary>
inline UI::PrivateCC::PrivateCC() noexcept {
    // TODO: reserve/OOM
    //update_list.reserve;
    // TODO: 次帧刷新列表...貌似不需要
}

/// <summary>
/// Optimizeds the render.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="region">The region.</param>
/// <param name="length">The length.</param>
/// <returns></returns>
void UI::CUIControlControl::RecursiveRender(
    const UIControl& ctrl,
    const RectF region[], 
    uint32_t length) noexcept {
    /*
    块呈现器的堆栈顺序如下：
        background color
        background image
        border
        children
        outline
    */
    // TODO: 脏矩形渲染: 没有交集就不渲染
    /*if (length && std::all_of(region, region + length, [&](const RectF& rect) {
        return !(rect && ctrl.m_oBox.rect);
    })) return;*/
    // 看不到就不渲染
    const auto csize = ctrl.GetSize();
    if (!ctrl.IsVisible() || csize.width <= 0.f || csize.height <= 0.f)
        return;
    // 渲染器设置本身裁剪矩形以免绘制出去
    //auto& r = UI::Private::renderer();
    //r.setClipRect(qt({}, ctrl.m_oBox.rect));
    // 区域渲染上层已经设定了region裁剪区域
    ctrl.Render();
    // 渲染子节点: 滚动
    for (auto& child : ctrl) {
        if (child.m_state.attachment == Attachment_Scroll)
            RecursiveRender(child, region, length);
    }
    // 渲染子节点: 固定
    for (auto& child : ctrl) {
        if (child.m_state.attachment != Attachment_Scroll)
            RecursiveRender(child, region, length);
    }
    //ctrl.render_children();
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIControlControl"/> class.
/// </summary>
UI::CUIControlControl::CUIControlControl() noexcept {
    new(&cc()) PrivateCC;
    m_dwTimeTick = UI::GetTimeTick();
    m_dwDeltaTime = 0;
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIControlControl"/> class.
/// </summary>
/// <returns></returns>
UI::CUIControlControl::~CUIControlControl() noexcept {
    cc().~PrivateCC();
}

// ui namespace
namespace UI {
    enum {
        pc_size = sizeof(PrivateCC),
        cc_size = detail::cc<sizeof(void*)>::size,
        cc_align = detail::cc<sizeof(void*)>::align,
    };
    static_assert(pc_size == cc_size, "must be same");
    static_assert(alignof(PrivateCC) == cc_align, "must be same");
}

/// <summary>
/// Controls the attached.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIControlControl::ControlAttached(UIControl& ctrl) noexcept {
    int b = 9;
    // 1.为控件链接新的样式表(有的话)
    ctrl;
}

/// <summary>
/// Removes the reference.
/// </summary>
void UI::CUIControlControl::ControlDisattached(UIControl& ctrl) noexcept {
    int b = 9;
    /*assert(!ll.is_in_update() && "remove in updated");
    ll.update_list.erase(std::remove(
        ll.update_list.begin(), ll.update_list.end(), &ctrl),
        ll.update_list.end()
    );*/
}

/// <summary>
/// Adds the update list.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::AddUpdateList(UIControl& ctrl) noexcept {
    // TODO: [优化] 将越接近根节点的控件放在前面
    if (!ctrl.is_in_update_list()) {
        ctrl.add_into_update_list();
        cc().update_list.push_back(&ctrl);
    }
}

/// <summary>
/// Adds the initialize list.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIControlControl::AddInitList(UIControl & ctrl) noexcept {
    cc().init_list.push_back(&ctrl);
}

/// <summary>
/// Adds the next update list.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::CUIControlControl::AddNextUpdateList(UIControl & ctrl) noexcept {
    cc().next_update.push_back(&ctrl);
}

/// <summary>
/// Invalidates the control.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUIControlControl::InvalidateControl(UIControl& ctrl, const RectF& rect) noexcept {
    int b = 9;
    ctrl; rect;

    //Private::update_window(reinterpret_cast<void*>(ll.root->user_data));
}

// UI Window
#include <core/ui_window.h>
#ifndef NDEBUG
#include <debugger/ui_debug.h>
#endif

/// <summary>
/// Initializes the control in list.
/// </summary>
/// <returns></returns>
bool UI::CUIControlControl::init_control_in_list() noexcept {
    // 遍历初始化列表
    for (auto ctrl : cc().init_list) {
        // 尝试初始化
        if (!ctrl->is_inited()) ctrl->init();
    }
    cc().init_list.clear();
    // 存在更新列表
    return !cc().update_list.empty();
}

#ifndef DEBUG
namespace UI {
    // debug counter
    static int cc_debug_counter = 0;
}
#endif

/// <summary>
/// Updates the control in list.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::update_control_in_list() noexcept {
    auto& cccc = cc();
    // 更新控件
    auto update = [](UIControl& ctrl) noexcept {
        // 进行刷新
        ctrl.Update();
        // 检测世界修改
        if (ctrl.m_state.world_changed && ctrl.GetWindow())
            ctrl.GetWindow()->SetControlWorldChanged(ctrl);
        // 标记移除
        ctrl.remove_from_update_list();
    };
    // 交换两者
    cccc.update_dofor.clear();
    cccc.update_list.swap(cccc.update_dofor);
#if 1
    // 单独刷新
    for (auto* ctrl : cccc.update_dofor) update(*ctrl);
#else
    ++cc_debug_counter;
    // 单独刷新
    for (auto* ctrl : cccc.update_dofor) {
        update(*ctrl);
        LUIDebug(Log) LUI_FRAMEID
            << '[' << cc_debug_counter << ']'
            << ctrl->name_dbg
            << endl;
    }
#endif
}

/// <summary>
/// Pushes the next update.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::push_next_update() noexcept {
#ifndef DEBUG
    cc_debug_counter = 0;
#endif
    // 添加次帧刷新
    for (auto ctrl : cc().next_update) this->AddUpdateList(*ctrl);
    cc().next_update.clear();
}

/// <summary>
/// Normals the update.
/// </summary>
/// <returns></returns>
void UI::CUIControlControl::normal_update() noexcept {
    // 更新时间
    const auto new_tick = UI::GetTimeTick();
    const auto delta = new_tick - m_dwTimeTick;
    m_dwDeltaTime = delta;
    m_dwTimeTick = new_tick;
    // 动画为空
    auto& animations = cc().animaitons;
    if (animations.empty()) return;
    // 更新基本动画
    auto basic_update = [delta](ControlAnimation& ca) noexcept {
        ca.basic.done += delta;
        // 完成动画: ctrl 标记为0
        if (ca.basic.done >= ca.basic.duration) {
            ca.basic.done = ca.basic.duration;
            assert(!"NOT IMPL");
            ca.ctrl = nullptr;
        }
    };
    // 更新复杂动画
    auto extra_update = [](ControlAnimation& ca) noexcept {
        assert(!"unsupported yet");
    };
    // 更新动画
    for (auto& x : animations) {
        // 检查有效
        if (!x.ctrl) continue;
        // 额外动画?
        if (x.extra) extra_update(x);
        else basic_update(x);
    }
    // 最后一个无效?
    // NOTE: 一帧最多删一个, 但是动画结束频率肯定不高
    if (!animations.back().ctrl) animations.pop_back();
}

/// <summary>
/// Starts the animation.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="type">The type.</param>
/// <returns></returns>
void UI::CUIControlControl::StartAnimation(
    UIControl& ctrl, StyleStateType type) noexcept {
    // 对比函数
    auto finder = [&ctrl](ControlAnimation& ca) noexcept {
        return ca.ctrl == &ctrl;
    };
    auto& anima = cc().animaitons;
    // 查找已有动画
    auto itr = std::find_if(anima.begin(), anima.end(), finder);
    ControlAnimation* ca;
    if (itr != anima.end()) ca = &(*itr);
    else {
        ControlAnimation init_ca;
        init_ca.ctrl = &ctrl;
        init_ca.basic.target = ctrl.m_oStyle.state;
        init_ca.extra = nullptr;
        anima.push_back(init_ca);
        // TODO: OOM处理
        if (!anima) return;
        ca = &anima.back();
    }
    // 检测类型
    const auto native_type = ctrl.m_oStyle.appearance;
    // 自带类型
    if (native_type != AttributeAppearance::Appearance_None) {
        // 基本动画直接复写已存在动画数据
        ca->basic.done = 0;
        ca->basic.target.Change({ type , true });
        ca->basic.duration = UI::NativeStyleDuration({});
    }
    // 自定义类型
    else {
        assert(!"unsupported yet");
    }
    // 设置动画
    assert(!"NOT IMPL");
    ctrl.m_pAnimation = ca;
}
