﻿#define WIN32_LEAN_AND_MEAN

#include <util/ui_default_config.h>
#include <core/ui_time_capsule.h>
#include <container/pod_vector.h>
#include <container/pod_hash.h>
#include <input/ui_kminput.h>
#include <core/ui_manager.h>
#include <util/ui_ostype.h>
#include <luiconf.h>

#include <type_traits>
#include <new>

#include <Windows.h>


// private manager
namespace UI { struct PrivateManager {
    // TC
    using TC = CUITimeCapsule;
    // ctor
    PrivateManager() noexcept {
        cclasses.insert({ "colorpicker", nullptr });
        cclasses.insert({ "scrollbar", nullptr });
        cclasses.insert({ "groupbox", nullptr });
        cclasses.insert({ "checkbox", nullptr });
        cclasses.insert({ "textbox", nullptr });
        cclasses.insert({ "button", nullptr });
        cclasses.insert({ "radio", nullptr });
        cclasses.insert({ "vbox", nullptr });
        cclasses.insert({ "hbox", nullptr });
        cclasses.insert({ "box", nullptr });
    }
    // dtor
    ~PrivateManager() noexcept {}
    // default config
    CUIDefaultConfigure     def_conf;
    // km-input
    CUIInputKM              km_input;
    // time capsules
    POD::Vector<TC*>        time_capsules;
    // unique style classes
    POD::HashMap<void*>     sclasses;
    // unique control classes
    POD::HashMap<void*>     cclasses;
};}

/// <summary>
/// Gets the unique style class.
/// </summary>
/// <param name="pair">The pair.</param>
/// <returns></returns>
auto UI::CUIManager::GetUniqueStyleClass(
    U8View pair) noexcept -> const char * {
    assert(pair.second > pair.first && "bad string");
    return pm().sclasses.insert(pair.first, pair.second, nullptr).first->first;
}

/// <summary>
/// Gets the name of the unique element.
/// </summary>
/// <param name="pair">The pair.</param>
/// <returns></returns>
auto UI::CUIManager::GetUniqueElementName(
    U8View pair) noexcept -> const char * {
    assert(pair.second > pair.first && "bad string");
    return pm().cclasses.insert(pair.first, pair.second, nullptr).first->first;
    /*const auto itr = ll.cclasses.find(pair.first, pair.second);
    if (itr != ll.cclasses.end()) return itr->first;
    return nullptr;*/
}

/// <summary>
/// longui namespace
/// </summary>
namespace UI {
    // help
    enum {
        pmanag1 = sizeof(PrivateManager),
        pm_size = detail::private_manager<sizeof(void*)>::size,
        pm_align= detail::private_manager<sizeof(void*)>::align,
    };
    // check
    static_assert(pm_size == pmanag1, "must be same");
    static_assert(pm_align == alignof(PrivateManager), "must be same");
    /// <summary>
    /// single instance buffer for longui manager
    /// </summary>
    static std::aligned_storage<
        sizeof(CUIManager), alignof(CUIManager)
    >::type s_bufManager;
    /// <summary>
    /// Gets the ui manager instance.
    /// 获取UI管理器实例
    /// </summary>
    /// <returns></returns>
    auto CUIManager::GetInstance() noexcept -> CUIManager & {
        return reinterpret_cast<CUIManager&>(s_bufManager);
    }
}

/// <summary>
/// Initializes the specified configuration.
/// </summary>
/// <param name="config">The configuration.</param>
/// <returns></returns>
auto UI::CUIManager::Initialize(IUIConfigure* cfg) noexcept -> Result {
    new(&pm()) PrivateManager;
    // 获取真正的配置接口
    if (!cfg) cfg = &pm().def_conf;
    new(&UIManager) CUIManager(cfg);
    // 初始化
    Result hr = { Result::RS_OK };
    // 初始化窗口管理器
    if (hr) {
        hr = this->CUIWndMgr::init();
    }
    // 初始化成员
    if (hr) {
        pm().time_capsules.reserve(32);
        if (!pm().time_capsules.is_ok())
            hr = { Result::RE_OUTOFMEMORY };
    }
    // 初始化一些东西
    m_szLocaleName[0] = L'\0';
    // 获取资源加载器
    //configure.CreateInterface(LongUI_IID_PV_ARGS(m_pResourceLoader));
    // 本地字符集名称
    configure.GetLocaleName(m_szLocaleName);
    // 获取实例句柄
    auto hInstance = ::GetModuleHandleW(nullptr);
    // 获取文本格式化器
    if (hr) {
        //hr = configure.CreateInterface(LongUI_IID_PV_ARGS(m_pTextFormatter));
        longui_debug_hr(hr, L"Create m_pTextFormatter faild");
    }
    // 创建工具窗口
    if (hr) {
        // 注册窗口
        WNDCLASSEXW wcex;
        constexpr auto cn = Attribute::WindowClassNameT;
        auto code = ::GetClassInfoExW(hInstance, cn, &wcex);
        if (!code) {
            // 处理函数
            auto wndproc = [](HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) noexcept ->LRESULT {
                switch (message)
                {
                case WM_INPUT:
                {
                    CUIDataAutoLocker locker;
                    //UIManager.m_uiInput.Update(reinterpret_cast<HRAWINPUT>(lParam));
                }
                return 1;
                case WM_DISPLAYCHANGE:
                    // 显示环境改变
                    UIManager.refresh_display_frequency();
                    //UIManager.create_dxgi_output();
#ifndef NDEBUG
                    LUIDebug(Hint) << "WM_DISPLAYCHANGE" << UI::endl;
                case WM_CLOSE:
                    // 不能关闭该窗口
#endif
                    return 0;
                default:
                    return ::DefWindowProcW(hwnd, message, wParam, lParam);
                }
                return 0;
            };
            // 注册窗口类
            wcex = { 0 };
            wcex.cbSize = sizeof(WNDCLASSEXW);
            wcex.style = CS_NOCLOSE;
            wcex.cbClsExtra = 0;
            wcex.cbWndExtra = sizeof(void*);
            wcex.hInstance = hInstance;
            wcex.hCursor = nullptr;
            wcex.hbrBackground = nullptr;
            wcex.lpszMenuName = nullptr;
            wcex.lpszClassName = Attribute::WindowClassNameT;
            wcex.hIcon = nullptr;
            wcex.lpfnWndProc = wndproc;
            ::RegisterClassExW(&wcex);
        }
#ifdef NDEBUG
        constexpr int SIX = 0;
        constexpr int SIY = 0;
        constexpr int SIW = 0;
        constexpr int SIH = 0;
#else
        constexpr int SIX = 50;
        constexpr int SIY = 50;
        constexpr int SIW_ = 256;
        constexpr int SIH_ = 0;
        RECT rect = { SIX, SIY, SIX + SIW_, SIY + SIH_ };
        ::AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);
        const int SIW = rect.right - rect.left;
        const int SIH = rect.bottom - rect.top;
#endif
        // 创建
        m_hToolWnd = ::CreateWindowExW(
            WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
            Attribute::WindowClassNameT, L"SystemInvoke",
            0, SIX, SIY, SIW, SIH, nullptr, nullptr, hInstance, nullptr
        );
        // 成功
        if (m_hToolWnd) {
#ifndef NDEBUG
            ::ShowWindow(m_hToolWnd, SW_SHOW);
#endif
        }
        else {
            hr = { Result::RE_FAIL };
        }

    }
    // 初始化输入
    if (hr) {
        hr = pm().km_input.Init(m_hToolWnd);
    }
    // 创建D2D工厂
    /*if (hr) {
        D2D1_FACTORY_OPTIONS options = { D2D1_DEBUG_LEVEL_NONE };
#ifndef NDEBUG
        options.debugLevel = D2D1_DEBUG_LEVEL_INFORMATION;
#endif
        hr = UI::Dll::D2D1CreateFactory(
            D2D1_FACTORY_TYPE_SINGLE_THREADED,
            IID_ID2D1Factory4,
            &options,
            reinterpret_cast<void**>(&m_pd2dFactory)
        );
        longui_debug_hr(hr, L"D2D1CreateFactory faild");
    }
    // 创建 DirectWrite 工厂.
    if (hr) {
        hr = ::DWriteCreateFactory(
            DWRITE_FACTORY_TYPE_SHARED,
            LongUI_IID_PV_ARGS_Ex(m_pDWriteFactory)
        );
        longui_debug_hr(hr, L"DWriteCreateFactory faild");
    }*/
    // 创建帮助器
    /*if (hr) {
    hr = ::CoCreateInstance(
    CLSID_DragDropHelper,
    nullptr,
    CLSCTX_INPROC_SERVER,
    LongUI_IID_PV_ARGS(m_pDropTargetHelper)
    );
    longui_debug_hr(hr, L"CoCreateInstance CLSID_DragDropHelper faild");
    }*/
    // 创建字体集
    if (hr) {
        // 获取脚本
        /*configure.CreateInterface(LongUI_IID_PV_ARGS(m_pFontCollection));
        // 失败获取系统字体集
        if (!m_pFontCollection) {
            hr = m_pDWriteFactory->GetSystemFontCollection(&m_pFontCollection);
            longui_debug_hr(hr, L"m_pDWriteFactory->GetSystemFontCollection faild");
        }*/
    }
#ifndef NDEBUG
    // 枚举字体
    /*if (hr && (this->flag & IUIConfigure::Flag_DbgOutputFontFamily)) {
        auto count = m_pFontCollection->GetFontFamilyCount();
        UIManager << DL_Log << "Font found: " << long(count) << L"\r\n";
        // 遍历所有字体
        for (auto i = 0u; i < count; ++i) {
            IDWriteFontFamily* family = nullptr;
            // 获取字体信息
            if (SUCCEEDED(m_pFontCollection->GetFontFamily(i, &family))) {
                IDWriteLocalizedStrings* string = nullptr;
                // 获取字体名称
                if (SUCCEEDED(family->GetFamilyNames(&string))) {
                    wchar_t buffer[LongUIStringBufferLength];
                    auto tc = string->GetCount();
                    UIManager << DLevel_Log << Formated(L"%4d[%d]: ", int(i), int(tc));
                    // 遍历所有字体名称
#if 0
                    for (auto j = 0u; j < 1u; j++) {
                        string->GetLocaleName(j, buffer, LongUIStringBufferLength);
                        UIManager << DLevel_Log << buffer << " => ";
                        // 有些语言在我的机器上显示不了(比如韩语), 会出现bug略过不少东西, 就显示第一个了
                        string->GetString(j, buffer, LongUIStringBufferLength);
                        UIManager << DLevel_Log << buffer << "; ";
                    }
#else
                    // 显示第一个
                    string->GetLocaleName(0, buffer, LongUIStringBufferLength);
                    UIManager << DLevel_Log << buffer << " => ";
                    string->GetString(0, buffer, LongUIStringBufferLength);
                    UIManager << DLevel_Log << buffer << ";\r\n";
#endif
                }
                UI::SafeRelease(string);
            }
            UI::SafeRelease(family);
        }
        // 刷新
        UIManager << DL_Log << UI::endl;
    }*/
#endif
    // 添加控件
    if (hr) {
        /*// 注册控件类
#define LONGUI_REGISTERCC(name) UI##name::CreateControl, #name
        //this->RegisterControlClass(LONGUI_REGISTERCC(ScrollBarB));
        // 添加默认控件创建函数
        this->RegisterControlClass(CreateNullControl, "Null");
        this->RegisterControlClass(LONGUI_REGISTERCC(Text));
        this->RegisterControlClass(LONGUI_REGISTERCC(List));
        this->RegisterControlClass(LONGUI_REGISTERCC(Edit));
        this->RegisterControlClass(LONGUI_REGISTERCC(Page));
        this->RegisterControlClass(LONGUI_REGISTERCC(Color));
        this->RegisterControlClass(LONGUI_REGISTERCC(Slider));
        this->RegisterControlClass(LONGUI_REGISTERCC(Button));
        this->RegisterControlClass(LONGUI_REGISTERCC(Single));
        this->RegisterControlClass(LONGUI_REGISTERCC(ListLine));
        this->RegisterControlClass(LONGUI_REGISTERCC(CheckBox));
        this->RegisterControlClass(LONGUI_REGISTERCC(ComboBox));
        this->RegisterControlClass(LONGUI_REGISTERCC(RamBitmap));
        this->RegisterControlClass(LONGUI_REGISTERCC(ListHeader));
        this->RegisterControlClass(LONGUI_REGISTERCC(ScrollBarA));
        this->RegisterControlClass(LONGUI_REGISTERCC(RadioButton));
        this->RegisterControlClass(LONGUI_REGISTERCC(FloatLayout));
        this->RegisterControlClass(LONGUI_REGISTERCC(VerticalLayout));
        this->RegisterControlClass(LONGUI_REGISTERCC(HorizontalLayout));*/
        // 添加自定义控件
        configure.RegisterSome();
    }
    // 初始化事件
    /*if (hr) {
        hr = this->do_creating_event(UI::CreateEventType::Type_Initialize);
        longui_debug_hr(hr, L"do_creating_event(init) faild");
    }
    // 创建资源
    if (hr) {
        hr = this->RecreateResources();
        longui_debug_hr(hr, L"RecreateResources faild");
    }*/
    // 检查错误
    if (FAILED(hr)) {
        this->ShowError(hr);
    }
    // 检查当前路径
#ifndef NDEBUG
    constexpr uint32_t buflen = MAX_PATH * 4;
    wchar_t buffer[buflen]; buffer[0] = 0;
    ::GetCurrentDirectoryW(buflen, buffer);
    LUIDebug(Log) 
        << L" Current Directory: "
        << buffer
        << UI::endl;
#endif
    return hr;
}


// longui::impl 命名空间
namespace UI {
    namespace impl {
        // get script interface from config
        inline auto&script_interface(IUIConfigure& c) noexcept {
            IUIScript* script = nullptr;
            return *script;
        }
    }
}

/// <summary>
/// Initializes a new instance of the <see cref="CUIManager"/> class.
/// </summary>
/// <param name="config">The configuration.</param>
UI::CUIManager::CUIManager(IUIConfigure* config) noexcept :
configure(*config),
script(impl::script_interface(*config)),
flag(configure.GetConfigureFlag()) {

}

/// <summary>
/// Finalizes an instance of the <see cref="CUIManager"/> class.
/// </summary>
/// <returns></returns>
UI::CUIManager::~CUIManager() noexcept {
}

/// <summary>
/// Uninitializes this instance.
/// </summary>
/// <returns></returns>
void UI::CUIManager::Uninitialize() noexcept {
    // 手动调用析构函数
    UIManager.~CUIManager();
}



/// <summary>
/// Shows the error.
/// </summary>
/// <param name="hr">The hr.</param>
/// <param name="str">The string.</param>
/// <returns></returns>
bool UI::CUIManager::ShowError(Result hr, const wchar_t* str) noexcept {
    assert(hr);
    return 0;
}


