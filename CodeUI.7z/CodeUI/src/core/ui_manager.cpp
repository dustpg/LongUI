﻿// ui
#include <interface/ui_default_config.h>
#include <interface/ui_ctrlinfolist.h>
#include <container/pod_vector.h>
#include <core/ui_time_capsule.h>
#include <container/pod_hash.h>
#include <input/ui_kminput.h>
#include <core/ui_manager.h>
#include <util/ui_ostype.h>
#include <util/ui_endian.h>
#include <luiconf.h>

// c++
#include <type_traits>
#include <new>

// windows com
#include <objbase.h>


// private manager
namespace UI { struct PrivateManager {
    // TC
    using TC = CUITimeCapsule;
    // meta
    using META = const MetaControl;
    // ctor
    PrivateManager() noexcept {  }
    // dtor
    ~PrivateManager() noexcept {}
    // time capsules
    POD::Vector<TC*>        time_capsules;
    // unique style classes
    POD::HashMap<void*>     sclasses;
    // unique control classes
    POD::HashMap<META*>     cclasses;
    // km-input
    CUIInputKM              km_input;
};}

/// <summary>
/// Instances this instance.
/// </summary>
/// <returns></returns>
auto UI::CUIInputKM::Instance() noexcept -> CUIInputKM & {
    return UIManager.pm().km_input;
}

// add defualt control class
namespace UI { void AddDefualtControlInfo(ControlInfoList&) noexcept; }

#ifndef NDEBUG
#include <util/ui_time_meter.h>
static void ui_endian_runtime_assert() noexcept;
static void ui_dbg_set_window_title(HWND, const wchar_t*) noexcept;

namespace UI {
    // debug data
    struct CUIManagerDebug {
        // ctor
        CUIManagerDebug() noexcept {}
        // dtor
        ~CUIManagerDebug() noexcept {}
        // next frame
        void NextFrame() noexcept { ++fcounter; }
        // delta time list
        POD::Vector<float>      fpsc;
        // frame counter
        uint32_t                fcounter = 0;
        // push delta
        auto PushDelta(float d, uint32_t f) noexcept {
            constexpr float add_one_sec = 0.233f * 2.33f * 1.2450f;
            if (const auto size = uint32_t(float(f) * add_one_sec)) {
                fpsc.push_back(d);
                if (fpsc.size() >= size) {
                    float time = 0.f;
                    for (auto t : fpsc) time += t;
                    const auto real_size = float(fpsc.size());
                    time /= real_size;
                    fpsc.clear();
                    return time;
                }
            }
            return 0.f;
        }
    };
    // data buffer
    static std::aligned_storage<
        sizeof(CUIManagerDebug), 
        alignof(CUIManagerDebug)
    >::type s_dbgfManager;
    // get inline
    auto DbgMgr() noexcept->CUIManagerDebug& {
        return reinterpret_cast<CUIManagerDebug&>(s_dbgfManager);
    }
    // get frame id
    auto get_frame_id() noexcept -> uint32_t {
        return DbgMgr().fcounter;
    }

}
#endif


/// <summary>
/// do one frame
/// </summary>
/// <returns></returns>
void UI::CUIManager::OneFrame() noexcept {
#ifndef NDEBUG
    CUITimeMeterH meter;
    meter.Start();
    int while_count = 0;
#endif
    // 数据更新区域
    this->DataLock();
    // 记录帧间时间
    m_fDeltaTime = this->update_delta_time();
    // 刷新控件控制
    this->normal_update();
    // 初始化控件
    while (this->init_control_in_list()) {
        // 更新窗口最小大小
        this->refresh_window_minsize();
        // 刷新在表控件
        this->update_control_in_list();
#ifndef NDEBUG
        ++while_count;
#endif
    }
#ifndef NDEBUG
    // 遍历次数>1
    if (while_count > 1) {
        LUIDebug(Hint) LUI_FRAMEID
            << "frame while loop count : "
            << while_count
            << endl;
    }
#endif
    // 次帧刷新列表
    this->push_next_update();
    // 更新世界
    this->refresh_window_world();
    // 结束数据更新
    this->DataUnlock();
#ifndef NDEBUG
    // 记录刷新时间
    const auto t1 = meter.Delta_ms<float>();
    meter.MovStartEnd();
    //meter.Start();
#endif
    // 渲染所有窗口
    this->RenderLock();
    const auto hr = this->render_windows();
    this->RenderUnlock();
#ifndef NDEBUG
    // 记录渲染时间
    const auto t2 = meter.Delta_ms<float>();
    if (this->flag & ConfigFlag::Flag_DbgOutputTimeTook)
        LUIDebug(None)
            << "U<" << DDFFloat2{ t1 } << "ms>"
            << "R<" << DDFFloat2{ t2 } << "ms>"
            << endl;
    // 计算FPS
    const auto time = DbgMgr().PushDelta(
        m_fDeltaTime, m_dwDisplayFrequency);
    if (time > 0.f) {
        constexpr size_t buflen = 128;
        wchar_t buffer[buflen];
        std::swprintf(
            buffer, buflen,
            L"delta: %.2fms -- %2.2f fps",
            time, 1000.f / time
        );
        ui_dbg_set_window_title(m_hToolWnd, buffer);
    }
    DbgMgr().NextFrame();
#endif
    // TODO: 错误处理
    assert(hr);
}


/// <summary>
/// Waits for v-blank.
/// </summary>
/// <returns></returns>
void UI::CUIManager::WaitForVBlank() noexcept {
    if (!this->wait_for_vblank()) {
        this->sleep_for_vblank();
    }
}

// windows api
#include <Windows.h>


/*// add default 
void UI::PrivateManager::add_class() noexcept {
    cclasses.insert({ "colorpicker", nullptr });
    cclasses.insert({ "scrollbar", nullptr });
    cclasses.insert({ "groupbox", nullptr });
    cclasses.insert({ "checkbox", nullptr });
    cclasses.insert({ "textbox", nullptr });
    cclasses.insert({ "button", nullptr });
    cclasses.insert({ "radio", nullptr });
    cclasses.insert({ "vbox", nullptr });
    cclasses.insert({ "hbox", nullptr });
    cclasses.insert({ "box", nullptr });
}*/

/// <summary>
/// Gets the unique style class.
/// </summary>
/// <param name="pair">The pair.</param>
/// <returns></returns>
auto UI::CUIManager::GetUniqueStyleClass(
    U8View pair) noexcept -> const char * {
    assert(pair.second > pair.first && "bad string");
    return pm().sclasses.insert(pair.first, pair.second, nullptr).first->first;
}

/// <summary>
/// Gets the name of the unique element.
/// </summary>
/// <param name="pair">The pair.</param>
/// <returns></returns>
auto UI::CUIManager::GetUniqueElementName(
    U8View pair) noexcept -> const char * {
    assert(pair.second > pair.first && "bad string");
    return pm().cclasses.insert(pair.first, pair.second, nullptr).first->first;
    /*const auto itr = ll.cclasses.find(pair.first, pair.second);
    if (itr != ll.cclasses.end()) return itr->first;
    return nullptr;*/
}

/// <summary>
/// longui namespace
/// </summary>
namespace UI {
    // help
    enum {
        pmanag1 = sizeof(PrivateManager),
        pm_size = detail::private_manager<sizeof(void*)>::size,
        pm_align= detail::private_manager<sizeof(void*)>::align,
    };
    // check
    static_assert(pm_size == pmanag1, "must be same");
    static_assert(pm_align == alignof(PrivateManager), "must be same");
    /// <summary>
    /// single instance buffer for longui manager
    /// </summary>
    std::aligned_storage<sizeof(CUIManager), alignof(CUIManager)>::type s_bufManager;
    // impl
    namespace impl {     
        // init HiDPI
        void init_high_dpi_support() noexcept;
        // uninit HiDPI
        void uninit_high_dpi_support() noexcept;
    }
}

/// <summary>
/// Initializes the specified configuration.
/// </summary>
/// <param name="config">The configuration.</param>
/// <returns></returns>
auto UI::CUIManager::Initialize(IUIConfigure* cfg) noexcept -> Result {
#ifndef NDEBUG
    // 大小端断言
    ::ui_endian_runtime_assert();
#endif
    // 设置高DPI支持
    impl::init_high_dpi_support();
    // 初始化COM
    {
        const Result hr = { ::CoInitialize(nullptr) };
        if (!hr) return hr;
    }
    // 默认配置
    constexpr auto DEFCFG_SIZE = sizeof(CUIDefaultConfigure);
    static void* s_config_buf[DEFCFG_SIZE / sizeof(void*)];
    static_assert(sizeof(s_config_buf) == sizeof(CUIDefaultConfigure), "Orz");
    // 直接初始化
    const auto defcfg = new(s_config_buf) CUIDefaultConfigure;
    if (!cfg) cfg = defcfg;
    // 构造管理器
    {
        Result hr = { Result::RS_OK };
        new(&UIManager) CUIManager{ cfg, hr };
        if (!hr) return hr;
    }
    // 致命BUG处理
    this->InitUnExpHandler();
    // 初始化
    Result hr = { Result::RS_OK };
    // 初始化成员
    if (hr) {
        pm().time_capsules.reserve(32);
        if (!pm().time_capsules.is_ok())
            hr = { Result::RE_OUTOFMEMORY };
    }
    // 获取实例句柄
    auto hInstance = ::GetModuleHandleW(nullptr);
    // 获取文本格式化器
    if (hr) {
        //hr = configure.CreateInterface(LongUI_IID_PV_ARGS(m_pTextFormatter));
        longui_debug_hr(hr, L"Create m_pTextFormatter faild");
    }
    // 创建工具窗口
    if (hr) {
        // 注册窗口
        WNDCLASSEXW wcex;
        auto code = ::GetClassInfoExW(
            hInstance, Attribute::WindowClassNameT, &wcex
        );
        if (!code) {
            // 处理函数
            auto wndproc = [](
                HWND hwnd, 
                UINT message, 
                WPARAM wParam,
                LPARAM lParam
                ) noexcept ->LRESULT {
                switch (message)
                {
                case WM_INPUT:
                    // XXX: 考虑加锁
                    //CUIDataAutoLocker locker;
                    UIManager.pm().km_input.Update(
                        reinterpret_cast<HRAWINPUT>(lParam)
                    );
                    return 1;
                case WM_DISPLAYCHANGE:
                    // 显示环境改变
                    UIManager.refresh_display_frequency();
                    UIManager.redirect_screen();
#ifndef NDEBUG
                    LUIDebug(Hint) << "WM_DISPLAYCHANGE" << UI::endl;
                case WM_CLOSE:
                    // 不能关闭该窗口
#endif
                    return 0;
                default:
                    return ::DefWindowProcW(hwnd, message, wParam, lParam);
                }
                return 0;
            };
            // 注册窗口类
            wcex = { 0 };
            wcex.cbSize = sizeof(WNDCLASSEXW);
            wcex.style = CS_NOCLOSE;
            wcex.cbClsExtra = 0;
            wcex.cbWndExtra = sizeof(void*);
            wcex.hInstance = hInstance;
            wcex.hCursor = nullptr;
            wcex.hbrBackground = nullptr;
            wcex.lpszMenuName = nullptr;
            wcex.lpszClassName = Attribute::WindowClassNameT;
            wcex.hIcon = nullptr;
            wcex.lpfnWndProc = wndproc;
            ::RegisterClassExW(&wcex);
        }
#ifdef NDEBUG
        constexpr int SIX = 0;
        constexpr int SIY = 0;
        constexpr int SIW = 0;
        constexpr int SIH = 0;
#else
        constexpr int SIX = 50;
        constexpr int SIY = 50;
        constexpr int SIW_ = 256;
        constexpr int SIH_ = 0;
        RECT rect = { SIX, SIY, SIX + SIW_, SIY + SIH_ };
        ::AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);
        const int SIW = rect.right - rect.left;
        const int SIH = rect.bottom - rect.top;
#endif
        // 创建
        m_hToolWnd = ::CreateWindowExW(
            WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
            Attribute::WindowClassNameT, Attribute::WindowClassNameT,
            0, SIX, SIY, SIW, SIH, nullptr, nullptr, hInstance, nullptr
        );
        auto isuc = ::IsWindowUnicode(m_hToolWnd);
        // 成功
        if (m_hToolWnd) {
#ifndef NDEBUG
            ::ShowWindow(m_hToolWnd, SW_SHOW);
#endif
        }
        else {
            hr = { Result::RE_FAIL };
        }
    }
    // 初始化输入
    if (hr) {
        hr = pm().km_input.Init(m_hToolWnd);
    }
    // 创建帮助器
    /*if (hr) {
        hr = ::CoCreateInstance(
            CLSID_DragDropHelper,
            nullptr,
            CLSCTX_INPROC_SERVER,
            LongUI_IID_PV_ARGS(m_pDropTargetHelper)
        );
        longui_debug_hr(hr, L"CoCreateInstance CLSID_DragDropHelper faild");
    }*/
    // 创建字体集
    if (hr) {
        // 获取脚本
        /*configure.CreateInterface(LongUI_IID_PV_ARGS(m_pFontCollection));
        // 失败获取系统字体集
        if (!m_pFontCollection) {
            hr = m_pDWriteFactory->GetSystemFontCollection(&m_pFontCollection);
            longui_debug_hr(hr, L"m_pDWriteFactory->GetSystemFontCollection faild");
        }*/
    }
#ifndef NDEBUG
    // 枚举字体
    /*if (hr && (this->flag & IUIConfigure::Flag_DbgOutputFontFamily)) {
        auto count = m_pFontCollection->GetFontFamilyCount();
        UIManager << DL_Log << "Font found: " << long(count) << "\r\n";
        // 遍历所有字体
        for (auto i = 0u; i < count; ++i) {
            IDWriteFontFamily* family = nullptr;
            // 获取字体信息
            if (SUCCEEDED(m_pFontCollection->GetFontFamily(i, &family))) {
                IDWriteLocalizedStrings* string = nullptr;
                // 获取字体名称
                if (SUCCEEDED(family->GetFamilyNames(&string))) {
                    wchar_t buffer[LongUIStringBufferLength];
                    auto tc = string->GetCount();
                    UIManager << DLevel_Log << Formated(L"%4d[%d]: ", int(i), int(tc));
                    // 遍历所有字体名称
#if 0
                    for (auto j = 0u; j < 1u; j++) {
                        string->GetLocaleName(j, buffer, LongUIStringBufferLength);
                        UIManager << DLevel_Log << buffer << " => ";
                        // 有些语言在我的机器上显示不了(比如韩语), 会出现bug略过不少东西, 就显示第一个了
                        string->GetString(j, buffer, LongUIStringBufferLength);
                        UIManager << DLevel_Log << buffer << "; ";
                    }
#else
                    // 显示第一个
                    string->GetLocaleName(0, buffer, LongUIStringBufferLength);
                    UIManager << DLevel_Log << buffer << " => ";
                    string->GetString(0, buffer, LongUIStringBufferLength);
                    UIManager << DLevel_Log << buffer << ";\r\n";
#endif
                }
                UI::SafeRelease(string);
            }
            UI::SafeRelease(family);
        }
        // 刷新
        UIManager << DL_Log << UI::endl;
    }*/
#endif
    // 添加控件
    if (hr) {
        ControlInfoList list;
        // 添加默认控件
        UI::AddDefualtControlInfo(list);
        // 添加自定义控件
        if (list) this->config->RegisterControl(list);
        // 注册控件
        if (list) for (auto info : list) {
            if (!pm().cclasses.insert({ info->element_name, info }).second) {
                goto error_oom;
            }
        }
        else {
        error_oom:
            hr = { Result::RE_OUTOFMEMORY };
            assert(!"check this");
        }
    }
    // 初始化事件
    /*if (hr) {
        hr = this->do_creating_event(UI::CreateEventType::Type_Initialize);
        longui_debug_hr(hr, L"do_creating_event(init) faild");
    }
    // 创建资源
    if (hr) {
        hr = this->RecreateResources();
        longui_debug_hr(hr, L"RecreateResources faild");
    }*/
    // 第一次重建设备资源
    if (hr) {
        auto& pmm = pm();
        hr = this->recreate(this->config);
    }
    // 检查当前路径
#ifndef NDEBUG
    constexpr uint32_t buflen = MAX_PATH * 4;
    wchar_t buffer[buflen]; buffer[0] = 0;
    ::GetCurrentDirectoryW(buflen, buffer);
    LUIDebug(Hint) 
        << " Current Directory: "
        << buffer
        << UI::endl;
#endif
    return hr;
}

#ifndef NDEBUG
#include <core/ui_string.h>
#endif

/// <summary>
/// Initializes a new instance of the <see cref="CUIManager"/> class.
/// </summary>
/// <param name="config">The configuration.</param>
UI::CUIManager::CUIManager(IUIConfigure* config, Result& out) noexcept :
ConfigKeeper{ config },
#ifndef NDEBUG
CUIDebug(config->GetSimpleLogFileName().c_str()),
#endif
CUIResMgr(config, out),
CUIWndMgr(out),
flag(config->GetConfigureFlag()) {
#ifndef NDEBUG
    new(&DbgMgr()) CUIManagerDebug;
#endif
    config->AddRef();
    new(&pm()) PrivateManager;
}

/// <summary>
/// Finalizes an instance of the <see cref="CUIManager"/> class.
/// </summary>
/// <returns></returns>
UI::CUIManager::~CUIManager() noexcept {
    this->config->Release();
    pm().~PrivateManager();
#ifndef NDEBUG
    DbgMgr().~CUIManagerDebug();
#endif
}

/// <summary>
/// Uninitializes this instance.
/// </summary>
/// <returns></returns>
void UI::CUIManager::Uninitialize() noexcept {
    // 手动调用析构函数
    UIManager.~CUIManager();
    // 反初始化COM
    ::CoUninitialize();
    // 反初始化高DPI支持
    impl::uninit_high_dpi_support();
}



/// <summary>
/// Shows the error.
/// </summary>
/// <param name="hr">The hr.</param>
/// <param name="str">The string.</param>
/// <returns></returns>
bool UI::CUIManager::ShowError(Result hr, const wchar_t* str) noexcept {
    assert(hr);
    return 0;
}



#ifndef NDEBUG
void ui_endian_runtime_assert() noexcept {
    using namespace UI;
    enum : uint32_t {
        LITTLE_ENDIAN = 0x03020100ul,
        BIG_ENDIAN = 0x00010203ul,
        PDP_ENDIAN = 0x01000302ul,
    };
    const union { unsigned char bytes[4]; uint32_t value; }
    host_order{ { 0, 1, 2, 3 } };
    const bool le = host_order.value == LITTLE_ENDIAN;
    const bool be = host_order.value == BIG_ENDIAN;
    const bool me = host_order.value == PDP_ENDIAN;
    assert(le == helper::is_little_endian::value);
    assert(be == helper::is_big_endian::value);
    assert(me == helper::is_pdp_endian::value);
}

void ui_dbg_set_window_title(HWND hwnd, const wchar_t * title) noexcept {
    ::SetWindowTextW(hwnd, title);
}
#endif