﻿#include <interface/ui_ctrlinfolist.h>
#include <control/ui_box_layout.h>
#include <control/ui_scroll_bar.h>
#include <control/ui_spacer.h>
#include <control/ui_button.h>
#include <control/ui_scale.h>
#include <control/ui_image.h>
#include <control/ui_label.h>
#include <control/ui_test.h>

// ui namespace
namespace UI {
    /// <summary>
    /// The defualt control information
    /// </summary>
    const MetaControl* const DefualtControlInfo[] = {
        // V Box Layout - 垂直箱型布局
        &UIVBoxLayout::s_meta,
        // H Box Layout - 水平箱型布局
        &UIHBoxLayout::s_meta,
        // Box Layout - 箱型布局
        &UIBoxLayout::s_meta,
        // Scroll Bar - 滚动条
        &UIScrollBar::s_meta,
        // Spacer - 占位控件
        &UISpacer::s_meta,
        // Button - 按钮控件
        &UIButton::s_meta,
        // Scale - 滑动控件
        &UIScale::s_meta,
        // Image - 图像控件
        &UIImage::s_meta,
        // Label - 标签控件
        &UILabel::s_meta,
#ifndef NDEBUG
        // Test - 测试控件
        &UITest::s_meta,
        // Test - 一般控件
        &UIControl::s_meta,
#endif
    };
    /// <summary>
    /// Adds the defualt control information.
    /// </summary>
    /// <param name="list">The list.</param>
    void AddDefualtControlInfo(ControlInfoList& list) noexcept {
        // 默认CC数量
        constexpr uint32_t CONTROL_CLASS_SIZE = 32;
        list.reserve(CONTROL_CLASS_SIZE);
        if (list) list.assign(
            std::begin(DefualtControlInfo),
            std::end(DefualtControlInfo)
        );
#ifndef NDEBUG
        // 测试正确性
        for (auto x : DefualtControlInfo) {
            if (auto ctrl = x->create_func(nullptr)) {
                assert(&ctrl->GetMetaInfo() == x);
                delete ctrl;
            }
        }
#endif
    }
}