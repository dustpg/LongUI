﻿#include <cstdint>
#include <core/ui_string.h>
#include <core/ui_manager.h>
#include <debugger/ui_debug.h>

void main_inited();

int main() {
    if (UIManager.Initialize()) {
        main_inited();
        UIManager.Uninitialize();
    }
    else assert(!"error");
    return 0;
}

void main_inited() {
    UI::CUIString str = L"Hello";
    UI::POD::Vector<double> a = { 32.f };
    LUIDebug(Hint) << UI::endl;
}
