﻿#include <cstdint>
#include <core/ui_string.h>
#include <core/ui_manager.h>
#include <core/ui_malloc.h>
#include <debugger/ui_debug.h>

#include <Windows.h>
void main_inited();

int CALLBACK WinMain(HINSTANCE, HINSTANCE, char*, int) {
    if (UIManager.Initialize()) {
        LUIDebug(Hint)
            << L"Battle Control Online..."
            << UI::endl;

        const auto ptr1 = UI::SmallAlloc(1024);
        const auto ptr2 = UI::SmallRealloc(ptr1, 2048);
        UI::SmallFree(ptr2);

        main_inited();

        LUIDebug(Hint)
            << L"Battle Control Terminated."
            << UI::endl;

        UIManager.Uninitialize();
    }
    else assert(!"error");
    return 0;
}

void main_inited() {
    UI::CUIString str;
    str.format(L"%f", 1.f);
    UI::POD::Vector<double> a = { 32.f };
    UIManager.MainLoop();
}
