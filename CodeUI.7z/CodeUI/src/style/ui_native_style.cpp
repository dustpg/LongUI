﻿// ui
#include <core/ui_object.h>
#include <core/ui_manager.h>
#include <core/ui_color_list.h>
#include <style/ui_native_style.h>
// c++
#include <cassert>
// windows
#include <Windows.h>
#if 0
#include <Uxtheme.h>
#include <vssym32.h>
#endif

// graphics
#include <graphics/ui_graphics_impl.h>

// ui namespace
namespace UI {
    // some constant
    enum : uint32_t {
        // basic animation duration(unit: ms)
        BASIC_ANIMATION_DURATION = 225,
    };
    // native theme not support any-scale(?), use hard-code simulate it
#if 0
#pragma comment(lib, "Uxtheme")
    // test code
    void NativeStyle() noexcept {
        if (const auto theme = ::OpenThemeData(nullptr, L"Button")) {
            ID2D1BitmapRenderTarget* target = nullptr;
            ID2D1GdiInteropRenderTarget* gdirt = nullptr;
            D2D1_PIXEL_FORMAT fmt = D2D1::PixelFormat(
                DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED
            );
            D2D1_SIZE_F size{ 512.f, 512.f };
            UIManager.Ref2DRenderer().CreateCompatibleRenderTarget(
                &size,
                nullptr,
                &fmt,
                D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS_GDI_COMPATIBLE,
                &target
            );
            assert(target);
            target->QueryInterface(
                IID_ID2D1GdiInteropRenderTarget,
                (void**)&gdirt
            );
            assert(gdirt && "cannot failed that documented");
            HDC hdc = nullptr;
            target->BeginDraw();
            auto code = gdirt->GetDC(D2D1_DC_INITIALIZE_MODE_CLEAR, &hdc);
            assert(SUCCEEDED(code));
            ::SetGraphicsMode(hdc, GM_ADVANCED);
            XFORM matrix;
            auto bv = ::GetWorldTransform(hdc, &matrix);
            matrix.eM11 = 2.f;
            matrix.eM22 = 2.f;
            reinterpret_cast<D2D1_MATRIX_3X2_F&>(matrix) = 
                D2D1::Matrix3x2F::Scale({ 2.f , 2.f });
            bv = ::SetWorldTransform(hdc, &matrix);
            assert(bv);
            //target->SetTransform(D2D1::Matrix3x2F::Scale({ 2,2 }));
            RECT rect{ 0, 0, 64, 64 };
            assert(SUCCEEDED(code));
            RECT content_rect;
            code = ::DrawThemeBackground(
                theme, hdc, 
                BP_PUSHBUTTON, PBS_NORMAL,
                &rect,
                nullptr
            );
            assert(SUCCEEDED(code));
            code = gdirt->ReleaseDC(nullptr);
            assert(SUCCEEDED(code));
            code = target->EndDraw();
            assert(SUCCEEDED(code));
            ID2D1Bitmap* bitmap = nullptr;
            target->GetBitmap(&bitmap);
            assert(bitmap);
            I::Bitmap* real_bitmap = nullptr;
            bitmap->QueryInterface(IID_ID2D1Bitmap1, (void**)&real_bitmap);
            auto hr = UIManager.SaveAsPng(*real_bitmap, L"test.png");
            assert(hr);
            gdirt->Release();
            bitmap->Release();
            target->Release();
            real_bitmap->Release();
            ::CloseThemeData(theme);
        }
        else assert(!"error");
}
#endif
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="CUIObject" />
    class CUINativeStyle : public CUIObject {

    };
    /// <summary>
    /// win8 native style simulator
    /// </summary>
    class CUINativeStyleWindows8 final : public CUINativeStyle {
        /*
            Win8/8.1/10.0.10158之前
            默认按钮: 0x3399FF 矩形描边
            0. 禁用: 0xD9D9D9 矩形描边; 中心 0xEFEFEF
            1. 普通: 0xACACAC 矩形描边; 中心 从上到下0xF0F0F0到0xE5E5E5渐变
            2. 移上: 0x7EB4EA 矩形描边; 中心 从上到下0xECF4FC到0xDCECFC渐变
            3. 按下: 0x569DE5 矩形描边; 中心 从上到下0xDAECFC到0xC4E0FC渐变
        */
    };

    /// <summary>
    /// win10 native style simulator
    /// </summary>
    class CUINativeStyleWindows10 final : public CUINativeStyle {
        // release device-dependent resources
        void release_dd_resources() noexcept;
        // release all resources
        void release_all_resources() noexcept;
    public:
        // ctor
        CUINativeStyleWindows10() noexcept {}
        // dtor
        ~CUINativeStyleWindows10() noexcept { this->release_all_resources(); }
        // recreate resources
        auto Recreate() noexcept->Result;
        // draw native
        void DrawNative(const NativeDrawArgs& args) noexcept;
    private:
        // draw button
        void draw_button(const RectF&, StyleState, float opacity) noexcept;
    private:
    };
}

/// <summary>
/// Gets the duration of the animation.
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
auto UI::NativeStyleDuration(const GetDurationArgs& args) noexcept -> uint32_t {
    // TODO: 不同状态 不同类型不一样
    return BASIC_ANIMATION_DURATION;
}

PCN_NOINLINE
/// <summary>
/// Draws the native style.
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
void UI::NativeStyleDraw(const NativeDrawArgs& args) noexcept {
    CUINativeStyleWindows10 style;
    style.DrawNative(args);
}

PCN_NOINLINE
/// <summary>
/// Initializes the native style.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="aa">The appearance.</param>
/// <returns></returns>
void UI::NativeStyleInit(UIControl& ctrl, AttributeAppearance aa) noexcept {
    assert(!"NOT IMPLE");
}


/// <summary>
/// Draws the native.
/// </summary>
/// <param name="appearance">The appearance.</param>
/// <param name="state">The state.</param>
/// <param name="opacity">The opacity.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUINativeStyleWindows10::DrawNative(const NativeDrawArgs& args) noexcept {
    this->draw_button(args.border, args.state, args.opacity);
}


/// <summary>
/// Releases all resources.
/// </summary>
/// <returns></returns>
void UI::CUINativeStyleWindows10::release_all_resources() noexcept {
    // 释放设备相关资源
    this->release_dd_resources();
    // 释放设备无关资源
}

/// <summary>
/// Releases the dd resources.
/// </summary>
/// <returns></returns>
void UI::CUINativeStyleWindows10::release_dd_resources() noexcept {
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUINativeStyleWindows10::Recreate() noexcept -> Result {
    this->release_dd_resources();
    Result hr = { Result::RS_OK };
    auto& renderer = UIManager.Ref2DRenderer();
    // HOVER 笔刷
    if (hr) {

    }
    return hr;
}

/// <summary>
/// Draws the button.
/// </summary>
/// <param name="border">The border rect.</param>
/// <param name="state">The state.</param>
/// <param name="opacity">The opacity.</param>
/// <returns></returns>
void UI::CUINativeStyleWindows10::draw_button(
    const RectF& border, StyleState state, float opacity) noexcept {
    // 内沿1逻辑像素
    auto get_rect_in1px = [](const RectF& rect) noexcept {
        return RectF{
            rect.left + 1.f, rect.top + 1.f,
            rect.right - 1.f, rect.bottom - 1.f,
        };
    };
    auto& renderer = UIManager.Ref2DRenderer();
    constexpr auto hover_border     = 0x0078d7ff_rgba;
    constexpr auto hover_backgd     = 0xe5f1fbff_rgba;
    constexpr auto active_border    = 0x005499ff_rgba;
    constexpr auto active_backgd    = 0xcce4f7ff_rgba;
    constexpr auto normal_border    = 0xadadadff_rgba;
    constexpr auto normal_backgd    = 0xe1e1e1ff_rgba;
    constexpr auto default_border   = 0x0078d7ff_rgba;
    constexpr auto disabled_border  = 0xbfbfbfff_rgba;
    constexpr auto disabled_backgd  = 0xccccccff_rgba;
    // 使用数据
    RectF content = get_rect_in1px(border);
    ColorF bdc, bgc;
    // 禁用
    if (state.disabled) {
        bdc = ColorF::FromRGBA_CT<disabled_border>();
        bgc = ColorF::FromRGBA_CT<disabled_backgd>();
    }
    // 按下
    else if (state.active) {
        bdc = ColorF::FromRGBA_CT<active_border>();
        bgc = ColorF::FromRGBA_CT<active_backgd>();
    }
    // 悬浮
    else if (state.hover) {
        bdc = ColorF::FromRGBA_CT<hover_border>();
        bgc = ColorF::FromRGBA_CT<hover_backgd>();
    }
    // 普通
    else {
        bgc = ColorF::FromRGBA_CT<normal_backgd>();
        // 作为默认按钮再缩1逻辑像素
        if (state.default_) {
            content = get_rect_in1px(content);
            bdc = ColorF::FromRGBA_CT<default_border>();
        }
        else bdc = ColorF::FromRGBA_CT<normal_border>();
    }
    // 渲染背景
    renderer.FillRectangle(auto_cast(border), &UIManager.RefCCBrush(bdc));
    renderer.FillRectangle(auto_cast(content), &UIManager.RefCCBrush(bgc));
}