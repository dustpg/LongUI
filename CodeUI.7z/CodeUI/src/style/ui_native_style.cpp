﻿// ui
#include <core/ui_object.h>
#include <core/ui_manager.h>
#include <core/ui_color_list.h>
#include <style/ui_native_style.h>
// c++
#include <cassert>
// windows
#include <Windows.h>
#include <Uxtheme.h>
#include <vssym32.h>


// graphics
#include <graphics/ui_graphics_impl.h>


namespace UI {
    // native theme not support any-scale(?), use hard-code simulate it
#if 0
#pragma comment(lib, "Uxtheme")
    // test code
    void NativeStyle() noexcept {
        if (const auto theme = ::OpenThemeData(nullptr, L"Button")) {
            ID2D1BitmapRenderTarget* target = nullptr;
            ID2D1GdiInteropRenderTarget* gdirt = nullptr;
            D2D1_PIXEL_FORMAT fmt = D2D1::PixelFormat(
                DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED
            );
            D2D1_SIZE_F size{ 512.f, 512.f };
            UIManager.Ref2DRenderer().CreateCompatibleRenderTarget(
                &size,
                nullptr,
                &fmt,
                D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS_GDI_COMPATIBLE,
                &target
            );
            assert(target);
            target->QueryInterface(
                IID_ID2D1GdiInteropRenderTarget,
                (void**)&gdirt
            );
            assert(gdirt && "cannot failed that documented");
            HDC hdc = nullptr;
            target->BeginDraw();
            auto code = gdirt->GetDC(D2D1_DC_INITIALIZE_MODE_CLEAR, &hdc);
            assert(SUCCEEDED(code));
            ::SetGraphicsMode(hdc, GM_ADVANCED);
            XFORM matrix;
            auto bv = ::GetWorldTransform(hdc, &matrix);
            matrix.eM11 = 2.f;
            matrix.eM22 = 2.f;
            reinterpret_cast<D2D1_MATRIX_3X2_F&>(matrix) = 
                D2D1::Matrix3x2F::Scale({ 2.f , 2.f });
            bv = ::SetWorldTransform(hdc, &matrix);
            assert(bv);
            //target->SetTransform(D2D1::Matrix3x2F::Scale({ 2,2 }));
            RECT rect{ 0, 0, 64, 64 };
            assert(SUCCEEDED(code));
            RECT content_rect;
            code = ::DrawThemeBackground(
                theme, hdc, 
                BP_PUSHBUTTON, PBS_NORMAL,
                &rect,
                nullptr
            );
            assert(SUCCEEDED(code));
            code = gdirt->ReleaseDC(nullptr);
            assert(SUCCEEDED(code));
            code = target->EndDraw();
            assert(SUCCEEDED(code));
            ID2D1Bitmap* bitmap = nullptr;
            target->GetBitmap(&bitmap);
            assert(bitmap);
            I::Bitmap* real_bitmap = nullptr;
            bitmap->QueryInterface(IID_ID2D1Bitmap1, (void**)&real_bitmap);
            auto hr = UIManager.SaveAsPng(*real_bitmap, L"test.png");
            assert(hr);
            gdirt->Release();
            bitmap->Release();
            target->Release();
            real_bitmap->Release();
            ::CloseThemeData(theme);
        }
        else assert(!"error");
}
#endif
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="CUIObject" />
    class CUINativeStyle : public CUIObject {

    };
    /// <summary>
    /// win8 native style simulator
    /// </summary>
    class CUINativeStyleWindows8 final : public CUINativeStyle {
        // release device-dependent resources
        void release_dd_resources() noexcept;
        // release all resources
        void release_all_resources() noexcept;
    public:
        // ctor
        CUINativeStyleWindows8() noexcept {}
        // dtor
        ~CUINativeStyleWindows8() noexcept { this->release_all_resources(); }
        // recreate resources
        auto Recreate() noexcept -> Result;
        // draw native
        void DrawNative(const DrawArgs& args) noexcept;
    private:
        // draw button
        void draw_button(const RectF&, StyleState, float opacity) noexcept;
    private:
        // hover brush
        ID2D1LinearGradientBrush*   m_pHoverBrush = nullptr;
        // active brush
        ID2D1LinearGradientBrush*   m_pActiveBrush = nullptr;
        // normal brush
        ID2D1LinearGradientBrush*   m_pNormalBrush = nullptr;
    };
}

PCN_NOINLINE
/// <summary>
/// Draws the native style.
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
void UI::NativeStyleDraw(const DrawArgs& args) noexcept {
    CUINativeStyleWindows8 style;
    style.DrawNative(args);
}

PCN_NOINLINE
/// <summary>
/// Initializes the native style.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <param name="aa">The appearance.</param>
/// <returns></returns>
void UI::NativeStyleInit(UIControl& ctrl, AttributeAppearance aa) noexcept {
    assert(!"NOT IMPLE");
}


/// <summary>
/// Draws the native.
/// </summary>
/// <param name="appearance">The appearance.</param>
/// <param name="state">The state.</param>
/// <param name="opacity">The opacity.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::CUINativeStyleWindows8::DrawNative(const DrawArgs& args) noexcept {
    this->draw_button(args.border, args.state, args.opacity);
}


/// <summary>
/// Releases all resources.
/// </summary>
/// <returns></returns>
void UI::CUINativeStyleWindows8::release_all_resources() noexcept {
    // 释放设备相关资源
    this->release_dd_resources();
    // 释放设备无关资源
}

/// <summary>
/// Releases the dd resources.
/// </summary>
/// <returns></returns>
void UI::CUINativeStyleWindows8::release_dd_resources() noexcept {
    UI::SafeRelease(m_pHoverBrush);
    UI::SafeRelease(m_pActiveBrush);
    UI::SafeRelease(m_pNormalBrush);
}

/// <summary>
/// Recreates this instance.
/// </summary>
/// <returns></returns>
auto UI::CUINativeStyleWindows8::Recreate() noexcept -> Result {
    this->release_dd_resources();
    Result hr = { Result::RS_OK };
    auto& renderer = UIManager.Ref2DRenderer();
    // HOVER 笔刷
    if (hr) {
    }
}

/// <summary>
/// Draws the button.
/// </summary>
/// <param name="rect">The rect.</param>
/// <param name="state">The state.</param>
/// <param name="opacity">The opacity.</param>
/// <returns></returns>
void UI::CUINativeStyleWindows8::draw_button(
    const RectF& rect, StyleState state, float opacity) noexcept {
    /*
    Win8/8.1/10.0.10158之前
    焦点: 0x3399FF 矩形描边 (并且内边有虚线矩形)
    0. 禁用: 0xD9D9D9 矩形描边; 中心 0xEFEFEF
    1. 普通: 0xACACAC 矩形描边; 中心 从上到下0xF0F0F0到0xE5E5E5渐变
    2. 移上: 0x7EB4EA 矩形描边; 中心 从上到下0xECF4FC到0xDCECFC渐变
    3. 按下: 0x569DE5 矩形描边; 中心 从上到下0xDAECFC到0xC4E0FC渐变
    */
    auto& renderer = UIManager.Ref2DRenderer();
    // 禁用
    if (state.disabled) {
        const auto pen = ColorF::FromRGBA_CT<0xd9d9d9ff_rgba>();
        const auto brush = ColorF::FromRGBA_CT<0xefefefff_rgba>();
        renderer.FillRectangle(auto_cast(rect), &UIManager.RefCCBrush(pen));
        renderer.DrawRectangle(auto_cast(rect), &UIManager.RefCCBrush(pen));
        return;
    }
    // 焦点描边色
    const auto focus_pen = ColorF::FromRGBA_CT<0x3399ffff_rgba>();
    // 按下
    if (state.active) {
        const auto pen = ColorF::FromRGBA_CT<0xd569de5ff_rgba>();

    }

}