﻿// ui
#include <core/ui_object.h>
#include <core/ui_manager.h>
#include <style/ui_native_style.h>
// c++
#include <cassert>
// windows
#include <Windows.h>
#include <Uxtheme.h>
#include <vssym32.h>


// graphics
#include <graphics/ui_graphics_impl.h>


namespace UI {
    // native theme not support any-scale(?), use hard-code simulate it
#if 0
#pragma comment(lib, "Uxtheme")
    // test code
    void NativeStyle() noexcept {
        if (const auto theme = ::OpenThemeData(nullptr, L"Button")) {
            ID2D1BitmapRenderTarget* target = nullptr;
            ID2D1GdiInteropRenderTarget* gdirt = nullptr;
            D2D1_PIXEL_FORMAT fmt = D2D1::PixelFormat(
                DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED
            );
            D2D1_SIZE_F size{ 512.f, 512.f };
            UIManager.Ref2DRenderer().CreateCompatibleRenderTarget(
                &size,
                nullptr,
                &fmt,
                D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS_GDI_COMPATIBLE,
                &target
            );
            assert(target);
            target->QueryInterface(
                IID_ID2D1GdiInteropRenderTarget,
                (void**)&gdirt
            );
            assert(gdirt && "cannot failed that documented");
            HDC hdc = nullptr;
            target->BeginDraw();
            auto code = gdirt->GetDC(D2D1_DC_INITIALIZE_MODE_CLEAR, &hdc);
            assert(SUCCEEDED(code));
            ::SetGraphicsMode(hdc, GM_ADVANCED);
            XFORM matrix;
            auto bv = ::GetWorldTransform(hdc, &matrix);
            matrix.eM11 = 2.f;
            matrix.eM22 = 2.f;
            reinterpret_cast<D2D1_MATRIX_3X2_F&>(matrix) = 
                D2D1::Matrix3x2F::Scale({ 2.f , 2.f });
            bv = ::SetWorldTransform(hdc, &matrix);
            assert(bv);
            //target->SetTransform(D2D1::Matrix3x2F::Scale({ 2,2 }));
            RECT rect{ 0, 0, 64, 64 };
            assert(SUCCEEDED(code));
            RECT content_rect;
            code = ::DrawThemeBackground(
                theme, hdc, 
                BP_PUSHBUTTON, PBS_NORMAL,
                &rect,
                nullptr
            );
            assert(SUCCEEDED(code));
            code = gdirt->ReleaseDC(nullptr);
            assert(SUCCEEDED(code));
            code = target->EndDraw();
            assert(SUCCEEDED(code));
            ID2D1Bitmap* bitmap = nullptr;
            target->GetBitmap(&bitmap);
            assert(bitmap);
            I::Bitmap* real_bitmap = nullptr;
            bitmap->QueryInterface(IID_ID2D1Bitmap1, (void**)&real_bitmap);
            auto hr = UIManager.SaveAsPng(*real_bitmap, L"test.png");
            assert(hr);
            gdirt->Release();
            bitmap->Release();
            target->Release();
            real_bitmap->Release();
            ::CloseThemeData(theme);
        }
        else assert(!"error");
}
#endif
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="CUIObject" />
    class CUINativeStyle : public CUIObject {

    };
    /// <summary>
    /// win8 native style simulator
    /// </summary>
    class CUINativeStyleWindows8 final : public CUINativeStyle {
    public:

    };
}

PCN_NOINLINE
/// <summary>
/// Draws the native style.
/// </summary>
/// <param name="appearance">The appearance.</param>
/// <param name="state">The state.</param>
/// <param name="opacity">The opacity.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::NativeStyleDraw(
    AttributeAppearance appearance, 
    StyleState state, 
    float opacity, 
    const RectF& rect) noexcept {
    assert(!"NOT IMPLE");
}

PCN_NOINLINE
/// <summary>
/// Initializes the native style.
/// </summary>
/// <param name="appearance">The appearance.</param>
/// <param name="style">The style.</param>
/// <param name="Box">The box.</param>
/// <returns></returns>
void UI::NativeStyleInit(
    AttributeAppearance appearance, 
    Style & style, 
    Box & Box) noexcept {
    assert(!"NOT IMPLE");
}

/// <summary>
/// Gets the sub element native style.
/// </summary>
/// <param name="sube">The sube.</param>
/// <param name="rect">The rect.</param>
/// <returns></returns>
void UI::NativeStyleAdjustSubElement(SubElement sube, RectF& rect) noexcept {
    assert(!"NOT IMPLE");
}
