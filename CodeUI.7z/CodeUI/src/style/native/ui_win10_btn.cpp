﻿// ui
#include <core/ui_manager.h>
#include <core/ui_color_list.h>
#include <style/ui_native_style.h>
#include <graphics/ui_graphics_impl.h>
// private
#include "../../private/ui_win10_stlye.h"

/// <summary>
/// Draws the button.
/// </summary>
/// <param name="args">The arguments.</param>
/// <returns></returns>
void UI::CUINativeStyleWindows10::draw_button(
    const NativeDrawArgs& args) noexcept {
    // 获取颜色
    ColorF bgcolor1, bdcolor1, bgcolor2, bdcolor2;
    const auto w1 = self::get_button_color(args.from, bdcolor1, bgcolor1);
    const auto w2 = self::get_button_color(args.to  , bdcolor2, bgcolor2);
    const auto bgcolor = UI::Mix(bgcolor1, bgcolor2, args.progress);
    const auto bdcolor = UI::Mix(bdcolor1, bdcolor2, args.progress);
    const auto border_width_half = (w1 + w2) * 0.5f;
    // 边框中心位置
    auto center = args.border;
    center.top += border_width_half;
    center.left += border_width_half;
    center.right -= border_width_half;
    center.bottom -= border_width_half;
    // 渲染器
    auto& renderer = UIManager.Ref2DRenderer();
    // 背景色彩
    renderer.FillRectangle(
        auto_cast(args.border), 
        &UIManager.RefCCBrush(bgcolor)
    );
    // 边框色彩
    renderer.DrawRectangle(
        auto_cast(center), 
        &UIManager.RefCCBrush(bdcolor),
        border_width_half * 2.f
    );
}

/// <summary>
/// Gets the color of the button.
/// </summary>
/// <param name="state">The state.</param>
/// <param name="bd">The bd.</param>
/// <param name="bg">The bg.</param>
/// <returns></returns>
auto UI::CUINativeStyleWindows10::get_button_color(
    StyleState state, ColorF & bd, ColorF & bg) noexcept -> float {
    // 颜色定义
    constexpr auto hover_border     = 0x0078d7ff_rgba;
    constexpr auto hover_backgd     = 0xe5f1fbff_rgba;
    constexpr auto active_border    = 0x005499ff_rgba;
    constexpr auto active_backgd    = 0xcce4f7ff_rgba;
    constexpr auto normal_border    = 0xadadadff_rgba;
    constexpr auto normal_backgd    = 0xe1e1e1ff_rgba;
    constexpr auto default_border   = 0x0078d7ff_rgba;
    constexpr auto disabled_border  = 0xbfbfbfff_rgba;
    constexpr auto disabled_backgd  = 0xccccccff_rgba;
    // 使用数据
    uint32_t bdc, bgc;
    float border_width_half = 0.5f;
    // 禁用
    if (state.disabled) { bdc = disabled_border; bgc = disabled_backgd; }
    // 按下
    else if (state.active) { bdc = active_border; bgc = active_backgd; }
    // 悬浮
    else if (state.hover) { bdc = hover_border; bgc = hover_backgd; }
    // 普通
    else {
        bgc = normal_backgd;
        // 作为默认按钮再缩1逻辑像素
        if (state.default_) {
            border_width_half = 1.f;
            bdc = default_border;
        }
        else bdc = normal_border;
    }
    // 返回数据
    ColorF::FromRGBA_RT(bd, { bdc });
    ColorF::FromRGBA_RT(bg, { bgc });
    return border_width_half;
}

