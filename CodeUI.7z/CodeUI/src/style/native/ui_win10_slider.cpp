﻿// ui
#include <core/ui_manager.h>
#include <core/ui_color_list.h>
#include <style/ui_native_style.h>
#include <graphics/ui_graphics_impl.h>
// private
#include "../../private/ui_win10_stlye.h"

/// <summary>
/// Draws the slider track.
/// </summary>
/// <param name="args">The arguments.</param>
/// <param name="vertical">if set to <c>true</c> [vertical].</param>
/// <returns></returns>
void UI::CUINativeStyleWindows10::draw_slider_track(
    const NativeDrawArgs& args, bool vertical) noexcept {
}

/// <summary>
/// Draws the slider thumb.
/// </summary>
/// <param name="args">The arguments.</param>
/// <param name="vertical">if set to <c>true</c> [vertical].</param>
/// <returns></returns>
void UI::CUINativeStyleWindows10::draw_slider_thumb(
    const NativeDrawArgs & args, bool vertical) noexcept {
}