﻿#include <control/ui_control.h>


/// <summary>
/// private function/data to UIControl
/// </summary>
struct UI::PrivateControl {
    // Pseudo classes hover
    struct PseudoClassesHover {
        static void Set(UIControl& ctrl, bool v) noexcept { ctrl.m_oStyle.state.hover = v; }
        static bool Get(const UIControl& ctrl) noexcept { return ctrl.m_oStyle.state.hover; }
    };
    // Pseudo classes active
    struct PseudoClassesActive {
        static void Set(UIControl& ctrl, bool v) noexcept { ctrl.m_oStyle.state.active = v; }
        static bool Get(const UIControl& ctrl) noexcept { return ctrl.m_oStyle.state.active; }
    };
    // ensure bgc renderer
    static auto EnsureBgcRenderer(UIControl& ctrl) noexcept->CUIRendererBackground*;
    // refresh min size
    static void RefreshMinSize(UIControl& ctrl) noexcept;
    // update world
    static void UpdateWorld(UIControl& ctrl) noexcept;
    // update children level
    static void UpdateLevel(UIControl& ctrl) noexcept;
    // do mouse enter event
    static auto DoMouseEnter(UIControl& ctrl, const Point2F& pos) noexcept->EventAccept;
    // do mouse leave event
    static auto DoMouseLeave(UIControl& ctrl, const Point2F& pos) noexcept->EventAccept;
    // set state
    template<typename State> static void SetState(UIControl&) noexcept;
    // set state
    template<typename State> static void ClearState(UIControl&) noexcept;
    // ----------- INLINE ZONE ----------------
    // add gui event listener
    static bool AddGuiEL(UIControl& ctrl, uintptr_t ownid, GuiEvent e, GuiEventListener&& l) noexcept {
        return ctrl.set_gui_event_listener(e, ownid, std::move(l));
    }
    // remove gui event listener
    static void RemoveGuiEL(UIControl& ctrl, uintptr_t ownid, GuiEvent e) noexcept {
        ctrl.set_gui_event_listener(e, ownid, std::move(*(GuiEventListener*)nullptr));
    }
    // ----------- NORMAL CONTROL CONTROL ----------------

};

