﻿#pragma once

// ui
#include <control/ui_control.h>

// c++
#include <cassert>


/// <summary>
/// private function/data to UIControl
/// </summary>
struct UI::PrivateControl {
    // test if world changed
    static bool TestWorldChanged(UIControl& ctrl) noexcept {
        return ctrl.m_state.world_changed;
    }
    // ensure bgc renderer
    static auto EnsureBgcRenderer(UIControl& ctrl) noexcept->CUIRendererBackground*;
    // refresh min size
    static void RefreshMinSize(UIControl& ctrl) noexcept;
    // update world
    static void UpdateWorld(UIControl& ctrl) noexcept;
    // Synchronous Init Data
    static void SyncInitData(UIControl& ctrl) noexcept;
    // do mouse enter event
    static auto DoMouseEnter(UIControl& ctrl, const Point2F& pos) noexcept->EventAccept;
    // do mouse leave event
    static auto DoMouseLeave(UIControl& ctrl, const Point2F& pos) noexcept->EventAccept;
    // ----------- INLINE ZONE ----------------
    // set focusable
    static void SetFocusable(UIControl& ctrl, bool f) noexcept {
        ctrl.m_state.focusable = f; }
    // set appearance
    static void SetAppearance(UIControl& ctrl, AttributeAppearance a) noexcept {
        ctrl.m_oStyle.appearance = a; }
    // set appearance if not set
    static void SetAppearanceIfNotSet(UIControl& ctrl, AttributeAppearance a) noexcept {
        auto& appearance = ctrl.m_oStyle.appearance;
        if (appearance == Appearance_NotSet) ctrl.m_oStyle.appearance = a; }
    // set flex
    static void SetFlex(UIControl& ctrl, float flex) noexcept {
        ctrl.m_oStyle.flex = flex; }
    // set orient
    static void SetOrient(UIControl& ctrl, bool o) noexcept {
        ctrl.m_state.orient = o; }
    // get parent data
    static auto GetParentData(UIControl& ctrl) noexcept {
        return ctrl.m_uData4Parent; }
    // set parent data
    static auto SetParentData(UIControl& ctrl, uint32_t data) noexcept {
        return ctrl.m_uData4Parent = data; }
    // set gui event to parent
    static void SetGuiEvent2Parent(UIControl& ctrl) noexcept {
        ctrl.m_state.gui_event_to_parent = true; }
    // call add child
    static void CallAddChild(UIControl& ctrl, UIControl& child) noexcept {
        ctrl.add_child(child); }
};
