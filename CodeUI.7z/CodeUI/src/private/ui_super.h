﻿#pragma once

#include <util/ui_unimacro.h>

#if LUI_COMPILER == LUI_COMPILER_MSVC
#define Super __super
#endif
