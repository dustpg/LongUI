﻿#pragma once

#include <core/ui_basic_type.h>

// ui::arg namespace
namespace UI { namespace Arg {
    // arg for create window
    struct Window {
        // title name
        const wchar_t*      title;
        // window rect
        
    };
}}