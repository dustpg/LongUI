﻿#include <graphics/ui_bg_renderer.h>
#include "ui_private_control.h"

#include <algorithm>



PCN_NOINLINE
/// <summary>
/// Ensures the BG-Color renderer.
/// </summary>
/// <param name="">The .</param>
/// <returns></returns>
auto UI::PrivateControl::EnsureBgcRenderer(
    UIControl& ctrl) noexcept ->CUIRendererBackground* {
    // ensure 函数尽量保证不内联
    if (ctrl.m_pBgRender)
        return ctrl.m_pBgRender;
    else
        return ctrl.m_pBgRender = new(std::nothrow) CUIRendererBackground;
}

/// <summary>
/// Updates the level.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::PrivateControl::UpdateLevel(UIControl& ctrl) noexcept {
    for (auto& child : ctrl) {
        child.m_state.level = ctrl.m_state.level + 1;
        assert(child.GetLevel() < 100ui8 && "tree too deep");
        PrivateControl::UpdateLevel(child);
    }
}

/// <summary>
/// Recursives the minimum size of the refresh.
/// </summary>
/// <returns></returns>
void UI::PrivateControl::RefreshMinSize(UIControl& ctrl) noexcept {
    for (auto& child : ctrl) RefreshMinSize(child);
    // 刷新大小
    ctrl.DoEvent(&ctrl, { NoticeEvent::Event_RefreshMinSize });
    // 指定大小作比较
    auto& s = ctrl.m_oStyle;
    s.minsize.width = std::max(s.minsize.width, s.minsize_sp.width);
    s.minsize.height = std::max(s.minsize.height, s.minsize_sp.height);
}

/// <summary>
/// Updates the world.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
void UI::PrivateControl::UpdateWorld(UIControl& ctrl) noexcept {
    // 需要刷新
    if (ctrl.m_state.world_changed) {
        Matrix3X2F matrix;
        // TODO: 根节点
        if (ctrl.IsTopLevel()) {

        }
        // 子节点
        else {
            auto parent = ctrl.GetParent();
            matrix = parent->GetWorld();
            matrix._31 += ctrl.GetPos().x;
            matrix._32 += ctrl.GetPos().y;
            // 固定位置?
            if (ctrl.m_state.attachment == Attachment_Scroll) {
                matrix._31 -= parent->m_ptChildOffset.x;
                matrix._32 -= parent->m_ptChildOffset.y;
            }
            ctrl.m_mtWorld = matrix;
        }
        ctrl.m_state.world_changed = false;
        auto& box = ctrl.m_oBox;
        auto ctrl_rect = ctrl.GetBox().GetBorderEdge();
        ctrl.MapToWindow(ctrl_rect);
        // 检查父控件
        if (!ctrl.IsTopLevel()) {
            auto parent = ctrl.m_pParent;
            auto ctn = parent->GetBox().visible;
            ctrl_rect.top = std::max(ctn.top, ctrl_rect.top);
            ctrl_rect.left = std::max(ctn.left, ctrl_rect.left);
            ctrl_rect.right = std::min(ctn.right, ctrl_rect.right);
            ctrl_rect.bottom = std::min(ctn.bottom, ctrl_rect.bottom);
        }
        box.visible = ctrl_rect;
        // 强行刷新子对象
        for (auto& child : ctrl) {
            child.m_state.world_changed = true;
            PrivateControl::UpdateWorld(child);
        }
        return;
    }
    // 刷新子对象
    for (auto& child : ctrl) PrivateControl::UpdateWorld(child);
}

/// <summary>
/// Does the mouse enter.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
auto UI::PrivateControl::DoMouseEnter(
    UIControl& ctrl, const Point2F& pos) noexcept -> EventAccept {
    return ctrl.DoMouseEvent({ MouseEvent::Event_MouseEnter, 0.f, pos.x, pos.y });
}

/// <summary>
/// Does the mouse enter.
/// </summary>
/// <param name="ctrl">The control.</param>
/// <returns></returns>
auto UI::PrivateControl::DoMouseLeave(
    UIControl& ctrl, const Point2F& pos) noexcept -> EventAccept {
    return ctrl.DoMouseEvent({ MouseEvent::Event_MouseLeave, 0.f, pos.x, pos.y });
}