﻿#include "ui_private_image.h"


/// <summary>
/// Destroys this instance.
/// </summary>
/// <returns></returns>
void UI::CUIImage0::Destroy() noexcept {
    // 什么也不干
}

/// <summary>
/// Creates the image0.
/// </summary>
/// <param name="ptr">The PTR.</param>
/// <returns></returns>
auto UI::CUIImage0::CreateImage0(
    CUISharedResource *& ptr) noexcept -> Result {
    // 默认 64x64 位图
    //CUIImage::MakeError;
    // 默认图片
    return Result();
}