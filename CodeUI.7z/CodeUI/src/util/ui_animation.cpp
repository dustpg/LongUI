﻿#include <cassert>
#include <algorithm>
#include <util/ui_aniamtion.h>


/// <summary>
/// Initializes the specified type.
/// </summary>
/// <param name="type">The type.</param>
/// <returns></returns>
void UI::PODAnimation::Init(AnimationType type) noexcept {
    this->time      = 0.f;
    this->duration  = 0.233f;
    this->type      = type;
    this->count     = 1;
    //this->write     = nullptr;
    this->starts[0] = 0.f;
    this->ends[0]   = 0.f;
}

extern "C" {
    // easing
    double ui_easing_function(uint32_t type, double p);
}

/// <summary>
/// Updates the specified t.
/// </summary>
/// <param name="t">The t.</param>
/// <returns></returns>
void UI::PODAnimation::Update(float t) noexcept {
    assert(!"NOT IMPL");
    float* output = nullptr;
    // 到点
    /*if (this->time <= 0.f) {
        std::memcpy(output, ends, sizeof(float) * count);
        return;
    }
    // 计算
    for (uint32_t i = 0; i < count; ++i) {
        const auto p = static_cast<double>(time / duration);
        const auto v = ui_easing_function(type, p);
        const auto fv = static_cast<float>(v);
        output[i] = fv * (starts[i] - ends[i]) + ends[i];
    }
    // 减少时间
    this->time -= t;*/
}