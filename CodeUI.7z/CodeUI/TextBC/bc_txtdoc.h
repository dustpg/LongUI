﻿#pragma once

#include "bc_txtcell.h"
#include "bc_txtplat.h"
#include "bc_txtline.h"

#include <vector>

// TextBC namespace
namespace TextBC {
    // Dirty rectangles
    using DirtyRects = std::vector<uint32_t[4]>;
    // text document
    class CBCTextDocument {
        // lines_t
        using lines_t = std::vector<TextLineData>;
        // until call
        struct until_call {
            // function ptr
            bool (*func)(void* this_ptr, uint64_t) noexcept;
        };
    protected:
        // find func return value
        struct find_rv {
            // line data
            const TextLineData*     line;
            // cell data
            CBCTextCell*            cell;
            // char count to the cell
            uint32_t                char_count;
            // string len to the cell
            uint32_t                string_len;
        };
    public:
        // ctor
        CBCTextDocument(IBCTextPlatform&) noexcept;
        // dtor
        ~CBCTextDocument();
        // render
        void Render(void* context, DirtyRects*) noexcept;
    public:
        // remove text
        void RemoveText(TextRange) noexcept;
        // insert text
        void InsertText(uint32_t pos, U16View view) noexcept;
        // hit test
        auto HitTest(Point2F) noexcept ->HitTest;
        // set selection
        void SetSelection(uint32_t pos, bool keep_anchor) noexcept;
        // set selection from point
        void SetSelection(Point2F pos, bool keep_anchor) noexcept;
    protected:
        // remove text
        void remove_text(TextRange) noexcept;
        // insert text
        void insert_text(uint32_t pos, U16View view) noexcept;
        // relayout cell
        void relayout_cell(CBCTextCell& cell);
        // sync cache until <T>
        void sync_cache_until(until_call call, uint64_t) noexcept;
        // sync cache to length
        void sync_cache_to_length(uint32_t pos) noexcept;
        // sync cache to offset
        void sync_cache_to_offset(double offset);
        // split cell
        void split_cell(TextLineData& line, CBCTextCell& node, uint32_t pos);
    protected:
        // find cell or after cell or last cell by pos
        auto find_cell_or_la_by_pos(uint32_t pos) const noexcept->find_rv;
        // find last valid cell
        auto find_last_valid_cell() const noexcept->find_rv;
        // set selection
        void set_selection(uint32_t, uint32_t pos) noexcept;
        // update caret rect
        void update_caret_rect() noexcept;
    private:
        // clear hittest cache
        inline void clear_last_hittest() noexcept { m_lastHitTest = nullptr; }
        // cache hittest data
        inline void cache_last_hittest(CBCTextCell* c, uint32_t p) noexcept { m_lastHitTest = c; m_lastHitPos = p; }
        // get absolute position
        inline auto get_abs_pos() const noexcept->uint32_t { return m_uCaretPos + m_uCaretOffset; }
        // valid length
        inline auto cache_valid_length() const noexcept->uint32_t;
        // valid offset
        inline auto cache_valid_offset() const noexcept->double;
        // add line data
        inline auto add_line(TextLineData&, const TextLineData&, CBCTextCell* node) noexcept->CBCTextCell*;
    public:
        // platform
        IBCTextPlatform&    platform;
    protected:
        // text cell head
        Node                m_head = Node{ nullptr, &m_tail };
        // text cell tail
        Node                m_tail = Node{ &m_head, nullptr};
        // total string len
        uint32_t            m_cTotalLen = 0;
        // total char count
        uint32_t            m_cTotalCount = 0;
        // line data
        lines_t             m_lines;
        // valid line count
        uint32_t            m_cValidLine = 0;
        // XXX:caret rect
        RectWHF             m_rcCaret = RectWHF{};
        // anchor positon
        uint32_t            m_uAnchor = 0;
        // caret positon
        uint32_t            m_uCaretPos = 0;
        // caret offset(for trailing)
        uint8_t             m_uCaretOffset = 0;
        // draw caret?
        bool                m_bDrawCaret = false;

        // cached hittest pos
        uint32_t            m_lastHitPos = 0;
        // cached hittest cell
        CBCTextCell*        m_lastHitTest = nullptr;

        // TODO: finish below
        // free list
        CBCTextCell*        m_pFreeList = nullptr;
        // LIMITED BUFFER begin
        Node*               m_pBufferBegin = &m_tail;
        // LIMITED BUFFER end
        Node*               m_pBufferEnd = &m_tail;
        // LIMITED BUFFER max count
        uint32_t            m_cBufferMax = 128;
        // LIMITED BUFFER cell count
        uint32_t            m_cBufferCount = 0;
        // undo/redo stack
        void*               m_pUndoStack = nullptr;
    public:
        enum {
            // init reserve line count
            INIT_RESERVE_LINE = 10,
        };
    };
}
