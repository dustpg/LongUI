﻿#include "bc_txtdoc.h"
#include <cassert>
#include <algorithm>

/// <summary>
/// Initializes a new instance of the <see cref="CBCTextDocument"/> class.
/// </summary>
/// <param name="plat">The plat.</param>
TextBC::CBCTextDocument::CBCTextDocument(IBCTextPlatform& plat) noexcept
    : platform(plat) {
    // 首行空数据
    try {
        m_lines.reserve(INIT_RESERVE_LINE);
        m_lines.push_back({});
        // TODO: 至少有一行
    }
    catch(...){
        assert(!"OOM");
    }


    // 载入测试数据
    try {
        char16_t buf[6];
        memcpy(buf, L"A機x\r\n", sizeof buf);
        // 测试数据
        
        // 首行数据
        const auto a = new CBCTextCell{ *this };
        a->prev = &m_head;
        a->next = m_head.next;
        m_head.next = a;

        a->InsertText(0, { buf , buf + 3 });
        a->MarkAsBOL();
        a->MarkAsEOL();

        memcpy(buf, L"F機x\r\n", sizeof buf);
        auto b = a->NewAfterThis();
        b->InsertText(0, { buf , buf + 3 });
        b->MarkAsBOL();
        b->MarkAsEOL();

        memcpy(buf, L"KLxNO", sizeof buf);
        auto c = b->NewAfterThis();
        c->InsertText(0, { buf , buf + 5 });
        c->MarkAsBOL();

        memcpy(buf, L"P😄ST", sizeof buf);
        auto d = c->NewAfterThis();
        d->InsertText(0, { buf , buf + 5 });

        m_cTotalCount = m_cTotalLen = 20;
        m_lines.resize(4);
        if (false) {
            //this->sync_cache_to_length(6);
            //this->remove_text({ 0, 0 });
            //this->remove_text({ 5, 6 });
            this->remove_text({ 1, 10 });
            //this->remove_text({ 3, 17 });
            auto text = (char16_t*)std::malloc(1024 * sizeof(char16_t));
            text[0] = 0;
            {
                int i = 0;
                for (i = 0; i != 50; ++i) {
                    text[i] = 'a' + i % 26;
                }
                text[i] = 0;
                text[21] = '\r';
                text[22] = '\n';
                const auto len = std::char_traits<char16_t>::length(text);
                this->insert_text(2, { text , text + len });
            }
            std::free(text);
            //reinterpret_cast<TextCell&>(head).insert_new();
        }

    }
    catch (...) {
        assert(!"error");
    }
}

/// <summary>
/// Finalizes an instance of the <see cref="CBCTextDocument"/> class.
/// </summary>
TextBC::CBCTextDocument::~CBCTextDocument() {
    // 释放缓存表
    //assert(m_pFreeList);
    // 一次删除各个节点
    auto node = m_head.next;
    while (node != &m_tail) {
        const auto tmp = static_cast<CBCTextCell*>(node);
        node = tmp->next;
        delete tmp;
    }
}

/// <summary>
/// Renders the specified context.
/// </summary>
/// <param name="context">The context.</param>
/// <param name="rects">The rects.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::Render(void* context, DirtyRects* rects) noexcept {
    rects;
    // TODO: 增量渲染


    // XXX: 整理代码

    if (m_bDrawCaret) this->platform.DrawCaret(context, m_rcCaret);

    // 暂时同步所有数据
    this->sync_cache_to_length(m_cTotalLen);

    auto node = static_cast<CBCTextCell*>(m_head.next);
    float dx = 0, dy = 0;
    // 行数
#ifdef NDEBUG
    auto this_line = m_lines.data() + 1;
#else
    auto this_line = m_lines.begin() + 1;
#endif
    // 遍历所有节点
    while (node != &m_tail) {
        // 尝试创建
        this->relayout_cell(*node);

        const auto ct = node->GetContent();
        // TODO: 基线对齐
        const auto baseoffset = this_line->max_height1 - node->GetBaseLine();
        this->platform.DrawContent(*ct, context,{ dx, dy + baseoffset });

        // 行末尾
        if (node->IsEOL()) {
            dy += this_line->max_height1 + this_line->max_height2;
            ++this_line;
            dx = 0;
        }
        // 行中间
        else {
            dx += node->GetSize().width;
        }
        node = static_cast<CBCTextCell*>(node->next);
    }

}

/// <summary>
/// Clears the specified lastline.
/// </summary>
/// <param name="lastline">The lastline.</param>
/// <returns></returns>
void TextBC::TextLineData::Clear(const TextLineData& lastline) noexcept {
    this->offset = lastline.offset 
        + lastline.max_height1
        + lastline.max_height2
        ;
    this->char_count = lastline.char_count;
    this->string_len = lastline.string_len;
    this->first = this->last = nullptr;
    this->max_height1 = 0.f;
    this->max_height2 = 0.f;
}

/// <summary>
/// Operator+=s the specified cell.
/// </summary>
/// <param name="cell">The cell.</param>
/// <returns></returns>
void TextBC::TextLineData::operator+=(CBCTextCell& cell) noexcept {
    assert(!cell.IsDirty() && "relayout first");
    this->char_count += cell.GetCharCount();
    this->string_len += cell.GetStringLen();
    // 更新高度
    const float height1 = cell.GetBaseLine();
    const float height2 = cell.GetSize().height - cell.GetBaseLine();
    this->max_height1 = std::max(this->max_height1, height1);
    this->max_height2 = std::max(this->max_height2, height2);

    // 行开头
    if (cell.IsBOL()) this->first = &cell;
    // 行结尾或者文本结尾
    if (cell.IsEOL() || cell.IsLastCell()) this->last = &cell;
}

/// <summary>
/// Caches the length of the valid.
/// </summary>
/// <returns></returns>
inline auto TextBC::CBCTextDocument::cache_valid_length() const noexcept -> uint32_t {
    return m_lines[m_cValidLine].string_len;
}

/// <summary>
/// Caches the valid offset.
/// </summary>
/// <returns></returns>
inline auto TextBC::CBCTextDocument::cache_valid_offset() const noexcept -> double {
    return m_lines[m_cValidLine].offset;
}



PCN_NOINLINE
/// <summary>
/// Synchronizes the length of the cache to.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::sync_cache_to_length(uint32_t pos) noexcept {
    // 检查必要性
    if (pos <= this->cache_valid_length()) return;
    // 回调函数
    struct func_t {
        static bool func(void* this_ptr, uint64_t len) noexcept {
            const auto this_ = static_cast<CBCTextDocument*>(this_ptr);
            auto& this_line = this_->m_lines[this_->m_cValidLine];
            return this_line.char_count >= uint32_t(len);
        }
    };
    // 同步数据 
    this->sync_cache_until({ func_t::func }, pos);
}

PCN_NOINLINE
/// <summary>
/// Synchronizes the cache to offset.
/// </summary>
/// <param name="offset">The offset.</param>
void TextBC::CBCTextDocument::sync_cache_to_offset(double offset) {
    // 检查必要性
    if (offset <= cache_valid_offset()) return;
    // union大法好
    union offset_t { uint64_t  len; double offset; };
    offset_t data; data.offset = offset;
    // 回调函数
    struct func_t {
        static bool func(void* this_ptr, uint64_t len) noexcept {
            const auto this_ = static_cast<CBCTextDocument*>(this_ptr);
            offset_t data; data.len = len;
            auto& this_line = this_->m_lines[this_->m_cValidLine];
            const double max_end = this_line.offset 
                + this_line.max_height1
                + this_line.max_height2
                ;
            return max_end >= data.offset;
        }
    };
    // 同步数据 
    this->sync_cache_until({ func_t::func }, data.len);
}


/// <summary>
/// Adds the line.
/// </summary>
/// <param name="this_line">The this line.</param>
/// <param name="last_line">The last line.</param>
/// <param name="node">The node.</param>
/// <returns></returns>
inline auto TextBC::CBCTextDocument::add_line(
    TextLineData& this_line, 
    const TextLineData& last_line, 
    CBCTextCell * node) noexcept -> CBCTextCell * {
    // 继承上一行数据
    this_line.Clear(last_line);
    do {
        // 尝试重新布局文本节点
        this->relayout_cell(*node);
        // 添加节点到改行
        this_line += *node;
        // 推进节点
        node = static_cast<CBCTextCell*>(node->next);
        // 遍历到行尾就退出
    } while (!this_line.last);
    // 返回下一行的首节点
    return node;
}

/// <summary>
/// Relayouts the cell.
/// </summary>
/// <param name="cell">The cell.</param>
void TextBC::CBCTextDocument::relayout_cell(CBCTextCell& cell) {
    // 只有脏节点需要重新布局
    if (!cell.IsDirty()) return;
    cell.BeginLayout();

    // TODO: 完成格式化
    // format(cell);

    cell.EndLayout();
}

PCN_NOINLINE
/// <summary>
/// Synchronizes the cache until X ??.
/// </summary>
/// <param name="this_ptr">The this PTR.</param>
/// <param name="arg">The argument.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::sync_cache_until(until_call call, uint64_t arg) noexcept {
    // 空数据...
    if (m_lines.size() <= 1) return;
    assert(m_cValidLine <= m_lines.size() && "bug");
    const auto itr = m_lines.data() + m_cValidLine;
    // 获取有效的首节点
    auto node = static_cast<CBCTextCell*>(m_head.next);
    if (m_cValidLine) node = static_cast<CBCTextCell*>(itr->last->next);
    // 遍历上限
    const uint32_t len = static_cast<uint32_t>(m_lines.size()) - m_cValidLine - 1;
    //float offset_height = 0;
    // 遍历次数
    for (uint32_t i = 0; i != len; ++i) {
        auto& last_line = itr[i];
        auto& this_line = itr[i + 1];
        node = this->add_line(this_line, last_line, node);
        ++m_cValidLine;
        if (call.func(this, arg)) break;
    }
}

/// <summary>
/// Inserts the text.
/// </summary>
/// <param name="pos">The position.</param>
/// <param name="view">The view.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::InsertText(uint32_t pos, U16View view) noexcept {
    const auto total_string_len = m_cTotalLen;
    // 范围断言
    assert(pos <= total_string_len && "out of range");
    // 插入位置超过范围
    if (pos <= total_string_len) this->insert_text(pos, view);
}

// TODO: 移除
namespace TextBC {
    // is_surrogate
    inline bool IsSurrogate(uint16_t ch) noexcept { return ((ch) & 0xF800) == 0xD800; }
    // is_low_surrogate
    inline bool IsLowSurrogate(uint16_t ch) noexcept { return ((ch) & 0xFC00) == 0xDC00; }
    // is_high_surrogate
    inline bool IsHighSurrogate(uint16_t ch) noexcept { return ((ch) & 0xFC00) == 0xD800; }
}

// ui::detail
namespace TextBC { namespace detail {
    // get a nicepair
    U16View nice_view(uint32_t max, U16View view) noexcept {
        U16View rv = { view.first, view.first };
        max = std::min(max, uint32_t(view.second - view.first));
        while (max--) if (*rv.second == '\n') break; else ++rv.second;
        if (rv.second < view.second && IsLowSurrogate(*rv.second)) ++rv.second;
        assert(IsLowSurrogate(*rv.second) == false);
        return rv;
    }
} }

/// <summary>
/// Inserts the text.
/// </summary>
/// <param name="pos">The position.</param>
/// <param name="view">The view.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::insert_text(uint32_t pos, U16View view) noexcept {
    // 范围断言
    assert(pos <= m_cTotalLen && "out of range");
    // 上次点击测试缓存失效
    this->clear_last_hittest();
    // 同步有效长度
    this->sync_cache_to_length(pos);
    // 插入偏移量
    int insert_offset = 0;
    CBCTextCell* node = nullptr;
    const auto insert_len = uint32_t(view.second - view.first);
    TextLineData* line_data = m_lines.data() + 1;
    // 插入之后的位置
    if (pos) {
        // 查找范围首节点
        const auto rv = this->find_cell_or_la_by_pos(pos);
        // 更新有效行
        const auto lineno = static_cast<uint32_t>(rv.line - m_lines.data());
        // 更新有效缓存行
        m_cValidLine = lineno - 1;
        // 插入偏移
        insert_offset = rv.cell->GetStringLen() + pos - rv.string_len;
        // 对应数据
        node = rv.cell;
        // 可以通过rv.line获取index(lineno)再访问该行
        // 以避免const_cast...不过无所谓了
        line_data = const_cast<TextLineData*>(rv.line);
    }
    // 插入第一个位置
    else {
        m_cValidLine = 0;
        insert_offset = 0;
        node = static_cast<CBCTextCell*>(m_head.next);
    }
    // 分裂首个节点
    {
        if (insert_len + node->GetStringLen() > TEXT_CELL_NICE_LENGTH) {
            this->split_cell(*line_data, *node, insert_offset);
        }
    }
    // 循环待使用数据
    bool newline = false;
    uint32_t line_insert = 0;
#ifndef NDEBUG
    int loop_count_dbg = 0;
#endif
    // 获取合适的串范围
    while (true) {
#ifndef NDEBUG
        ++loop_count_dbg;
#endif
        const auto nicelen = TEXT_CELL_NICE_LENGTH - node->GetStringLen();
        const U16View now = detail::nice_view(nicelen, view);
        // 检查是否插入完毕
        // 有效情况下
        if (now.second != now.first) {
            view.first = now.second;
            // 插入字符串
            node->InsertText(insert_offset, now);
            // 检查是否起行
            if (newline) {
                node->MarkAsBOL();
                newline = false;
            }
            // 之后的字符串插入0
            insert_offset = 0;
            // 字符串用完
            if (view.first == view.second) break;
            // 检查是否换行
            if (*now.second == '\n') {
                node->MarkAsEOL();
                newline = true;
                ++line_insert;
                view.first++;
            }
        }
        // TODO: 错误处理
        node = node->NewAfterThis();
    }
    // 行
    m_lines.resize(m_lines.size() + line_insert);
    // TODO: 字符数量插入时候可能插入[\r\n \n]
    m_cTotalLen += insert_len;
    // TODO: 字符数量
    m_cTotalCount += insert_len;
    // TODO: 尝试合并插入末的两端节点
}

/// <summary>
/// Removes the text.
/// </summary>
/// <param name="range">The range.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::RemoveText(TextRange range) noexcept {
    assert(range.length && "cannot remove 0 char");
    const uint32_t endpos = range.pos + range.length;
    assert(range.pos < m_cTotalLen && "out of range");
    assert(endpos <= m_cTotalLen && "out of range");
    // 删除位置超过范围
    if (range.pos > m_cTotalLen) return;
    // 修正长度
    range.length = std::min(endpos, m_cTotalLen) - range.pos;
    // 正式执行
    this->remove_text(range);
}

/// <summary>
/// Removes the text.
/// </summary>
/// <param name="range">The range.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::remove_text(TextRange range) noexcept {
    assert(range.length && "cannot remove 0 char");
    const uint32_t endpos = range.pos + range.length;
    assert(range.pos < m_cTotalLen && "out of range");
    assert(endpos <= m_cTotalLen && "out of range");
    // 上次点击测试缓存失效
    this->clear_last_hittest();
    // 同步有效长度
    this->sync_cache_to_length(endpos);
    // 查找范围首节点
    const auto rv = this->find_cell_or_la_by_pos(range.pos);
    // 记录当前行数
    const auto lineno = static_cast<uint32_t>(rv.line - m_lines.data());
    // 更新有效缓存行
    m_cValidLine = lineno - 1;
    // 删除首节点文本
    const auto start_length = rv.string_len - static_cast<uint32_t>(rv.cell->GetStringLen());
    uint32_t max2remove = rv.string_len - range.pos;
    auto remain_len = range.length;
    auto offset_pos = range.pos - start_length;
    auto node = rv.cell;
    uint32_t line_removed = 0;
    // 直到删完
    while (true) {
        const auto this_node = node;
        node = static_cast<CBCTextCell*>(node->next);
        // 检查是否为行开始
        const auto linestart = this_node->IsBOL();
        // 准备删除的数控
        const auto removed = std::min(max2remove, remain_len);
        // 删除并检查是否删除行
        line_removed += this_node->RemoveText({ offset_pos, removed });
        // 调整下次使用数据
        remain_len -= removed; offset_pos = 0;
        // 没得删了?
        if (!remain_len) break;
        // 节点删除 + 删除行?
        if (linestart && node->prev != this_node) {
            //node->beginofline = true;
            node->MarkAsBOL();
        }
        // 获取下次最大删除数量
        max2remove = node->GetStringLen();
    }
    assert(line_removed <= m_lines.size());
    m_lines.resize(m_lines.size() - line_removed);
    // TODO: 删除一半双字字符
    m_cTotalLen -= range.length;
    // TODO: 字符数量
    m_cTotalCount -= range.length;
    // TODO: 尝试合并删除点两侧节点
}


/// <summary>
/// Finds the cell or la by position.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
auto TextBC::CBCTextDocument::find_cell_or_la_by_pos(uint32_t pos) const noexcept ->find_rv {
    // 最后一个有效字符
    if (pos == this->cache_valid_length())
        return this->find_last_valid_cell();
    // 范围断言
    assert(pos <= cache_valid_length() && "out of range");
    // 二分查找区间
    const auto b = m_lines.begin();
    const auto e = m_lines.begin() + m_cValidLine + 1;
    // 二分查找到行
    auto itr = std::lower_bound(b, e, pos, [](const TextLineData& data, uint32_t pos) {
        return data.string_len <= pos;
    });
    // 结果断言
    assert(itr != e && "not found");
    // 数据处理
    auto node = itr->first;
    auto length = itr[-1].string_len;
    auto count = itr[-1].char_count;
    // 行内定位到节点
    while (true) {
        length += node->GetStringLen();
        count += node->GetCharCount();
        if (length > pos) break;
        node = static_cast<CBCTextCell*>(node->next);
    }
    return{ &*itr, node, count, length };
}

/// <summary>
/// Finds the last valid cell.
/// </summary>
/// <returns></returns>
auto TextBC::CBCTextDocument::find_last_valid_cell() const noexcept -> find_rv {
    auto& line = m_lines[m_cValidLine];
    const auto cell = line.last;
    return{ &line, cell, line.char_count, line.string_len };
}

/// <summary>
/// Splits the cell.
/// </summary>
/// <param name="line">The line.</param>
/// <param name="node">The node.</param>
/// <param name="pos">The position.</param>
void TextBC::CBCTextDocument::split_cell(TextLineData& line, 
    CBCTextCell& node, uint32_t pos) {
    // 长度为0不考虑
    //assert(pos != node.string_len() && "UNTESTED");
    // 在尾分裂则不考虑
    if (pos != node.GetStringLen()) {
        const auto created = node.NewAfterThis();
        const auto raw_string = node.GetStringPtr();
        const auto endlen = static_cast<uint32_t>(node.GetStringLen());
        created->InsertText(0, { raw_string + pos, raw_string + endlen });
        node.RemoveTextOnly({ pos, endlen - pos });
        // 插入行尾节点检查
        if (line.last == &node) {
            line.last = created;
            node.MoveEOL2Next();
        }
    }
}


/// <summary>
/// Hits the test.
/// </summary>
/// <param name="pos">The position.</param>
/// <returns></returns>
auto TextBC::CBCTextDocument::HitTest(Point2F pos) noexcept -> TextBC::HitTest {
    // XXX: 固定行距优化
    //if(richtext())
    // 同步到指定行
    const double scrollx = 0, scrolly = 0;
    const double offy = scrolly + double(pos.y);
    this->sync_cache_to_offset(offy);
    // 二分查找到行
    const auto b = m_lines.begin();
    const auto e = m_lines.begin() + m_cValidLine + 1;
    const auto itr = std::lower_bound(b, e, offy, [](const TextLineData& data, double y) {
        return data.offset + data.max_height1 + data.max_height2 <= y;
    });
    //assert(itr != e && "not found");
    if (itr == e) return{ m_cTotalLen , false };
    // 顺序遍历使用数据
    auto string_len = itr[-1].string_len;
    auto node = itr->first;
    const auto last = itr->last;
    float offx = float(scrollx) + pos.x;
    float xadded = 0.0;
    const auto yadded = itr->offset;
    // 顺序遍历到指定节点
    while (true) {
        const auto node_size_width = node->GetSize().width;
        if (node == last || offx < node_size_width) break;
        offx -= node_size_width;
        xadded += node_size_width;
        string_len += node->GetStringLen();
        node = static_cast<CBCTextCell*>(node->next);
    }
    // 节点
    union { TextBC::HitTest ht; float pos; } hittest_v;
    hittest_v.pos = offx;
    const auto ct = node->GetContent();
    this->platform.ContentEvent(*ct, platform.Event_HitTest, &hittest_v);
    // 结果
    const auto rva = hittest_v.ht.pos;
    const auto rvb = hittest_v.ht.u16_trailing;
    // 保存缓存节点
    this->cache_last_hittest(node, string_len + rva + rvb);
    // 字符位置
    return{ string_len + rva, rvb };
}


// richtb::impl namespace
namespace TextBC { namespace impl {
    // selection mode
    enum selection_mode : uint32_t {
        mode_all= 0,
        mode_leading,
        mode_trailing,
        mode_up,
        mode_down,
        mode_left,
        mode_right,
        mode_home,
        mode_end,
        mode_first,
        mode_last,
        mode_leftchar,
        mode_rightchar,
        mode_leftword,
        mode_rightword,
    };
    // selection flag
    enum selection_flag : uint32_t {
        flag_keepanchor = 16,
    };
}}


/// <summary>
/// Sets the selection.
/// </summary>
/// <param name="pos">The position.</param>
/// <param name="keep_anchor">if set to <c>true</c> [keep anchor].</param>
/// <returns></returns>
void TextBC::CBCTextDocument::SetSelection(uint32_t pos, bool keep_anchor) noexcept {
    assert((keep_anchor & 1) == keep_anchor && "bad bool");
    const auto mode = impl::mode_leading;
    const auto flag = uint32_t(keep_anchor) << impl::flag_keepanchor;
    this->set_selection(mode | flag, pos);
}

/// <summary>
/// Sets the selection from point.
/// </summary>
/// <param name="pos">The position.</param>
/// <param name="keep_anchor">if set to <c>true</c> [keep anchor].</param>
/// <returns></returns>
void TextBC::CBCTextDocument::SetSelection(Point2F pos, bool keep_anchor) noexcept {
    assert((keep_anchor & 1) == keep_anchor && "bad bool");
    const auto ht = this->HitTest(pos);
    const auto mode = impl::mode_leading;
    const auto flag = uint32_t(keep_anchor) << impl::flag_keepanchor;
    this->set_selection(mode | flag, ht.pos);
}


/// <summary>
/// Sets the selection.
/// </summary>
/// <param name="mode_flag">The mode flag.</param>
/// <returns></returns>
void TextBC::CBCTextDocument::set_selection(
    uint32_t mode_flag,
    uint32_t pos) noexcept {
    // 记录旧数据
    const auto anchor_old = m_uAnchor;
    const auto abspos_old = this->get_abs_pos();
    switch (static_cast<impl::selection_mode>(mode_flag & 0xffffu))
    {
    case impl::mode_all:
        break;
    case impl::mode_leading:
        m_uCaretPos = pos;
        m_uCaretOffset = 0;
        break;
    case impl::mode_trailing:
        break;
    case impl::mode_up:
        break;
    case impl::mode_down:
        break;
    case impl::mode_left:
        break;
    case impl::mode_right:
        break;
    case impl::mode_home:
        break;
    case impl::mode_end:
        break;
    case impl::mode_first:
        break;
    case impl::mode_last:
        break;
    case impl::mode_leftchar:
        break;
    case impl::mode_rightchar:
        break;
    case impl::mode_leftword:
        break;
    case impl::mode_rightword:
        break;
    }
    // 当前位置
    const auto abspos_now = this->get_abs_pos();
    // 不保留上次锚点
    if (!(mode_flag & impl::flag_keepanchor)) m_uAnchor = abspos_now;
    // 移动了?
    if (abspos_now != abspos_old || m_uAnchor != abspos_old) {
        this->update_caret_rect();
        this->platform.NeedRedraw();
    }
}


/// <summary>
/// Updates the caret rect.
/// </summary>
/// <returns></returns>
void TextBC::CBCTextDocument::update_caret_rect() noexcept {
    assert(m_lastHitTest);
    float xadded = 0;
    float yadded = 0;
    union { uint32_t pos; CharMetrics cm; } cm_data;
    const auto node = m_lastHitTest;
    const auto ct = node->GetContent();
    cm_data.pos = this->get_abs_pos();
    this->platform.ContentEvent(*ct, platform.Event_CharMetrics, &cm_data);
    m_rcCaret.x = cm_data.cm.x + xadded;
    m_rcCaret.width = cm_data.cm.width;
    // XXX: 相对偏移
    m_rcCaret.y = static_cast<float>(yadded);
    m_rcCaret.height = node->GetSize().height;
    m_bDrawCaret = true;
}