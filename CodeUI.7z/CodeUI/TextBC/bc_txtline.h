﻿#pragma once

#include <cstdint>

// TextBC namespace
namespace TextBC {
    // text cell
    class CBCTextCell;
    // text line data
    struct TextLineData {
        // y offset
        double          offset;
        // first cell
        CBCTextCell*    first;
        // last cell
        CBCTextCell*    last;
        // char count to here
        uint32_t        char_count;
        // string len to here
        uint32_t        string_len;
        // max height above baseline
        float           max_height1;
        // max height under baseline
        float           max_height2;
        // TODO: max_height1-> max_baseline  max_height2 -> max_height

        // clear line data
        void Clear(const TextLineData& lastline) noexcept;
        // add cell
        void operator +=(CBCTextCell&) noexcept;
    };
    
}