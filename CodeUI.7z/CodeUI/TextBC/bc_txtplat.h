﻿#pragma once


#ifndef PCN_NOVTABLE
#define PCN_NOVTABLE _declspec(novtable)
#endif

#ifndef PCN_NOINLINE
#define PCN_NOINLINE _declspec(noinline)
#endif

#if _MSC_VER < 1900
#define noexcept throw()
#endif

#include <cstdint>

// richtb namespace
namespace TextBC {
    struct Node { Node* prev, *next; };
    struct SizeF { float width, height; };
    struct Point2F { float x, y; };
    struct HitTest { uint32_t pos; uint32_t u16_trailing; };
    struct RectWHF { float x, y, width, height; };
    struct U16View { const char16_t* first, *second; };
    struct CharMetrics { float x, width; };
    struct CBCSmallObject {};
    using Result = long;
}

// richtb namespace
namespace TextBC {
    // text content
    struct IBCTextContent;
    // text platform
    struct PCN_NOVTABLE IBCTextPlatform {
        // metrics event
        enum MetricsEvent : uint32_t {
            // get size.            arg: [out]<SizeF*>
            Event_GetSize = 0,
            // get baseline.        arg: [out]<float*>
            Event_GetBaseline,
            // hit test             arg: [out]<HitTest*>        [in]<float*> 
            Event_HitTest,
            // char metrics         arg: [out]<CharMetrics*>    [in]<uint32_t*> 
            Event_CharMetrics,
        };
        // need redraw
        virtual void NeedRedraw() noexcept = 0;
        // draw caret, TODO: set caret rect
        virtual void DrawCaret(void* ctx, const RectWHF& rect) noexcept = 0;
        // delete content
        virtual void DeleteContent(IBCTextContent&) noexcept = 0;
        // draw content
        virtual void DrawContent(IBCTextContent&, void* ctx, Point2F pos) noexcept = 0;
        // content metrics event
        virtual void ContentEvent(IBCTextContent&, MetricsEvent, void*) noexcept = 0;
        // create content
        virtual auto CreateContent(
            const char16_t*, 
            uint32_t len, 
            IBCTextContent&& old /* maybe null */
        ) noexcept->IBCTextContent* = 0;
    };
}