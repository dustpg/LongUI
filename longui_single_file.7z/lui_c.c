﻿
#define LUI_COMPILER_UNK    0
#define LUI_COMPILER_GCC    1
#define LUI_COMPILER_MSVC   2
#define LUI_COMPILER_CLANG  3


#if defined(__clang__)
#define LUI_COMPILER LUI_COMPILER_CLANG
#elif defined(__GNUC__) || defined(__GNUG__)
#define LUI_COMPILER LUI_COMPILER_GCC
#elif defined(_MSC_VER)
#define LUI_COMPILER LUI_COMPILER_MSVC
#else
#define LUI_COMPILER LUI_COMPILER_UNK
#endif


#if (LUI_COMPILER == LUI_COMPILER_MSVC)
#if _MSC_VER < 1900
#ifdef __cplusplus
#define noexcept
#define constexpr const
#define alignas(x)
#define alignof(x) sizeof(void*)
#endif
#define __restrict
#endif
#endif

#define UNICALL __stdcall
#define luiref

#ifndef PCN_NOINLINE

#if  LUI_COMPILER == LUI_COMPILER_MSVC
#define PCN_NOINLINE __declspec(noinline)
#define PCN_NOVTABLE __declspec(novtable)
#define PCN_DLLEXPRT
#else
#define PCN_NOINLINE __attribute__((noinline))
#define PCN_NOVTABLE
#define PCN_DLLEXPRT
#endif

#define PCN_DLL_PUBLIC  PCN_DLLEXPRT
#define PCN_DLL_PROTECT

#endif
#include <stdint.h>
#include <assert.h>

// HSVA
typedef struct {
    float h;       // ∈ [0, 360]
    float s;       // ∈ [0, 1]
    float v;       // ∈ [0, 1]
    float a;       // ∈ [0, 1]
} hsva_t;

// HSLA
typedef struct {
    float h;       // ∈ [0, 360]
    float s;       // ∈ [0, 1]
    float l;       // ∈ [0, 1]
    float a;       // ∈ [0, 1]
} hsla_t;

// RGBA
typedef struct {
    float r;       // ∈ [0, 1]
    float g;       // ∈ [0, 1]
    float b;       // ∈ [0, 1]
    float a;       // ∈ [0, 1]
} rgba_t;

PCN_NOINLINE
/// <summary>
/// UIs the function HSL to RGB float32.
/// </summary>
/// <param name="data">The data.</param>
void ui_function_hsla_to_rgba_float32(const float hsla[4], float rgba[4]) {
    // 将A弄过去
    rgba[3] = hsla[3];
    // 准备数据
    const float h = hsla[0];
    assert(0.f <= h && h < 360.f && "out of range");
    const float s = hsla[1];
    const float l = hsla[2];
    float *r = rgba + 0;
    float *g = rgba + 1;
    float *b = rgba + 2;
    // Q
    const float v = (l <= 0.5f) ? (l * (1.0f + s)) : (l + s - l * s);
    // 黑色
    if (v <= 0.0f) {
        *r = *g = *b = 0.f;
    }
    // 其他
    else {
        const float m = l + l - v;
        const float sv = (v - m) / v;
        const int sextant = (int)(h / 60.0f);
        const float fract = h / 60.0f - sextant;
        const float vsf = v * sv * fract;
        const float mid1 = m + vsf;
        const float  mid2 = v - vsf;
        switch (sextant) {
        case 0: *r = v; *g = mid1; *b = m; break;
        case 1: *r = mid2; *g = v; *b = m; break;
        case 2: *r = m; *g = v; *b = mid1; break;
        case 3: *r = m; *g = mid2; *b = v; break;
        case 4: *r = mid1; *g = m; *b = v; break;
        case 5: *r = v; *g = m; *b = mid2; break;
        }
    }
}
// easing
#include <stdint.h>
#include <assert.h>
#include <math.h>

#define EASING_PI (3.14159265358979323846)
#define EASINGPI2 (EASING_PI / 2.0)

/// <summary>
/// Implementations the bounce ease out.
/// </summary>
/// <param name="p">The p.</param>
/// <returns></returns>
static double impl_bounce_ease_out(double p) {
    if (p < 4.0 / 11.0) {
        return (121.0 * p * p) / 16.0;
    }
    else if (p < 8.0 / 11.0) {
        return (363.0 / 40.0 * p * p) - (99.0 / 10.0 * p) + 17.0 / 5.0;
    }
    else if (p < 9.0 / 10.0) {
        return (4356.0 / 361.0 * p * p) - (35442.0 / 1805.0 * p) + 16061.0 / 1805.0;
    }
    else {
        return (54.0 / 5.0 * p * p) - (513.0 / 25.0 * p) + 268.0 / 25.0;
    }
}

// the type of aniamtion
enum ui_impl_animation_type {
    // #1
    ui_impl_linear = 0,
    // #2
    ui_impl_quad_ease_in,
    ui_impl_quad_ease_out,
    ui_impl_quad_ease_inout,
    // #3
    ui_impl_cubi_ease_in,
    ui_impl_cubi_ease_out,
    ui_impl_cubi_ease_inout,
    // #4
    ui_impl_quar_ease_in,
    ui_impl_quar_ease_out,
    ui_impl_quar_ease_inout,
    // #5
    ui_impl_quin_ease_in,
    ui_impl_quin_ease_out,
    ui_impl_quin_ease_inout,
    // #sin
    ui_impl_sine_ease_in,
    ui_impl_sine_ease_out,
    ui_impl_sine_ease_inout,
    // #circle
    ui_impl_circ_ease_in,
    ui_impl_circ_ease_out,
    ui_impl_circ_ease_inout,
    // #exp
    ui_impl_expo_ease_in,
    ui_impl_expo_ease_out,
    ui_impl_expo_ease_inout,
    // #elastic
    ui_impl_elas_ease_in,
    ui_impl_elas_ease_out,
    ui_impl_elas_ease_inout,
    // #back
    ui_impl_back_ease_in,
    ui_impl_back_ease_out,
    ui_impl_back_ease_inout,
    // #bounce
    ui_impl_boun_ease_in,
    ui_impl_boun_ease_out,
    ui_impl_boun_ease_inout,
};

/// <summary>
/// UIs the easing function.
/// </summary>
/// <param name="type">The type.</param>
/// <param name="p">The p.</param>
/// <returns></returns>
double ui_easing_function(uint32_t type, double p) {
    assert((p >= 0.0 && p <= 1.0) && "bad argument");
    switch (type)
    {
    default:
        assert(!"type unknown");
    case ui_impl_linear:
        // 线性插值     f(x) = x
        return p;
    case ui_impl_quad_ease_in:
        // 平次渐入     f(x) = x^2
        return p * p;
    case ui_impl_quad_ease_out:
        // 平次渐出     f(x) =  -x^2 + 2x
        return -(p * (p - 2.0));
    case ui_impl_quad_ease_inout:
        // 平次出入
        // [0, 0.5)     f(x) = (1/2)((2x)^2)
        // [0.5, 1.0]   f(x) = -(1/2)((2x-1)*(2x-3)-1) ; 
        return p < 0.5 ? (p * p * 2.0) : ((-2.0 * p * p) + (4.0 * p) - 1.0);
    case ui_impl_cubi_ease_in:
        // 立次渐入     f(x) = x^3;
        return p * p * p;
    case ui_impl_cubi_ease_out:
        // 立次渐出     f(x) = (x - 1)^3 + 1
    {
        double f = p - 1.0;
        return f * f * f + 1.0;
    }
    case ui_impl_cubi_ease_inout:
        // 立次出入
        // [0, 0.5)     f(x) = (1/2)((2x)^3) 
        // [0.5, 1.0]   f(x) = (1/2)((2x-2)^3 + 2) 
        if (p < 0.5) {
            return p * p * p * 2.0;
        }
        else {
            double f = (2.0 * p) - 2.0;
            return 0.5 * f * f * f + 1.0;
        }
    case ui_impl_quar_ease_in:
        // 四次渐入     f(x) = x^4
        return  p * p *  p * p;
    case ui_impl_quar_ease_out:
        // 四次渐出     f(x) = 1 - (x - 1)^4
    {
        double f = (p - 1.0); f *= f;
        return 1.0 - f * f;
    }
    case ui_impl_quar_ease_inout:
        // 四次出入
        // [0, 0.5)     f(x) = (1/2)((2x)^4)
        // [0.5, 1.0]   f(x) = -(1/2)((2x-2)^4 - 2)
        if (p < 0.5) {
            double f = p * p;
            return 8.0 * f * f;
        }
        else {
            double f = (p - 1.0); f *= f;
            return 1.0 - 8.0 * f * f;
        }
    case ui_impl_quin_ease_in:
        // 五次渐入     f(x) = x^5
    {
        double f = p * p;
        return f * f * p;
    }
    case ui_impl_quin_ease_out:
        // 五次渐出     f(x) = (x - 1)^5 + 1
    {
        double f = (p - 1.0);
        return f * f * f * f * f + 1.0;
    }
    case ui_impl_quin_ease_inout:
        // 五次出入
        // [0, 0.5)     f(x) = (1/2)((2x)^5) 
        // [0.5, 1.0]   f(x) = (1/2)((2x-2)^5 + 2)
        if (p < 0.5) {
            double f = p * p;
            return 16.0 * f * f * p;
        }
        else {
            double f = ((2.0 * p) - 2.0);
            return  f * f * f * f * f * 0.5 + 1.0;
        }
    case ui_impl_sine_ease_in:
        // 正弦渐入     
        return sin((p - 1.0) * EASINGPI2) + 1.0;
    case ui_impl_sine_ease_out:
        // 正弦渐出     
        return sin(p * EASINGPI2);
    case ui_impl_sine_ease_inout:
        // 正弦出入     
        return 0.5 * (1.0 - cos(p * EASING_PI));
    case ui_impl_circ_ease_in:
        // 四象圆弧
        return 1.0 - sqrt(1.0 - (p * p));
    case ui_impl_circ_ease_out:
        // 二象圆弧
        return sqrt((2.0 - p) * p);
    case ui_impl_circ_ease_inout:
        // 圆弧出入
        if (p < 0.5) {
            return 0.5 * (1.0 - sqrt(1.0 - 4.0 * (p * p)));
        }
        else {
            return 0.5 * (sqrt(-((2.0 * p) - 3.0) * ((2.0 * p) - 1.0)) + 1.0);
        }
    case ui_impl_expo_ease_in:
        // 指数渐入     f(x) = 2^(10(x - 1))
        return (p == 0.0) ? (p) : (pow(2.0, 10.0 * (p - 1.0)));
    case ui_impl_expo_ease_out:
        // 指数渐出     f(x) =  -2^(-10x) + 1
        return (p == 1.0) ? (p) : (1.0 - pow(2.0, -10.0 * p));
    case ui_impl_expo_ease_inout:
        // 指数出入
        // [0,0.5)      f(x) = (1/2)2^(10(2x - 1)) 
        // [0.5,1.0]    f(x) = -(1/2)*2^(-10(2x - 1))) + 1 
        if (p == 0.0 || p == 1.0) return p;
        if (p < 0.5) {
            return 0.5 * pow(2.0, (20.0 * p) - 10.0);
        }
        else {
            return -0.5 * pow(2.0, (-20.0 * p) + 1.0) + 1.0;
        }
    case ui_impl_elas_ease_in:
        // 弹性渐入
        return sin(13.0 * EASINGPI2 * p) * pow(2.0, 10.0 * (p - 1.0));
    case ui_impl_elas_ease_out:
        // 弹性渐出
        return sin(-13.0 * EASINGPI2 * (p + 1.0)) * pow(2.0, -10.0 * p) + 1.0;
    case ui_impl_elas_ease_inout:
        // 弹性出入
        if (p < 0.5) {
            return 0.5 * sin(13.0 * EASINGPI2 * (2.0 * p)) *pow(2.0, 10.0 * ((2.0 * p) - 1.0));
        }
        else {
            return 0.5 * (sin(-13.0 * EASINGPI2 * ((2.0 * p - 1.0) + 1.0)) * pow(2.0, -10.0 * (2.0 * p - 1.0)) + 2.0);
        }
    case ui_impl_back_ease_in:
        // 回退渐入
        return  p * p * p - p * sin(p * EASING_PI);
    case ui_impl_back_ease_out:
        // 回退渐出
    {
        double f = (1.0 - p);
        return 1.0 - (f * f * f - f * sin(f * EASING_PI));
    }
    case ui_impl_back_ease_inout:
        // 回退出入
        if (p < 0.5) {
            double f = 2.0 * p;
            return 0.5 * (f * f * f - f * sin(f * EASING_PI));
        }
        else {
            double f = (1.0 - (2 * p - 1.0));
            return 0.5 * (1.0 - (f * f * f - f * sin(f * EASING_PI))) + 0.5;
        }
    case ui_impl_boun_ease_in:
        // 反弹渐入
        return 1.0 - impl_bounce_ease_out(1.0 - p);
    case ui_impl_boun_ease_out:
        // 反弹渐出
        return impl_bounce_ease_out(p);
    case ui_impl_boun_ease_inout:
        // 反弹出入
        if (p < 0.5) {
            return 0.5 * (1.0 - impl_bounce_ease_out(1.0 - (p*2.0)));
        }
        else {
            return 0.5 * impl_bounce_ease_out(p * 2.0 - 1.0) + 0.5;
        }
    }
}
// web color name to argb32
#include <stdint.h>
#include <assert.h>

PCN_NOINLINE
/// <summary>
/// hash ignore case. ansi char supported only
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
uint32_t ui_hash_ignore_case(const char* begin, const char* end, char step) {
    assert((end - begin) % step == 0 && "bad string");
    const uint32_t seed = 131;
    uint32_t hash = 0;
    while (begin != end) {
        hash = hash * seed + (((*begin) & 0x1f) + 0x40);
        begin += step;
    }
    return hash;
}

// color hash
struct ct { uint32_t hash; uint8_t r, g, b, x; };
// color hash
struct tt { struct ct a, b, c; };

// bstable
static const struct ct ui_hash_color_table[] = {
    { 0x00159c75, 0xff, 0x00, 0x00, 0 }, { 0x00162085, 0xd2, 0xb4, 0x8c, 0 },
    { 0x00e0fc23, 0xf5, 0xde, 0xb3, 0 }, { 0x00e211f1, 0xff, 0xff, 0xff, 0 },
    { 0x016295b9, 0xff, 0xf5, 0xee, 0 }, { 0x06164ca6, 0xda, 0xa5, 0x20, 0 },
    { 0x067fa0ae, 0x55, 0x6b, 0x2f, 0 }, { 0x08cb15f4, 0x00, 0xff, 0xff, 0 },
    { 0x08ec1466, 0x00, 0x00, 0xff, 0 }, { 0x0911bf43, 0x00, 0xff, 0xff, 0 },
    { 0x0963e047, 0x69, 0x69, 0x69, 0 }, { 0x09985cec, 0xff, 0xd7, 0x00, 0 },
    { 0x0999207b, 0x80, 0x80, 0x80, 0 }, { 0x0a424f41, 0x00, 0xff, 0x00, 0 }, 
    { 0x0a84d6de, 0x00, 0x00, 0x80, 0 }, { 0x0aca7c28, 0xcd, 0x85, 0x3f, 0 },
    { 0x0acb8636, 0xff, 0xc0, 0xcb, 0 }, { 0x0acc52e8, 0xdd, 0xa0, 0xdd, 0 },
    { 0x0b231d4e, 0xfa, 0x80, 0x72, 0 }, { 0x0b33bec3, 0xff, 0xfa, 0xfa, 0 },
    { 0x0b53a9d8, 0x00, 0x80, 0x80, 0 }, { 0x0bc722bd, 0x46, 0x82, 0xb4, 0 },
    { 0x0d03e941, 0xff, 0xff, 0xf0, 0 }, { 0x0e254c7d, 0x3c, 0xb3, 0x71, 0 },
    { 0x0e9fcac8, 0xfa, 0xfa, 0xd2, 0 }, { 0x146ea803, 0xd8, 0xbf, 0xd8, 0 },
    { 0x1752ac68, 0xff, 0x8c, 0x00, 0 }, { 0x1795b66d, 0x99, 0x32, 0xcc, 0 },
    { 0x1b16efda, 0x4b, 0x00, 0x82, 0 }, { 0x1df11bb1, 0xff, 0x00, 0xff, 0 },
    { 0x213ae781, 0xff, 0xe4, 0xb5, 0 }, { 0x22491d7a, 0xfd, 0xf5, 0xe6, 0 },
    { 0x2343e297, 0xf0, 0x80, 0x80, 0 }, { 0x234ec770, 0xad, 0xd8, 0xe6, 0 },
    { 0x2374724d, 0xe0, 0xff, 0xff, 0 }, { 0x23fbd385, 0xd3, 0xd3, 0xd3, 0 },
    { 0x24342b57, 0xb2, 0x22, 0x22, 0 }, { 0x252e3940, 0xff, 0xb6, 0xc1, 0 },
    { 0x26d7b050, 0x80, 0x00, 0x00, 0 }, { 0x27bc78a2, 0xdc, 0xdc, 0xdc, 0 },
    { 0x2957a7d4, 0xba, 0x55, 0xd3, 0 }, { 0x2a618a0c, 0xee, 0xe8, 0xaa, 0 },
    { 0x2e3b6946, 0xf0, 0xe6, 0x8c, 0 }, { 0x2fdc90d8, 0xd2, 0x69, 0x1e, 0 },
    { 0x30150e68, 0x2e, 0x8b, 0x57, 0 }, { 0x333c2b69, 0x40, 0xe0, 0xd0, 0 },
    { 0x36737844, 0xff, 0xff, 0x00, 0 }, { 0x3a3f6783, 0x8b, 0x00, 0x8b, 0 },
    { 0x3c47c2e9, 0x48, 0x3d, 0x8b, 0 }, { 0x3cf4cefe, 0x2f, 0x4f, 0x4f, 0 },
    { 0x3d5a764f, 0xff, 0x69, 0xb4, 0 }, { 0x3feed19a, 0xfa, 0xf0, 0xe6, 0 },

    // rebeccapurple
    { 0x455fd72b, 0x66, 0x33, 0x99, 0 },

    { 0x4601f422, 0xff, 0xa5, 0x00, 0 }, { 0x4644fe27, 0xda, 0x70, 0xd6, 0 },
    { 0x48e0676d, 0x1e, 0x90, 0xff, 0 }, { 0x4f0ea139, 0xc7, 0x15, 0x85, 0 },
    { 0x55a3fc2d, 0xff, 0xf0, 0xf5, 0 }, { 0x56313dfc, 0x00, 0x00, 0x8b, 0 },
    { 0x5656e8d9, 0x00, 0x8b, 0x8b, 0 }, { 0x56de4a11, 0xa9, 0xa9, 0xa9, 0 },
    { 0x57040f9a, 0x00, 0xff, 0x7f, 0 }, { 0x578768cf, 0xaf, 0xee, 0xee, 0 },
    { 0x5b89bc21, 0x93, 0x70, 0xdb, 0 }, { 0x5bd50b25, 0x94, 0x00, 0xd3, 0 },
    { 0x61fee746, 0x7b, 0x68, 0xee, 0 }, { 0x64ee7562, 0x7f, 0xff, 0xd4, 0 },
    { 0x6636a70b, 0xff, 0x45, 0x00, 0 }, { 0x68db189b, 0x87, 0xce, 0xeb, 0 },
    { 0x69de3f45, 0x90, 0xee, 0x90, 0 }, { 0x6f03de15, 0xf4, 0xa4, 0x60, 0 },
    { 0x73c0231f, 0x66, 0xcd, 0xaa, 0 }, { 0x73c0e8e9, 0x00, 0x64, 0x00, 0 },
    { 0x74fd96db, 0x80, 0x80, 0x00, 0 }, { 0x75e09e8b, 0x5f, 0x9e, 0xa0, 0 },
    { 0x78700c6f, 0xbc, 0x8f, 0x8f, 0 }, { 0x78771274, 0x80, 0x00, 0x80, 0 },
    { 0x7d4d1b55, 0x64, 0x95, 0xed, 0 }, { 0x7f46c0ad, 0x98, 0xfb, 0x98, 0 },
    { 0x8120ff47, 0xf0, 0xff, 0xff, 0 }, { 0x8152552b, 0x8b, 0x45, 0x13, 0 },
    { 0x82aeed08, 0xb8, 0x86, 0x0b, 0 }, { 0x858f4ca7, 0x8b, 0x00, 0x00, 0 },
    { 0x8a46dffd, 0xff, 0xfa, 0xf0, 0 }, { 0x8a8452df, 0xee, 0x82, 0xee, 0 },
    { 0x8aa4baeb, 0x00, 0x00, 0xcd, 0 }, { 0x8ae2465a, 0x32, 0xcd, 0x32, 0 },
    { 0x8d9616d7, 0xff, 0x00, 0xff, 0 }, { 0x8fdb2dd4, 0xf5, 0xf5, 0xdc, 0 },
    { 0x90c932c3, 0x00, 0x00, 0x00, 0 }, { 0x919ab922, 0xa5, 0x2a, 0x2a, 0 },
    { 0x94a8af53, 0xad, 0xff, 0x2f, 0 }, { 0x96a0f312, 0xa0, 0x52, 0x2d, 0 },
    { 0x9793260d, 0xc0, 0xc0, 0xc0, 0 }, { 0x97b7a913, 0xe6, 0xe6, 0xfa, 0 },
    { 0xa2c24479, 0xff, 0x7f, 0x50, 0 }, { 0xa44e8a1a, 0x77, 0x88, 0x99, 0 },
    { 0xac25dade, 0x8f, 0xbc, 0x8f, 0 }, { 0xaf67d42e, 0x19, 0x19, 0x70, 0 },
    { 0xafd4cbcb, 0x00, 0xce, 0xd1, 0 }, { 0xb34f97c6, 0xff, 0xef, 0xd5, 0 },
    { 0xb375c3c6, 0xff, 0xda, 0xb9, 0 }, { 0xb53e21aa, 0xff, 0xde, 0xad, 0 },
    { 0xb6550387, 0x7c, 0xfc, 0x00, 0 }, { 0xb89fb108, 0xbd, 0xb7, 0x6b, 0 },
    { 0xb9ffb48a, 0x22, 0x8b, 0x22, 0 }, { 0xbce7d9ee, 0xff, 0x14, 0x93, 0 },
    { 0xbe9cd3f2, 0xcd, 0x5c, 0x5c, 0 }, { 0xbfaf2287, 0x6a, 0x5a, 0xcd, 0 },
    { 0xc05c2e9c, 0x70, 0x80, 0x90, 0 }, { 0xc13c28db, 0xf0, 0xff, 0xf0, 0 },
    { 0xc28cf6b0, 0xff, 0xfa, 0xcd, 0 }, { 0xc3fbf62a, 0xf8, 0xf8, 0xff, 0 },
    { 0xcd7706a8, 0xff, 0xa0, 0x7a, 0 }, { 0xcd9c1c0d, 0x41, 0x69, 0xe1, 0 },
    { 0xcdbaa31d, 0xde, 0xb8, 0x87, 0 }, { 0xcf2fb840, 0xf5, 0xff, 0xfa, 0 },
    { 0xd10a19e0, 0xdb, 0x70, 0x93, 0 }, { 0xd2f3dd4a, 0xff, 0xeb, 0xcd, 0 },
    { 0xd58bf028, 0x48, 0xd1, 0xcc, 0 }, { 0xd8dd15fb, 0xff, 0xe4, 0xe1, 0 },
    { 0xd9cb81a9, 0x87, 0xce, 0xfa, 0 }, { 0xdc73d594, 0xe9, 0x96, 0x7a, 0 },
    { 0xe0174796, 0xfa, 0xeb, 0xd7, 0 }, { 0xe035ffae, 0x7f, 0xff, 0x00, 0 },
    { 0xe28793b3, 0x9a, 0xcd, 0x32, 0 }, { 0xe3a02103, 0x00, 0xbf, 0xff, 0 },
    { 0xe4b8fb9d, 0xff, 0xe4, 0xc4, 0 }, { 0xe6ef2dff, 0xdc, 0x14, 0x3c, 0 },
    { 0xe76bf492, 0xf5, 0xf5, 0xf5, 0 }, { 0xe95ca127, 0x00, 0x80, 0x00, 0 },
    { 0xec4ff751, 0x00, 0xfa, 0x9a, 0 }, { 0xee44195a, 0xf0, 0xf8, 0xff, 0 },
    { 0xefb97e3b, 0xb0, 0xc4, 0xde, 0 }, { 0xf1e75f55, 0x8a, 0x2b, 0xe2, 0 },
    { 0xf5656557, 0xb0, 0xe0, 0xe6, 0 }, { 0xf77f805d, 0xff, 0xf8, 0xdc, 0 },
    { 0xf84da4de, 0x6b, 0x8e, 0x23, 0 }, { 0xf8c7619e, 0xff, 0xff, 0xe0, 0 },
    { 0xfb1ad092, 0x20, 0xb2, 0xaa, 0 }, { 0xfc868cee, 0xff, 0x63, 0x47, 0 },
};

PCN_NOINLINE
/// <summary>
/// UIs the web color name to rgb32(RGBX byte order).
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
uint32_t ui_web_color_name_hash_to_rgb32(uint32_t hash) {
    // 二分搜索
    int left = 0, right = sizeof(ui_hash_color_table) / sizeof(ui_hash_color_table[0]);
    while (left < right) {
        const int mid = (left + right) / 2;
        if (ui_hash_color_table[mid].hash < hash) left = mid + 1;
        else if (ui_hash_color_table[mid].hash > hash) right = mid;
        else return *(const uint32_t*)&ui_hash_color_table[mid].r;
    }
    //assert(!"unkown color name");
    return 0;
}


PCN_NOINLINE
/// <summary>
/// UIs the web color name to rgb32(RGBX byte order).
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
uint32_t ui_web_color_name_to_rgb32(const char* begin, const char* end, char step) {
    const uint32_t hash = ui_hash_ignore_case(begin, end, step);
    return ui_web_color_name_hash_to_rgb32(hash);
}

// web color string to argb32
#include <stdint.h>
#include <assert.h>
#include <limits.h>

// color-name to rgb32
extern uint32_t 
ui_web_color_name_hash_to_rgb32(uint32_t hash);
// hash
extern uint32_t
ui_hash_ignore_case(const char* begin, const char* end, char step);
// hex-char to int
extern char
ui_hex_to_int(char ch);

#define HEX16_BIT 4
typedef union { uint32_t pri; uint8_t rgba[4]; } color_t;

#define fallthrough

/// <summary>
/// web color string to RGBA32(RGBA byte-order).
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <remarks>
/// color format support:
/// [O] keywords colors
/// [O] transparent
/// [O] rebeccapurple
/// [O] #RRGGBB, #RGB
/// [O] #RRGGBBAA, #RGBA
/// [X] rgb(), rgba()
/// [X] hsl(), hsla()
/// [X] system-color [context-sensitive]
/// [X] currentColor [context-sensitive]
/// </remarks>
/// <returns></returns>
uint32_t ui_web_color_string_to_rgba32(const char* begin, const char* end, char step) {
    assert((end - begin) % step == 0 && "bad string");
    // #开头的16进制
    if (*begin == '#') {
        const int len = (int)(end - begin) / step;
        //char R1, R2, G1, G2, B1, B2, A1, A2;
        color_t color;
        switch (len)
        {
        case 4:
            // #RGB
            color.rgba[3] = 0xff;
            fallthrough;
        case 5:
            // #RGBA
        {
            unsigned char r = ui_hex_to_int(begin[step * 1]);
            color.rgba[0] = (r << HEX16_BIT) | r;
            unsigned char g = ui_hex_to_int(begin[step * 2]);
            color.rgba[1] = (g << HEX16_BIT) | g;
            unsigned char b = ui_hex_to_int(begin[step * 3]);
            color.rgba[2] = (b << HEX16_BIT) | b;
            if (len == 5) {
                unsigned char a = ui_hex_to_int(begin[step * 3]);
                color.rgba[3] = (a << HEX16_BIT) | a;
            }
            break;
        }
        case 7:
            // #RRGGBB
            color.rgba[3] = 0xff;
            fallthrough;
        case 9:
            // #RRGGBBAA
        {
            unsigned char r1 = ui_hex_to_int(begin[step * 1]);
            unsigned char r2 = ui_hex_to_int(begin[step * 2]);
            color.rgba[0] = (r1 << HEX16_BIT) | r2;
            unsigned char g1 = ui_hex_to_int(begin[step * 3]);
            unsigned char g2 = ui_hex_to_int(begin[step * 4]);
            color.rgba[1] = (g1 << HEX16_BIT) | g2;
            unsigned char b1 = ui_hex_to_int(begin[step * 5]);
            unsigned char b2 = ui_hex_to_int(begin[step * 6]);
            color.rgba[2] = (b1 << HEX16_BIT) | b2;
            if (len == 9) {
                unsigned char a1 = ui_hex_to_int(begin[step * 7]);
                unsigned char a2 = ui_hex_to_int(begin[step * 8]);
                color.rgba[3] = (a1 << HEX16_BIT) | a2;
            }
            break;
        }
        default:
            assert(!"bad hexadecimal color");
            color.pri = 0;
            break;
        }
        return color.pri;
    }
    // TODO: 函数调用(百分号/数字 空格/逗号 百分号/数字)

    // 颜色名称
    else {
        // hash("transparent") = 0x062e7992
        // 无视大小写计算HASH
        const uint32_t hash = ui_hash_ignore_case(begin, end, step);
        // 透明不包括在RGB32里面
        if (hash == 0x062e7992ul) return 0;
        // 将RGB32的A置为FF
#if 0
        //color_t alpha; alpha.pri = 0; alpha.rgba[3] = 0xff;
        //const uint32_t mask = alpha.pri;
        return ui_web_color_name_hash_to_rgb32(hash) | 0xff000000ul;
#else
        color_t color;
        color.pri = ui_web_color_name_hash_to_rgb32(hash);
        color.rgba[3] = 0xff;
        return color.pri;
#endif
    }
    //return 0;
}


#include <windows.h>
#include <shellapi.h>

#ifndef DEBUG
void ui_debug_output_info(const char* str) {
    OutputDebugStringA(str);
}
void ui_debug_output_infow(const wchar_t* str) {
    OutputDebugStringW(str);
}
#endif

void longui_error_beep() {
    MessageBeep(MB_ICONWARNING);
    //MessageBeep(MB_ICONERROR);
}

void longui_open_href(const char* href) {
    ShellExecuteA(NULL, NULL, href, NULL, NULL, SW_NORMAL);
}
// std::atof like funciton, but 3 args
#include <stdint.h>

#define white_space(c) ((c) == ' ' || (c) == '\t')
#define valid_digit(c) ((c) >= '0' && (c) <= '9')

PCN_NOINLINE
/// <summary>
/// UIs the function view atof.
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <returns></returns>
double ui_function_view_atof_le(const char* begin, const char* end, char step) {
    int frac = 0; double sign = 1.0, value = 0.0, scale = 1.0;
    const int cstep = step;
    // 跳过开头空白
    while (white_space(*begin) && begin < end) begin += cstep;
    // 结尾?
    if (begin == end) return 0.0;
    // 获取符号
    if (*begin == '-') { sign = -1.0; begin += cstep; }
    else if (*begin == '+') { begin += cstep; }
    // 跳过符号后空白
    while (white_space(*begin) && begin < end) begin += cstep;
    // 结尾?
    if (begin == end) return 0.0;
    // 获取小数点前面数字
    for (value = 0.0; valid_digit(*begin) && begin < end; begin += cstep) {
        value = value * 10.0 + (*begin - '0');
    }
    // 结尾?
    if (begin == end) return value;
    // 获取小数点后面数据
    if (*begin == '.') {
        double pow10 = 10.0;
        begin += cstep;
        while (valid_digit(*begin) && begin < end) {
            value += (*begin - '0') / pow10;
            pow10 *= 10.0;
            begin += cstep;
        }
    }
    // 结尾?
    if (begin < end) {
        // 指数?
        if ((*begin == 'e') || (*begin == 'E')) {
            unsigned int expon;
            // 获取指数符号
            begin += cstep;
            if (*begin == '-') { frac = 1; begin += cstep; }
            else if (*begin == '+') { begin += cstep; }
            // 获取指数数字
            for (expon = 0; valid_digit(*begin) && begin < end; begin += cstep) {
                expon = expon * 10 + (*begin - '0');
            }
            // 双精度浮点限制
            if (expon > 308) expon = 308;
            // 获取指数大小
            while (expon >= 50) { scale *= 1E50; expon -= 50; }
            while (expon >= 8) { scale *= 1E8;  expon -= 8; }
            while (expon > 0) { scale *= 10.0; expon -= 1; }
        }
    }
    // 返回数据
    return sign * (frac ? (value / scale) : (value * scale));
}


/// <summary>
/// UIs the function view atof [big-endian]
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
double ui_function_view_atof_be(const char* begin, const char* end, char step) {
    return ui_function_view_atof_le(begin + step - 1, end, step);
}

/// <summary>
/// UIs the function view atof [same as cpu]
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
double ui_function_view_atof_cpu(const char* begin, const char* end, char step) {
    const int16_t endianness = 0x01;
    if (!(*((const char*)&endianness))) begin += step - 1;
    return ui_function_view_atof_be(begin, end, step);
}
// std::atoi like funciton, but 3 args
#include <stdint.h>
#include <assert.h>

#define white_space(c) ((c) == ' ' || (c) == '\t')
#define valid_digit(c) ((c) >= '0' && (c) <= '9')
#define char_to_int(c) ((int32_t)(hex_lookup_table[(c) & 127]))

// digital lookup table for self
static const char hex_lookup_table[128]={
  // 0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 0
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 1
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 2
     0,  1,  2,  3,  4,  5,  6,  7,  8,  9, -1, -1, -1, -1, -1, -1,  // 3
    -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 4
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 5
    -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 6
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  // 7
};


/// <summary>
/// UIs the hexadecimal to int.
/// </summary>
/// <param name="ch">The ch.</param>
/// <returns></returns>
char ui_hex_to_int(char ch) {
    const char i = char_to_int(ch);
    assert(i != -1);
    return i;
}

PCN_NOINLINE
/// <summary>
/// UIs the function view atof.[little-endian]
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <returns></returns>
int32_t ui_function_view_atoi_le(const char* begin, const char* end, char step) {
    int32_t sign = 1, value, base = 10;
    const int cstep = step;
    // 跳过开头空白
    while (white_space(*begin) && begin < end) begin += cstep;
    // 结尾?
    if (begin == end) return 0;
    // 获取符号
    if (*begin == '-') { sign = -1; begin += cstep; }
    else if (*begin == '+') { begin += cstep; }
    // 0开头?
    else if (*begin == '0') { 
        begin += cstep;
        switch (*begin)
        {
        case 'x': case 'X': base = 16; begin += cstep; break;
        case 'b': case 'B': base = 2; begin += cstep; break;
        default: base = 8; break;
        }
    }
    // 跳过符号后空白
    while (white_space(*begin) && begin < end) begin += cstep;
    // 结尾?
    if (begin == end) return 0;
    // 获取小数点前面数字
    for (value = 0; valid_digit(*begin) && begin < end; begin += cstep) {
        // 十进制
        value = value * base + char_to_int(*begin);
        // 数据溢出
        if (value < 0) { value = 0; break; }
    }
    // 结尾
    return value * sign;
}

/// <summary>
/// UIs the function view atoi [big-endian]
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
int32_t ui_function_view_atoi_be(const char* begin, const char* end, char step) {
    return ui_function_view_atoi_le(begin + step - 1, end, step);
}

/// <summary>
/// UIs the function view atoi [same as cpu]
/// </summary>
/// <param name="begin">The begin.</param>
/// <param name="end">The end.</param>
/// <param name="step">The step.</param>
/// <returns></returns>
int32_t ui_function_view_atoi_cpu(const char* begin, const char* end, char step) {
    const int16_t endianness = 0x01;
    begin += (step - 1) * (!(*((const char*)&endianness)));
    return ui_function_view_atoi_be(begin , end, step);
}
#include "assert.h"
#include "stdint.h"
// C99 support
#if defined(_MSC_VER) && (_MSC_VER < 1900)
typedef int16_t char16_t;
typedef int32_t char32_t;
#define inline __inline
#else
#include "uchar.h"
#endif


// 0xD800 <= ch <= 0xDFFF
#define is_surrogate(ch) (((ch) & 0xF800) == 0xD800)

// 0xD800 <= ch <= 0xDBFF
#define is_high_surrogate(ch) (((ch) & 0xFC00) == 0xD800)

// 0xDC00 <= ch <= 0xDFFF
#define is_low_surrogate(ch) (((ch) & 0xFC00) == 0xDC00)

// UTF-8 字节长度 [5, 6已被弃用]
static const char ui_bytes_for_utf8[256] = {
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,

    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2, 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
    3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3, 4,4,4,4,4,4,4,4,5,5,5,5,6,6,6,6
};

// mark for first byte
static const char32_t ui_first_byte_mark[7] = {
    0x00, 0x00, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC
};

// offset
static const char32_t ui_offsets_from_utf8[6] = {
    0x00000000UL, 0x00003080UL, 0x000E2080UL,
    0x03C82080UL, 0xFA082080UL, 0x82082080UL
};

/// <summary>
/// Implementations the char16x2 to char32.
/// </summary>
/// <param name="lead">The lead.</param>
/// <param name="trail">The trail.</param>
/// <returns></returns>
extern inline char32_t impl_char16x2_to_char32(char16_t lead, char16_t trail) {
    assert(is_high_surrogate(lead) && "illegal utf-16 char");
    assert(is_low_surrogate(trail) && "illegal utf-16 char");
    return (char32_t)((lead - 0xD800) << 10 | (trail - 0xDC00)) + (0x10000);
};

/// <summary>
/// Char32s to char16.
/// </summary>
/// <param name="ch">The ch.</param>
/// <param name="str">The string.</param>
/// <returns></returns>
static inline char16_t* impl_char32_to_char16(char32_t ch, char16_t* str) {
    assert(str && "bad argment");
    // 检查是否需要转换
    if (ch > 0xFFFF) {
        str[0] = (char16_t)(0xD800 + (ch >> 10) - (0x10000 >> 10));
        str[1] = (char16_t)(0xDC00 + (ch & 0x3FF));
        return str + 2;
    }
    else {
        str[0] = (char16_t)ch;
        return str + 1;
    }
}

PCN_NOINLINE
/// <summary>
/// UIs the UTF16 to UTF8 get buflen.
/// 获取u16转换u8后u8所占长度(不含0结尾符)
/// </summary>
/// <param name="src">The source.</param>
/// <returns></returns>
uint32_t ui_utf16_to_utf8_get_buflen(const char16_t* src, const char16_t* end) {
    assert(src && end && end >= src && "bad string");
    uint32_t length = 0;
    // 遍历字符串
    for (ptrdiff_t i = 0; i != (end - src); ++i) {
        char16_t ch = src[i];
        // 1字节区域 [0-7F]
        if (ch < 0x0080) {
            length += 1;
        }
        // 四字节区
        else if (is_high_surrogate(ch)) {
            assert(is_low_surrogate(src[i+1]) && "illegal utf-16 string");
            ++i;
            length += 4;
        }
        // 3字节区域 > 2^11
        else if (ch > 0x07FF) {
            length += 3;
        }
        // 2字节区域 [80-7FF]
        else /*if (ch < 0x0800) */ {
            length += 2;
        }
    }
    return length;
}

PCN_NOINLINE
/// <summary>
/// UIs the UTF16 to UTF32 get buflen.
/// 获取u16转换u32后u32所占长度(不含0结尾符)
/// </summary>
/// <param name="src">The source.</param>
/// <returns></returns>
uint32_t ui_utf16_to_utf32_get_buflen(const char16_t* src, const char16_t* end) {
    assert(src && end && end >= src && "bad string");
    uint32_t length = 0;
    // 遍历字符串
    for (ptrdiff_t i = 0; i < (end - src); ++i) {
        char16_t ch = src[i]; ++length;
        // 双字区
        if (is_high_surrogate(ch)) {
            assert(is_low_surrogate(src[i+1]) && "illegal utf-16 string");
            ++i;
            assert((end - src) != i && "end of string");
        }
    }
    return length;
}

PCN_NOINLINE
/// <summary>
/// UIs the UTF16 to UTF8 get buflen.
/// </summary>
/// <param name="src">The source.</param>
/// <returns></returns>
uint32_t ui_utf8_to_utf16_get_buflen(const char* src, const char* end) {
    uint32_t length = 0;
    // 遍历字符串
    while (src < end) {
        unsigned char ch = *src;
        const char blen = ui_bytes_for_utf8[ch];
        assert(blen > 0 && blen < 5 && "illegal utf-8 @ RFC 3629");
        src += blen;
        length += 1 + (blen >> 2);
    }
    assert(src == end && "end of string!");
    return length;
}

PCN_NOINLINE
/// <summary>
/// UIs the UTF16 to UTF8 get buflen.
/// </summary>
/// <param name="src">The source.</param>
/// <returns></returns>
uint32_t ui_utf8_to_utf32_get_buflen(const char* src, const char* end) {
    uint32_t length = 0;
    // 遍历字符串
    while (src < end) {
        unsigned char ch = *src;
        const char blen = ui_bytes_for_utf8[ch];
        assert(blen > 0 && blen < 5 && "illegal utf-8 @ RFC 3629");
        src += blen;
        length += 1;
    }
    assert(src == end && "end of string!");
    return length;
}

PCN_NOINLINE
/// <summary>
/// UIs the UTF16 to UTF8.
/// </summary>
/// <param name="buf">The buf.</param>
/// <param name="buflen">The buflen.</param>
/// <param name="src">The source.</param>
/// <param name="end">The end.</param>
/// <returns></returns>
uint32_t ui_utf16_to_utf8(
    char* __restrict buf,
    uint32_t buflen,
    const char16_t* __restrict src,
    const char16_t* end) {
    assert(buf && "bad buffer");
    assert(src && end >= end && "bad string");
#ifndef NDEBUG
    const uint32_t needed = ui_utf16_to_utf8_get_buflen(src, end);
    assert(buflen >= needed && "buffer too small");
#endif
    uint32_t bufrm = buflen;
    char* __restrict des = buf;
    // 遍历
    while (src < end) {
        // 初始数据
        char32_t ch = 0;
        uint32_t move = 0;
        // 辅助平面
        if (((*src) & 0xD800) == 0xD800) {
            ch = impl_char16x2_to_char32(src[0], src[1]);
            assert(ch > 0xFFFF && ch <= 0x10FFFF && "bad utf32 char");
            // UTF-16 x2 --- UTF-8  x4
            src += 2;
            move = 4;
        }
        // 基本多语言平面
        else {
            ch = (char32_t)(*src);
            src += 1;
            // 单字节
            if (ch < (char32_t)(0x80)) {
                move = 1;
            }
            // 双字节
            else if (ch < (char32_t)(0x0800)) {
                move = 2;
            }
            // 三字节
            else {
                move = 3;
            }
        }
        // [RT]缓存不足
        if (bufrm < move) break;
        bufrm -= move;
        des += move;
        // 掩码
#define byteMask ((char32_t)0xBF)
#define byteMark ((char32_t)0x80)
        // 转换
        switch (move) {
        case 4: *--des = (char)((ch | byteMark) & byteMask); ch >>= 6;
        case 3: *--des = (char)((ch | byteMark) & byteMask); ch >>= 6;
        case 2: *--des = (char)((ch | byteMark) & byteMask); ch >>= 6;
        case 1: *--des = (char)(ch | ui_first_byte_mark[move]);
        }
        des += move;
    }
    // 收尾检查
    assert((uint32_t)(des - buf) == needed && "bug");
    return (uint32_t)(des - buf);
}

PCN_NOINLINE
/// <summary>
///  the UTF8 to UTF16.
///  UTF8字符串 转 UTF16字符串
/// </summary>
/// <param name="buf">The buf.</param>
/// <param name="buflen">The buflen.</param>
/// <param name="src">The source.</param>
/// <param name="end">The end.</param>
/// <returns></returns>
uint32_t ui_utf8_to_utf16(
    char16_t* __restrict buf,
    uint32_t buflen,
    const char* __restrict src,
    const char* end) {
#ifndef NDEBUG
    const uint32_t needed = ui_utf8_to_utf16_get_buflen(src, end);
    assert(buflen >= needed && "buffer too small");
#endif
    uint32_t bufremain = buflen;
    char16_t* __restrict des = buf;
    // 遍历字符串
    while (src < end) {
        // 初始数据
        char32_t ch = 0;
        const unsigned char read = ui_bytes_for_utf8[(unsigned char)(*src)] - 1;
        // 读取
        switch (read)
        {
#ifndef NDEBUG
        default:assert(!"bug"); break;
        case 5:
        case 4: assert(!"illegal utf-8 @ RFC 3629");
#endif
        case 3: ch += (unsigned char)(*src++); ch <<= 6;
        case 2: ch += (unsigned char)(*src++); ch <<= 6;
        case 1: ch += (unsigned char)(*src++); ch <<= 6;
        case 0: ch += (unsigned char)(*src++);
        }
        // 减去偏移量
        ch -= ui_offsets_from_utf8[read];
        // 检查缓存是否富裕
        const uint32_t u16len = ch > 0xFFFF ? 2 : 1;
        if (bufremain < u16len) break;
        bufremain -= u16len;
        // 写入
        des = impl_char32_to_char16(ch, des);
    }
    // 收尾检查
#ifndef NDEBUG
    if (buflen >= needed) {
        assert((uint32_t)(des - buf) == needed && "bug");
    }
#endif
    return (uint32_t)(des - buf);
}


PCN_NOINLINE
/// <summary>
///  the UTF8 to UTF16.
///  UTF8字符串 转 UTF32字符串
/// </summary>
/// <param name="buf">The buf.</param>
/// <param name="buflen">The buflen.</param>
/// <param name="src">The source.</param>
/// <param name="end">The end.</param>
/// <returns></returns>
uint32_t ui_utf8_to_utf32(
    char32_t* __restrict buf,
    uint32_t buflen,
    const char* __restrict src,
    const char* end) {
#ifndef NDEBUG
    const uint32_t needed = ui_utf8_to_utf32_get_buflen(src, end);
    assert(buflen >= needed && "buffer too small");
#endif
    uint32_t bufremain = buflen;
    char32_t* __restrict des = buf;
    // 遍历字符串
    while (src < end) {
        // 初始数据
        char32_t ch = 0;
        const unsigned char read = ui_bytes_for_utf8[(unsigned char)(*src)] - 1;
        // 读取
        switch (read)
        {
#ifndef NDEBUG
        default:assert(!"bug"); break;
        case 5:
        case 4: assert(!"illegal utf-8 @ RFC 3629");
#endif
        case 3: ch += (unsigned char)(*src++); ch <<= 6;
        case 2: ch += (unsigned char)(*src++); ch <<= 6;
        case 1: ch += (unsigned char)(*src++); ch <<= 6;
        case 0: ch += (unsigned char)(*src++);
        }
        // 减去偏移量
        ch -= ui_offsets_from_utf8[read];
        // 检查缓存是否富裕
        if (!bufremain) break; --bufremain;
        // 写入
        des[0] = ch; des++;
    }
    // 收尾检查
#ifndef NDEBUG
    if (buflen >= needed) {
        assert((uint32_t)(des - buf) == needed && "bug");
    }
#endif
    return (uint32_t)(des - buf);
}