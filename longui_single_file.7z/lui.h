﻿#pragma once
#include "luiconf.h"

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// config
// c++
#include <cstdint>

// ui namespace
namespace LongUI {
#ifdef LUI_ACCESSIBLE
    // accessible
    class CUIAccessible;
    // accessible class for window
    class CUIAccessibleWnd;
    // event args
    struct AccessibleEventArg;
    // finalize for accessible
    void FinalizeAccessible(CUIAccessible& obj) noexcept;
    // finalize for accessible
    void FinalizeAccessible(CUIAccessibleWnd& obj) noexcept;
    // patterns
    enum AccessiblePattern : uint16_t {
        Pattern_None        = 0,
        Pattern_Grid        = 1 << 0,
        Pattern_Table       = 1 << 1,
        Pattern_Value       = 1 << 2,
        Pattern_Range       = 1 << 3,
        Pattern_Toggle      = 1 << 4,
        Pattern_Invoke      = 1 << 5,
    };
#endif
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// accessible

// c++
#include <cstdint>

// ui namespace
namespace LongUI {
#ifdef LUI_ACCESSIBLE
    // accessible callback
    enum AccessibleCallback : uint32_t {
        // accessible property/name changed
        Callback_PropertyChanged,
        // invoked
        Callback_Invoked,
    };
    void Accessible(CUIAccessible*, AccessibleCallback) noexcept;
#endif
}

namespace LongUI {
    // string view
    template<typename T> struct PodStringView;
    // UTF-8 String View
    using U8View = PodStringView<char>;
    // utf-16 string view
    using U16View = PodStringView<char16_t>;
    // basic string
    template<typename T, unsigned B> class CUIBasicString;
    // utf-8 string
    using CUIStringU8 = CUIBasicString<char, 8>;
    // utf-16 string
    using CUIString16 = CUIBasicString<char16_t, 4>;
    // utf-32 string
    using CUIString32 = CUIBasicString<char32_t, 2>;
    // utf-16 string ex
    using CUIStringEx = CUIBasicString<char16_t, 64>;
    // default string: utf-16
    using CUIString = CUIString16;
    // pod vector
    namespace POD { template<typename T> class Vector; }
    // string vectors
    //struct CUIStringList;
    // EventAccept
    enum EventAccept : bool { Event_Accept = true, Event_Ignore = false };
    // graphics adapter desc
    struct GraphicsAdapterDesc;
    // stylesheet value
    struct SSValue;
    // viewport
    class UIViewport;
    // control class
    class UIControl;
    // window
    class CUIWindow;
    // manager
    class CUIManager;
    // signature
    template<typename signature> class CUIFunction;
    // Gui Event Listener
    using GuiEventListener = CUIFunction<EventAccept(UIControl& host)>;
}

#include <cstdint>

// ui
namespace LongUI {
    // type healper
    namespace type_helper {
        // base int type
        template<size_t> struct int_type;
        // 1 byte
        template<> struct int_type<sizeof(uint8_t)> {
            // signed 1 byte int
            using signed_t = int8_t;
            // unsigned 1 byte int
            using unsigned_t = uint8_t;
        };
        // 2 byte
        template<> struct int_type<sizeof(uint16_t)> {
            // signed 2 byte int
            using signed_t = int16_t;
            // unsigned 2 byte int
            using unsigned_t = uint16_t;
        };
        // 4 byte
        template<> struct int_type<sizeof(uint32_t)> {
            // signed 4 byte int
            using signed_t = int32_t;
            // unsigned 4 byte int
            using unsigned_t = uint32_t;
        };
        // 8 byte
        template<> struct int_type<sizeof(uint64_t)> {
            // signed 8 byte int
            using signed_t = int64_t;
            // unsigned 8 byte int
            using unsigned_t = uint64_t;
        };
    }
    // half ptr
    using halfptr_t = typename type_helper::int_type<sizeof(void*) / 2>::signed_t;
    // unsigned half ptr
    using uhalfptr_t = typename type_helper::int_type<sizeof(void*) / 2>::unsigned_t;
    // i8
    inline constexpr int32_t operator ""_i8(unsigned long long i) noexcept {
        return static_cast<int8_t>(i);
    }
    // ui8
    inline constexpr uint8_t operator ""_ui8(unsigned long long i) noexcept {
        return static_cast<uint8_t>(i);
    }
    // i16
    inline constexpr int16_t operator ""_i16(unsigned long long i) noexcept {
        return static_cast<int16_t>(i);
    }
    // ui16
    inline constexpr uint16_t operator ""_ui16(unsigned long long i) noexcept {
        return static_cast<uint16_t>(i);
    }
    // i32 
    inline constexpr int32_t operator ""_i32(unsigned long long i) noexcept {
        return static_cast<int32_t>(i);
    }
    // ui32 
    inline constexpr uint32_t operator ""_ui32(unsigned long long i) noexcept {
        return static_cast<uint32_t>(i);
    }
    // i64
    inline constexpr int64_t operator ""_i64(unsigned long long i) noexcept {
        return static_cast<int64_t>(i);
    }
    // ui64
    inline constexpr uint64_t operator ""_ui64(unsigned long long i) noexcept {
        return static_cast<uint64_t>(i);
    }
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// accessible
// int

// c++
#include <cstdint>

// ui namespace
namespace LongUI {
#ifdef LUI_ACCESSIBLE
    // | operator
    inline auto operator|(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) | b);
    }
    // & operator
    inline auto operator&(AccessiblePattern a, AccessiblePattern b) noexcept {
        using pattrten_t = typename type_helper::int_type<sizeof(a)>::unsigned_t;
        return static_cast<AccessiblePattern>(static_cast<pattrten_t>(a) & b);
    }
    // |= operator
    inline auto&operator|=(AccessiblePattern& a, AccessiblePattern b) noexcept {
        a = a | b; return a;
    }
    // &= operator
    inline auto&operator&=(AccessiblePattern& a, AccessiblePattern b) noexcept {
        a = a & b; return a;
    }
    // accessible type;
    enum class AccessibleControlType : uint32_t;
    // accessible event: for patterns
    enum AccessibleEvent : uint32_t {
        // get patterns
        Event_GetPatterns = 0,
        // all-get control type
        Event_All_GetControlType,
        // all-get accessible name
        Event_All_GetAccessibleName,
        // all-get description
        Event_All_GetDescription,
        // invoke-invoke
        Event_Invoke_Invoke,
        // toggle-toggle
        Event_Toggle_Toggle,
        // value-set value(string)
        Event_Value_SetValue,
        // value-get value(string)
        Event_Value_GetValue,
        // range&value-read only? return Event_Accept if true
        Event_RangeValue_IsReadOnly,
        // range-get value(double)
        Event_Range_GetValue,
        // range-set value(double)
        Event_Range_SetValue,
        // range-get max value
        Event_Range_GetMax,
        // range-set max value
        Event_Range_GetMin,
        // range-get large step
        Event_Range_GetLargeStep,
        // range-set small step
        Event_Range_GetSmallStep,
    };
    // accessible event args
    struct AccessibleEventArg {
        // event id
        AccessibleEvent     event;
    };
    // accessible event: get patterns
    struct AccessibleGetPatternsArg : AccessibleEventArg {
        // <out> patterns
        mutable AccessiblePattern   patterns;
        // ctor
        AccessibleGetPatternsArg() noexcept {
            this->event = AccessibleEvent::Event_GetPatterns;
            this->patterns = AccessiblePattern::Pattern_None;
        }
    };
    // accessible event: get control type
    struct AccessibleGetCtrlTypeArg : AccessibleEventArg {
        // <out> name
        mutable AccessibleControlType   type;
        // ctor
        AccessibleGetCtrlTypeArg() noexcept {
            this->event = AccessibleEvent::Event_All_GetControlType;
            type = AccessibleControlType(-1);
        }
    };
    // accessible event: get accessible name
    struct AccessibleGetAccNameArg : AccessibleEventArg {
        // <out> name
        CUIString*          name;
        // ctor
        AccessibleGetAccNameArg(CUIString& str) noexcept {
            this->event = AccessibleEvent::Event_All_GetAccessibleName;
            name = &str;
        }
    };
    // accessible event: get description
    struct AccessibleGetDescriptionArg : AccessibleEventArg {
        // <out> name
        CUIString*          description;
        // ctor
        AccessibleGetDescriptionArg(CUIString& str) noexcept {
            this->event = AccessibleEvent::Event_All_GetDescription;
            description = &str;
        }
    };

    // accessible event: set value
    struct AccessibleVSetValueArg : AccessibleEventArg {
        // string pointer
        const char16_t* string;
        // string length
        uint32_t        length;
        // ctor
        AccessibleVSetValueArg(const char16_t* str, uint32_t len) noexcept {
            this->event = AccessibleEvent::Event_Value_SetValue;
            string = str;
            length = len;
        }
    };
    // accessible event: get value
    struct AccessibleVGetValueArg : AccessibleEventArg {
        // <out> name
        CUIString*          value;
        // ctor
        AccessibleVGetValueArg(CUIString& str) noexcept {
            this->event = AccessibleEvent::Event_Value_GetValue;
            value = &str;
        }
    };


    // accessible event: set range value
    struct AccessibleRSetValueArg : AccessibleEventArg {
        // value
        double          value;
        // ctor
        AccessibleRSetValueArg(double v) noexcept {
            this->event = AccessibleEvent::Event_Range_SetValue;
            value = v;
        }
    };
    // accessible event: get range value
    struct AccessibleRGetValueArg : AccessibleEventArg {
        // <out> name
        mutable double  value;
        // ctor
        AccessibleRGetValueArg() noexcept {
            this->event = AccessibleEvent::Event_Range_GetValue;
            value = 0.;
        }
    };
    // accessible event: get range max value
    struct AccessibleRGetMaxArg : AccessibleEventArg {
        // <out> name
        mutable double  value;
        // ctor
        AccessibleRGetMaxArg() noexcept {
            this->event = AccessibleEvent::Event_Range_GetMax;
            value = 0.;
        }
    };
    // accessible event: get range min value
    struct AccessibleRGetMinArg : AccessibleEventArg {
        // <out> name
        mutable double  value;
        // ctor
        AccessibleRGetMinArg() noexcept {
            this->event = AccessibleEvent::Event_Range_GetMin;
            value = 0.;
        }
    };
    // accessible event: get range large-step value
    struct AccessibleRGetLargeStepArg : AccessibleEventArg {
        // <out> name
        mutable double  value;
        // ctor
        AccessibleRGetLargeStepArg() noexcept {
            this->event = AccessibleEvent::Event_Range_GetLargeStep;
            value = 0.;
        }
    };
    // accessible event: get range small-step value
    struct AccessibleRGetSmallStepArg : AccessibleEventArg {
        // <out> name
        mutable double  value;
        // ctor
        AccessibleRGetSmallStepArg() noexcept {
            this->event = AccessibleEvent::Event_Range_GetSmallStep;
            value = 0.;
        }
    };
#endif
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// c++
#include <cstdint>

// ui namespace
namespace LongUI {
    // accessible event
    enum class AccessibleControlType : uint32_t {
        // custom type
        Type_Custom = 0,
        // button
        Type_Button,
        // calendar
        Type_Calendar,
        // check-box
        Type_CheckBox,
        // combo-box
        Type_ComboBox,
        // text-edit
        Type_TextEdit,
        // hyperlink
        Type_Hyperlink,
        // image
        Type_Image,
        // list
        Type_List,
        // list item
        Type_ListItem,
        // menu
        Type_Menu,
        // menu bar
        Type_MenuBar,
        // menu item
        Type_MenuItem,
        // progress bar
        Type_ProgressBar,
        // radio button
        Type_RadioButton,
        // scroll bar
        Type_ScrollBar,
        // slider
        Type_Slider,
        // spinner
        Type_Spinner,
        // tab
        Type_Tab,
        // tab item
        Type_TabItem,
        // text
        Type_Text,
        // tool bar
        Type_ToolBar,
        // tooltip
        Type_Tooltip,
        // tree
        Type_Tree,
        // tree item
        Type_TreeItem,
        // group
        Type_Group,
        // thumb
        Type_Thumb,
        // header
        Type_Header,
        // header item
        Type_HeaderItem,
        // table
        Type_Table,
        // NONE
        Type_None,
    };
}

#include <cstdlib>

// function Setting
namespace LongUI {
    // alloc for normal space
    void*NormalAlloc(size_t length) noexcept;
    // free for normal space
    void NormalFree(void* address) noexcept;
    // realloc for normal space
    void*NormalRealloc(void* address, size_t length) noexcept;
    // alloc for small space
    void*SmallAlloc(size_t length) noexcept;
    // free for small space
    void SmallFree(void* address) noexcept;
    // template helper
    template<typename T> inline auto NormalAllocT(size_t length) noexcept {
        return reinterpret_cast<T*>(NormalAlloc(length * sizeof(T)));
    }
    // template helper
    template<typename T> inline auto SmallAllocT(size_t length) noexcept {
        return reinterpret_cast<T*>(SmallAlloc(length * sizeof(T)));
    }
}



#define LUI_COMPILER_UNK    0
#define LUI_COMPILER_GCC    1
#define LUI_COMPILER_MSVC   2
#define LUI_COMPILER_CLANG  3


#if defined(__clang__)
#define LUI_COMPILER LUI_COMPILER_CLANG
#elif defined(__GNUC__) || defined(__GNUG__)
#define LUI_COMPILER LUI_COMPILER_GCC
#elif defined(_MSC_VER)
#define LUI_COMPILER LUI_COMPILER_MSVC
#else
#define LUI_COMPILER LUI_COMPILER_UNK
#endif


#if (LUI_COMPILER == LUI_COMPILER_MSVC)
#if _MSC_VER < 1900
#ifdef __cplusplus
#define noexcept
#define constexpr const
#define alignas(x)
#define alignof(x) sizeof(void*)
#endif
#define __restrict
#endif
#endif

#define UNICALL __stdcall
#define luiref

#if  LUI_COMPILER == LUI_COMPILER_MSVC
#define PCN_NOINLINE __declspec(noinline)
#define PCN_NOVTABLE __declspec(novtable)
#define PCN_DLLEXPRT
#else
#define PCN_NOINLINE __attribute__((noinline))
#define PCN_NOVTABLE
#define PCN_DLLEXPRT
#endif

#define PCN_DLL_PUBLIC  PCN_DLLEXPRT
#define PCN_DLL_PROTECT

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cstdint>

// ui namespace
namespace LongUI {
    // detail namespace
    namespace detail {
        template<uint32_t SEED>
        constexpr uint32_t const_bkdr(uint32_t hash, const char* str) noexcept {
            return *str ? const_bkdr<SEED>(
                static_cast<uint32_t>(static_cast<uint64_t>(hash) * SEED + (*str))
                , str + 1) : hash;
        }
    }
    // Typical BKDR hash function
    constexpr uint32_t TypicalBKDR(const char* str) noexcept {
        return detail::const_bkdr<131>(0, str);
    }
    // BKDR
    constexpr uint32_t operator ""_bkdr(const char* str, size_t) noexcept {
        return TypicalBKDR(str);
    }
}
#include <type_traits>
#include <iterator>

// ui
namespace LongUI {
    // type healper
    namespace type_helper {
        // is_iterator: FALSE
        template<typename U, typename = void>
        struct is_iterator { enum : bool { value = false }; };
        // is_iterator: TRUE
        template<typename U>
        struct is_iterator<U, typename std::enable_if<!std::is_same<typename
            std::iterator_traits<U>::value_type, void>::value>::type>
        {
            enum : bool { value = true };
        };
    }
}


#include <utility>
#include <cassert>
#include <type_traits>


#ifndef LUI_CANNOT_CALL_CONSTRUCTOR_DIRECTLY

// MSVC  -> can call ctor
// Clang -> call ctor via -Wmicrosoft-explicit-constructor-call
// GCC   -> cannot call ctor

#if LUI_COMPILER == LUI_COMPILER_GCC
#define LUI_CANNOT_CALL_CONSTRUCTOR_DIRECTLY
#endif

#endif

#ifdef LUI_CANNOT_CALL_CONSTRUCTOR_DIRECTLY
#include <new>
#endif

// LongUI::detail namespace
namespace LongUI { namespace detail {
    // empty dtor
    void empty_dtor(void*) noexcept;
    // dtor_t
    struct dtor_t { void(*ptr)(void*) noexcept; };
    // func-vtable helper
    struct vtable_helper {
        void(*create_obj)(void*) noexcept;
        void(*copy_t_obj)(void*, const void*) noexcept;
        void(*move_t_obj)(void*, void*) noexcept;
        void(*delete_obj)(void*) noexcept;
    };
    // release the object: real
    template<typename T, bool> struct delete_obj_helper { };
    // release the object: real
    template<typename T>
    struct delete_obj_helper<T, true> {
        // delete obj
        static inline void delete_obj_real(void*p) noexcept { }
        // get delete 
        static inline dtor_t delete_obj_ptr() noexcept { return { empty_dtor }; }
    };
    // release the object: real
    template<typename T>
    struct delete_obj_helper<T, false> {
        // delete
        static inline void delete_obj_real(void*p) noexcept { static_cast<T*>(p)->T::~T(); }
        // get delete 
        static inline dtor_t delete_obj_ptr() noexcept { return { delete_obj_real }; }
    };
    // empty0
    struct empty0 {};
    // func-vtable getter
    template<typename T> struct ctor_dtor {
        // member
        T       m;
        // ctor
        inline ctor_dtor() noexcept {};
        // dtor
        inline ~ctor_dtor() noexcept {};
        // copy ctor
        inline ctor_dtor(const ctor_dtor& a) noexcept : m(a.m) {};
        // move ctor
        inline ctor_dtor(ctor_dtor&& a) noexcept : m(std::move(a.m)) {};
        // create the object
        static void create_obj(void* ptr) noexcept {
#ifdef LUI_CANNOT_CALL_CONSTRUCTOR_DIRECTLY
            // gcc cannot call ctor directly
            new(ptr) ctor_dtor<T>();
#else
            // msc/clang extended support
            static_cast<ctor_dtor<T>*>(ptr)->ctor_dtor<T>::ctor_dtor();
#endif
        }
        // release the object
        static void delete_obj(void*p) noexcept { 
            delete_obj_helper<T, std::is_trivially_destructible<T>::value>::delete_obj_real(p);
        }
        // delete_obj pointer
        static inline dtor_t delete_obj_ptr() noexcept {
            return delete_obj_helper<T, std::is_trivially_destructible<T>::value>::delete_obj_ptr();
        }
        // ctor
        template<typename ...Args>
        ctor_dtor(empty0, Args&&... args) noexcept : m(std::forward<Args>(args)...) {};
        // create
        template<typename ...Args>
        static void create(void* ptr, Args&&... args) noexcept {
#ifdef LUI_CANNOT_CALL_CONSTRUCTOR_DIRECTLY
            // gcc cannot call ctor directly
            new(ptr) ctor_dtor<T>(empty0{}, std::forward<Args>(args)...);
#else
                // msc/clang extended support
            static_cast<ctor_dtor<T>*>(ptr)->ctor_dtor<T>::ctor_dtor(empty0{}, std::forward<Args>(args)...);
#endif
        }
#ifdef LUI_NONPOD_VECTOR
        // copy the object
        static void copy_t_obj(void* ptr, const void* x) noexcept {
            assert(ptr != x);
            const T& obj = static_cast<const T*>(x);
            create(t, obj);
        }
        // move the object
        static void move_t_obj(void* ptr, void* x) noexcept {
            assert(ptr != x);
            T& obj = static_cast<T*>(x);
            create(t, std::move(obj));
        }
        // get the vtable ptr
        static const vtable_helper* get() noexcept {
            static const vtable_helper helper{
                create_obj,  copy_t_obj, move_t_obj,  delete_obj };
            return &helper;
        }
#endif
    };
}}


#include <type_traits>
#include <iterator>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <new>


namespace LongUI {
    // string class
    template<typename TT, unsigned BB> class CUIBasicString;
    // detail::string_helper namespace
    namespace detail { struct string_helper; }
    // nullptr must be 0
    static_assert(nullptr == 0, "not supported if nullptr != 0");
    // sizeof boolean must be 1
    //static_assert(sizeof(bool) == 1, "not supported if sizeof(bool) != 1");
    // pointer vector
    struct PointerVector;
    // ensure remove pointer item
    void RemovePointerItem(PointerVector&, void *) noexcept;
}

namespace LongUI { namespace POD {
    /// <summary>
    /// detail namespace
    /// </summary>
    namespace detail {
        // log2 helper
        template <size_t x>
        struct log2 { enum : size_t { value = 1 + log2<x / 2>::value }; };
        // log2 helper
        template <> struct log2<1> { enum : size_t { value = 0 }; };
        // using
        using LongUI::detail::ctor_dtor;
        // push_back_helper impl
        template<size_t> struct push_back_helper;
        /// <summary>
        /// Vector base class
        /// </summary>
        class vector_base {
            // friend
            friend LongUI::detail::string_helper;
            // friend
            friend ctor_dtor<vector_base>;
            // template friend
            template<size_t> friend struct push_back_helper;
            // extra bit
            enum {
                // extra aligned size(max for 128 byte in 32bit...)
                EX_ALIGNED1 = 0, EX_ALIGNED2 = 4,
                // extra reservation length(+1s)
                EX_RESERVED1 = 4, EX_RESERVED2 = 8,
                // extra fixed buffer length
                EX_FBL1 = 8,  EX_FBL2 = 16,
            };
        public:
#ifdef LUI_VECTOR_SIZE_USE_UINT32
            // size type
            using size_type = uint32_t;
#else
            // size type
            using size_type = std::uintptr_t;
#endif
            // size of template
            auto size_of_template() const noexcept { return m_uByteLen; }
            // max size
            auto max_size() const noexcept ->size_type { return 1u << 30; }
            // clear data
            void clear() noexcept { m_uVecLen = 0; }
            // pop back
            void pop_back() noexcept { assert(m_uVecLen && "UB: none data"); --m_uVecLen; }
            // size of Vector
            auto size() const noexcept -> size_type { return m_uVecLen; }
            // get capacity
            auto capacity() const noexcept->size_type { return m_uVecCap; }
            // check
            bool check() const noexcept { return !!m_uVecCap; }
            // is_ok?
            bool is_ok() const noexcept { return !!m_uVecCap; }
            // is empty?
            bool empty() const noexcept { return !m_uVecLen; }
            // reserve space
            void reserve(size_type n) noexcept;
        public:
            // extra helper
            template<size_t ali, size_t res, size_t fbl>
            struct extra_t {
                static_assert((ali & (ali - 1)) == 0, "must aligned in power of 2");
                static_assert(ali != 0, "must not be 0");
                static_assert(ali < (1<<(1<<(EX_RESERVED2- EX_RESERVED1))), "must less than it");
                static_assert(res < 16, "must less than 16");
                static_assert(fbl < 256, "must less than 256");
                static_assert(res <= fbl, "must less or eq than fbl");
                enum : size_t { value = (fbl<< EX_FBL1) | (res << EX_RESERVED1) | (log2<ali>::value <<  EX_ALIGNED1) };
            };
        protected:
            // ctor
            template<typename EX>
            vector_base(size_type bl, EX) noexcept
                :vector_base(bl, static_cast<uhalfptr_t>(EX::value)) {}
            // ctor
            vector_base(size_type bl) noexcept
                : vector_base(bl, extra_t<sizeof(double), 0, 0>{}) { }
        protected:
            // dtor
            ~vector_base() noexcept { this->free_memory(); }
            // copy ctor
            vector_base(const vector_base&) noexcept;
            // move ctor
            vector_base(vector_base&&) noexcept;
            // ctor
            vector_base(size_type bl, uhalfptr_t ex) noexcept;
            // resize
            void resize(size_type n, const char* data) noexcept;
            // shrink resize
            void shrink_resize(size_type n) noexcept;
            // erase at pos range
            void erase(size_type start, size_type end) noexcept;
            // insert range
            void insert(size_type pos, const char* first, const char* last) noexcept;
            // insert pos
            void insert(size_type pos, size_type n, const char* data) noexcept;
            // assign data
            void assign(const char* first, const char* last) noexcept;
            // assign data n times
            void assign(size_type n, const char* data) noexcept;
            // push back
            void push_back(const char*) noexcept;
            // push back pointer
            void push_back_ptr(const char*) noexcept;
            // swap another object
            void swap(vector_base& x) noexcept;
            // begin pointer
            auto begin() noexcept ->void* { return m_pData; }
            // end pointer
            auto end() noexcept ->void* { return const_cast<void*>(static_cast<const vector_base&>(*this).end()); }
            // const begin pointer
            auto begin() const noexcept ->const void* { return m_pData; }
            // const end pointer
            auto end() const noexcept ->const void*;
            // operator= move
            void op_equal(vector_base&& x) noexcept { free_memory(); ctor_dtor<vector_base>::create(this, std::move(x)); }
            // operator= copy
            void op_equal(const vector_base& x) noexcept;
            // fit size
            void shrink_to_fit() noexcept;
        private:
            // force_reset
            void force_reset() noexcept;
        private:
            // free memory
            static void free(char*) noexcept;
            // alloc memory
            static auto malloc(size_type len) noexcept -> char*;
            // realloc memory
            static auto realloc(char*, size_type len) noexcept -> char*;
            // is valid heap data
            bool is_valid_heap(void* ptr) const noexcept { return ptr != (this + 1); }
            // invalid heap data
            auto invalid_heap() const noexcept ->char* { return (char*)(this + 1); }
            // free memory
            void free_memory() noexcept;
            // alloc memory
            void alloc_memory(size_type len) noexcept;
            // insert helper
            bool insert_helper(size_type pos, size_type n) noexcept;
        private:
            // get aligned size
            auto get_extra_ali() const noexcept ->uhalfptr_t { 
                return 1 << ((m_uExtra >> EX_ALIGNED1) & ((1 << (EX_ALIGNED2 - EX_ALIGNED1)) - 1));
            }
            // get extra buy
            auto get_extra_buy() const noexcept ->uhalfptr_t { 
                return (m_uExtra >> EX_RESERVED1) & ((1 << (EX_RESERVED2 - EX_RESERVED1)) - 1);
            }
            // get extra fixed length
            auto get_extra_fbl() const noexcept->uhalfptr_t { 
                return (m_uExtra >> EX_FBL1) & ((1 << (EX_FBL2 - EX_FBL1)) - 1);
            }
        private:
            // data ptr
            char*               m_pData = invalid_heap();
            // Vector length
            uint32_t            m_uVecLen = 0;
            // Vector capacity
            uint32_t            m_uVecCap = 0;
            // data byte size
            const uhalfptr_t    m_uByteLen;
            // extra data
            const uhalfptr_t    m_uExtra;
        };
        // base iterator
        template<typename V, typename Ptr> class base_iterator {
            // self type
            using self = base_iterator;
        public:
            // c++ iterator traits
            using iterator_category = std::random_access_iterator_tag;
            // c++ iterator traits
            using difference_type = std::ptrdiff_t;
            // c++ iterator traits
            using pointer = Ptr;
            // c++ iterator traits
            using value_type = typename std::remove_pointer<pointer>::type;
            // c++ iterator traits
            using reference = typename std::add_lvalue_reference<value_type>::type;
#ifndef NDEBUG
        private:
            // data debug
            void data_dbg() const noexcept { assert(m_data == m_vector.data() && "invalid iterator"); }
            // range debug
            void range_dbg() const noexcept { assert((*this) >= m_vector.begin() && (*this) <= m_vector.end() && "out of range"); }
            // range debug
            void range_dbg_ex() const noexcept { assert((*this) >= m_vector.begin() && (*this) < m_vector.end() && "out of range"); }
            // debug check
            void check_dbg() const noexcept { data_dbg(); range_dbg(); }
            // debug check
            void check_dbg_ex() const noexcept { data_dbg(); range_dbg_ex(); }
        public:
            // def dtor
            base_iterator() noexcept : m_vector(*(V*)(nullptr)), m_ptr(nullptr), m_data(nullptr) {};
            // nor ctor
            base_iterator(V& v, Ptr ptr) noexcept : m_vector(v), m_ptr(ptr), m_data(v.data()) {};
            // copy ctor
            base_iterator(const self& x) noexcept = default;
            // ++operator
            auto operator++() noexcept -> self& { ++m_ptr; check_dbg(); return *this; }
            // --operator
            auto operator--() noexcept -> self& { --m_ptr; check_dbg(); return *this; }
            // operator*
            auto operator*() const noexcept -> reference { check_dbg_ex(); return *m_ptr; }
            // operator->
            auto operator->() const noexcept -> pointer { check_dbg_ex(); return m_ptr; }
            // operator +=
            auto operator+=(difference_type i) noexcept ->self& { m_ptr += i; check_dbg(); return *this; }
            // operator -=
            auto operator-=(difference_type i) noexcept ->self& { m_ptr -= i; check_dbg(); return *this; }
            // operator[]
            auto operator[](difference_type i) noexcept ->reference { auto itr = *this; itr += i; return *itr.m_ptr; }
#else
        public:
            // def dtor
            base_iterator() noexcept : m_ptr(nullptr) {};
            // nor ctor
            base_iterator(V& v, Ptr ptr) noexcept : m_ptr(ptr) {};
            // copy ctor
            base_iterator(const self& x) noexcept = default;
            // ++operator
            auto operator++() noexcept -> self& { ++m_ptr; return *this; }
            // --operator
            auto operator--() noexcept -> self& { --m_ptr; return *this; }
            // operator*
            auto operator*() const noexcept ->reference { return *m_ptr; }
            // operator->
            auto operator->() const noexcept ->pointer { return m_ptr; }
            // operator +=
            auto operator+=(difference_type i) noexcept ->self& { m_ptr += i; return *this; }
            // operator -=
            auto operator-=(difference_type i) noexcept ->self& { m_ptr -= i; return *this; }
            // operator[]
            auto operator[](difference_type i) noexcept ->reference { return m_ptr[i]; }
#endif
            // operator=
            auto operator= (const self& x) noexcept ->self& { std::memcpy(this, &x, sizeof x); return *this; }
            // operator<
            bool operator< (const self& x) const noexcept { return m_ptr <  x.m_ptr; }
            // operator>
            bool operator> (const self& x) const noexcept { return m_ptr >  x.m_ptr; }
            // operator==
            bool operator==(const self& x) const noexcept { return m_ptr == x.m_ptr; }
            // operator!=
            bool operator!=(const self& x) const noexcept { return m_ptr != x.m_ptr; }
            // operator<=
            bool operator<=(const self& x) const noexcept { return m_ptr <= x.m_ptr; }
            // operator>=
            bool operator>=(const self& x) const noexcept { return m_ptr >= x.m_ptr; }
            // operator-
            auto operator-(const self& x) const noexcept ->difference_type { return m_ptr - x.m_ptr; }
            // operator +
            auto operator+(difference_type i) const noexcept ->self { self itr{ *this }; itr += i; return itr; }
            // operator -=
            auto operator-(difference_type i) const noexcept ->self { self itr{ *this }; itr -= i; return itr; }
            // operator++
            auto operator++(int) noexcept -> self { self itr{ *this }; ++(*this); return itr; }
            // operator--
            auto operator--(int) noexcept -> self { self itr{ *this }; ++(*this); return itr; }
        private:
#ifndef NDEBUG
            // Vector data
            V&                  m_vector;
            // data ptr
            const void*         m_data;
#endif
            // pointer
            pointer             m_ptr;
        };
        // push back helper
        template<size_t> struct push_back_helper {
            // call push back
            template<typename T>
            static inline void call(vector_base& obj, const T& data) noexcept {
                const auto ptr = reinterpret_cast<const char*>(&data);
                obj.push_back(ptr);
            }
        };
        // push back helper
        template<> struct push_back_helper<sizeof(void*)> {
            // call push back
            template<typename T>
            static inline void call(vector_base& obj, const T& data) noexcept {
                union { const char* ptr; T t; } union_data;
                union_data.t = data;
                obj.push_back_ptr(union_data.ptr);
            }
        };
    }
    // Vector
    template<typename T> class Vector : protected detail::vector_base {
        // type helper
        static inline auto tr(T* ptr) noexcept -> char* { return reinterpret_cast<char*>(ptr); }
        // type helper
        static inline auto tr(const T* ptr) noexcept ->const char* { return reinterpret_cast<const char*>(ptr); }
    public:
        // size type
        using size_type = vector_base::size_type;
        // size of template
        auto size_of_template() const noexcept { return vector_base::size_of_template();  }
        // max size
        auto max_size() const noexcept ->size_type { return vector_base::max_size(); }
        // clear data
        void clear() noexcept { return vector_base::clear(); }
        // pop back
        void pop_back() noexcept { return vector_base::pop_back(); }
        // size of Vector
        auto size() const noexcept -> size_type { return vector_base::size(); }
        // get capacity
        auto capacity() const noexcept->size_type { return vector_base::capacity(); }
        // check
        bool check() const noexcept { return vector_base::check(); }
        // is_ok?
        bool is_ok() const noexcept { return vector_base::is_ok(); }
        // is empty?
        bool empty() const noexcept { return vector_base::empty(); }
        // reserve space
        void reserve(size_type n) noexcept { return vector_base::reserve(n); }
        // swap
        void swap(Vector<T>& x) noexcept { this->vector_base::swap(x); }
        // operator !
        bool operator!() const noexcept { return !this->is_ok(); }
        // operator bool
        operator bool() const noexcept { return this->is_ok(); }
    protected:
        // friend
        template<typename TT, unsigned BB> friend class LongUI::CUIBasicString;
        // buffer ctor
        template<typename EX>
        Vector(size_type /*ali*/, EX ex) noexcept: vector_base(sizeof(T), ex) {}
    public:
        // iterator
        using iterator = detail::base_iterator<Vector, T*>;
        // const iterator
        using const_iterator = const detail::base_iterator<const Vector, const T*>;
        // check for pod
        static_assert(std::is_pod<T>::value, "type T must be POD type");
        // ctor
        Vector() noexcept : vector_base(sizeof(T)) {}
        // ctor with initializer_list
        Vector(std::initializer_list<T> list) noexcept : vector_base(sizeof(T)) { assign(list); }
        // copy ctor
        Vector(const Vector& v) noexcept : vector_base(v) {}
        // move ctor
        Vector(Vector&& v) noexcept : vector_base(std::move(v)) {}
        // range ctor with random access iterator(Partially compatible with the standard)
        template<typename RAI>
        Vector(RAI frist, RAI last) noexcept : vector_base(sizeof(T)) { assign(frist, last); }
        // fill 0 ctor
        Vector(size_type n) noexcept : Vector(n, T{}) {}
        // fill x ctor
        Vector(size_type n, const T& x) noexcept : vector_base(sizeof(T)) { assign(n, x); }
        // copy op_equal
        auto operator=(const Vector& x)noexcept ->Vector & { vector_base::op_equal(x); return *this; }
        // move op_equal
        auto operator=(Vector&& x) noexcept ->Vector & { vector_base::op_equal(std::move(x)); return *this; }
        // get at
        auto at(size_type pos) noexcept -> T& { assert(pos < size() && "OOR"); return data()[pos]; }
        // get at const
        auto at(size_type pos) const noexcept -> const T&{ assert(pos < size() && "OOR"); return data()[pos]; }
        // operator[] 
        auto operator[](size_type pos) noexcept -> T& { assert(pos < size() && "OOR"); return data()[pos]; }
        // operator[] const
        auto operator[](size_type pos) const noexcept -> const T&{ assert(pos < size() && "OOR"); return data()[pos]; }
        // force base object
        auto force_base_object() noexcept ->detail::vector_base* { return this; }
    public:
        // assign data
        void assign(size_type n, const T& value) noexcept { vector_base::assign(n, tr(&value)); }
        // assign range with random access iterator(Partially compatible with the standard)
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, void>::type
            assign(RAI first, RAI last) noexcept {
#ifndef NDEBUG
            if (const auto n = last - first) {
                const auto ptr = &first[0];
                vector_base::assign(tr(ptr), tr(ptr + n));
            }
#else
            vector_base::assign(tr(&first[0]), tr(&last[0]));
#endif
        }
        // resize
        void resize(size_type n) noexcept { vector_base::resize(n, nullptr); }
        // resize with filled-value
        void resize(size_type n, const T& x) noexcept { vector_base::resize(n, tr(&x)); }
        // shrink resize
        void shrink_resize(size_type n) noexcept { vector_base::shrink_resize(n); }
        // fit
        void shrink_to_fit() noexcept { vector_base::shrink_to_fit(); }
        // get data ptr
        auto data() noexcept -> T* { return reinterpret_cast<T*>(vector_base::begin()); }
        // get data ptr
        auto data() const noexcept -> const T*{ return reinterpret_cast<const T*>(vector_base::begin()); }
        // assign data
        void assign(std::initializer_list<T> list) noexcept { assign(list.begin(), list.end()); }
        // push back
        void push_back(const T& x) noexcept { detail::push_back_helper<sizeof(T)>::call(*this, x); }
        // begin iterator
        auto begin() noexcept -> iterator { return{ *this, reinterpret_cast<T*>(vector_base::begin()) }; }
        // end iterator
        auto end() noexcept ->iterator { return{ *this, reinterpret_cast<T*>(vector_base::end()) }; }
        // front
        auto front() noexcept ->T& { return *reinterpret_cast<T*>(vector_base::begin()); }
        // back
        auto back() noexcept ->T& { assert(!empty()); return reinterpret_cast<T*>(vector_base::end())[-1]; }
        // begin iterator
        auto begin() const noexcept -> const_iterator { return{ *this, reinterpret_cast<const T*>(vector_base::begin()) }; }
        // end iterator
        auto end() const noexcept ->const_iterator { return{ *this, reinterpret_cast<const T*>(vector_base::end()) }; }
        // const begin iterator
        auto cbegin() const noexcept -> const_iterator { return begin(); }
        // const end iterator
        auto cend() const noexcept ->const_iterator { return end(); }
        // const front
        auto front() const noexcept ->const T&{ return *reinterpret_cast<const T*>(vector_base::begin()); }
        // const back
        auto back() const noexcept ->const T&{ assert(!empty()); return reinterpret_cast<const T*>(vector_base::begin())[-1]; }
    public:
        // insert value
        iterator insert(size_type pos, const T& val) noexcept {
            vector_base::insert(pos, tr(&val), tr(&val + 1));
            return{ *this, reinterpret_cast<T*>(vector_base::begin()) + pos };
        }
        // insert range with random access iterator(Partially compatible with the standard)
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, iterator>::type
            insert(size_type pos, RAI first, RAI last) noexcept {
#ifndef NDEBUG
            if (const auto n = last - first) {
                const auto ptr = &first[0];
                vector_base::insert(pos, tr(ptr), tr(ptr + n));
            }
#else
            vector_base::insert(pos, tr(&first[0]), tr(&last[0]));
#endif
            return{ *this, reinterpret_cast<T*>(vector_base::begin()) + pos };
        }
        // insert value n times
        iterator insert(size_type pos, size_type n, const T& val) noexcept {
            vector_base::insert(pos, n, tr(&val));
            return{ *this, reinterpret_cast<T*>(vector_base::begin()) + pos };
        }
        // insert value
        iterator insert(iterator itr, const T& val) noexcept { return insert(itr - begin(), val); }
        // insert value n times
        iterator insert(iterator itr, size_type n, const T& val) noexcept { return insert(itr - begin(), n, val); }
        // insert range with random access iterator(Partially compatible with the standard)
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, iterator>::type
            insert(iterator itr, RAI first, RAI last) noexcept { return insert(itr - begin(), first, last); }
        // insert range
        iterator insert(iterator itr, std::initializer_list<T> list) noexcept { return insert(itr - begin(), list.begin(), list.end()); }
    public:
        // erase at pos 
        iterator erase(size_type pos) noexcept {
            vector_base::erase(pos, pos + 1);
            return{ *this, reinterpret_cast<T*>(vector_base::begin()) + pos };
        }
        // erase range
        iterator erase(size_type first, size_type last) noexcept {
            vector_base::erase(first, last);
            return{ *this, reinterpret_cast<T*>(vector_base::begin()) + first };
        }
        // erase at pos itr
        iterator erase(iterator itr) noexcept { return erase(itr - begin()); }
        // erase at range itr
        iterator erase(iterator first, iterator last) noexcept { return erase(first - begin(), last - begin()); }
        // erase at pos itr
        iterator erase(const_iterator itr) noexcept { return erase(itr - cbegin()); }
        // erase at range itr
        iterator erase(const_iterator first, const_iterator last) noexcept { return erase(first - begin(), last - cbegin()); }
    private:
    };
}}



// ui namespace
namespace LongUI {
    /// <summary>
    /// const string list
    /// </summary>
    /*class CUIConstStringList {
        // node size
        enum { NODE_SIZE = 2048  };
        // list for node
        struct Node {
            // next
            Node*       next;
            // buffer
            char        buf[NODE_SIZE - sizeof(void*)];
        };
    public:
        // 
        using T = wchar_t;
    private:
        // index vector
        POD::Vector<const T*>       m_index;
    };*/
}



#include <utility>
#include <cstdint>
#include <cassert>
#include <cstring>
#include <iterator>
#include <type_traits>

#ifdef LUI_NONPOD_VECTOR

// LongUI::non-pod namespace
namespace LongUI { namespace NonPOD {
    // detail namespace
    namespace detail {
        // vtable_helper
        using LongUI::detail::vtable_helper;
        // ctor_dtor
        using LongUI::detail::ctor_dtor;
        // base vector
        class vector_base {
        public:
            // ctor
            vector_base(const vtable_helper*, uint16_t len, uint16_t ex) noexcept;
            // ctor
            ~vector_base() noexcept { this->free_data(); }
            // copy ctor
            vector_base(const vector_base&) noexcept;
            // move ctor
            vector_base(vector_base&&) noexcept;
            // operator= move
            void op_equal(vector_base&& x) noexcept { free_data();  ctor_dtor<vector_base>::create(this, std::move(x)); }
            // operator= copy
            void op_equal(const vector_base& x) noexcept;
        public:
            // max size
            auto max_size() const noexcept -> uint32_t { return 1u << 20; }
            // size of Vector
            auto size() const noexcept  { return m_uVecLen; }
            // get capacity
            auto capacity() const noexcept { return m_uVecCap; }
            // is_ok?
            bool is_ok() const noexcept { return !!m_uVecCap; }
            // is empty?
            bool empty() const noexcept { return !m_uVecLen; }
            // data
            auto data_c() const noexcept -> const char* { return m_pData; }
            // data
            auto data_n() noexcept { return m_pData; }
            // end pointer
            auto end_c() const noexcept -> const char*;
            // end pointer
            auto end_n() noexcept { return const_cast<char*>(end_c()); }
            // last pointer
            auto last_c() const noexcept -> const char*;
            // last pointer
            auto last_n() noexcept { return const_cast<char*>(last_c()); }
        public:
            // free all data
            void free_data() noexcept;
            // shrink
            void shrink_to_fit() noexcept;
            // reserve
            void reserve(uint32_t) noexcept;
            // resize
            void resize(uint32_t) noexcept;
            // push back - help
            void push_back_help(char* obj, void* func) noexcept;
            // push back - copy
            void push_back_copy(const char*) noexcept;
            // push back - move
            void push_back_move(char*) noexcept;
            // emplace back
            char*emplace_back() noexcept;
            // insert - help
            //void insert_help(char* obj, uint32_t pos, uint32_t len, void* func) noexcept;
            // emplace objects
            //char*emplace_objs(uint32_t pos, uint32_t len) noexcept;
            // pop back
            void pop_back() noexcept;
            // erase
            void erase(uint32_t pos, uint32_t len) noexcept;
            // clear
            void clear() noexcept;
            // assign range
            void assign_range(const char*, uint32_t) noexcept;
            // assign count
            void assign_count(const char*, uint32_t) noexcept;
        private:
            // check aligned
            inline void check_aligned(const char* ptr) noexcept;
            // free
            static inline void free(char*) noexcept;
            // malloc
            static inline char*malloc(size_t) noexcept;
            // realloc
            static inline char*realloc(char*, size_t) noexcept;
            // realloc
            static inline char*try_realloc(char*, size_t) noexcept;
            // do objects
            static void do_objects(char* obj, void* func, uint32_t count, uint32_t blen) noexcept;
            // do objects with objects
            static void do_objobj(char* obj, const char* obj2, void* func, uint32_t count, uint32_t blen) noexcept;
            // release objs
            void release_objs(char*, uint32_t count) noexcept;
            // create objects
            void create_objs(char*, uint32_t count) noexcept;
            // move objs
            void move_objects(char*, char*, uint32_t count) noexcept;
            // copy objs
            void copy_objects(char*, const char*, uint32_t count) noexcept;
        protected:
            // vtable
            const vtable_helper* const  m_pVTable;
            // data pointer
            char*                       m_pData = nullptr;
            // Vector length
            uint32_t                    m_uVecLen = 0;
            // Vector capacity
            uint32_t                    m_uVecCap = 0;
            // data byte size
            const uint16_t              m_uByteLen;
            // data aligned size
            const uint16_t              m_uAligned;
        };
        // base iterator
        template<typename V, typename Ptr> class base_iterator {
            // self type
            using self = base_iterator;
        public:
            // c++ iterator traits
            using iterator_category = std::random_access_iterator_tag;
            // c++ iterator traits
            using difference_type = std::ptrdiff_t;
            // c++ iterator traits
            using pointer = Ptr;
            // c++ iterator traits
            using value_type = typename std::remove_pointer<pointer>::type;
            // c++ iterator traits
            using reference = typename std::add_lvalue_reference<value_type>::type;
#ifndef NDEBUG
        private:
            // data debug
            void data_dbg() const noexcept { assert(m_data == m_vector.data() && "invalid iterator"); }
            // range debug
            void range_dbg() const noexcept { assert((*this) >= m_vector.begin() && (*this) <= m_vector.end() && "out of range"); }
            // range debug
            void range_dbg_ex() const noexcept { assert((*this) >= m_vector.begin() && (*this) < m_vector.end() && "out of range"); }
            // debug check
            void check_dbg() const noexcept { data_dbg(); range_dbg(); }
            // debug check
            void check_dbg_ex() const noexcept { data_dbg(); range_dbg_ex(); }
        public:
            // def dtor
            base_iterator() noexcept : m_vector(*(V*)(nullptr)), m_ptr(nullptr), m_data(nullptr) {};
            // nor ctor
            base_iterator(V& v, Ptr ptr) noexcept : m_vector(v), m_ptr(ptr), m_data(v.data()) {};
            // copy ctor
            base_iterator(const self& x) noexcept = default;
            // ++operator
            auto operator++() noexcept -> self& { ++m_ptr; check_dbg(); return *this; }
            // --operator
            auto operator--() noexcept -> self& { --m_ptr; check_dbg(); return *this; }
            // operator*
            auto operator*() const noexcept -> reference { check_dbg_ex(); return *m_ptr; }
            // operator->
            auto operator->() const noexcept -> pointer { check_dbg_ex(); return m_ptr; }
            // operator +=
            auto operator+=(difference_type i) noexcept ->self& { m_ptr += i; check_dbg(); return *this; }
            // operator -=
            auto operator-=(difference_type i) noexcept ->self& { m_ptr -= i; check_dbg(); return *this; }
            // operator[]
            auto operator[](difference_type i) noexcept ->reference { auto itr = *this; itr += i; return *itr.m_ptr; }
#else
        public:
            // def dtor
            base_iterator() noexcept : m_ptr(nullptr) {};
            // nor ctor
            base_iterator(V& v, Ptr ptr) noexcept : m_ptr(ptr) {};
            // copy ctor
            base_iterator(const self& x) noexcept = default;
            // ++operator
            auto operator++() noexcept -> self& { ++m_ptr; return *this; }
            // --operator
            auto operator--() noexcept -> self& { --m_ptr; return *this; }
            // operator*
            auto operator*() const noexcept ->reference { return *m_ptr; }
            // operator->
            auto operator->() const noexcept ->pointer { return m_ptr; }
            // operator +=
            auto operator+=(difference_type i) noexcept ->self& { m_ptr += i; return *this; }
            // operator -=
            auto operator-=(difference_type i) noexcept ->self& { m_ptr -= i; return *this; }
            // operator[]
            auto operator[](difference_type i) noexcept ->reference { return m_ptr[i]; }
#endif
            // operator=
            auto operator= (const self& x) noexcept ->self& { std::memcpy(this, &x, sizeof x); return *this; }
            // operator<
            bool operator< (const self& x) const noexcept { return m_ptr <  x.m_ptr; }
            // operator>
            bool operator> (const self& x) const noexcept { return m_ptr >  x.m_ptr; }
            // operator==
            bool operator==(const self& x) const noexcept { return m_ptr == x.m_ptr; }
            // operator!=
            bool operator!=(const self& x) const noexcept { return m_ptr != x.m_ptr; }
            // operator<=
            bool operator<=(const self& x) const noexcept { return m_ptr <= x.m_ptr; }
            // operator>=
            bool operator>=(const self& x) const noexcept { return m_ptr >= x.m_ptr; }
            // operator-
            auto operator-(const self& x) const noexcept ->difference_type { return m_ptr - x.m_ptr; }
            // operator +
            auto operator+(difference_type i) const noexcept ->self { self itr{ *this }; itr += i; return itr; }
            // operator -=
            auto operator-(difference_type i) const noexcept ->self { self itr{ *this }; itr -= i; return itr; }
            // operator++
            auto operator++(int) noexcept -> self { self itr{ *this }; ++(*this); return itr; }
            // operator--
            auto operator--(int) noexcept -> self { self itr{ *this }; ++(*this); return itr; }
        private:
#ifndef NDEBUG
            // Vector data
            V&                  m_vector;
            // data ptr
            const void*         m_data;
#endif
            // pointer
            pointer             m_ptr;
        };
    }
    // vector
    template<typename T> class Vector {
        // trans
        static auto tr(T* ptr) noexcept { return reinterpret_cast<char*>(ptr); }
        // trans
        static auto tr(char* ptr) noexcept { return reinterpret_cast<T*>(ptr); }
        // trans
        static auto tr(const T* ptr) noexcept { return reinterpret_cast<const char*>(ptr); }
        // trans
        static auto tr(const char* ptr) noexcept { return reinterpret_cast<const T*>(ptr); }
    public:
        // iterator
        using iterator = detail::base_iterator<Vector<T>, T*>;
        // const iterator
        using const_iterator = const detail::base_iterator<const Vector<T>, const T*>;
        // check for pod
        static_assert(!std::is_pod<T>::value, "type T must NOT be POD type");
    public:
        // ctor
        Vector() noexcept : m_vector(LongUI::detail::ctor_dtor<T>::get(), sizeof(T),alignof(T)){};
        // copy ctor
        Vector(const Vector& x) noexcept : m_vector(x.m_vector) {}
        // move ctor
        Vector(Vector&& x) noexcept : m_vector(std::move(x.m_vector)) {}
        // dtor
        ~Vector() noexcept {};
        // operator = copy
        auto&operator=(const Vector<T>& x) noexcept { m_vector.op_equal(x.m_vector); return *this; }
        // operator = move
        auto&operator=(Vector<T>&& x) noexcept { m_vector.op_equal(std::move(x.m_vector)); return *this; }
        // operator[]
        auto&operator[](uint32_t i) noexcept { assert(i < size() && "out of range"); return tr(m_vector.data_n())[i]; }
        // operator[]
        auto&operator[](uint32_t i) const noexcept { assert(i < size() && "out of range"); return tr(m_vector.data_c())[i]; }
    public:
        // data
        auto data() const noexcept { return tr(m_vector.data_c()); }
        // data
        auto data() noexcept { return tr(m_vector.data_n()); }
        // size
        auto size() noexcept { return m_vector.size(); }
        // is ok?
        bool is_ok() const noexcept { return m_vector.is_ok(); }
        // is empty?
        bool empty() const noexcept { return m_vector.empty(); }
    public:
        // push back: 
        void push_back(const T& x) noexcept { m_vector.push_back_copy(tr(&x)); }
        // [Not recommended for use] push back: use this -> emplace back
        void push_back(T&& x) noexcept { m_vector.push_back_move(tr(&x)); }
        // [    recommended for use] emplace back without args, return null for OOM
        auto emplace_back_ex() noexcept -> T* { return tr(m_vector.emplace_back()); }
        // pop back
        void pop_back() noexcept { m_vector.pop_back(); }
        // reserve
        void reserve(uint32_t len) noexcept { m_vector.reserve(len); }
        // resize
        void resize(uint32_t len) noexcept { m_vector.resize(len); }
        // clear
        void clear() noexcept { m_vector.clear(); }
        // erase
        void erase(uint32_t pos) noexcept { m_vector.erase(pos, 1); }
        // erase
        void erase(uint32_t pos, uint32_t len) noexcept { m_vector.erase(pos, len); }
        // assign count
        void assign(uint32_t count, const T& data) noexcept { m_vector.assign_count(tr(&data), count); }
        // assign range
        void assign(const T* first, uint32_t length) noexcept { m_vector.assign_range(tr(first), length); }
        // emplace, return null for OOM
        //auto emplace(uint32_t pos) noexcept { return tr(m_vector.emplace_objs(pos, 1)); }
        // emplace for many, return null for OOM
        //auto emplace_ex(uint32_t pos, uint32_t n) noexcept { return tr(m_vector.emplace_objs(pos, n)); }
    protected:
        // detail implment
        detail::vector_base         m_vector;
    public:
        // begin
        auto begin() noexcept ->iterator { return { *this, tr(m_vector.data_n()) }; }
        // end
        auto end() noexcept ->iterator { return { *this, tr(m_vector.end_n()) }; }
    };
}}

#endif
#include <type_traits>
#include <cstdint>
#include <utility>


namespace LongUI {
    // BKDR Hash Function
    auto BKDRHash(const char* str) noexcept->uint32_t;
    // BKDR Hash Function
    auto BKDRHash(const char* strbgn, const char* strend) noexcept->uint32_t;
}

namespace LongUI { namespace POD {
    /// <summary>
    /// detail namespace
    /// </summary>
    namespace detail {
        // end symbol
        enum : uintptr_t { end_symbol = 233 };
        // hash cell
#pragma warning(suppress: 4200)
        struct hash_cell { hash_cell* next; const char* str; char data[0]; };
        // hash iterator
        struct hash_iterator { uintptr_t* bucket; hash_cell* cell; void move_next(); };
        // operator == for hash_iterator
        inline bool operator==(const hash_iterator& a, const hash_iterator& b) noexcept { 
            return a.bucket == b.bucket && a.cell == b.cell; 
        }
        // string hash base
        class hash_base {
        protected:
            // ctor
            hash_base(uint32_t sizeof_T) noexcept;
            // dtor
            ~hash_base() noexcept;
            // is ok
            bool is_ok() const noexcept { return !!m_pBaseTable; }
            // clear
            void clear() noexcept;
            // find cell
            auto find(const char*) const noexcept->hash_iterator;
            // find cell with string view
            auto find(const char*, const char*) const noexcept->hash_iterator;
            // insert
            auto insert(const char*, const char*) noexcept-> std::pair<hash_iterator, bool>;
            // insert
            auto insert(const char*, const char*, const char*) noexcept->std::pair<hash_iterator, bool>;
            // remove
            bool remove(const char*) noexcept;
            // remove
            bool remove(const char*, const char*) noexcept;
            // remove
            bool remove(hash_iterator) noexcept;
#ifndef UI_HASH_TABLE_NO_ITERATOR
            // begin iterator
            auto begin_itr() const noexcept -> hash_iterator { return m_itrFirst; }
            // end iterator
            auto end_itr() const noexcept -> hash_iterator { return{ m_pBaseTableEnd, nullptr }; }
#endif
            // force insert cell
            auto force_insert(hash_cell& cell) noexcept ->uintptr_t*;
        private:
            // malloc data
            static void*malloc(size_t) noexcept;
            // free data
            static void free(void* ptr) noexcept;
            // force insert
            auto force_insert(const char*, const char*, const char*) noexcept->hash_iterator;
            // growup
            void growup() noexcept;
            // alloc cell
            auto alloc_cell(const char*, const char*, const char*) noexcept->hash_cell*;
            // for each
            template<typename T> void for_each(T call) noexcept;
        protected:
            // base table
            uintptr_t*          m_pBaseTable = nullptr;
            // base table end
            uintptr_t*          m_pBaseTableEnd = nullptr;
#ifndef UI_HASH_TABLE_NO_ITERATOR
            // first item
            hash_iterator       m_itrFirst = this->end_itr();
#endif
            // item size
            uint32_t            m_cItemSize = 0;
            // item byte size
            uint32_t    const   m_cItemByteSize;
        };
    }
    // string hash table
    template<typename T>
    class HashMap : protected detail::hash_base {
    public:
        // key type
        using key_type = const char*;
        // mapped type
        using mapped_type = T;
        // value type
        using value_type = std::pair<const key_type, mapped_type>;
        // size type
        using size_type = uint32_t;
#ifndef UI_HASH_TABLE_NO_ITERATOR
        // hash iterator
        class iterator {
            // self type
            using self = iterator;
            // friend class
            friend HashMap;
        public:
            // copy ctor
            iterator(const iterator& x) noexcept : m_itr(x.m_itr) {  }
            // copy =
            self& operator=(const iterator& x) noexcept { m_itr = x.m_itr; return *this; }
        private:
            // itr ctor
            iterator(const detail::hash_iterator& x) noexcept : m_itr(x) {}
        public:
            // operator *
            auto operator*() const noexcept ->value_type& { return reinterpret_cast<value_type&>(m_itr.cell->str); }
            // operator ->
            auto operator->() const noexcept ->value_type* { return &(*(*this)); }
            // operator ==
            bool operator==(const iterator& x) const noexcept { return m_itr == x.m_itr; }
            // operator !=
            bool operator!=(const iterator& x) const noexcept { return !(m_itr == x.m_itr); }
            // ++operator
            self&operator++() noexcept { m_itr.move_next(); return *this; }
            // operator++
            self operator++(int) noexcept { auto itr = *this; m_itr.move_next(); return itr; }
        private:
            // iterator
            detail::hash_iterator   m_itr;
        };
#endif
    public:
        // check for pod
        static_assert(std::is_pod<T>::value, "type T must be POD type");
#ifndef UI_HASH_TABLE_NO_ITERATOR
        // begin itr
        auto begin() noexcept ->iterator { return{ hash_base::begin_itr() }; }
        // end itr
        auto end() noexcept ->iterator { return{ hash_base::end_itr() }; }
#endif
    public:
        // ctor
        HashMap() noexcept : detail::hash_base(sizeof(T)) {}
        // dtor
        ~HashMap() noexcept = default;
        // copy : not implement yet
        HashMap(const HashMap&) noexcept = delete;
        // move : not implement yet
        HashMap(HashMap&&) noexcept = delete;
#ifndef UI_HASH_TABLE_NO_ITERATOR
        // find item with c-style string
        auto find(const char* str) noexcept ->iterator { return{ hash_base::find(str) }; }
        // find item with string view
        auto find(const char* str, const char* end) noexcept ->iterator { return{ hash_base::find(str, end) }; }
#else
#error not implement yet
#endif
        // get size
        auto size() const noexcept ->size_type { return m_cItemSize; }
        // insert with <c-style string, value> pair
        auto insert(const value_type& v) noexcept -> std::pair<iterator, bool> {
            const auto re = hash_base::insert(v.first, reinterpret_cast<const char*>(&v.second));
            return *reinterpret_cast<const std::pair<iterator, bool>*>(&re);
            auto ptr = reinterpret_cast<const std::pair<iterator, bool>*>(&re); return *ptr;
        }
        // insert with <string view, value>
        auto insert(const char* str, const char* end, const T& value) noexcept -> std::pair<iterator, bool> {
            const auto re = hash_base::insert(str, end, reinterpret_cast<const char*>(&value));
            auto ptr = reinterpret_cast<const std::pair<iterator, bool>*>(&re); return *ptr;
        }
    };
}}
#include <cstdint>
#include <type_traits>


// ui namespace
namespace LongUI { namespace POD {
    // forward
    template<typename T> class SharedArray;
    // detail namespace
    namespace detail {
        // basic array
        class basic_shared_array {
            // friend class
            template<typename T> friend class POD::SharedArray;
        protected:
            // assert range
#ifdef NDEBUG
            inline void assert_range(uint32_t) noexcept {};
#else
            void assert_range(uint32_t i) noexcept;
#endif
            // self type
            using self = basic_shared_array;
            // add ref
            auto add_ref() noexcept -> uint32_t { return ++m_cRefCount; }
            // release
            auto release() noexcept ->uint32_t;
            // get data
            auto data() noexcept ->void* { return m_data; }
            // length
            auto length() const noexcept ->uint32_t { return m_cLength; }
            // copy from
            static void copy_from(self*&, self*) noexcept;
            // move from
            static void move_from(self*&, self*&) noexcept;
            // safe ref
            static auto safe_ref(self* x) noexcept -> self * { if (x) x->add_ref(); return x; }
            // safe release
            static void safe_release(self* x) noexcept { if (x) x->release(); }
            // create one
            static auto create(
                const void* data,
                uint32_t len,
                uint32_t byte
            ) noexcept->self*;
        protected:
            // ref-count
            uint32_t        m_cRefCount;
            // length in count
            uint32_t        m_cLength;
            // data
#pragma warning(suppress: 4200)
            char            m_data[0];
        };
    }
    // pod shared array
    template<typename T>
    class SharedArray {
        // self type
        using Self = SharedArray;
    public:
        // check for pod
        static_assert(std::is_pod<T>::value, "type T must be POD type");
        // release
        //void release() noexcept { detail::basic_shared_array::safe_release(m_pointer); m_pointer = nullptr; }
        // ctor
        ~SharedArray() noexcept { detail::basic_shared_array::safe_release(m_pointer); }
        // ctor with data
        SharedArray(const T* begin, const T* end) noexcept : m_pointer(
            detail::basic_shared_array::create(begin, uint32_t(end - begin), sizeof(T))) {}
        // ctor with data
        SharedArray(const T* begin, uint32_t length) noexcept : m_pointer(
            detail::basic_shared_array::create(begin, length, sizeof(T))) {}
        // copy ctor
        SharedArray(const SharedArray& x) noexcept : m_pointer(
            detail::basic_shared_array::safe_ref(x.m_pointer)){  }
        // move ctor
        SharedArray(SharedArray&& x) noexcept : m_pointer(x.m_pointer)
            { x.m_pointer = nullptr; }
        // operator copy =
        Self& operator=(const SharedArray&x) noexcept { detail::basic_shared_array::copy_from(m_pointer, x.m_pointer); return *this; }
        // operator move =
        Self& operator=(SharedArray&&x) noexcept { detail::basic_shared_array::move_from(m_pointer, x.m_pointer); return *this; }
        //SharedArray(SharedArray&& x) noexcept { release(); m_pointer = x.m_pointer; x.m_pointer = nullptr; }
        // is ok?
        bool is_ok() const noexcept { return !!m_pointer; }
        // bool
        operator bool() const noexcept { return !!m_pointer; }
        // not
        bool operator !() const noexcept { return !m_pointer; }
        // size
        auto size() const noexcept ->uint32_t { return m_pointer->length(); }
        // length
        auto length() const noexcept ->uint32_t { return m_pointer->length(); }
        // end
        auto end() noexcept -> T* { return begin() + length(); }
        // begin
        auto begin() noexcept -> T* { return reinterpret_cast<T*>(m_pointer->data()); }
        // cend
        auto cend() noexcept -> const T*{ return cbegin() + length(); ; }
        // cbegin
        auto cbegin() noexcept -> const T* { return reinterpret_cast<const T*>(m_pointer->data()); }
        // operator []
        T& operator [](uint32_t i) noexcept { 
            m_pointer->assert_range(i); 
            return reinterpret_cast<T*>(m_pointer->data())[i]; 
        }
        // operator [] const
        const T& operator [](uint32_t i) const noexcept {
            m_pointer->assert_range(i);
            return reinterpret_cast<const T*>(m_pointer->data())[i];
        }
    private:
        // array pointer
        detail::basic_shared_array*     m_pointer;
    };
    // make shared array
    template<typename T, typename U>
    inline auto MakeSharedArray(const T* ptr, U b) noexcept ->SharedArray<T> {
        return { ptr, b };
    }
}}



namespace LongUI {
    // helper
    namespace helper {
#ifdef __GNUC__
        // is little endian
        struct is_little_endian { enum : bool { value = __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__ }; };
        // is big endian
        struct is_big_endian { enum : bool { value = __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__ }; };
        // is pdp endian
        struct is_pdp_endian { enum : bool { value = __BYTE_ORDER__ == __ORDER_PDP_ENDIAN__ }; };
#else
        // is little endian
        struct is_little_endian { enum : bool { value = true }; };
        // is big endian
        struct is_big_endian { enum : bool { value = false }; };
        // is pdp endian
        struct is_pdp_endian { enum : bool { value = false }; };
#endif
        // color order
        template<int> struct color_order_ {};
        // color order: le
        template<> struct color_order_<(1 << 0)> { enum { r = 3, g = 2, b = 1, a = 0 }; };
        // color order: be
        template<> struct color_order_<(1 << 1)> { enum { r = 0, g = 1, b = 2, a = 3 }; };
        // color order: pe
        template<> struct color_order_<(1 << 2)> { enum { r = 1, g = 0, b = 3, a = 2 }; };
        // color order: host
        using color_order = color_order_<
            (is_little_endian::value << 0)
            | (is_big_endian::value << 1)
            | (is_pdp_endian::value << 2)
        >;
        // ascii offset
        template<unsigned SIZE> struct ascii_offset;
        // ascii offset for 1
        template<> struct ascii_offset<1> { enum { value = color_order::a % 1 }; };
        // ascii offset for 2
        template<> struct ascii_offset<2> { enum { value = color_order::a % 2 }; };
        // ascii offset for 4
        template<> struct ascii_offset<4> { enum { value = color_order::a % 4 }; };
    }
}
#include <cstdint>

namespace LongUI {
    /// <summary>
    /// unicode namespace
    /// </summary>
    namespace Unicode {
        // utf-8
        struct UTF8 { using type = char; };
        // utf-16
        struct UTF16 { using type = char16_t; };
        // utf-16
        struct UTF32 { using type = char32_t; };
        // wchar helper
        template<size_t> struct wchar_helper;
        // 2?char16_t
        template<> struct wchar_helper<sizeof(char16_t)> { using type = UTF16; using untype = UTF32; };
        // 4?char32_t
        template<> struct wchar_helper<sizeof(char32_t)> { using type = UTF32; using untype = UTF16; };
        // wide char
        struct WChar {
            using type = wchar_t;
            using same = typename wchar_helper<sizeof(wchar_t)>::type;
            using same_t = typename same::type;
            using unsame = typename wchar_helper<sizeof(wchar_t)>::untype;
            using unsame_t = typename unsame::type;
        };
        // is_surrogate
        inline auto IsSurrogate(uint16_t ch) noexcept { return ((ch) & 0xF800) == 0xD800; }
        // is_high_surrogate
        inline auto IsHighSurrogate(uint16_t ch) noexcept { return ((ch) & 0xFC00) == 0xD800; }
        // is_low_surrogate
        inline auto IsLowSurrogate(uint16_t ch) noexcept { return ((ch) & 0xFC00) == 0xDC00; }
    }
    // wchar_t
    using wcharxx_t = typename Unicode::WChar::same_t;
    // not wchar_t
    using unwchar_t = typename Unicode::WChar::unsame_t;
    // detail namespace
    namespace detail {
        // utf16 to system char type
        inline auto sys(const wcharxx_t* str) noexcept {
            return reinterpret_cast<const wchar_t*>(str);
        }
        // utf16 to system char type
        inline auto sys(const wchar_t* str) noexcept {
            return reinterpret_cast<const wcharxx_t*>(str);
        }
    }
}


// Util
// C++
#include <cstdint>
#include <cstring>
#include <cwchar>


namespace LongUI {
    // detail namespace
    namespace detail {
        // string length
        inline auto strlen(const char* ptr) noexcept { return std::strlen(ptr); }
        // string length
        inline auto strlen(const wcharxx_t* ptr) noexcept { return std::wcslen(reinterpret_cast<const wchar_t*>(ptr)); }
        // string length
        auto strlen(const unwchar_t* ptr) noexcept->size_t;
        // name to rgb32
        auto name_rgb32(const char* a, const char* b, char c) noexcept->uint32_t;
        // name to rgba32
        auto color_rgba32(const char* a, const char* b, char c) noexcept->uint32_t;
    }
    // string view
    template<typename T> struct PodStringView {
        // from c-tyle string
        static auto FromCStyle(const T str[]) noexcept -> PodStringView { return{ str, str + detail::strlen(str) }; };
        // size
        auto size() const noexcept { return static_cast<uint32_t>(end() - begin()); }
        // begin
        auto begin() const noexcept { return first; };
        // end
        auto end() const noexcept { return second; };
        // to RGBA32 in byte order
        auto ColorRGBA32() const noexcept->uint32_t {
            return detail::color_rgba32(
                reinterpret_cast<const char*>(first) + helper::ascii_offset<sizeof(T)>::value,
                reinterpret_cast<const char*>(second) + helper::ascii_offset<sizeof(T)>::value,
                sizeof(T)
            );}
        // to RGBA32 in byte order
        auto NamedRGB32() const noexcept->uint32_t { 
            return detail::name_rgb32(
                reinterpret_cast<const char*>(first) + helper::ascii_offset<sizeof(T)>::value,
                reinterpret_cast<const char*>(second) + helper::ascii_offset<sizeof(T)>::value,
                sizeof(T)
            );}
        // get char then move
        //auto Char32() noexcept -> char32_t;
        // to rgba32
        //auto NamedRGBA32() const noexcept -> uint32_t { (NamedRGB32() << 8) | 0xff; }
        // split then move
        auto Split(T ch) noexcept->PodStringView;
        // to float
        operator float() const noexcept;
        // to double
        operator double() const noexcept;
        // to int32_t
        operator int32_t() const noexcept;
        // operator==
        bool operator==(const PodStringView x) const noexcept {
            return size() == x.size() && !std::memcmp(begin(), x.begin(), size() * sizeof(T));
        }
        // operator!=
        bool operator!=(const PodStringView x) const noexcept {
            return !((*this) == x);
        }
        // to bool
        bool ToBool() noexcept { return *begin() == 't'; }
        // to float
        auto ToFloat() const noexcept { return static_cast<float>(*this); }
        // to int32_t
        auto ToInt32() const noexcept { return static_cast<int32_t>(*this); }
        // to double
        auto ToDouble() const noexcept { return static_cast<double>(*this); }
        // 1st
        const T*        first;
        // 2nd
        const T*        second;
    };
    // split unit for U8View
    auto SplitUnit(PodStringView<char>&) noexcept ->PodStringView<char>;
    // split string with substring
    auto SplitStr(PodStringView<char>&, PodStringView<char>) noexcept->PodStringView<char>;
    // find last dir
    auto FindLastDir(PodStringView<char>) noexcept ->PodStringView<char>;
    // _sv
    inline PodStringView<char> operator ""_sv(const char* str, size_t len) noexcept {
        return{ str , str + len };
    }
    // _sv
    inline PodStringView<wchar_t> operator ""_sv(const wchar_t* str, size_t len) noexcept {
        return{ str , str + len };
    }
    // _sv
    inline PodStringView<char16_t> operator ""_sv(const char16_t* str, size_t len) noexcept {
        return{ str , str + len };
    }
    // _sv
    inline PodStringView<char32_t> operator ""_sv(const char32_t* str, size_t len) noexcept {
        return{ str , str + len };
    }
}
// HELPER MACRO
#define LUI_DECLARE_METHOD_FOR_CHAR_TYPE(T) \
    template<> PodStringView<T>::operator float() const noexcept;\
    template<> PodStringView<T>::operator double() const noexcept;\
    template<> PodStringView<T>::operator int32_t() const noexcept;\
    template<> PodStringView<T> PodStringView<T>::Split(T ch) noexcept;

namespace LongUI {
    // char
    LUI_DECLARE_METHOD_FOR_CHAR_TYPE(char);
    // char16_t
    LUI_DECLARE_METHOD_FOR_CHAR_TYPE(char16_t);
    // char32_t
    LUI_DECLARE_METHOD_FOR_CHAR_TYPE(char32_t);
}
#undef LUI_DECLARE_METHOD_FOR_CHAR_TYPE



namespace LongUI {
    // detail namespace
    namespace detail {
        // string helper
        struct string_helper {
            // base string
            using base_str = POD::detail::vector_base;
            // string set null char
            static void string_set_null_char(void* pos, size_t bytelen) noexcept;
            // change length
            static void relength(base_str& str, uint32_t len) noexcept { str.m_uVecLen = len; }
            // string assign helper
            static void string_assign(base_str&, const char*, const char*) noexcept;
            // string format helper
            static bool string_format(base_str&, const char* fmt, ...) noexcept;
            // string insert helper
            static void string_insert(base_str&, uintptr_t, const char*, const char*) noexcept;
            // string erase
            static void string_erase(base_str& str, size_t pos, size_t len) noexcept;
            // copy as latin1
            static void copy_from_latin1(wchar_t* des, const char* src_begin, const char* src_end) noexcept;
            // copy as latin1
            static void copy_from_latin1(char* des, const char* src_begin, const char* src_end) noexcept {
                std::memcpy(des, src_begin, src_end - src_begin);
            }
            // string utf8 to utf-16
            static void string_u8_u16(base_str& str, const char*, const char*) noexcept;
            // string utf8 to utf-xx
            static void string_u8(char16_t, base_str& str, const char* a, const char* b) noexcept {
                string_u8_u16(str, a, b);
            }
            // string utf8 to utf-xx
            static void string_u8(wchar_t, base_str& str, const char* a, const char* b) noexcept {
                    string_u8(wcharxx_t{}, str, a, b);
            }
#ifdef OPTIMIZATION_STRING_SPLIT_WITHIN_SINGLE_CHAR
            // string split with single char
            static auto string_split(base_str& str, POD::Vector<PodStringView<char>>&, char ch) noexcept->views<char>;
            // string split with single char
            static auto string_split(base_str& str, POD::Vector<PodStringView<wchar_t>>&, wchar_t ch) noexcept->views<wchar_t>;
        private:
            // string split with single char, implement
            template<typename T>
            static void string_split(T ch, base_str& str, POD::Vector<PodStringView<T>>&) noexcept;
#endif
        public:
            // string split with string
            static void string_split(
                const base_str& str,
                POD::Vector<PodStringView<char>>&,
                const char* b,
                const char* end
            ) noexcept;
            // string split with string
            static inline void string_split(
                const base_str& str,
                POD::Vector<PodStringView<wchar_t>>& list,
                const char* b,
                const char* end
            ) noexcept {
                string_split(str, reinterpret_cast<POD::Vector<PodStringView<char>>&>(list), b, end);
            }
        };
    }
}


namespace LongUI {
    // basic string
    template<typename T, unsigned B>
    class CUIBasicString {
        // self type
        using Self = CUIBasicString;
        // Vector type
        using V = POD::Vector<T>;
        // View
        using View = LongUI::PodStringView<T>;
        // B must > 0
        static_assert(B > 0, "B must > 0");
        // type helper
        static inline auto tr(T* ptr) noexcept -> char* { return reinterpret_cast<char*>(ptr); }
        // type helper
        static inline auto tr(const T* ptr) noexcept ->const char* { return reinterpret_cast<const char*>(ptr); }
    public:
        // iterator
        using iterator = typename V::iterator;
        // const iterator
        using const_iterator = typename V::const_iterator;
        // size_type
        using size_type = typename V::size_type;
        // npos
        enum : size_type { npos = size_t(-1) };
        // extra type
        using ex_t = POD::detail::vector_base::extra_t<sizeof(T), +1, B>;
        // ctor +1s
        PCN_NOINLINE CUIBasicString() noexcept : m_vector(sizeof(T), ex_t{}) { m_buffer[0] = 0; }
        // ctor with pair
        CUIBasicString(const T* strb, const T* stre) noexcept : Self() { this->assign(strb, stre); }
        // copy ctor
        CUIBasicString(const Self& str) noexcept : Self() { this->assign(str); }
        // ctor with c-style string
        CUIBasicString(const T* str) noexcept : Self(str, str + detail::strlen(str)) { }
        // ctor with init list
        CUIBasicString(std::initializer_list<T> list) noexcept : Self(list.begin(), list.end()) { }
        // ctor with view
        CUIBasicString(LongUI::PodStringView<T> view) noexcept : Self(view.begin(), view.end()) { }
        // move ctor
        CUIBasicString(Self&& str) noexcept : m_vector(std::move(str.m_vector)) {  }
    public:
        // from utf-8
        static auto FromUtf8(const char* a, const char* b) noexcept->Self;
        // from utf-8
        static auto FromUtf8(PodStringView<char> view) noexcept->Self { return FromUtf8(view.begin(), view.end());  }
        // from utf-8
        static auto FromUtf8(const char* str) noexcept ->Self { return FromUtf8(str, str + detail::strlen(str)); }
        // from latin1
        // from number
    public:
        // is empty?
        bool empty() const noexcept { return m_vector.empty(); }
        // begin iterator
        auto begin() noexcept -> iterator { return m_vector.begin(); }
        // end iterator
        auto end() noexcept ->iterator { return m_vector.end(); }
        // front
        auto front() noexcept ->T& { return m_vector.front(); }
        // back
        auto back() noexcept ->T& { return m_vector.back(); }
        // begin iterator
        auto begin() const noexcept -> const_iterator { return m_vector.cbegin(); }
        // end iterator
        auto end() const noexcept ->const_iterator { return m_vector.cend(); }
        // const begin iterator
        auto cbegin() const noexcept -> const_iterator { return m_vector.cbegin(); }
        // const end iterator
        auto cend() const noexcept ->const_iterator { return m_vector.cend(); }
        // const front
        auto front() const noexcept ->const T& { return m_vector.front(); }
        // const back
        auto back() const noexcept ->const T& { return m_vector.back(); }
    public:
        // as buffer, null-terminated string
        template<typename Lam> void as_buffer_nul(uint32_t len, Lam call) noexcept {
            this->reserve(len); if (is_ok()) {
                call(const_cast<T*>(c_str())); 
                detail::string_helper::relength(m_vector, len);
            }
        }
        // as buffer, not null-terminated string
        template<typename Lam> void as_buffer(uint32_t len, Lam call) noexcept {
            this->reserve(len); if (is_ok()) { 
                void* ntbs = m_vector.detail::string_helper::base_str::begin();
                call(reinterpret_cast<T*>(ntbs));
                detail::string_helper::relength(m_vector, len);
                reinterpret_cast<T*>(ntbs)[len] = 0;
            }
        }
    public:
        // assign with string
        Self&assign(const T* str) noexcept { return assign(str, str + detail::strlen(str)); };
        // assign with string
        Self&assign(const Self& str) noexcept { return assign(str.begin(), str.end()); };
        // assign width RAI
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, Self&>::type
            assign(RAI first, RAI last) noexcept {
            detail::string_helper::string_assign(m_vector, tr(&first[0]), tr(&last[0]));
            return *this;
        }
    public:
        // append with char
        Self&append(const T& ch) noexcept { return append(&ch, &ch + 1); };
        // append with string
        Self&append(const T* str) noexcept { return append(str, str + detail::strlen(str)); };
        // append with string
        Self&append(const Self& str) noexcept { return append(str.begin(), str.end()); };
        // append with char
        Self&append(const View v) noexcept { return append(v.begin(), v.end()); };
        // append width RAI
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, Self&>::type
            append(RAI first, RAI last) noexcept {
            detail::string_helper::string_insert(m_vector, npos, tr(&first[0]), tr(&last[0]));
            return *this;
        }
    public:
        // insert
        Self&insert(size_type pos, const T* str) noexcept { return insert(pos, str, detail::strlen(str)); }
        // insert
        Self&insert(size_type pos, const T* str, size_type n) noexcept { return insert(pos, str, str + n); }
        // insert width RAI
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, Self&>::type
            insert(size_type pos, RAI first, RAI last) noexcept {
            detail::string_helper::string_insert(m_vector, pos, tr(&first[0]), tr(&last[0]));
            return *this;
        }
    public:
        // erase
        Self&erase(size_type pos = 0, size_type len = npos) noexcept { 
            detail::string_helper::string_erase(m_vector, pos, len);
            return *this;
        }
    public:
        // replace
        Self&replace(size_type pos, size_type len, const T* str) noexcept {
            return replace(pos, len, str, detail::strlen(str));
        }
        // replace
        Self&replace(size_type pos, size_type len, const T* str, size_type n) noexcept {
            return replace(pos, len, str, str + n);
        }
        // insert width RAI
        template<typename RAI> typename std::enable_if<type_helper::is_iterator<RAI>::value, Self&>::type
            replace(size_type pos, size_type len, RAI first, RAI last) noexcept {
            detail::string_helper::string_erase(m_vector, pos, len);
            detail::string_helper::string_insert(m_vector, pos, tr(&first[0]), tr(&last[0]));
            return *this;
        }
    public:
        // format
        template<typename... Args> bool format(const T fmt[], Args... args) noexcept {
            return detail::string_helper::string_format(
                m_vector, reinterpret_cast<const char*>(fmt), std::forward<Args>(args)...
            );
        }
        // splited type
        using splited_t = POD::Vector<View>;
#ifdef OPTIMIZATION_STRING_SPLIT_WITHIN_SINGLE_CHAR
        // split within single char
        inline auto split(T ch) const noexcept ->splited_t {
            return detail::string_helper::string_split(m_vector, ch);
        }
#else
        // split within single char
        inline auto split(const T& ch) const noexcept ->splited_t {
            splited_t v;
            detail::string_helper::string_split(m_vector, v, tr(&ch), tr(&ch + 1));
            return v;
        }
#endif
        // split within string
        auto split(const T* strbegin, const T* strend) const noexcept ->splited_t {
            splited_t v;
            detail::string_helper::string_split(m_vector, v, tr(strbegin), tr(strend));
            return v;
        }
        // split within view
        inline auto split(const View view) const noexcept ->splited_t {
            return this->split(view.begin(), view.end());
        }
        // split within string
        inline auto split(const T* str) const noexcept ->splited_t {
            return this->split(str, str + detail::strlen(str));
        }
    public:
        // operator==
        bool operator==(const Self&x) const noexcept {
            return size() == x.size() && !std::memcmp(c_str(), x.c_str(), size() * sizeof(T));
        }
        // operator!=
        bool operator!=(const Self&x) const noexcept {
            return size() != x.size() || std::memcmp(c_str(), x.c_str(), size() * sizeof(T));
        }
        // operator==
        bool operator==(const View x) const noexcept {
            return size() == x.size() && !std::memcmp(c_str(), x.begin(), size() * sizeof(T));
        }
        // operator!=
        bool operator!=(const View x) const noexcept {
            return size() != x.size() || std::memcmp(c_str(), x.begin(), size() * sizeof(T));
        }
    public:
        // operator+=
        Self&operator+=(const T x) noexcept { append(x); return *this; }
        // operator+=
        Self&operator+=(const T* x) noexcept { append(x); return *this; }
        // operator+=
        Self&operator+=(const View x) noexcept { append(x); return *this; }
        // operator+=
        Self&operator+=(const Self&x) noexcept { append(x); return *this; }
        // operator=
        Self&operator=(const Self&x) noexcept { m_vector = x.m_vector; return *this; }
        // operator=
        Self&operator=(View v) noexcept { return this->assign(v.begin(), v.end()); }
        // operator=
        Self&operator=(Self&&x) noexcept { m_vector = std::move(x.m_vector); return *this; }
        // operator[]
        auto operator[](size_t pos) noexcept ->T& { return m_vector[pos]; }
        // operator[]
        auto operator[](size_t pos) const noexcept ->const T&{ return m_vector[pos]; }
    public:
        // is ok?
        bool is_ok() const noexcept { return m_vector.is_ok(); }
        // view
        auto view() const noexcept ->View { return { c_str(), c_str() + length() }; }
        // length
        auto length() const noexcept ->size_type { return m_vector.size(); }
        // length
        auto size() const noexcept ->size_type { return m_vector.size(); }
        // clear data
        void clear() noexcept { m_vector.clear(); *m_vector.data() = 0; };
        // data string
        auto data() const noexcept -> const T*{ return m_vector.data(); };
        // c-style string
        auto c_str() const noexcept -> const T*{ return m_vector.data(); };
        // get capacity
        auto capacity() const noexcept -> size_type { return m_vector.capacity() - 1; }
        // get vector capacity
        auto vcapacity() const noexcept -> size_type { return m_vector.capacity(); }
        // fit memory
        void shrink_to_fit() noexcept { m_vector.shrink_to_fit(); }
        // reserve cap
        void reserve(size_type new_cap) noexcept { m_vector.reserve(new_cap); };
    protected:
        // pod vector
        V                   m_vector;
        // fixed buffer
        T                   m_buffer[B];
    };
    // basic string
    template<typename T, unsigned B, typename U> inline CUIBasicString<T, B>
    operator+(const CUIBasicString<T, B>& a, const U& b) noexcept {
        CUIBasicString<T, B> c{ a }; return c += b;
    }
    // string from utf-8
    template<typename T, unsigned B> inline
    auto CUIBasicString<T, B>::FromUtf8(const char* a,
        const char* b) noexcept -> CUIBasicString<T, B> {
        CUIBasicString<T, B> str;
        detail::string_helper::string_u8(T{}, str.m_vector, a, b);
        return str;
    }
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


namespace LongUI {
    /// <summary>
    /// CUIStringExs 
    /// </summary>
    //struct CUIStringList final : NonPOD::Vector<CUIStringEx> {
    //    // super class
    //    using Super = NonPOD::Vector<CUIStringEx>;
    //    // def ctor
    //    CUIStringList() noexcept {}
    //    // copy ctor
    //    CUIStringList(const CUIStringList& s) noexcept : Super(s) {}
    //    // copy ctor v2
    //    CUIStringList(const Super& s) noexcept : Super(s) {}
    //    // move ctor
    //    CUIStringList(CUIStringList&& s) noexcept : Super(std::move(s)) {}
    //    // move ctor v2
    //    CUIStringList(Super&& s) noexcept : Super(std::move(s)) {}
    //};
}

#include <cstdint>
#include <iterator>

// Node
namespace LongUI {
    // Node
    template<typename T> struct Node {
        // node ptr
        T* prev, *next;
        // operator ==
        bool operator==(const Node& n) const noexcept { return this == &n; }
        // operator !=
        bool operator!=(const Node& n) const noexcept { return this != &n; }
        // control iterator
        class Iterator {
            // self type
            using Self = Iterator;
        public:
            // c++ iterator traits
            using iterator_category = std::bidirectional_iterator_tag;
            // c++ iterator traits
            using difference_type = std::ptrdiff_t;
            // c++ iterator traits
            using value_type = T;
            // c++ iterator traits
            using reference = T&;
            // c++ iterator traits
            using pointer = T*;
        public:
            // ctor
            Iterator(T* c) noexcept : m_pTNode(c) {}
            // cpy ctor
            Iterator(const Self& itr) noexcept : m_pTNode(itr.m_pTNode) { }
            // operator =
            auto operator=(const Self& itr) noexcept ->Self& { m_pTNode = itr.m_pTNode; return *this; }
            //  ++itr
            auto operator++() noexcept ->Self { m_pTNode = static_cast<T*>(m_pTNode->next); return *this; }
            // itr++
            auto operator++(int) const noexcept->Self { Self itr{ m_pTNode }; return ++itr; }
            //  --itr
            auto operator--() noexcept ->Self { m_pTNode = static_cast<T*>(m_pTNode->prev); return *this; }
            // itr--
            auto operator--(int) const noexcept ->Self { Self itr{ m_pTNode }; return --itr; }
            // operator ==
            bool operator==(const Self& itr) const noexcept { return m_pTNode == itr.m_pTNode; }
            // operator !=
            bool operator!=(const Self& itr) const noexcept { return m_pTNode != itr.m_pTNode; }
            // operator *
            auto operator*() const noexcept -> T& { return *m_pTNode; }
            // operator *
            operator T*() const noexcept { return m_pTNode; }
        private:
            // node pointer
            T*          m_pTNode;
        };
        // reverse iterator
        class ReverseIterator {
            // self type
            using Self = ReverseIterator;
        public:
            // c++ iterator traits
            using iterator_category = std::bidirectional_iterator_tag;
            // c++ iterator traits
            using difference_type = std::ptrdiff_t;
            // c++ iterator traits
            using value_type = T;
            // c++ iterator traits
            using reference = T&;
            // c++ iterator traits
            using pointer = T*;
        public:
            // ctor
            ReverseIterator(T* c) noexcept : m_pTNode(c) {}
            // cpy ctor
            ReverseIterator(const Self& itr) noexcept : m_pTNode(itr.m_pTNode) { }
            // operator =
            auto operator=(const Self& itr) noexcept ->Self& { m_pTNode = itr.m_pTNode; return *this; }
            //  ++itr
            auto operator++() noexcept ->Self { m_pTNode = static_cast<T*>(m_pTNode->prev); return *this; }
            // itr++
            auto operator++(int) const noexcept ->Self { Self itr{ m_pTNode }; return ++itr; }
            //  --itr
            auto operator--() noexcept ->Self { m_pTNode = static_cast<T*>(m_pTNode->next); return *this; }
            // itr--
            auto operator--(int) const noexcept ->Self { Self itr{ m_pTNode }; return --itr; }
            // operator ==
            bool operator==(const Self& itr) const noexcept { return m_pTNode == itr.m_pTNode; }
            // operator !=
            bool operator!=(const Self& itr) const noexcept { return m_pTNode != itr.m_pTNode; }
            // operator *
            auto operator*() const noexcept -> T& { return *m_pTNode; }
            // operator *
            operator T*() const noexcept { return m_pTNode; }
        private:
            // node pointer
            T*          m_pTNode;
        };
    };
}

//#pragma interface

#include <cstddef>
#include <new>

namespace LongUI {
    /// <summary>
    /// ui object cannot new
    /// </summary>
    class CUINoMo {
    public:
        // no move
        //CUINoMo(CUINoMo&&) noexcept = delete;
        // mo copy
        //CUINoMo(const CUINoMo&) noexcept = delete;
        // ctor
        CUINoMo() noexcept = default;
        // no-exception new
        void*operator new(size_t) = delete;
        // no-exception new[]
        void*operator new[](size_t) = delete;
        // delete []
        void operator delete[](void*, size_t size) noexcept = delete;
        // delete object
        void operator delete(void* ptr) noexcept = delete;
        // nothrow new 
        void*operator new(size_t size, const std::nothrow_t&) noexcept = delete;
        // nothrow delete 
        void operator delete(void* ptr, const std::nothrow_t&) noexcept = delete;
    };
    /// <summary>
    /// ui object
    /// </summary>
    class CUIObject {
    public:
        // no-exception new
        void*operator new(size_t) = delete;
        // no-exception new[]
        void*operator new[](size_t) = delete;
        // delete []
        void operator delete[](void*, size_t size) noexcept = delete;
        // delete object
        void operator delete(void* ptr) noexcept;
        // nothrow new 
        void*operator new(size_t size, const std::nothrow_t&) noexcept;
        // nothrow delete 
        void operator delete(void* ptr, const std::nothrow_t&) noexcept;
    };
    /// <summary>
    /// ui object
    /// </summary>
    class CUISmallObject {
    public:
        // no-exception new
        void*operator new(size_t) = delete;
        // no-exception new[]
        void*operator new[](size_t) = delete;
        // delete []
        void operator delete[](void*, size_t size) noexcept = delete;
        // delete object
        void operator delete(void* ptr) noexcept;
        // nothrow new 
        void*operator new(size_t size, const std::nothrow_t&) noexcept;
        // nothrow delete 
        void operator delete(void* ptr, const std::nothrow_t&) noexcept;
    };
    // updatable object
    //struct PCN_NOVTABLE IUIUpdatable { virtual void Update() noexcept = 0; };
    // destroyable object
    struct PCN_NOVTABLE IUIDestroyable { virtual void Destroy() noexcept = 0; };
}

#include <cstdint>

namespace LongUI {
    /// <summary>
    /// notice event type
    /// </summary>
    enum class NoticeEvent : uint32_t {
        // initialize
        Event_Initialize = 0,
        // refresh min size
        Event_RefreshBoxMinSize,
        // do default/access action
        Event_DoAccessAction,
        // show access key  [derived: 1/0 show/hide]
        Event_ShowAccessKey,
        // viewport/ uievent-to-parent only
        Event_UIEvent,
        // popup hoster only
        Event_PopupBegin,
        // popup hoster only
        Event_PopupEnd,
        // splitter drag
        Event_Splitter,
        // implicit radio group member checked
        Event_ImplicitGroupChecked,


        // ----------------------------
#if 0
        // timer event #0
        Event_Timer0,
        // timer event #1
        Event_Timer1,
        // timer event #2
        Event_Timer2,
        // timer event #3
        Event_Timer3,
#endif
    };
    /// <summary>
    /// event argument
    /// </summary>
    struct EventArg {
        // event type
        NoticeEvent     nevent;
        // derived used data
        uint32_t        derived;
    };
}

#include <cstdint>

namespace LongUI {
    /// <summary>
    /// gui event type
    /// </summary>
    /// <seealso cref="https://developer.mozilla.org/en-US/docs/Mozilla/Tech/XUL/Events"/>
    enum class GuiEvent : uint32_t {
        // [unknown]
        Event_Unknown = 0,

        // [onblur] The opposite of the focus event, the blur event is passed after an element loses the focus.
        Event_OnBlur,
        // [onfocus] called on focus
        Event_OnFocus,
        // [onclick] This event handler is called when the object is clicked. This event is also sent when the user double-clicks with the mouse.
        Event_OnClick,
        // [ondblclick][unsupport yet] This event handler is called when the object is double-clicked.
        Event_OnDblClick,


        // [onchange] An onchange attribute is an event listener to the object for the Event change.
        // - TextBox            When [pressed enter key, or killed-focus] if text changed
        // - Select List        When the selected item is changed
        // - Scale(Slider)      When value changed
        Event_OnChange,

        // [onselect] This event is sent to a listbox or tree when an item is selected.
        // - MenuList(ComboBox) When the item is selected
        //                    - [unsupported yet(same as oncommand?)]
        // - RadioGroup         When the item is selected
        //                    - [unsupported yet(same as oncommand?)]
        // - UITabBox           When the index is changed
        //                    - [unsupported yet(same as oncommand?)]
        Event_OnSelect,

        // [oncommand] This event handler is called when the command is activated. 
        // - RadioGroup         When the selected item changed
        // - Radio/Check Box    When the state is changed
        // - MenuList(ComboBox) When the item is changed
        // - MenuPopup          When the item is changed
        // - MenuItem           When the item is selected
        // - Button             When the button (lbtn) clicked
        // - UITabBox           When the index is changed
        Event_OnCommand,

        // [oninput] This event is sent when a user enters text in a textbox.
        // - TextBox            When text changed by user-input
        Event_OnInput,
    };
    // gui event, EventAccept: have no effect 
    struct EventGuiArg : EventArg {
        // ctor
        EventGuiArg(GuiEvent e) noexcept {
            this->nevent = NoticeEvent::Event_UIEvent;
            this->derived = static_cast<int32_t>(e);
        }
        // get event
        auto GetEvent() const noexcept {
            return static_cast<GuiEvent>(this->derived) ;
        }
    };
}


#include <cassert>

namespace LongUI {
    // Function Connection 
    struct Conn {
        // handle
        const uintptr_t     handle;
        // disconnect
        void Disconnect() noexcept;
    };
    // detail namespace
    namespace detail {
        // func base
        template<typename Result, typename ...Args>
        class func : public CUISmallObject {
        public:
            // ctor
            func(
                Result(*call)(void*, Args&&...) noexcept,
                void(*dtor)(void*) noexcept,
                func** perv
            ) noexcept : call_ptr(call), dtor_ptr(dtor), prev_funcpp(perv){}
            // call
            auto call(Args&&... args) noexcept ->Result {
                if (this->chain) this->chain->call(std::forward<Args>(args)...);
                return this->call_ptr(this, std::forward<Args>(args)...);
            }
            // dtor
            ~func() noexcept { delete this->chain; dtor_ptr(this); };
            // call ptr
            Result(*  const call_ptr)(void*, Args&&...) noexcept;
            // dtor ptr
            void(*    const dtor_ptr)(void*) noexcept;
            // prev_funcpp
            func**          prev_funcpp = nullptr;
            // call chain [next node]
            func*           chain = nullptr;
        };
        // TODO: function pointer

        // func derived 
        template<typename Func, typename Result, typename ...Args>
        class func_ex final : public func<Result, Args...> {
            // cannot be function pointer
            static_assert(
                std::is_pointer<Func>::value == false,
                "cannot be function pointer because of type-safety"
                );
            // alignof Func cannot over double
            static_assert(
                alignof(Func) <= alignof(double),
                "alignof Func cannot over double because of memory-alloc function"
                );
            // T data
            typename std::aligned_storage<sizeof(Func), alignof(Func)>::type  m_buffer;
            // call pointer
            static Result call(void* ptr, Args&&... args) noexcept {
                auto& fobj = reinterpret_cast<Func&>(static_cast<func_ex*>(ptr)->m_buffer);
                return fobj(std::forward<Args>(args)...);
            }
        public:
            // super class
            using super_t = func<Result, Args...>;
            // ctor
            func_ex(Func&&x, super_t** p) noexcept : super_t(call, 
                ctor_dtor<Func>::delete_obj_ptr().ptr, p) {
                ctor_dtor<Func>::create(&m_buffer, std::move(x));
            }
        };
        // type helper
        template<typename Func> struct type_helper {
            using type = Func;
        };
        // type helper
        template<typename Result, typename ...Args> struct type_helper<Result(Args...)> {
            using type = Result(*)(Args...);
        };
        // uifunc helper
        struct uifunc_helper {
            // add chain, specialization for reducing code size
            static auto add_chain_helper(GuiEventListener&, GuiEventListener&&) noexcept -> uintptr_t;
            // add chain
            template<typename T> static inline auto add_chain(T& a, T&& b) noexcept {
                return add_chain_helper(
                    reinterpret_cast<GuiEventListener&>(a), 
                    std::move(reinterpret_cast<GuiEventListener&>(b))
                );
            }
        };
    }
    // UI Function, lightweight and chain-call-able version std::function, and could be disconnect
    template<typename Result, typename... Args>
    class CUIFunction<Result(Args...)> {
    public:
        // friend
        friend detail::uifunc_helper;
        // this type
        using Self = CUIFunction<Result(Args...)>;
        // func_t
        using FuncT = detail::func<Result, Args...>;
    private:
        // RealFunc pointer
        FuncT *      m_pFunction = nullptr;
        // dispose
        void dispose() noexcept { delete m_pFunction; }
    public:
        // Ok
        bool IsOK() const noexcept { return !!m_pFunction; }
        // dtor
        ~CUIFunction() noexcept { this->dispose(); }
        // ctor
        CUIFunction() noexcept = default;
        // move ctor
        CUIFunction(Self&& obj) noexcept : m_pFunction(obj.m_pFunction) {
            assert(&obj != this && "bad move"); obj.m_pFunction = nullptr;
        };
        // no copy ctor
        CUIFunction(const Self&) = delete;
        // operator =
        Self&operator=(const Self &x) noexcept = delete;
        // add call chain
        Self&operator += (Self&& chain) noexcept { this->AddCallChain(std::move(chain)); return *this; }
        // add call chain
        template<typename Func>
        Self& operator += (const Func &x) noexcept { this->AddCallChain(std::move(CUIFunction(x))); return *this; }
        // operator =
        template<typename Func> Self& operator=(const Func &x) noexcept {
            this->dispose(); m_pFunction = new(std::nothrow) detail::
                func_ex<typename detail::type_helper<Func>::type, Result, Args...>(x); return *this;
        }
        // operator =
        Self& operator=(Self&& x) noexcept {
            this->dispose(); std::swap(m_pFunction, x.m_pFunction); return *this;
        }
        // ctor with func
        template<typename Func> CUIFunction(Func&& f) noexcept : m_pFunction(
            new(std::nothrow) detail::func_ex<typename detail::type_helper<Func>::type, Result, Args...>(std::move(f), &m_pFunction)) { }
        // () operator
        auto operator()(Args&&... args) const noexcept -> Result {
            assert(m_pFunction && "bad call or oom");
            return m_pFunction ? m_pFunction->call(std::forward<Args>(args)...) : Result();
        }
        // add call chain with exist call chain, return first connection of chain
        Conn AddCallChain(Self&& chain) noexcept { return { detail::uifunc_helper::add_chain(*this, std::move(chain)) }; }
        // add call chain with callable obj(except self), return connection
        template<typename Func>
        Conn AddCallChain(const Func &x) noexcept { return { detail::uifunc_helper::add_chain(*this, Self{ x }) }; }
    };
}

#ifndef LUI_DISABLE_STYLE_SUPPORT

#include <cstdint>
#include <cassert>

// simpac namespace
namespace SimpAC {
    // Func Value
    struct FuncValue;
}

namespace LongUI {
    /// <summary>
    /// type of value
    /// </summary>
    enum class ValueType : uint32_t {
        // new one
        Type_NewOne = 0xfffffffful,
        // unknown
        Type_Unknown = 0,

        // [Position] overflow-x
        Type_PositionOverflowX,
        // [Position] overflow-y
        Type_PositionOverflowY,
        // [Position] left 
        Type_PositionLeft,
        // [Position] top 
        Type_PositionTop,

        // [Dimension] width
        Type_DimensionWidth,
        // [Dimension] height
        Type_DimensionHeight,
        // [Dimension] min-width
        Type_DimensionMinWidth,
        // [Dimension] min-height
        Type_DimensionMinHeight,
        // [Dimension] max-width
        Type_DimensionMaxWidth,
        // [Dimension] max-height
        Type_DimensionMaxHeight,

        // [Box] flex
        Type_BoxFlex,

        // [Margin] top
        Type_MarginTop,
        // [Margin] right
        Type_MarginRight,
        // [Margin] bottom
        Type_MarginBottom,
        // [Margin] left
        Type_MarginLeft,

        // [Padding] top
        Type_PaddingTop,
        // [Padding] right
        Type_PaddingRight,
        // [Padding] bottom
        Type_PaddingBottom,
        // [Padding] left
        Type_PaddingLeft,

        // [Border] top-width
        Type_BorderTopWidth,
        // [Border] right-width
        Type_BorderRightWidth,
        // [Border] bottom-width
        Type_BorderBottomWidth,
        // [Border] left-width
        Type_BorderLeftWidth,
        // [Border] style
        Type_BorderStyle,
        // [Border] color
        Type_BorderColor,
        // [Border] radius
        Type_BorderRadius,
        // [Border] image-source
        Type_BorderImageSource,
        // [Border] image-slice         : bool + [SliceRect]
        Type_BorderImageSlice,
        // [Border] image-repeat
        Type_BorderImageRepeat,


        // [Background] color
        Type_BackgroundColor,
        // [Background] image
        Type_BackgroundImage,
        // [Background] attachment
        Type_BackgroundAttachment,
        // [Background] repeat
        Type_BackgroundRepeat,
        // [Background] clip
        Type_BackgroundClip,
        // [Background] origin 
        Type_BackgroundOrigin,

        // [Transition] duration
        Type_TransitionDuration,
        // [Transition] timing funtion
        Type_TransitionTimingFunc,

        // [Text] color
        Type_TextColor,
        // [Text] align
        Type_TextAlign,
        // [-Webkit-Text] stroke-width
        Type_WKTextStrokeWidth,
        // [-Webkit-Text] stroke-color
        Type_WKTextStrokeColor,

        // [Font] size
        Type_FontSize,
        // [Font] style
        Type_FontStyle,
        // [Font] stretch
        Type_FontStretch,
        // [Font] weight
        Type_FontWeight,
        // [Font] family
        Type_FontFamily,
        // [LongUI] appearance
        Type_LUIAppearance,

        // last single property
        SINGLE_LAST = Type_LUIAppearance,

        // [ShortHand] overflow
        Type_ShortHandOverflow,
        // [ShortHand] -webkit-text-stroke 
        Type_ShortHandWKTextStroke,
        // [ShortHand] margin
        Type_ShortHandMargin,
        // [ShortHand] padding
        Type_ShortHandPadding,
        // [ShortHand] border-width
        Type_ShortHandBorderWidth,
    };
    // value easy type
    enum class ValueEasyType : int8_t {
        // no animation
        Type_NoAnimation = 0,
        // float
        Type_Float,
        // color
        Type_Color,
        // size
        Type_Size,
    };
    // union 4
    union UniByte4 {
        // u32 data
        uint32_t    u32;
        // i32 data
        int32_t     i32;
        // u16 data
        uint16_t    word;
        // single float data
        float       single;
        // byte data
        uint8_t     byte;
        // boolean data
        bool        boolean;
    };
    // union 8
    union UniByte8 {
        // u32 data
        uint32_t    dword[2];
        // i32 data
        int32_t     i32[2];
        // u16 data
        uint16_t    word[4];
        // i16 data
        int16_t     i16[4];
        // single float data
        float       single[2];
        // double float data
        //double      double_;
        // byte data
        uint8_t     byte[8];
        // boolean data
        bool        boolean[8];
        // u8 string data
        const char* strptr;
    };
    static_assert(sizeof(UniByte8) == sizeof(double), "same!");
    /// <summary>
    /// value of style sheet
    /// </summary>
    struct SSValue {
        // type of value
        ValueType       type;
        // data
        UniByte4        data4;
        // data
        UniByte8        data8;
    };
    // UniByte8 to SliceRect
    void UniByte8ToSliceRect(UniByte8 data, float out[4]) noexcept;
    // SliceRect to UniByte8
    void SliceRectToUniByte8(const float rect[4], UniByte8& out) noexcept;
    // get easy type
    auto GetEasyType(ValueType) noexcept->ValueEasyType;
    // is image
    bool IsImageType(ValueType) noexcept;
    // init states buffer
    void InitDefaultState(UniByte4[], UniByte8[]) noexcept;
    // u8view to value type
    auto U8View2ValueType(U8View view) noexcept->ValueType;
    // make value
    void ValueTypeMakeValue(
        ValueType ex,
        uint32_t value_len,
        const SimpAC::FuncValue values[],
        void* values_write
    ) noexcept;
}

#endif



namespace LongUI {
    /// <summary>
    /// orientation
    /// </summary>
    enum AttributeOrient : bool {
        /// <summary>
        /// The orient horizontal
        /// </summary>
        Orient_Horizontal = false,
        /// <summary>
        /// The orient vertical
        /// </summary>
        Orient_Vertical = true,
    };
    /// <summary>
    /// attachment
    /// </summary>
    enum AttributeAttachment : bool {
        /// <summary>
        /// The attachment scroll
        /// </summary>
        Attachment_Scroll = false,
        /// <summary>
        /// The attachment fixed
        /// </summary>
        Attachment_Fixed = true,
    };
    /// <summary>
    /// direction
    /// </summary>
    enum AttributeDir : bool {
        /// <summary>
        /// The normal direction
        /// </summary>
        Dir_Normal = false,
        /// <summary>
        /// The reverse direction
        /// </summary>
        Dir_Reverse = true,
    };
    /// <summary>
    /// pack
    /// </summary>
    enum AttributePack : uint8_t {
        /// <summary>
        /// Child elements are placed starting from the left or top edge 
        /// of the box.If the box is larger than the total size of the 
        /// children, the extra space is placed on the right or bottom side.
        /// </summary>
        Pack_Start = 0,

        /// <summary>
        /// Extra space is split equally along each side of the child 
        /// elements, resulting the children being placed in the center of the box.
        /// </summary>
        Pack_Center,

        /// <summary>
        /// Child elements are placed on the right or bottom edge of 
        /// the box.If the box is larger than the total size of the 
        /// children, the extra space is placed on the left or top side.
        /// </summary>
        Pack_End
    };
    /// <summary>
    /// align
    /// </summary>
    enum AttributeAlign : uint8_t {
        /// <summary>
        /// 尽可能扩大侧轴
        /// This is the default value.The child elements are stretched to
        /// fit the size of the box.For a horizontal box, the children are
        /// stretched to be the height of the box.For a vertical box, the
        /// children are stretched to be the width of the box.
        ///
        /// if child element was fixed in other orientation, same as 'start'
        /// </summary>
        Align_Stretcht = 0,
        /// <summary>
        /// 向主轴起点对齐
        /// Child elements are aligned starting from the left or top 
        /// edge of the box.If the box is larger than the total size of 
        /// the children, the extra space is placed on the right or bottom side.
        /// </summary>
        Align_Start,
        /// <summary>
        /// 向主轴中央对齐
        /// Extra space is split equally along each side of the child elements, 
        /// resulting in the children being placed in the center of the box.
        /// </summary>
        Align_Center,
        /// <summary>
        /// 向主轴终点对齐
        /// Child elements are placed on the right or bottom edge of the 
        /// box.If the box is larger than the total size of the children, 
        /// the extra space is placed on the left or top side.
        /// </summary>
        Align_End,
        /// <summary>
        /// 向主轴基线对齐
        /// This value applies to horizontally oriented
        /// boxes only.It  causes the child elements to be aligned so that
        /// their text labels are lined up.
        /// </summary>
        Align_Baseline,
    };
    /// <summary>
    /// repeat 2-attr: [high-4bit(y) low-4bit(x)]
    /// </summary>
    enum AttributeRepeat : uint8_t {
        Repeat_Repeat = 0,                  // *-repeat
        Repeat_Space,                       // *-repeat
        Repeat_Round,                       // *-repeat
        Repeat_NoRepeat,                    // background-repeat
        Repeat_Stretch = Repeat_NoRepeat,   // border-image-repeat
        // ---------------
        Repeat_RepeatXOnly = Repeat_NoRepeat << 4 | Repeat_Repeat,
        Repeat_RepeatYOnly = Repeat_Repeat << 4 | Repeat_NoRepeat,
        Repeat_Stretch2 = Repeat_Stretch << 4 | Repeat_Stretch,
    };
    /// <summary>
    /// repeat for image
    /// </summary>
    enum AttributeImageRepeat : uint8_t {
        IRepeat_Stretch = 0,
        IRepeat_Repeat,
        IRepeat_Round,
        IRepeat_Space,
    };
    /// <summary>
    /// aligned box 
    /// </summary>
    enum AttributeBox : uint8_t {
        Box_BorderBox = 0,
        Box_PaddingBox,
        Box_ContentBox,
        BOX_COUNT,
    };
    /// <summary>
    /// overflow
    /// </summary>
    enum AttributeOverflow : uint8_t {
        Overflow_Auto = 0,      // & 1 == 0
        Overflow_Hidden,        // & 1 == 1
        Overflow_Scroll,        // & 1 == 0
        Overflow_Visible,       // & 1 == 1
    };
    /// <summary>
    /// border style 
    /// </summary>
    enum AttributeBStyle : uint8_t {
        Style_None = 0,
        Style_Solid,
        Style_Dotted,
        Style_Dashed,
        Style_Double,
        Style_Groove,
        Style_Ridge,
        Style_Inset,
        Style_OutSet,
    };
    /// <summary>
    /// appearance attr
    /// </summary>
    enum AttributeAppearance : uint8_t {
        Appearance_NotSet = uint8_t(-1),    // init value
        Appearance_None = 0,                // [none]
        Appearance_Radio,                   // [radio]
        Appearance_Button,                  // [button]
        Appearance_Resizer,                 // [resizer]
        Appearance_CheckBox,                // [checkbox]
        Appearance_MenuRadio,               // [menuradio]
        Appearance_MenuCheckBox,            // [menucheckbox]
        Appearance_ToolBarButton,           // [toolbarbutton]
        Appearance_ScrollBarButtonUp,       // [scrollbarbutton-up]
        Appearance_ScrollBarButtonRight,    // [scrollbarbutton-right]
        Appearance_ScrollBarButtonDown,     // [scrollbarbutton-down]
        Appearance_ScrollBarButtonLeft,     // [scrollbarbutton-left]
        Appearance_ScrollbarThumbH,         // [scrollbarthumb-horizontal]
        Appearance_ScrollbarThumbV,         // [scrollbarthumb-vertical]
        Appearance_ScrollbarTrackH,         // [scrollbartrack-horizontal]
        Appearance_ScrollbarTrackV,         // [scrollbartrack-vertical]
        Appearance_MenuSeparator,           // [menuseparator]
        Appearance_MenuArrow,               // [menuarrow]
        Appearance_Separator,               // [separator]
        Appearance_CheckBoxContainer,       // [checkbox-container]
        Appearance_ScaleH,                  // [scale-horizontal]
        Appearance_ScaleV,                  // [scale-vertical]
        Appearance_ScaleThumbH,             // [scalethumb-horizontal]
        Appearance_ScaleThumbV,             // [scalethumb-vertical]
        Appearance_ProgressBarH,            // [progressbar]
        Appearance_ProgressBarV,            // [progressbar-vertical]
        Appearance_ProgressChunkH,          // [progresschunk]
        Appearance_ProgressChunkV,          // [progresschunk-vertical]
        Appearance_ListBox,                 // [listbox]
        Appearance_StatusBar,               // [statusbar]
        Appearance_StatusBarPanel,          // [statusbarpanel]
        Appearance_GroupBox,                // [groupbox]
        Appearance_Caption,                 // undefined in xul
        Appearance_TreeHeaderCell,          // [treeheadercell]
        Appearance_TreeTwisty,              // [treetwisty]
        Appearance_DropDownMarker,          // used for menu list drop down marker
        Appearance_ListItem,                // [listitem]
        Appearance_MenuItem,                // [menuitem]
        Appearance_Tab,                     // [tab]
        Appearance_TabPanels,               // [tabpanels]
        Appearance_TextField,               // [textfield]
    }; 
    /// <summary>
    /// select type
    /// </summary>
    enum AttributeSeltype : uint8_t {
        Seltype_Single = 0,
        Seltype_Multiple,
        Seltype_Cell,
        Seltype_Text,
    };
    /// <summary>
    /// pseudo
    /// </summary>
    enum class PseudoType : uint8_t {
        Type_NoPseudo = 0,
        Type_Disabled,
        Type_Active,
        Type_Hover,
        Type_Focus,
        Type_Checked,
        Type_Indeterminate,
    };
    /// <summary>
    /// unit of value
    /// </summary>
    enum class ValueUnit : uint32_t {
        // unknown
        Unit_Unknown = 0,
        // auto
        Unit_Auto,
        // argb
        Unit_ARGB,
        // pixels
        Unit_Pixels,
        // percentage%
        Unit_Percentage,
    };
    // BKDR Hash Function
    auto BKDRHash(const char* a, const char* b) noexcept->uint32_t;
    // Hash find index
    auto Uint32FindIndex(const uint32_t[], uint32_t len, uint32_t code) noexcept->uint32_t;
    // parse the attribute
    struct AttrParser {
        // box
        static auto Box(U8View) noexcept->AttributeBox;
        // view to align
        static auto Align(U8View) noexcept->AttributeAlign;
        // view to pack
        static auto Pack(U8View) noexcept->AttributePack;
        // view to seltype
        static auto Seltype(U8View) noexcept->AttributeSeltype;
        // view to overflow
        static auto Overflow(U8View) noexcept->AttributeOverflow;
        // view to appearance
        static auto Appearance(U8View) noexcept->AttributeAppearance;
        // view to repeat
        static auto Repeat2(U8View, U8View) noexcept ->AttributeRepeat;
    };
}

#include <cstdint>

// ui namespace
namespace LongUI{
    /// <summary>
    /// text-align
    /// </summary>
    enum AttributeTextAlign : uint8_t {
        TAlign_Start = 0,
        TAlign_End,
        TAlign_Center,
        TAlign_Justified,
        // ---------------
        TAlign_Left = TAlign_Start,
        TAlign_Right = TAlign_End,
    };

    /// <summary>
    /// font weight
    /// </summary>
    enum AttributeFontWeight : uint16_t {
        /// <summary>
        /// Predefined font weight : Thin (100).
        /// </summary>
        Weight_Thin = 100,

        /// <summary>
        /// Predefined font weight : Extra-light (200).
        /// </summary>
        Weight_ExtraLight = 200,

        /// <summary>
        /// Predefined font weight : Light (300).
        /// </summary>
        Weight_Light = 300,

        /// <summary>
        /// Predefined font weight : Normal (400).
        /// </summary>
        Weight_Normal = 400,

        /// <summary>
        /// Predefined font weight : Medium (500).
        /// </summary>
        Weight_Medium = 500,

        /// <summary>
        /// Predefined font weight : Semi-bold (600).
        /// </summary>
        Weight_SemiBold = 600,

        /// <summary>
        /// Predefined font weight : Bold (700).
        /// </summary>
        Weight_Bold = 700,

        /// <summary>
        /// Predefined font weight : Extra-bold (800).
        /// </summary>
        Weight_ExtraBold = 800,

        /// <summary>
        /// Predefined font weight : Heavy (900).
        /// </summary>
        Weight_Heavy = 900,
    };
    /// <summary>
    /// font style
    /// </summary>
    enum AttributeFontStyle : uint8_t {
        /// <summary>
        /// Font slope style : Normal.
        /// </summary>
        Style_Normal = 0,

        /// <summary>
        /// Font slope style : Oblique.
        /// </summary>
        Style_Oblique,

        /// <summary>
        /// Font slope style : Italic.
        /// </summary>
        Style_Italic
    };

    /// <summary>
    /// font stretch
    /// </summary>
    enum AttributeFontStretch : uint8_t {
        /// <summary>
        /// Predefined font stretch : Not known (0).
        /// </summary>
        Stretch_Undefined = 0,

        /// <summary>
        /// Predefined font stretch : Ultra-condensed (1).
        /// </summary>
        Stretch_UltraCondensed = 1,

        /// <summary>
        /// Predefined font stretch : Extra-condensed (2).
        /// </summary>
        Stretch_ExtraCondensed = 2,

        /// <summary>
        /// Predefined font stretch : Condensed (3).
        /// </summary>
        Stretch_Condensed = 3,

        /// <summary>
        /// Predefined font stretch : Semi-condensed (4).
        /// </summary>
        Stretch_SemiCondensed = 4,

        /// <summary>
        /// Predefined font stretch : Normal (5).
        /// </summary>
        Stretch_Normal = 5,

        /// <summary>
        /// Predefined font stretch : Semi-expanded (6).
        /// </summary>
        Stretch_SemiExpanded = 6,

        /// <summary>
        /// Predefined font stretch : Expanded (7).
        /// </summary>
        Stretch_Expanded = 7,

        /// <summary>
        /// Predefined font stretch : Extra-expanded (8).
        /// </summary>
        Stretch_ExtraExpanded = 8,

        /// <summary>
        /// Predefined font stretch : Ultra-expanded (9).
        /// </summary>
        Stretch_UltraExpanded = 9
    };

    // parse the attribute
    struct TFAttrParser {
        // font-style
        static auto Style(U8View) noexcept->AttributeFontStyle;
        // font-weight
        static auto Weight(U8View) noexcept->AttributeFontWeight;
        // font stretch
        static auto Stretch(U8View) noexcept->AttributeFontStretch;
        // Align
        static auto TextAlign(U8View) noexcept->AttributeTextAlign;
    }; 
}

// c++
#include <cstdint>
#include <climits>
// ui

// ui
namespace LongUI {
    // RGBA(ABGR in little-endian system, like x86)
    union RGBA {
        // primitive type
        using type = uint32_t;
        // primitive data
        type                primitive;
        // right byte order
        struct  { uint8_t   r, g, b, a; } u8;
    };
    // ColorRGBA
    enum ColorRGBA : RGBA::type;
    // ColorF basic interface
    //struct ColorFBI {  };
    // colorf
    namespace helper {
        // rgba
        constexpr inline RGBA::type rgba(int r, int g, int b, int a) noexcept {
            return 
                RGBA::type(RGBA::type(r) << (CHAR_BIT * (3 - color_order::r))) |
                RGBA::type(RGBA::type(g) << (CHAR_BIT * (3 - color_order::g))) |
                RGBA::type(RGBA::type(b) << (CHAR_BIT * (3 - color_order::b))) |
                RGBA::type(RGBA::type(a) << (CHAR_BIT * (3 - color_order::a))) ;
        }
        // rgba
        constexpr inline RGBA::type rgba(uint32_t value) noexcept {
            using c = helper::color_order;
            return
                uint32_t((value >> (CHAR_BIT * 0)) & 0xfful) << (CHAR_BIT * c::r) |
                uint32_t((value >> (CHAR_BIT * 1)) & 0xfful) << (CHAR_BIT * c::g) |
                uint32_t((value >> (CHAR_BIT * 2)) & 0xfful) << (CHAR_BIT * c::b) |
                uint32_t((value >> (CHAR_BIT * 3)) & 0xfful) << (CHAR_BIT * c::a);
        }
    }
    // ColorF
    struct ColorF {
        // rgba
        float r, g, b, a;
        // to rgba
        auto ToRGBA() const noexcept->RGBA;
        // from rgba in run-time
        static void FromRGBA_RT(ColorF& c, RGBA) noexcept;
        // from rgba in compile-time
        template<RGBA::type C>
        static inline ColorF FromRGBA_CT() noexcept {
            ColorF color;
            constexpr float r = GetFloat<0, C>();
            constexpr float g = GetFloat<1, C>();
            constexpr float b = GetFloat<2, C>();
            constexpr float a = GetFloat<3, C>();
            color.r = r; color.g = g; color.b = b; color.a = a;
            return color;
        }
        // get float
        template<RGBA::type SHIFT, RGBA::type COLOR>
        static inline constexpr auto GetFloat() noexcept -> float {
            return static_cast<float>((COLOR & (0xfful << (8 * SHIFT))) >> (8 * SHIFT)) / 255.f;
        }
    };
    // mix color
    auto Mix(const ColorF& from, const ColorF& to, float x) noexcept->ColorF;
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cstdint>

// longui namespace
namespace LongUI {
    /// <summary>
    /// Result code
    /// </summary>
    struct Result {
        // code
        std::int32_t    code;
        // Commonly used code list
        enum CommonResult : int32_t { 
            RS_OK           = (int32_t)0x00000000, // Operation successful
            RS_FALSE        = (int32_t)0x00000001, // Operation successful
            RE_NOTIMPL      = (int32_t)0x80004001, // Not implemented
            RE_NOINTERFACE  = (int32_t)0x80004002, // No such interface supported
            RE_POINTER      = (int32_t)0x80004003, // Pointer that is not valid
            RE_ABORT        = (int32_t)0x80004004, // Operation aborted
            RE_FAIL         = (int32_t)0x80004005, // Unspecified failure
            RE_FILENOTFOUND = (int32_t)0x80070002, // File not found
            RE_UNEXPECTED   = (int32_t)0x8000FFFF, // Unexpected failure
            RE_ACCESSDENIED = (int32_t)0x80070005, // General access denied error
            RE_HANDLE       = (int32_t)0x80070006, // Handle that is not valid
            RE_OUTOFMEMORY  = (int32_t)0x8007000E, // Failed to allocate necessary memory
            RE_INVALIDARG   = (int32_t)0x80070057, // One or more arguments are not valid
        };
        // operator bool
        operator bool() const noexcept { return code >= 0; }
        // operator !
        bool operator !() const noexcept { return code < 0; }
        // get system last error
        static auto GetSystemLastError() noexcept ->Result;
    };
    // basic dpi(100%)
    enum : uint32_t { BASIC_DPI = 96, };
    // Script define
    struct ScriptUI {
        // script data, maybe binary data maybe string
        const uint8_t*      script;
        // size of it
        size_t              size;
    };
    // point
    template<typename T> struct Point { T x; T y; };
    // rect
    template<typename T> struct Rect { T left; T top; T right; T bottom; };
    // rect w/h model
    template<typename T> struct RectWH { T left; T top; T width; T height; };
    // size
    template<typename T> struct Size { T width; T height; };
    // Point2U
    using Point2U = Point<uint32_t>;
    // Point2F
    using Point2F = Point<float>;
    // Point2L
    using Point2L = Point<std::int32_t>;
    // Vector2F
    struct Vector2F { float x; float y; };
    // Vector3F
    struct Vector3F { float x; float y; float z; };
    // Vector4F
    struct Vector4F { float x; float y; float z; float w; };
    // RectF
    using RectF = Rect<float>;
    // RectU
    using RectU = Rect<uint32_t>;
    // RectL
    using RectL = Rect<std::int32_t>;
    // RectWHF
    using RectWHF = RectWH<float>;
    // RectWHU
    using RectWHU = RectWH<uint32_t>;
    // RectWHL
    using RectWHL = RectWH<std::int32_t>;
    // Size2F
    using Size2F = Size<float>;
    // Size2U
    using Size2U = Size<uint32_t>;
    // Size2U
    using Size2L = Size<int32_t>;
    // Matrix3X2F
    struct Matrix3X2F { float _11, _12, _21, _22, _31, _32; };
    // Matrix4X4F
    struct Matrix4X4F { float m[4][4]; };
#ifndef NDEBUG
    // debug display format float: x.xx
    struct DDFFloat2 { float f; };
    // debug display format float: x.xxx
    struct DDFFloat3 { float f; };
    // debug display format float: x.xxxx
    struct DDFFloat4 { float f; };
    // get float1
    static inline auto Get2() noexcept ->DDFFloat2 { return{ 0.0f }; }
    // get float1
    static inline auto Get3() noexcept ->DDFFloat3 { return{ 0.0f }; }
    // get float1
    static inline auto Get4() noexcept ->DDFFloat4 { return{ 0.0f }; }
#endif
    // Ellipse
    struct Ellipse { Point2F point; float radius_x; float radius_y; };
    // transform point
    auto TransformPoint(const Matrix3X2F& matrix, Point2F point) noexcept->Point2F;
    // transform point - inverse
    auto TransformPointInverse(const Matrix3X2F& matrix, Point2F point) noexcept->Point2F;
    // is overlap?
    bool IsOverlap(const RectF& a, const RectF& b) noexcept;
    // is include?
    bool IsInclude(const RectF& a, const RectF& b) noexcept;
    // is include?
    bool IsInclude(const RectF& a, const Point2F& b) noexcept;
    // is same?
    bool IsSame(const RectF& a, const RectF& b) noexcept;
    // gui float same
    bool IsSameInGuiLevel(float a, float b) noexcept;
    // gui point same
    bool IsSameInGuiLevel(Point2F a, Point2F b) noexcept;
    // get area
    auto GetArea(const RectF& rect) noexcept -> float;
    // mix point
    auto Mix(Point2F from, Point2F to, float progress) noexcept ->Point2F;
    // mix rect
    auto Mix(const RectF& from, const RectF& to, float progress) noexcept;
    // round in gui level
    inline auto RoundInGuiLevel(float a) noexcept { return float(long(a + 0.5f)); }
    // round in gui level
    inline auto RoundInGuiLevel(double a) noexcept { return double(long(a + 0.5)); }
    // a && b
    inline bool operator &&(const RectF& a, const RectF& b) noexcept {
        return LongUI::IsOverlap(a, b);
    }
    // a == b
    inline bool operator ==(const RectF& a, const RectF& b) noexcept {
        return LongUI::IsSame(a, b);
    }
    // a != b
    inline bool operator !=(const RectF& a, const RectF& b) noexcept {
        return LongUI::IsSame(a, b);
    }
    // gui size same
    inline bool IsSameInGuiLevel(const Size2F& a, const Size2F& b) noexcept {
        return IsSameInGuiLevel(
            reinterpret_cast<const Point2F&>(a),
            reinterpret_cast<const Point2F&>(b)
        );
    }
    // point + oparator
    template<typename T> auto operator +(Point<T> a, Point<T> b) noexcept {
        return Point<T>{ a.x + b.x, a.y + b.y };
    }
    // point - oparator
    template<typename T> auto operator -(Point<T> a, Point<T> b) noexcept {
        return Point<T>{ a.x - b.x, a.y - b.y };
    }
}
//#pragma interface


namespace LongUI {
    /// <summary>
    /// gui style value host
    /// </summary>
    class PCN_NOVTABLE CUIStyleValue {
    protected:
        // virtual dtor
        virtual ~CUIStyleValue() noexcept = default;
    public:
        // set foreground color
        void SetFgColor(RGBA color) noexcept;
        // get foreground color
        auto GetFgColor() const noexcept->RGBA;
        // set text align
        void SetTextAlign(AttributeTextAlign) noexcept;
        // get text align
        auto GetTextAlign() const noexcept ->AttributeTextAlign;
    public:
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // set text stroke color
        void SetTextStrokeWidth(float width) noexcept;
        // set text stroke color
        void SetTextStrokeColor(RGBA color) noexcept;
        // set background clip
        void SetBgClip(AttributeBox clip) noexcept;
        // set background color
        void SetBgColor(RGBA color) noexcept;
        // set background image from resource id
        void SetBgImage_NCRC(uint32_t id) noexcept;
        // set background repeat
        void SetBgRepeat(AttributeRepeat ar) noexcept;
        // set background origin
        void SetBgOrigin(AttributeBox ab) noexcept;
        // set background attachment
        void SetBgAttachment(AttributeAttachment aa) noexcept;
        // set border style
        void SetBdStyle(AttributeBStyle style) noexcept;
        // set border color
        void SetBdColor(RGBA color) noexcept;
        // set border radius
        void SetBdRadius(Size2F radius) noexcept;
        // set border image source from resource id
        void SetBdImageSource_NCRC(uint32_t id) noexcept;
        // set border image slice
        void SetBdImageSlice(const RectF& slice, bool fill) noexcept;
        // set border image repeat
        void SetBdImageRepeat(AttributeRepeat repeat) noexcept;
        // set font size
        void SetFontSize(float size) noexcept;
        // set font style
        void SetFontStyle(AttributeFontStyle style) noexcept;
        // set font family(maybe you should use GetUniqueText)
        void SetFontFamily(const char* family) noexcept;
        // set font weight
        void SetFontWeight(AttributeFontWeight weight) noexcept;
        // set font stretch
        void SetFontStretch(AttributeFontStretch stretch) noexcept;
    public:
        // set text stroke color
        auto GetTextStrokeWidth() const noexcept->float;
        // set text stroke color
        auto GetTextStrokeColor() const noexcept->RGBA;
        // get background clip
        auto GetBgClip() const noexcept->AttributeBox;
        // get background color
        auto GetBgColor() const noexcept->RGBA;
        // get background image resource id
        auto GetBgImage_NCRC() const noexcept->uint32_t;
        // get background repeat
        auto GetBgRepeat() const noexcept->AttributeRepeat;
        // get background origin
        auto GetBgOrigin() const noexcept->AttributeBox;
        // get border style
        auto GetBdStyle() const noexcept->AttributeBStyle;
        // get border color
        auto GetBdColor() const noexcept->RGBA;
        // get border radius
        auto GetBdRadius() const noexcept->Size2F;
        // get border image source [resource id]
        auto GetBdImageSource_NCRC() const noexcept ->uint32_t;
        // get border image slice
        bool GetBdImageSlice(RectF& output) const noexcept;
        // get border image repeat
        auto GetBdImageRepeat() const noexcept->AttributeRepeat;
        // get font size
        auto GetFontSize() const noexcept->float;
        // get font style
        auto GetFontStyle() const noexcept->AttributeFontStyle;
        // get font family
        auto GetFontFamily() const noexcept->const char*;
        // get font weight
        auto GetFontWeight() const noexcept->AttributeFontWeight;
        // get font stretch
        auto GetFontStretch() const noexcept->AttributeFontStretch;
    public:
        // set margin top
        void SetMarginTop(float value) noexcept;
        // set margin left
        void SetMarginLeft(float value) noexcept;
        // set margin right
        void SetMarginRight(float value) noexcept;
        // set margin bottom
        void SetMarginBottom(float value) noexcept;
        // set padding top
        void SetPaddingTop(float value) noexcept;
        // set padding left
        void SetPaddingLeft(float value) noexcept;
        // set padding right
        void SetPaddingRight(float value) noexcept;
        // set padding bottom
        void SetPaddingBottom(float value) noexcept;
        // set border top width
        void SetBorderTop(float value) noexcept;
        // set border left width
        void SetBorderLeft(float value) noexcept;
        // set border right width
        void SetBorderRight(float value) noexcept;
        // set border bottom width
        void SetBorderBottom(float value) noexcept;
    private:
        // after box changed
        void after_box_changed();
#endif
    };
}

//#pragma interface
#include <utility>

namespace LongUI {
    /// <summary>
    /// gui event host
    /// </summary>
    class PCN_NOVTABLE CUIEventHost : public CUIStyleValue {
        // function node
        struct FunctionNode;
        // add gui event listener
        Conn add_gui_event_listener(GuiEvent, GuiEventListener&&) noexcept;
    public:
        // event string view to event id
        static auto StrToId(U8View view) noexcept ->GuiEvent;
        // add gui event listener
        template<typename Callable>
        inline Conn AddGuiEventListener(GuiEvent e, Callable&& call) noexcept {
            //static_assert(
            //    std::is_same<E, const char*>::value ||
            //    std::is_same<E, U8View>::value ||
            //    std::is_same<E, GuiEvent>::value,
            //    "e must be 'const char*' or 'GuiEvent'"
            //    );
            GuiEventListener listener{ std::move(call) };
            return this->add_gui_event_listener(e, std::move(listener));
        }
        // add gui event listener const ref overload
        template<typename Callable>
        inline Conn AddGuiEventListener(GuiEvent e, const Callable& call) noexcept {
            //static_assert(
            //    std::is_same<E, const char*>::value ||
            //    std::is_same<E, U8View>::value ||
            //    std::is_same<E, GuiEvent>::value,
            //    "e must be 'const char*' or 'GuiEvent'"
            //    );
            Callable mcall = call;
            GuiEventListener listener{ std::move(mcall) };
            return this->add_gui_event_listener(e, std::move(listener));
        }
        // trigger event
        virtual auto TriggerEvent(GuiEvent event) noexcept ->EventAccept;
        // set script
        void SetScript(GuiEvent, U8View) noexcept;
    private:
        // find event
        auto find_event(GuiEvent) const noexcept->FunctionNode*;
        // require event
        auto require_event(GuiEvent) noexcept->FunctionNode*;
    protected:
        // ctor
        CUIEventHost() noexcept {}
        // dtor
        virtual ~CUIEventHost() noexcept;
    private:
        // head function node
        FunctionNode*           m_pFuncNode = nullptr;
    };
}

// ui

// ui namespace
namespace LongUI {
    // const short string
    class CUIConstShortString {
    public:
        // self type
        //using Self = CUIConstShortString;
        // empty string
        static constexpr const char* EMPTY = "";
    public:
        // ctor
        CUIConstShortString() noexcept {}
        // dtor
        ~CUIConstShortString() noexcept { this->release(); }
        // c-style string
        auto c_str() const noexcept { return m_string; }
        // is empty?
        bool empty() const noexcept { return m_string == EMPTY; }
        // operator with string view
        auto&operator=(U8View view) noexcept { this->set_view(view); return *this; }
    private:
        // set with string view
        void set_view(U8View view) noexcept;
        // release
        void release() noexcept;
    private:
        // data
        const char*         m_string = EMPTY;
    };
}


#include <cstdint>


namespace LongUI {
    /// <summary>
    /// normal input event
    /// </summary>
    enum class InputEvent : uint32_t {
        // event char
        Event_Char = 0,
        // event key
        Event_KeyDown,
#if 0
        // --------------------- Unified Input -----------------
        // event-left 
        Event_TurnLeft,
        // event-top
        Event_TurnUp,
        // event-right
        Event_TurnRight,
        // event-down
        Event_TurnDown,
        // event-next       : RB R1 TAB
        Event_TurnNext,
        // event-prev       : LB L1 Shift+TAB
        Event_TurnPrev,
        // event-ok         : A  ○  Enter
        Event_Ok,
        // event-cancel     : B  ×  ESC
        Event_Cancel,
        // event-function   : X  □  CtxMenu
        Event_Function,
        // event-action     : Y  △  
        Event_Action,
#endif
    };
    /// <summary>
    /// Argument for mouse event
    /// </summary>
    struct InputEventArg {
        // input event type
        InputEvent      event;
        // character
        char32_t        character;
    };
}

#include <cstdint>


namespace LongUI {
    /// <summary>
    /// event for longui control event
    /// </summary>
    enum class MouseEvent : uint32_t {
        // mouse wheel in v-dir
        Event_MouseWheelV,
        // mouse wheel in h-dir
        Event_MouseWheelH,
        // mouse enter, send this event even control disabled
        Event_MouseEnter,
        // mouse leave, send this event even control disabled
        Event_MouseLeave,
        // mouse idle hover
        Event_MouseIdleHover,
        // mouse move
        Event_MouseMove,
        // left-button down
        Event_LButtonDown,
        // left-button up
        Event_LButtonUp,
        // right-button down
        Event_RButtonDown,
        // right-button up
        Event_RButtonUp,
        // middle-button down
        Event_MButtonDown,
        // middle-button up
        Event_MButtonUp,
        // event unknown
        Event_Unknown,
    };

    /// <summary>
    /// modifier
    /// </summary>
    enum InputModifier : uint32_t {
        Modifier_None = 0,
        Modifier_LButton    = 1 << 0,
        Modifier_RButton    = 1 << 1,
        Modifier_Shift      = 1 << 2,
        Modifier_Control    = 1 << 3,
        Modifier_MButton    = 1 << 4,
    };
    /// <summary>
    /// Argument for mouse event
    /// </summary>
    struct MouseEventArg {
        // mouse event type
        MouseEvent      type;
        // wheel data
        float           wheel;
        // mouse windows point x
        float           px;
        // mouse windows point y
        float           py;
        // modifier
        InputModifier   modifier;
    };
}

// c++
#include <cstdint>

namespace LongUI {
    // typeof StyleState
    enum class StyleStateType : uint8_t {
        Type_None = 0, // for trigger event
        Type_Selected,
        Type_Default,
        Type_Disabled,
        Type_Hover,
        Type_Active,
        Type_Focus,
        Type_Checked,
        Type_Indeterminate,
        Type_Closed,

        //Type_OddIndex,
        //Type_Current,
        Type_NA_TabAfterSelectedTab,

        //Type_Opening,
        //Type_Idle1,
        //Type_Idle2,
        //Type_Ending,

        //Type_NA_FirstChild,
        //Type_NA_LastChild,
    };
    // state change
    struct StyleStateTypeChange { StyleStateType type; bool change; };
    // style state
    struct alignas(uint32_t) StyleState {
        // ctor
        void Init() noexcept;
        // change, return true if changed
        bool Change(StyleStateTypeChange) noexcept;
        // reserved flag, index 0 : used for trigger event
        bool        none        : 1;
        // ui-selected
        bool        selected    : 1;
        // default command control
        bool        default5    : 1;
        // disable
        bool        disabled    : 1;
        // hover
        bool        hover       : 1;
        // active, higher than hover
        bool        active      : 1;
        // [space to trigger] focus
        bool        focus       : 1;
        // checked
        bool        checked     : 1;
        // indeterminate, higher than checked
        bool        indeterminate : 1;
        // closed   [typical: twisty]
        bool        closed      : 1;

        // odd index
        //bool        odd_index   : 1;
        // current 
        //bool        current     : 1;
        // after selected tab
        bool        after_seltab : 1;

        // opening 
        //bool        opening     : 1;
        //// idle1
        //bool        idle1       : 1;
        //// idle2
        //bool        idle2       : 1;
        // ending
        //bool        ending      : 1;

        // first child
        //bool        first_child  : 1;
        // last child
        //bool        last_child   : 1;
    };
}

// c++
#include <cstdint>
// ui

#ifndef LUI_DISABLE_STYLE_SUPPORT
namespace LongUI {
    // style trigger list
    struct StyleTrigger {
        // p-s yes match:
        uint32_t  yes;
        // p-s not match
        uint32_t  noo;
        // trigger id     : +1 for be triggered
        uintptr_t tid;
    };
    // style sheet
    class CUIStyleSheet;
    // control
    class UIControl;
    // style sheet pointer
    using SSPtr = CUIStyleSheet * ;
    // controls
    using UIControls = POD::Vector<UIControl*>;
    // stylesheets: values
    using SSValues = POD::Vector<SSValue>;
    // stylesheets: trigger
    using SSTrigger = POD::Vector<StyleTrigger>;
    // delete style sheet
    void DeleteStyleSheet(CUIStyleSheet* ptr) noexcept;
    // match style sheet
    void MatchStyleSheet(UIControl&, CUIStyleSheet* ptr) noexcept;
    // parse inline style
    bool ParseInlineStlye(SSValues&, U8View) noexcept;
    // stylesheets: value pc
    struct SSValuePC {
        // yes pseudo-classes
        StyleState      yes;
        // not pseudo-classes
        StyleState      noo;
    };
    // stylesheets: value pc with length
    struct SSValuePCL {
        // type of value
        ValueType       type;
        // length of data
        uint32_t        length;
        // yes pseudo-classes
        StyleState      yes;
        // not pseudo-classes
        StyleState      noo;
    };
    // SSValuePC = SSValue
    static_assert(sizeof(SSValuePCL) == sizeof(SSValue), "must be same");
    // Combinator
    enum Combinator : uint8_t {
        // Combinator None
        Combinator_None         = 0,
        // Adjacent sibling selectors   A + B
        Combinator_AdjacentSibling,
        // General sibling selectors    A ~ B
        Combinator_GeneralSibling,
        // Child selectors              A > B
        Combinator_Child,
        // Descendant selectors         A   B
        Combinator_Descendant,
    };
    // stylesheets: selector
    struct SSSelector {
        // next level 
        SSSelector*     next;
        // type selector 
        const char*     stype;
        // class selector
        const char*     sclass;
        // id selector
        const char*     sid;
        // pseudo classes
        SSValuePC       pc;
        // combinator
        Combinator      combinator;
    };
}
#endif

// ui
// c++
#include <cassert>

namespace LongUI {
    // Box Model
    struct Box {
        // visible rect[world border edge]
        RectF       visible;
        // box position
        Point2F     pos;
        // box rect
        Size2F      size;
        // margin
        RectF       margin;
        // border
        RectF       border;
        // padding
        RectF       padding;
        // box used min size
        Size2F      minsize;
        // TODO: box used max size 
        Size2F      maxsize;
        // ctor
        void Init() noexcept;
        // get Non-content rect
        auto GetNonContect() const noexcept { RectF rc; GetNonContect(rc); return rc; }
        // get margin edge
        auto GetMarginEdge() const noexcept { RectF rc; GetMarginEdge(rc); return rc; }
        // get border edge
        auto GetBorderEdge() const noexcept { RectF rc; GetBorderEdge(rc); return rc; }
        // get padding edge
        auto GetPaddingEdge() const noexcept { RectF rc; GetPaddingEdge(rc); return rc; }
        // get content edge
        auto GetContentEdge() const noexcept { RectF rc; GetContentEdge(rc); return rc; }
        // get safe-border edge
        auto GetSafeBorderEdge() const noexcept->RectF;
        // get contect size
        auto GetContentSize() const noexcept->Size2F;
        // get border size
        auto GetBorderSize() const noexcept->Size2F;
        // get contect pos
        auto GetContentPos() const noexcept->Point2F;
        // get Non-content rect
        void GetNonContect(RectF&) const noexcept;
        // get margin edge
        void GetMarginEdge(RectF&) const noexcept;
        // get border edge
        void GetBorderEdge(RectF&) const noexcept;
        // get padding edge
        void GetPaddingEdge(RectF&) const noexcept;
        // get content edge
        void GetContentEdge(RectF&) const noexcept;
    };
    // text/font
    struct TextFont;
    // Style model
    struct Style {
        // get TextFont
        auto GetTextFont() noexcept {
            assert(offset_tf && "bad offset");
            const auto ptr = reinterpret_cast<char*>(this) + offset_tf;
            return reinterpret_cast<TextFont*>(ptr);
        }
        // ctor
        Style() noexcept;
        // dtor
        ~Style() noexcept;
        // no copy
        Style(const Style&) noexcept = delete;
        // state            [4]
        StyleState          state;
        // pack             [1]
        AttributePack       pack;
        // t-duration       [2]
        uint16_t            tduration;
        // unused           [2]
        uint16_t            unused2;
        // unused           [4]
        uint32_t            unused4;
        // align            [1]
        AttributeAlign      align;
        // appearance tpye  [1]
        AttributeAppearance appearance;
        // t-timing funtion [1]
        uint8_t             tfunction;
        // offset in byte for text font, set this if support text [2]
        uint16_t            offset_tf;
        // overflow-x       [1]
        AttributeOverflow   overflow_x;
        // overflow-y       [1]
        AttributeOverflow   overflow_y;
        // flex             [4]
        float               flex;
        // style used min size
        Size2F              minsize;
        // style used max size
        Size2F              maxsize;
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // value list matched
        SSValues            matched;
        // trigger
        SSTrigger           trigger;
#endif
    };
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cstdint>

namespace LongUI {
    // control state
    struct CtrlState {
        // ctor
        void Init() noexcept;
        // tree level
        uint8_t     level;
        // ------------ life

        // has been inited
        bool        inited : 1;
        // ctor failed
        bool        ctor_failed : 1;
        // in dtor
        bool        destructing : 1;

        // ------------ attr

        // attachment 
        bool        attachment : 1;
        // focusable
        bool        focusable : 1;
        // orientation
        bool        orient : 1;
        // layout direction
        bool        dir : 1;

        // ---------- unstable interface

        // is delete later?
        bool        delete_later : 1;
        // gui event to parent[true, to parent, false to viewport]
        bool        gui_event_to_parent : 1;
        // in animation
        bool        in_basic_animation : 1;
        // defaultable
        bool        defaultable : 1;
        // atomicity (children will keep same input-state with parent)
        bool        atomicity   : 1;
        // tooltip shown?
        bool        tooltip_shown : 1;


        // ----------- custom data

        // custom data, defined via control self, donot use this if you donot know
        //  - listbox   : need refresh index flag
        //  - progress  : data changed flag
        //  - menu popup: save selected
        bool        custom_data : 1;


        // ----------- state

        // text-font display attr changed
        bool        textfont_display_changed : 1;
        // text-font layout attr changed
        bool        textfont_layout_changed : 1;
        // layout dirty
        bool        dirty : 1;
        // visible                          [S-falg]
        bool        visible : 1;
        // world matrix changed             [N-flag]
        bool        world_changed : 1;
        // state changed if [animated]      [N-flag]
        bool        style_state_changed : 1;
        // in update list                   [O-flag]
        bool        in_update_list : 1;
        // in render-dirty list             [O-flag]
        bool        in_dirty_list : 1;
        // child index changed(+ - child)   [N-flag]
        bool        child_i_changed : 1;
        // parent changed                   [N-flag]
        bool        parent_changed : 1;

    };
}

// ui namespace
namespace LongUI { 
    // background renderer
    class CUIRendererBackground;
    // border renderer
    class CUIRendererBorder;
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// config
// super class list
// id string
// vector
// basic type
// event
// style
// state
// renderer
// accessible

// assert
#include <cstddef>
#include <cassert>

#ifdef LUI_USER_U16STR_DATA
#endif

// ui namespace
namespace LongUI {
    // meta info
    struct MetaControl;
    // control control
    class CUIControlControl;
    // control private function
    struct UIControlPrivate;
    // time capsule
    class CUITimeCapsule;
    // control
    class UIControl :
        public CUIEventHost,
        protected Node<UIControl>,
        public CUIObject {
        // super class
        using Super = void;
        // private impl
        friend UIControlPrivate;
        // friend
        friend CUIControlControl;
    protected:
        // unique classes
        using UniqueClasses = POD::Vector<const char*>;
        // Itr
        using Iterator = Node<UIControl>::Iterator;
        // R-Itr
        using RIterator = Node<UIControl>::ReverseIterator;
        // C-Itr
        using CIterator = Node<const UIControl>::Iterator;
        // CR-Itr
        using CRIterator = Node<const UIControl>::ReverseIterator;
        // friend
        friend Node<UIControl>::Iterator;
        // friend
        friend CIterator;
        // friend
        friend Node<UIControl>::ReverseIterator;
        // friend
        friend CRIterator;
    public:
        // on this object clicked
        static constexpr auto _onClick() noexcept { return GuiEvent::Event_OnClick; }
#if 0
        // [unsupport yet]on this object double-clicked
        static constexpr auto _onDblClick() noexcept { return GuiEvent::Event_OnDblClick; }
#endif
        // on this object set focus
        static constexpr auto _onFocus() noexcept { return GuiEvent::Event_OnFocus; }
        // on this object kill focus
        static constexpr auto _onBlur() noexcept { return GuiEvent::Event_OnBlur; }
    public:
        // class meta
        static const  MetaControl   s_meta;
        // safe type cast, null this safe
        auto SafeCastTo(const LongUI::MetaControl&) const noexcept->const UIControl*;
        // safe type cast, none const overload
        auto SafeCastTo(const LongUI::MetaControl& m) noexcept {
            const auto* p = this; return const_cast<UIControl*>(p->SafeCastTo(m));
        }
#ifndef NDEBUG
        // assert type cast, null this pointer acceptable
        void AssertCast(const LongUI::MetaControl&) const noexcept;
#endif
    protected:
        // std lui ctrl ctor
        UIControl(UIControl* parent, const MetaControl&) noexcept;
    public:
        // no copy ctor
        UIControl(const UIControl&) = delete;
        // no move ctor
        UIControl(UIControl&&) = delete;
        // ctor
        UIControl(UIControl* parent = nullptr) noexcept : UIControl(parent, UIControl::s_meta) {}
        // delete later
        void DeleteLater() noexcept;
        // dtor
        virtual ~UIControl() noexcept;
        // do normal event
        virtual auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept;
        // do input event
        virtual auto DoInputEvent(InputEventArg e) noexcept->EventAccept;
        // do mouse event
        virtual auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept;
        // update, postpone change some data
        virtual void Update() noexcept;
        // render this control only
        virtual void Render() const noexcept;
        // render this and all descendant
        //virtual void RenderAll() const noexcept;
        // recreate/init device(gpu) resource
        virtual auto Recreate(bool release_only) noexcept->Result;
    protected:
        // add child[child maybe in ctor, cannot call method except under UIControl]
        virtual void add_child(UIControl& child) noexcept;
        // get sub element ::before
        //virtual auto get_subelement(U8View name) noexcept->UIControl*;
        // add attribute : key = bkdr hashed string key, this method valid before inited
        virtual void add_attribute(uint32_t key, U8View value) noexcept;
#ifdef LUI_ACCESSIBLE
    public:
        // get logic accessible control
        auto GetLogicAccessibleControl() const noexcept { return m_pAccCtrl; }
    protected:
        // accessible 
        virtual auto accessible(const AccessibleEventArg&) noexcept ->EventAccept;
        // friends
        friend class CUIAccessible;
        // accessible object
        CUIAccessible*          m_pAccessible = nullptr;
        // accessible control  null->one ctrl this->this child->child
        UIControl*              m_pAccCtrl = this;
#endif
    public:
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // apply value
        void ApplyValue(const SSValue&) noexcept;
        // get value[cannot get string yet]
        void GetValue(SSValue&) const noexcept;
#endif
        // call this before making lots of controls
        static void ControlMakingBegin() noexcept;
        // call this after lots of controls maked
        static void ControlMakingEnd() noexcept;
        // need update in this frame
        void NeedUpdate() noexcept;
        // need update in next frame
        void NextUpdate() noexcept;
        // need relayout in this freame
        void NeedRelayout() noexcept;
        // is first child?
        bool IsFirstChild() const noexcept;
        // is last child
        bool IsLastChild() const noexcept;
        // is descendant or sibling
        bool IsDescendantOrSiblingFor(const UIControl&) const noexcept;
        // set timer 0~3
        //void SetTimer0123(uint32_t id0123, uint32_t elapse) noexcept;
        // kill timer 0~3
        //void KillTimer0123(uint32_t id0123) noexcept;
    public:
        // clear appearance and all margin/padding/border
        void ClearAppearance() noexcept;
        // set xul-string as content
        // remarks: SetXul accept null-terminated-string only
        // 注: SetXul目前只接受 NUL 结尾字符串
        void SetXul(const char* xul) noexcept;
        // set xul-file as content, return false if not-found
        bool SetXulFromFile(U8View url) noexcept;
        // find child via position 
        auto FindChild(const Point2F pos) noexcept->UIControl*;
        // swap child index
        void SwapChildren(UIControl& a, UIControl& b) noexcept;
        // get children count
        auto GetCount() const noexcept { return m_cChildrenCount; }
        // invalidate this control
        void Invalidate() noexcept;
        // is ctor failed? if true you must delete/dtor it after ctor
        auto IsCtorFailed() const noexcept { return m_state.ctor_failed; }
        // is top level of tree? -> no parent
        bool IsTopLevel() const noexcept { return !m_pParent; }
        // get style model
        auto&GetStyle() const noexcept { return m_oStyle; }
        // get box model
        auto&GetBox() const noexcept { return m_oBox; }
    public:
        // is ancestor for this
        bool IsAncestorForThis(const UIControl& node) const noexcept;
        // get parent
        auto GetParent() const noexcept { return m_pParent; }
        // get window
        auto GetWindow() const noexcept { return m_pWindow; }
        // set a new parent
        void SetParent(UIControl& parent) noexcept;
        // set a new parent to null
        void SetParent(std::nullptr_t parent) noexcept { this->clear_parent(); }
        // set focus of this control, return true if set
        bool SetFocus() noexcept;
        // kill focus of this control
        void KillFocus() noexcept;
        // set as default/focus
        void SetAsDefaultAndFocus() noexcept;
        // focusable?
        auto IsFocusable() const noexcept { return m_state.focusable; }
        // defaultable?
        auto IsDefaultable() const noexcept { return m_state.defaultable; }
        // is gui event to parent?
        auto IsGuiEvent2Parent() const noexcept { return m_state.gui_event_to_parent; }
        // is in delete later
        auto IsDeleteLater() const noexcept { return m_state.delete_later; }
        // mark delete later
        auto MarkDeleteLater() noexcept { m_state.delete_later = true; }
    public:
        // resize
        bool Resize(Size2F size) noexcept;
        // set fixed/style size
        void SetFixedSize(Size2F size) noexcept;
        // set fixed/style size
        void SetStyleSize(Size2F size) noexcept { this->SetFixedSize(size); }
        // set style minsize
        void SetStyleMinSize(Size2F size) noexcept;
        // set style maxsize
        void SetStyleMaxSize(Size2F size) noexcept;
        // get minsize
        auto GetMinSize() const noexcept->Size2F;
        // is vaild in layout?
        bool IsVaildInLayout() const noexcept;
        // get size
        auto GetSize() const noexcept { return m_oBox.size; }
        // get maxsize
        auto GetMaxSize() const noexcept { return m_oStyle.maxsize; }
    protected:
        // set box rect minsize
        void set_box_minsize(Size2F size) noexcept;
        // set box contect minsize
        void set_contect_minsize(Size2F size) noexcept;
    public:
        // set visible
        void SetVisible(bool visible) noexcept;
        // get access key
        auto GetAccessKey() const noexcept { return m_chAccessKey; }
        // get id, default as ""
        auto GetID() const noexcept { return m_id; }
        // set tooltip text
        void SetTooltipText(U8View v) noexcept;
        // set tooltip text
        auto GetTooltipText() const noexcept { return m_strTooltipText.c_str(); }
        // set postion of control [Relative to parent]
        void SetPos(Point2F pos) noexcept;
        // get postion of control [Relative to parent]
        auto GetPos() const noexcept { return m_oBox.pos; }
        // get world matrix [Relative to window]
        auto&GetWorld() const noexcept { return m_mtWorld; }
        // get tree level
        auto GetLevel() const noexcept { return m_state.level; }
        // is enabled
        bool IsEnabled() const noexcept { return !m_oStyle.state.disabled; }
        // is disabled
        bool IsDisabled() const noexcept { return m_oStyle.state.disabled; }
        // is visible
        bool IsVisible() const noexcept { return m_state.visible; }
        // is visible to root
        bool IsVisibleToRoot() const noexcept;
        // set hidden
        void SetHidden(bool hidden) noexcept { this->SetVisible(!hidden); }
        // set this and all descendant enabled/disabled
        void SetDisabled(bool disabled) noexcept;
        // set this and all descendant enabled/disabled
        void SetEnabled(bool enable) noexcept { this->SetDisabled(!enable); }
        // start state animation [do not use this to change state, use SetXXX instead]
        void StartAnimation(StyleStateTypeChange) noexcept;
        // start general animation

    public:
        // get style classes
        auto&GetStyleClasses() const noexcept { return m_classesStyle; }
        // get meta info
        auto&GetMetaInfo() const noexcept { return m_refMetaInfo; }
        // add style class
        void AddStyleClass(U8View) noexcept;
        // remove style class
        void RemoveStyleClass(U8View) noexcept;
    public:
        // window point inside border?
        bool IsPointInsideBorder(Point2F) const noexcept;
        // map rect to window
        void MapToWindow(RectF& rect) const noexcept;
        // map rect to parent
        void MapToParent(RectF& rect) const noexcept;
        // map point to window
        void MapToWindow(Point2F& point) const noexcept;
        // map point to parent
        void MapToParent(Point2F& point) const noexcept;
        // map rect from window
        void MapFromWindow(RectF& rect) const noexcept;
        // map rect from parent
        void MapFromParent(RectF& rect) const noexcept;
        // map point from window
        void MapFromWindow(Point2F& point) const noexcept;
        // map point from parent
        void MapFromParent(Point2F& point) const noexcept;
        // map point to window
        auto MapToWindowEx(Point2F&& point) const noexcept {
            this->MapToWindow(point); return point; }
    protected:
        // clear parent
        void clear_parent() noexcept;
        // mark minsize changed
        void mark_window_minsize_changed() noexcept;
        // take clicked control
        auto take_clicked() noexcept -> UIControl*;
        // remove child
        void remove_child(UIControl& child) noexcept;
        // start animation: bottom-up
        void start_animation_b2u(StyleStateTypeChange) noexcept;
        // start animation: up-bottom
        void start_animation_children(StyleStateTypeChange) noexcept;
        // do mouse under atomicity
        auto mouse_under_atomicity(const MouseEventArg& e) noexcept ->EventAccept;
        // calculate child index
        auto calculate_child_index(const UIControl&) const noexcept->uint32_t;
        // calculate child at
        auto calculate_child_at(uint32_t index) noexcept->UIControl*;
        // do tooltip
        auto do_tooltip(Point2F pos) noexcept->EventAccept;
        // release tooltip
        void release_tooltip() noexcept;
    private:
        // init
        auto init() noexcept->Result;
        // remove triggered
        void remove_triggered() noexcept;
        // setup init state
        void setup_init_state() noexcept;
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // make off init data
        void make_off_initstate(UIControl* ,uint32_t, UniByte4[], UniByte8[]) const noexcept;
        // extra animation callback
        void extra_animation_callback(
            StyleStateTypeChange changed, 
            void* out_values, 
            void* out_blocks
        ) noexcept;
        // extra animation callback
        void extra_animation_callback(
            UIControl& trigger,
            const SSValues& values,
            void* out_values,
            bool set
        ) noexcept;
        // link style sheet
        void link_style_sheet() noexcept;
        // animation property filter
        auto animation_property_filter(void*) noexcept->uint32_t;
#endif
        // start animation change
        bool start_animation_change(StyleStateTypeChange) noexcept;
    protected:
        // apply world transform to renderer
        void apply_world_transform() const noexcept;
        // apply clip rect
        void apply_clip_rect() const noexcept;
        // cancel clip rect
        void cancel_clip_rect() const noexcept;
        // native style render, return true if not rendered 
        bool native_style_render() const noexcept;
        // custom style render
        void custom_style_render() const noexcept;
        // delete renderer
        void delete_renderer() noexcept;
        // exist basic animation ?
        auto exist_basic_animation() const noexcept { return m_state.in_basic_animation; }
        // clear basic animation
        void clear_basic_animation() noexcept { m_state.in_basic_animation = false; }
        // setup basic animation
        void setup_basic_animation() noexcept { m_state.in_basic_animation = true; }
    protected:
        // state
        CtrlState               m_state;
        // child count
        uint32_t                m_cChildrenCount = 0;
        // id of control
        const char*             m_id = CUIConstShortString::EMPTY;
        // meta info of control
        const MetaControl&      m_refMetaInfo;
        // style model
        Style                   m_oStyle;
        // box model
        Box                     m_oBox;
        // world transform: do mapping
        Matrix3X2F              m_mtWorld;
        // child-control head node
        Node<UIControl>         m_oHead;
        // child-control tail node
        Node<UIControl>         m_oTail;
        // children offset
        Point2F                 m_ptChildOffset;
        // parent
        UIControl*              m_pParent;
        // window
        CUIWindow*              m_pWindow = nullptr;
        // hovered child, always right
        UIControl*              m_pHovered = nullptr;
        // clicked child, right during in click-down-to-up
        UIControl*              m_pClicked = nullptr;
        // last end time capsule
        CUITimeCapsule*         m_pLastEnd = nullptr;
        // context menu
        const char*             m_pCtxCtrl = nullptr;
        // tooltip window
        const char*             m_pTooltipCtrl = nullptr;
        // tooltip text
        CUIConstShortString     m_strTooltipText;
        // style unique classes
        UniqueClasses           m_classesStyle;
#ifndef LUI_DISABLE_STYLE_SUPPORT
    private:
        // bg renderer
        CUIRendererBackground*  m_pBgRender = nullptr;
        // bd renderer
        CUIRendererBorder*      m_pBdRender = nullptr;
#endif
    protected:
        // parent accessible data
        uint32_t                m_uData4Parent = 0;
        // ununsed u16
        uint16_t                m_unused_u16 = 0;
        // accesskey char
        char                    m_chAccessKey = 0;
        // has timer
        bool                    m_bHasTimer : 1;
        // has inline style
        bool                    m_bHasInlineStyle : 1;
        // text changed, use this if you support text display for optimization
        bool                    m_bTextChanged : 1;
    public:
#ifdef LUI_USER_INIPTR_DATA
        // user int data, for user accessing
        std::intptr_t           user_data = 0;
#endif
#ifdef LUI_USER_U8STR_DATA
        // user str data, for user accessing
        CUIConstShortString     user_u8str;
#endif
#ifdef LUI_USER_U16STR_DATA
        // user str data, for user accessing
        CUIString               user_u16str;
#endif
#ifndef NDEBUG
        // debug name
        const char*             name_dbg = "";
        // set debug name
        void SetDebugName(const char* name) noexcept { name_dbg = name; }
#else
        // set debug name
        void SetDebugName(const char*) noexcept { }
#endif
    public:
        // end iterator
        auto end()noexcept->Iterator { return{ static_cast<UIControl*>(&m_oTail) }; }
        // begin iterator
        auto begin()noexcept->Iterator { return{ static_cast<UIControl*>(m_oHead.next) }; }
        // rend iterator
        auto rend()noexcept->RIterator { return{ static_cast<UIControl*>(&m_oHead) }; }
        // rbegin iterator
        auto rbegin()noexcept->RIterator { return{ static_cast<UIControl*>(m_oTail.prev) }; }
        // const end iterator
        auto end()const noexcept->CIterator { return{ static_cast<const UIControl*>(&m_oTail) }; }
        // begin iterator
        auto begin()const noexcept->CIterator { return{ static_cast<const UIControl*>(m_oHead.next) }; }
        // rend iterator
        auto rend()const noexcept->CRIterator { return{ static_cast<const UIControl*>(&m_oHead) }; }
        // rbegin iterator
        auto rbegin()const noexcept->CRIterator { return{ static_cast<const UIControl*>(m_oTail.prev) }; }
    protected:
        // ctor failed if
        void ctor_failed_if(const void* ptr) noexcept { if (!ptr) m_state.ctor_failed = true; }
        // size change handled
        void size_change_handled() noexcept { m_state.dirty = false; }
        // add into update list
        void add_into_update_list() noexcept { m_state.in_update_list = true; }
        // remove from update list
        void remove_from_update_list() noexcept { m_state.in_update_list = false; }
        // is inited?
        bool is_inited() const noexcept { return m_state.inited; }
        // is need relayout
        bool is_need_relayout() const noexcept { return m_state.dirty; }
        // is size changed?
        bool is_size_changed() const noexcept { return m_state.dirty; }
        // is in update list?
        bool is_in_update_list() const noexcept { return m_state.in_update_list; }
        // is in dirty list?
        bool is_in_dirty_list() const noexcept { return m_state.in_dirty_list; }
        // mark child world changed
        static void mark_child_world_changed(UIControl& c) noexcept { c.m_state.world_changed = true; }
        // resize child
        static void resize_child(UIControl& child, Size2F size) noexcept;
        // set child fixed attachment
        static void set_child_fixed_attachment(UIControl& child) noexcept {
            child.m_state.attachment = Attachment_Fixed; }
    protected: // COPY FROM NODE
        // swap node
        static void SwapNode(UIControl& a, UIControl& b) noexcept;
        // swap A-B node
        static void SwapAB(UIControl& a, UIControl& b) noexcept;
    };
    // == operator
    inline bool operator==(const UIControl& a, const UIControl& b) noexcept {
        return &a == &b; }
    // get meta info
    template<typename T> const MetaControl& GetMetaInfo() noexcept;
    // get meta info through pointer
    template<typename T> const MetaControl& GetMetaInfoPtr(T*) noexcept {
        return GetMetaInfo<T>(); }
    // longui type cast
    template<typename T, typename U> inline T longui_cast(U* ptr) noexcept {
#ifndef NDEBUG
        ptr->AssertCast(GetMetaInfoPtr(static_cast<T>(nullptr)));
#endif
        return static_cast<T>(ptr);
    }
    // longui safe cast
    template<typename T, typename U> inline T* uisafe_cast(U* ptr) noexcept {
        return static_cast<T*>(ptr->SafeCastTo(GetMetaInfo<T>())); }
    // decl meta control
#define LUI_DECLARE_METAINFO(C)\
    template<> inline const MetaControl& GetMetaInfo<C>() noexcept {\
        return C::s_meta; }\
    template<> inline const MetaControl& GetMetaInfo<const C>() noexcept {\
        return C::s_meta; }
    // get meta info for UIControl
    LUI_DECLARE_METAINFO(UIControl);
}

// move to top namespace
using LongUI::longui_cast;
// move to top namespace
using LongUI::uisafe_cast;

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


namespace LongUI {
        // scroll bar
    class UIScrollBar;
    // scroll area
    class UIScrollArea : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UIScrollArea(UIControl* parent, const MetaControl&) noexcept;
    public:
        // meta info
        static const MetaControl    s_meta;
        // dtor
        ~UIScrollArea() noexcept;
        // ctor
        UIScrollArea(UIControl* parent = nullptr) noexcept : UIScrollArea(parent, UIScrollArea::s_meta) {}
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
    private:
        // [NEW] relayout
        virtual void relayout() noexcept;
    public:
        // set auto overflow
        void SetAutoOverflow() noexcept;
        // force update scroll size
        void ForceUpdateScrollSize(Size2F ss) noexcept;
        // add spacer
        void AddSpacer(Size2F size, float flex) noexcept;
        // get min scroll size
        auto GetMinScrollSize() const noexcept { return m_minScrollSize; }
        // get layout direcition
        auto GetLayoutDirection() const noexcept ->AttributeDir { return AttributeDir(m_state.dir); }
        // get vertical ScrollBar
        auto GetVerticalScrollBar() noexcept -> UIScrollBar* { return m_pVerticalSB; }
        // get horizontal ScrollBar
        auto GetHorizontalScrollBar() noexcept -> UIScrollBar* { return m_pHorizontalSB; }
        // get vertical ScrollBar | const overload
        auto GetVerticalScrollBar() const noexcept -> const UIScrollBar*{ return m_pVerticalSB; }
        // get horizontal ScrollBar | const overload
        auto GetHorizontalScrollBar() const noexcept -> const UIScrollBar*{ return m_pHorizontalSB; }
    protected:
        // get child flex sum
        auto sum_children_flex() const noexcept -> float;
        // synchronize the scroll bar
        void sync_scroll_bar() noexcept;
        // layout the scroll bar
        auto layout_scroll_bar() noexcept->Size2F;
        // get layout position
        auto get_layout_position() const noexcept->Point2F;
    private:
        // on state dirty
        void on_state_dirty() noexcept;
        // do wheel
        auto do_wheel(int index, float wheel) noexcept->EventAccept;
        // create scroll bar
        auto create_scrollbar(AttributeOrient) noexcept->UIScrollBar*;
        // layout the scroll bar - h
        auto layout_vscrollbar(bool notenough) noexcept->float;
        // layout the scroll bar - v
        auto layout_hscrollbar(bool notenough) noexcept->float;
    public:
        // line size
        Size2F              line_size;
    protected:
        // min scroll size
        Size2F              m_minScrollSize;
        // horizontal scroll bar
        UIScrollBar*        m_pHorizontalSB = nullptr;
        // vertical scroll bar
        UIScrollBar*        m_pVerticalSB = nullptr;
    };
    // get meta info for UIScrollArea
    LUI_DECLARE_METAINFO(UIScrollArea);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


namespace LongUI {
    // splitter
    class UISplitter;
    // meta def
    struct UIMetaTypeDef;
    // box layout
    class UIBoxLayout : public UIScrollArea {
        // super class
        using Super = UIScrollArea;
        // friend class
        friend UIMetaTypeDef;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIBoxLayout() noexcept;
        // ctor
        UIBoxLayout(UIControl* parent = nullptr) noexcept : UIBoxLayout(parent, UIBoxLayout::s_meta) {}
        // do event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
    protected:
        // lui std ctor
        UIBoxLayout(UIControl* parent, const MetaControl& ) noexcept;
    private:
        // relayout
        void relayout() noexcept override;
        // move splitter
        void move_splitter(UISplitter& splitter, Point2F offset) noexcept;
    protected:
         //add attribute
        //void add_attribute(uint32_t key, U8View value) noexcept override;
        // relayout h
        void relayout_h() noexcept;
        // relayout v
        void relayout_v() noexcept;
        // refresh min size
        void refresh_min() noexcept;
#ifdef LUI_ACCESSIBLE
        // accessible 
        auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    public:
        // set orient
        void SetOrient(AttributeOrient o) noexcept;
        // get orient
        auto GetOrient() const noexcept { return static_cast<AttributeOrient>(m_state.orient); }
    };
    // v-box layout
    class UIVBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIVBoxLayout(UIControl* parent = nullptr) noexcept : UIVBoxLayout(parent, UIVBoxLayout::s_meta) {}
        // dtor
        ~UIVBoxLayout() noexcept;
    protected:
        // ctor
        UIVBoxLayout(UIControl* parent, const MetaControl&) noexcept;
    public:
    };
    // h-box layout
    class UIHBoxLayout final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIHBoxLayout(UIControl* parent = nullptr) noexcept : UIHBoxLayout(parent, UIHBoxLayout::s_meta) {}
        // dtor
        ~UIHBoxLayout() noexcept;
    protected:
        // ctor
        UIHBoxLayout(UIControl* parent, const MetaControl& ) noexcept;
    public:
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIBoxLayout);
    // get meta info for UIBBoxLayout
    LUI_DECLARE_METAINFO(UIVBoxLayout);
    // get meta info for UIHBoxLayout
    LUI_DECLARE_METAINFO(UIHBoxLayout);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // menu popup
    class UIMenuPopup;
    // button
    class UIButton : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    public:
        // min button width
        //enum { MIN_BUTTON_WIDTH = 175 };
        // button type
        enum ButtonType : uint8_t {
            Type_Normal = 0,    // normal type
            Type_Checkbox,      // toggle button
            Type_Radio,         // radio-like button
            Type_Menu,          // menu
        };
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIButton() noexcept;
        // ctor
        UIButton(UIControl* parent = nullptr) noexcept : UIButton(parent, UIButton::s_meta) {}
    protected:
        // ctor
        UIButton(UIControl* parent, const MetaControl&) noexcept;
    public:
        // on commnad event
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
        // clicked event
        //static inline constexpr auto _clicked() noexcept { return GuiEvent::Event_Click; }
        // checked change event
        //static inline constexpr auto _checkedChanged() noexcept { return GuiEvent::Event_Change; }
    public:
        // click this
        void Click() noexcept;
        // set image source
        void SetImageSource(U8View src) noexcept;
        // get text
        auto GetText() const noexcept ->const char16_t*;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
        // is checked?
        auto IsChecked() const noexcept { return m_oStyle.state.checked; }
    public:
        // do event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // input event
        auto DoInputEvent(InputEventArg e) noexcept->EventAccept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // set label flex
        void set_label_flex(float f) noexcept;
        // add private child
        void add_private_child() noexcept;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
        // parse button type
        static auto parse_button_type(U8View) noexcept->ButtonType;
    private:
        // private data
        Private*            m_private = nullptr;
        // group id
        const char*         m_pGroup = nullptr;
    protected:
        // menupopup
        UIMenuPopup*        m_pMenuPopup = nullptr;
        // button type
        ButtonType          m_type = Type_Normal;
        // toolbar button   :<UIToolBarButton>
        bool                m_bToolBar = false;
        // menu button      :<UIMenu>
        bool                m_bMenuBar = false;
        // popup shown
        bool                m_bPopupShown = false;
    };
    // get meta info for UIButton
    LUI_DECLARE_METAINFO(UIButton);
}

#include <cstddef>

// LongUI::i namespace
namespace LongUI { namespace I {
    // CTL Factory
    struct FactoryCTL;
    // CTL Font
    struct Font;
    // CTL Text
    struct Text;
    // CTL Text Renderer
    struct TextRenderer;
}}

// ui
namespace LongUI {
    // ctl style text
    struct StyleText;
    // ctl text arg
    struct TextArg;
    // ctl font arg
    struct FontArg;
}


// decl

// ui namespace
namespace LongUI {
    // text arg
    struct TextArg {
        // font, null for default
        I::Font*        font;
        // string pointer, be carefual about dangling pointer
        const char16_t* string;
        // string length
        size_t          length;
        // max width
        float           mwidth;
        // max height
        float           mheight;
    };
    // font arg
    struct FontArg {
        // [layout]font family, maybe use CUIManager::GetUniqueText to create release-free text
        const char*             family;
        // [layout]font size
        float                   size;
        // [layout]line height * 
        float                   line_height_multi;
        // [layout]line height + 
        float                   line_height_plus;
        // [layout]weight
        AttributeFontWeight     weight;
        // [layout]style
        AttributeFontStyle      style;
        // [layout]stretch 
        AttributeFontStretch    stretch;
    };
    // get line height
    inline auto GetLineHeight(const FontArg& fa) noexcept {
        return fa.size * fa.line_height_multi + fa.line_height_plus;
    }
}


// ui

// ui namepsace
namespace LongUI {
    // style.text
    struct StyleText {
        // [display]text color
        ColorF              color;
        // [display]text stroke color
        ColorF              stroke_color;
        // [display]text stroke width
        float               stroke_width;
        // [layout] text alignment
        AttributeTextAlign  alignment;
        // text crop

    };
    // style.text/font
    struct TextFont {
        // text data
        StyleText       text;
        // font data
        FontArg         font;
    };
    // default 
    void MakeDefault(TextFont&) noexcept;
}

// LongUI::i namespace
namespace LongUI { namespace I {
    // renderer 2d
    struct Renderer2D;
    // geometry
    struct Geometry;
    // bitmap
    struct Bitmap;
    // brush
    struct Brush;
    // effect
    struct Effect;
    // image
    struct Drawable;
    // 3d device
    struct Device3D;
    // renderer 3d
    struct Renderer3D;
    // Swap ちゃん
    struct Swapchan;
    // graphics factory
    struct FactoryGraphics;
}}




// ui namespace
namespace LongUI {
    // color
    struct ColorF;
    // text font
    struct TextFont;
    // static text layout
    class CUITextLayout : public CUINoMo {
        // set text
        auto set_text(TextArg& arg) noexcept->Result;
    public:
        // ctor
        CUITextLayout() noexcept = default;
        // dtor
        ~CUITextLayout() noexcept;
        // renderer with default text render
        void Render(
            I::Renderer2D& renderer, 
            const ColorF& color,
            Point2F point
        ) const noexcept;
    public:
        // set font data
        auto SetFont(const TextFont& arg, const char16_t* str, size_t len) noexcept->Result;
        // set text
        auto SetText(const char16_t* str, size_t len) noexcept->Result;
        // resize
        void Resize(Size2F) noexcept;
        // test text size
        auto GetSize() const noexcept->Size2F;
        // set underline
        void SetUnderline(uint32_t pos, uint32_t len, bool) noexcept;
    public:
        // ok
        bool IsOK() const noexcept { return !!m_text; }
        // bool
        operator bool() const noexcept { return !!m_text; }
        // operator !
        bool operator!() const noexcept { return !m_text; }
        // get ctl text
        auto GetCtlText() const noexcept { return m_text; }
    private:
        // ctl text data
        I::Text*            m_text = nullptr;
        // half line spacing
        //float               m_halfls = 0.f;
#ifndef NDEBUG
        // text setted
        bool                m_dbgTexted = false;
#endif
    };
}


// ui namespace
namespace LongUI {
    // text basic context
    struct TextBasicContext {
        // 2d render
        I::Renderer2D*  renderer;
        // text color
        ColorF          color;
    };
    // text outline context
    struct TextOutlineContext : TextBasicContext {
        // outline-color
        ColorF          outline_color;
        // outline-width
        float           outline_width;
    };
    // text outline renderer
    class CUITextOutline : public CUINoMo {
    public:
        // ctor
        CUITextOutline() noexcept;
        // dtor
        ~CUITextOutline() noexcept;
        // render text layout
        void Render(
            const TextOutlineContext& ctx,
            I::Text* text,
            Point2F point
        ) const noexcept;
    private:
        // ctl text renderer buffer
        void*           m_buffer;
    };
}

#include <cstdint>
#include <cassert>

// ui namespace
namespace LongUI {
    // control 
    class UIControl;
    // window
    class CUIWindow;
    // named control to find
    union NamedControl {
        // ctor
        NamedControl() noexcept : ctrl(nullptr) {}
#ifndef NDEBUG
        // dtor
        ~NamedControl() noexcept { assert((value & 1) == 0 && "must call Find if SetName"); }
#endif
        // set name
        void SetName(const char* begin, const char* end) noexcept;
        // set control
        void SetControl(UIControl* c) noexcept { assert((value & 1) == 0); ctrl = c; }
        // find control window
        void FindControl(CUIWindow* window) noexcept;
        // control ptr
        UIControl*      ctrl;
        // control name
        const char*     name;
        // pointer value
        uintptr_t       value;
    };
}

#include <cstdint>

namespace LongUI {
    // cursor
    class CUICursor final {
    public:
        // default
        enum DefaultCursor : uintptr_t {
            // arraw
            Cursor_Arrow = 0,
            // 'I' beam
            Cursor_Ibeam,
            // wait
            Cursor_Wait,
            // hand
            Cursor_Hand,
            // help
            Cursor_Help,
            // + cross
            Cursor_Cross,
            // 4-pointed arrow
            Cursor_SizeAll,
            // up arrow
            Cursor_UpArrow,
            // NW-SE arrow
            Cursor_SizeNWSE,
            // NE-SW arrow
            Cursor_SizeNESW,
            // W-E arrow
            Cursor_SizeWE,
            // N-S arrow
            Cursor_SizeNS,
            // count of this
            CURSOR_COUNT
        };
    public:
        // from DefaultCursor
        CUICursor(DefaultCursor) noexcept;
        // copy ctor
        CUICursor(const CUICursor&) noexcept = default;
        // dtor
        ~CUICursor() noexcept = default;
        // get handle
        auto GetHandle() const noexcept { return m_handle; }
    private:
        // handle to cursor
        uintptr_t           m_handle;
    };
}

// ui header
// cursor

// ui namespace
namespace LongUI {
    // label
    class UILabel : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UILabel(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UILabel() noexcept;
        // ctor
        UILabel(UIControl* parent = nullptr) noexcept : UILabel(parent, UILabel::s_meta) {}
    public:
        // normal event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
        // render
        void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept override;
#endif
        // after set text
        void after_set_text() noexcept;
        // on text changed
        void on_text_changed() noexcept;
        // init label
        void reset_font() noexcept;
        // setup access key
        void setup_access_key() noexcept;
        // is default href
        auto is_def_href() const noexcept { return !m_href.empty() 
#ifndef LUI_DISABLE_STYLE_SUPPORT
            && m_oStyle.matched.empty()
#endif
            ; }
    public:
        // get text
        auto GetText() const noexcept { return m_string.c_str(); }
        // get text- string object
        auto&GetTextString() const noexcept { return m_string; }
        // set text, return true if changed
        bool SetText(const CUIString& text) noexcept;
        // set text, return true if changed
        bool SetText(CUIString&& text) noexcept;
        // set text, return true if changed
        bool SetText(U16View text) noexcept;
        // set default minsize
        void SetAsDefaultMinsize() noexcept;
    public:
        // set connection control
        void SetControl(UIControl& ctrl) noexcept { m_control.SetControl(&ctrl); }
        // show access key
        void ShowAccessKey(bool show = true) noexcept;
    protected:
        // hovered curor
        CUICursor               m_hrefCursor;
        // connection control
        NamedControl            m_control;
        // text font buffer
        TextFont                m_tfBuffer;
        // href text
        CUIConstShortString     m_href;
        // text layout
        CUITextLayout           m_text;
        // outline renderer
        CUITextOutline          m_outline;
        // text string
        CUIString               m_string;
        // access key position
        uint32_t                m_uPosAkey = 0;
    public:
        // default value
        enum : int32_t {
            // ** fonts are much differenty with each other
            // ** use this to adjust

            // default text x offset
            DEFUALT_TEXT_X_OFFSET = 0,
            // default text y offset
            DEFUALT_TEXT_Y_OFFSET = 0,
        };
    };
    // get meta info for UILabel
    LUI_DECLARE_METAINFO(UILabel);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui header

// ui namespace
namespace LongUI {
    // caption
    class UICaption : public UILabel {
        // super class
        using Super = UILabel;
    protected:
        // ctor
        UICaption(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UICaption() noexcept;
        // ctor
        UICaption(UIControl* parent = nullptr) noexcept : UICaption(parent, UICaption::s_meta) {}
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
    };
    // get meta info for UICaption
    LUI_DECLARE_METAINFO(UICaption);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // image control
    class UIImage;
    // checkbox
    class UICheckBox : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
        // init checkbox
        void init_checkbox() noexcept;
    public:
        // on commnad event
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
    public:
        // set indeterminate
        void SetIndeterminate() noexcept;
        // set checked
        void SetChecked(bool checked) noexcept;
        // set image source
        void SetImageSource(U8View src) noexcept;
        // get checked
        auto GetChecked() const noexcept { return m_oStyle.state.checked; }
        // get indeterminate
        auto GetIndeterminate() const noexcept { return m_oStyle.state.indeterminate; }
        // toggle this
        void Toggle() noexcept { return this->SetChecked(!this->GetChecked()); }
        // get text
        auto GetText() const noexcept ->const char16_t*;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
    protected:
        // ctor
        UICheckBox(UIControl* parent, const MetaControl& ) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UICheckBox() noexcept;
        // ctor
        UICheckBox(UIControl* parent = nullptr) noexcept : UICheckBox(parent, UICheckBox::s_meta) {}
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    public:
        // render
        //void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // set indeterminate
        void change_indeterminate(bool) noexcept;
        // change state
        void changed() noexcept;
    private:
        // private data
        Private*                m_private = nullptr;
        // image child
        UIImage*                m_pImageChild = nullptr;
    };
    // get meta info for UICheckBox
    LUI_DECLARE_METAINFO(UICheckBox);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // stack container
    class UIStack : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UIStack(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIStack() noexcept;
        // ctor
        UIStack(UIControl* parent = nullptr) noexcept : UIStack(parent, UIStack::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        //// update, postpone change some data
        void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // refresh min size
        void refresh_minsize() noexcept;
        // relayout stack
        void relayout_stack() noexcept;
    protected:
        // add child
        //void add_child(UIControl& child) noexcept override;
    private:
    };
    // get meta info for UIStack
    LUI_DECLARE_METAINFO(UIStack);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // deck container
    class UIDeck : public UIStack {
        // super class
        using Super = UIStack;
    protected:
        // ctor
        UIDeck(UIControl* parent, const MetaControl&) noexcept;
    public:
        // selected changed
        //static inline constexpr auto _selectedChanged() noexcept { return GuiEvent::Event_Change; }
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIDeck() noexcept;
        // ctor
        UIDeck(UIControl* parent = nullptr) noexcept : UIDeck(parent, UIDeck::s_meta) {}
    public:
        // set selected index
        void SetSelectedIndex(uint32_t) noexcept;
        // get selected index
        auto GetSelectedIndex() const noexcept { return m_index; }
    public:
        //// do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        //// update, postpone change some data
        void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // on index changed
        void on_index_changed() noexcept;
        // selected index
        uint32_t            m_index = 0;
    private:
    };
    // get meta info for UIDeck
    LUI_DECLARE_METAINFO(UIDeck);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui
// tmp->hbox

// ui namespace
namespace LongUI {
    // caption
    class UICaption;
    // groupbox
    class UIGroupBox : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    protected:
        // ctor
        UIGroupBox(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIGroupBox() noexcept;
        // ctor
        UIGroupBox(UIControl* parent = nullptr) noexcept : UIGroupBox(parent, UIGroupBox::s_meta) {}
    public:
         //update this
        //void Update() noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // add child
        void add_child(UIControl& child) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept;
#endif
    private:
        // relayout this box
        //void relayout() noexcept;
    private:
        // private data
        Private*                m_private = nullptr;
        // caption
        UICaption*              m_pCaption = nullptr;
    };
    // get meta info for UIGroupBox
    LUI_DECLARE_METAINFO(UIGroupBox);
}
//#pragma interface

// ui
// c++
#include <cstdint>

// ui namespace
namespace LongUI {
    // Shared Resource Object
    class CUISharedResource;
    // resource manager
    class CUIResMgr;
    // resource type
    enum class ResourceType : uhalfptr_t {
        // custom type
        Type_Custom = 0,
        // image type
        Type_Image,
    };
    // Resource Data
    struct ResourceData {
        // shared object
        CUISharedResource*  obj;
        // utf-8 string of uri
        const char*         uri;
        // ref-count
        uhalfptr_t          ref;
        // type of resource
        ResourceType        type;
    };
    // Shared Resource
    class PCN_NOVTABLE CUISharedResource : 
        protected IUIDestroyable,
        protected CUISmallObject {
        // friend class
        friend class CUIResMgr;
    public:
        // render
    public:
        // def ctor
        CUISharedResource() noexcept = default;
        // def dtor
        ~CUISharedResource() noexcept = default;
        // no move ctor
        CUISharedResource(CUISharedResource&&) noexcept = delete;
        // no copy ctor
        CUISharedResource(const CUISharedResource&) noexcept = delete;
    };
}

// ui

// c++
#include <cstdint>

// ui namespace
namespace LongUI {
    // Shared Resource ID
    class CUIResourceID : public CUINoMo {
    public:
        // copy
        CUIResourceID(const CUIResourceID&) noexcept = delete;
        // ctor
        CUIResourceID() noexcept {}
        // dtor
        ~CUIResourceID() noexcept;
    public:
        // get id
        auto GetId() const noexcept { return m_id; }
        // set a new id
        void SetId(uint32_t id) noexcept;
        // get resource data
        auto GetResoureceData() const noexcept -> const ResourceData&;
        // get resource uri
        auto GetResoureceUri() const noexcept { return GetResoureceData().uri; }
        // get resource obj
        auto GetResoureceObj() const noexcept { return GetResoureceData().obj; }
        // get resource type
        auto GetResoureceType() const noexcept { return GetResoureceData().type; }
    private:
        // id
        uint32_t            m_id = 0;
    };
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui

#define LUI_IMAGE_ASICON_SUPPORT

// ui namespace
namespace LongUI {
    // image resource
    class CUIImage;
    // image control
    class UIImage : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // set image source
        void SetSource(U8View src) noexcept;
#ifdef LUI_IMAGE_ASICON_SUPPORT
        // just set center contain
        void JustSetAsIcon() noexcept { m_bAsIcon = true; }
#else
        // just set center contain
        void JustSetAsIcon() noexcept { }
#endif
    protected:
        // ctor
        UIImage(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIImage() noexcept;
        // ctor
        UIImage(UIControl* parent = nullptr) noexcept : UIImage(parent, UIImage::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // mouse event
        //auto DoMouseEvent(const MouseEventArg & e) noexcept->EventAccept override;
        // recreate_device
        //auto Recreate() noexcept->Result override;
        // render
        void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
    protected:
        // shared image
        CUIImage*           m_pSharedSrc = nullptr;
        // image id
        CUIResourceID       m_idSrc;
#ifdef LUI_IMAGE_ASICON_SUPPORT
        // as icon
        bool                m_bAsIcon = false;
#endif
    };
    // get meta info for UIImage
    LUI_DECLARE_METAINFO(UIImage);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // list cols
    class UIListCols;
    // list item
    class UIListItem;
    // list head
    class UIListHead;
    // list body(ScrollArea)
    class UIScrollArea;
    // listbox control
    class UIListBox : public UIControl {
        // super class
        using Super = UIControl;
        // item list
        using ItemList = POD::Vector<UIListItem*>;
    protected:
        // ctor
        UIListBox(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListBox() noexcept;
        // ctor
        UIListBox(UIControl* parent = nullptr) noexcept : UIListBox(parent, UIListBox::s_meta) {}
    public:
        // is multi-selected?
        bool IsMultiple() const noexcept { return m_seltype == Seltype_Multiple; }
        // get cols
        auto GetCols() const noexcept { return m_pCols; }
        // item removed. called from UIListItem's dtor
        void ItemRemoved(UIListItem&) noexcept;
        // get item index
        auto GetItemIndex(const UIListItem&) noexcept -> uint32_t;
        // get item count
        auto GetItemCount() const noexcept { return m_list; }
        // get item at
        auto GetItemAt(uint32_t i) const noexcept { return m_list[i]; }
        // insert item to
        auto InsertItem(uint32_t index, const CUIString&) noexcept -> UIListItem*;
        // select item
        void SelectItem(UIListItem&, bool exadd) noexcept;
        // select to
        void SelectTo(UIListItem&) noexcept;
        // clear select
        void ClearSelected(UIListItem&) noexcept;
        // clear all select
        void ClearAllSelected() noexcept;
        // get selected items
        auto&GetSelected() const noexcept { return m_selected; };
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept;
        // add child
        void add_child(UIControl& child) noexcept override;
        // re-layout
        void relayout() noexcept;
        // refresh cols min size
        void refresh_cols_minsize() noexcept;
        // refresh this min size
        void refresh_minsize() noexcept;
        // select item
        void select_item(UIListItem& item) noexcept;
        // refresh items index
        void refresh_item_index() noexcept;
        // need refresh index
        bool need_refresh_index() const noexcept { return m_state.custom_data; }
        // clear need refresh index
        void clear_need_refresh_index() noexcept { m_state.custom_data = false; }
        // clear need refresh index
        void mark_need_refresh_index() noexcept { m_state.custom_data = true; }
    private:
        // list cols
        UIListCols*         m_pCols = nullptr;
        // list head
        UIListHead*         m_pHead = nullptr;
        // last op
        UIListItem*         m_pLastOp = nullptr;
        // listbox body
        UIScrollArea*       m_pListboxBody = nullptr;
        // item list
        ItemList            m_list;
        // selected
        ItemList            m_selected;
        // minwidth
        POD::Vector<float>  m_minwidth;
        // display row | xul::rows related
        uint16_t            m_displayRow = 4;
        // unused u8
        char                m_unusedU8 = 0;
        // select type
        AttributeSeltype    m_seltype = Seltype_Single;
    };
    // get meta info for UIListBox
    LUI_DECLARE_METAINFO(UIListBox);
}



/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // listcol
    class UIListCol : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UIListCol(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListCol() noexcept;
        // ctor
        UIListCol(UIControl* parent = nullptr) noexcept:UIListCol(parent, UIListCol::s_meta) {}
        // render
        void Render() const noexcept override;
    };
    // get meta info for UISpacer
    LUI_DECLARE_METAINFO(UIListCol);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // list col
    class UIListCol;
    // listcols control
    class UIListCols : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // item list
        //using ColList = POD::Vector<UIListCol*>;
    protected:
        // ctor
        UIListCols(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListCols() noexcept;
        // ctor
        UIListCols(UIControl* parent = nullptr) noexcept : UIListCols(parent, UIListCols::s_meta) {}
        // will relayout?
        bool WillRelayout() const noexcept { return this->is_need_relayout(); }
        // match layout
        void MatchLayout(UIControl&) noexcept;
    protected:
        // add child
        //void add_child(UIControl& child) noexcept override;
    protected:
        // item list
        //ColList             m_list;
    };
    // get meta info for UIListCols
    LUI_DECLARE_METAINFO(UIListCols);
}


/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // listhead control
    class UIListHead : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    protected:
        // ctor
        UIListHead(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListHead() noexcept;
        // ctor
        UIListHead(UIControl* parent = nullptr) noexcept : UIListHead(parent, UIListHead::s_meta) {}
    protected:
        // add child
        //void add_child(UIControl& child) noexcept override;
        // re-layout
        void relayout() noexcept override;
    private:
    };
    // get meta info for UIListHead
    LUI_DECLARE_METAINFO(UIListHead);
}


/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // listheader
    class UIListHeader : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListHeader() noexcept;
        // ctor
        UIListHeader(UIControl* parent = nullptr) noexcept : UIListHeader(parent, UIListHeader::s_meta) {}
    protected:
        // ctor
        UIListHeader(UIControl* parent, const MetaControl&) noexcept;
    public:
        // clicked event
        //static inline constexpr auto _clicked() noexcept { return GuiEvent::Event_Click; }
    public:
        // get text
        //auto GetText() const noexcept ->const wchar_t*;
        //// get text- string object
        //auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
    public:
        // do event
        //auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // relayout
        //void relayout() noexcept override;
        // add private child
        //void add_private_child() noexcept;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        //auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    private:
        // private data
        Private*                m_private = nullptr;
    };
    // get meta info for UIListHeader
    LUI_DECLARE_METAINFO(UIListHeader);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // listbox
    class UIListBox;
    // listitem
    class UIListItem : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIListItem() noexcept;
        // ctor
        UIListItem(UIControl* parent = nullptr) noexcept : UIListItem(parent, UIListItem::s_meta) {}
    protected:
        // ctor
        UIListItem(UIControl* parent, const MetaControl&) noexcept;
    public:
        // clicked event
        //static inline constexpr auto _clicked() noexcept { return GuiEvent::Event_Click; }
    public:
        // is selected?
        auto IsSelected() const noexcept { return m_oStyle.state.selected; }
    public:
        // get index
        auto GetIndex() const noexcept->uint32_t;
        // get text
        auto GetText() const noexcept ->const char16_t*;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
    public:
        // do event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
    protected:
        // relayout
        void relayout() noexcept override;
        // add private child
        void add_private_child() noexcept;
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        //auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    private:
        // parent box 
        UIListBox*          m_pListBox = nullptr;
        // private data
        Private*            m_private = nullptr;
    };
    // get meta info for UIListItem
    LUI_DECLARE_METAINFO(UIListItem);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // menu
    class UIMenu : public UIButton {
        // super class
        using Super = UIButton;
        // private impl
        struct Private;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenu() noexcept;
        // ctor
        UIMenu(UIControl* parent = nullptr) noexcept : UIMenu(parent, UIMenu::s_meta) {}
    protected:
        // ctor
        UIMenu(UIControl* parent, const MetaControl&) noexcept;
    public:
        // do normal event
        auto DoEvent(UIControl*, const EventArg&)noexcept->EventAccept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
        // add attribute : key = bkdr hashed string key, this method valid before inited
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // try show next level menu
        void try_show_next_level_menu() noexcept;
        // arrow item if UIMenu as child of UIMenuPopup
        UIControl*          m_pMenuArrow = nullptr;
    };
    // get meta info for UIMenu
    LUI_DECLARE_METAINFO(UIMenu);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // menu
    class UIMenu;
    // menubar
    class UIMenuBar : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuBar() noexcept;
        // ctor
        UIMenuBar(UIControl* parent = nullptr) noexcept : UIMenuBar(parent, UIMenuBar::s_meta) {}
    protected:
        // lui std ctor
        UIMenuBar(UIControl* parent, const MetaControl&) noexcept;
        // now popup menu
        UIMenu*             m_pPopupNow = nullptr;
    public:
        // has now menu?
        auto HasNowMenu(UIMenu& m) const noexcept { return m_pPopupNow && m_pPopupNow != &m; }
        // set now menu
        void SetNowMenu(UIMenu& m) noexcept { m_pPopupNow = &m; }
        // clear now menu
        void ClearNowMenu() noexcept { m_pPopupNow = nullptr; }
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIMenuBar);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // menuitem
    class UIMenuItem : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
        // init menuitem
        void init_menuitem() noexcept;
    protected:
        // ctor
        UIMenuItem(UIControl* parent, const MetaControl& ) noexcept;
    public:
        // command: this item is selected
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
    public:
        // set check (if in checkbox/radio mode)
        void SetChecked(bool checked) noexcept;
        // is checked?
        auto IsChecked() const noexcept { return m_oStyle.state.checked; }
        // get text
        auto GetText() const noexcept->const char16_t*;
        // get text object
        auto GetTextString() const noexcept->const CUIString&;
        // set text
        void SetText(CUIString&&) noexcept;
        // set text
        void SetText(U16View) noexcept;
    public:
        // ICON WIDTH
        enum : uint32_t { ICON_WIDTH = 28 };
        // item type
        enum ItemType : uint32_t {
            // normal type
            Type_Normal = 0,
            // checkbox
            Type_CheckBox,
            // radio
            Type_Radio,
        };
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuItem() noexcept;
        // ctor
        UIMenuItem(UIControl* parent = nullptr) noexcept : UIMenuItem(parent, UIMenuItem::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // re-layout
        //void relayout() noexcept override;
        // view to type
        static auto view2type(U8View) noexcept->ItemType;
        // do check box
        void do_checkbox() noexcept;
        // do radio
        void do_radio() noexcept;
    private:
        // private data
        Private*            m_private = nullptr;
    protected:
        // group name
        const char*         m_pName = nullptr;
        // item type
        ItemType            m_type = Type_Normal;
    };
    // get meta info for UIMenuItem
    LUI_DECLARE_METAINFO(UIMenuItem);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // menu popup
    class UIMenuPopup;
    // menulist/combobox
    class UIMenuList : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
        // menu list
        void init_menulist();
    public:
        // command selected changed
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
        // select: item selected
        //static constexpr auto _onSelect() noexcept { return GuiEvent::Event_OnSelect; }
    protected:
        // ctor
        UIMenuList(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuList() noexcept;
        // ctor
        UIMenuList(UIControl* parent = nullptr) noexcept : UIMenuList(parent, UIMenuList::s_meta) {}
    public:
        // get popup pointer
        auto GetPopupObj() const noexcept { return m_pMenuPopup; }
        // show popup
        void ShowPopup() noexcept;
        // get text
        auto GetText() const noexcept ->const char16_t*;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
        // set selected index
        //void SetSelectedIndex(long) noexcept;
        // get selected index
        long GetSelectedIndex() const noexcept { return m_iSelected; }
    public:
        // update
        //void Update() noexcept override;
        // do event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept->EventAccept override;
        // render
        //void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible event
        //auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    protected:
        // on popup selected changed
        void on_selected_changed() noexcept;
    private:
        // popup
        UIMenuPopup*            m_pMenuPopup = nullptr;
        // private data
        Private*                m_private = nullptr;
        // selected index
        long                    m_iSelected = -1;
    };
    // get meta info for UIMenuList
    LUI_DECLARE_METAINFO(UIMenuList);
}

// ui
// c++
#include <cstddef>

namespace LongUI {
    /// <summary>
    /// window event handle class
    /// </summary>
    class CUIWindowEvent {
    public:
        // on window event: Resize
        //void OnResize(Size2U size) noexcept;
        // on window event: Closed
        //void OnClosed() noexcept;
    };
}

// HANDLE FOR WINDOWS
#define LUI_DECLARE_HANDLE(name) struct name##__; using name = name##__ *;
LUI_DECLARE_HANDLE(HWND);
LUI_DECLARE_HANDLE(HRAWINPUT);
#undef LUI_DECLARE_HANDLE



// ui
// c++
#include <cstddef>

namespace LongUI {
    // style sheet
    class CUIStyleSheet;
    // Cursor
    class CUICursor;
    // window manager
    class CUIWndMgr;
    // color
    struct ColorF;
    // popup type
    enum class PopupType : uint32_t;
    /// <summary>
    /// window base class
    /// </summary>
    class CUIWindow final : public CUIWindowEvent, public CUINoMo {
        // private impl
        class Private;
        // friend class
        friend class UIViewport;
        // friend class
        friend class CUIWndMgr;
#ifdef LUI_ACCESSIBLE
        // friend class
        friend class CUIAccessibleWnd;
#endif
        // show type
        enum TypeShow : int32_t {
            Show_Hide   = 0,
            Show_Show   = 1,
            Show_Min    = 2,
            Show_Max    = 3,
            Show_NA     = 8,    // not activated
            Show_Restore= 9,
        };
        // show window
        void show_window(TypeShow) noexcept;
        // close window
        void close_window() noexcept;
    public:
        // window config
        enum WindowConfig : uint16_t {
            // press esc to close window
            Config_EscToCloseWindow = 1 << 0,
            // press alt+f4 to close window
            Config_AltF4ToCloseWindow = 1 << 1,
            // quit on close
            Config_QuitOnClose = 1 << 2,
            // delete on close
            Config_DeleteOnClose = 1 << 3,

            // popup window
            Config_Popup = 1 << 8,
            // frameless window
            Config_Frameless = 1 << 9,
            // tool window, no included in "quit on close"
            Config_ToolWindow = 1 << 10,
            // fixed size, cannot drag to resize but invoke Resize()
            Config_FixedSize = 1 << 11,
            // layered window[support for Win8.1 and higher]
            Config_LayeredWindow = 1 << 12,

            // default config
            Config_Default = Config_AltF4ToCloseWindow,
        };
    public:
        // hide the window
        void HideWindow() noexcept { this->show_window(Show_Hide); }
        // show the window
        void ShowWindow() noexcept { this->show_window(Show_Show); }
        // min the window
        void MinWindow() noexcept { this->show_window(Show_Min); }
        // max the window
        void MaxWindow() noexcept { this->show_window(Show_Max); }
        // show the window - not activated.
        void ShowNoActivate() noexcept { this->show_window(Show_NA); }
        // restore the window
        void RestoreWindow() noexcept { this->show_window(Show_Restore); }
        // close window
        void CloseWindow() noexcept;
        // active window
        void ActiveWindow() noexcept;
        // is visible
        bool IsVisible() const noexcept;
        // is in dtor
        bool IsInDtor() const noexcept { return m_inDtor; }
        // is ctor failed?
        bool IsCtorFailed() const noexcept { return m_bCtorFaild; }
        // mark full rendering
        void MarkFullRendering() noexcept;
        // is auto sleep?
        bool IsAutpSleep() const noexcept { return !!(config & Config_Popup); }
        // is in sleep mode?
        auto IsInSleepMode() const noexcept { return !m_hwnd; }
        // into sleep mode immediately
        void IntoSleepImmediately() noexcept;
        // try sleep
        void TrySleep() noexcept;
        // wake up
        void WakeUp() noexcept;
        // set result to exit Exec()
        void SetResult(uintptr_t) noexcept;
        // execute, as modal window if parent window exist
        auto Exec() noexcept -> uintptr_t;
        // is in exec
        bool IsInExec() const noexcept { return m_bInExec; }
#ifndef LUI_DISABLE_STYLE_SUPPORT
    public:
        // load css file
        void LoadCssFile(U8View file) noexcept;
        // load css string
        void LoadCssString(U8View string) noexcept;
        // get style sheet
        auto GetStyleSheet() const noexcept { return m_pStyleSheet; }
#endif
    public:
        // map to screen
        void MapToScreen(RectF& rect) const noexcept;
        // map to screen
        void MapToScreen(Point2F& pos) const noexcept;
        // map from screen
        //void MapFromScreen(RectF& rect) const noexcept;
        // map from screen
        void MapFromScreen(Point2F& pos) const noexcept;
        // hi-dpi support
        void HiDpiSupport() noexcept;
    public:
        // show popup window
        void PopupWindow(CUIWindow& wnd, Point2F pos, PopupType type) noexcept;
        // set tooltip text, return tooltip viewport pointer
        auto TooltipText(CUIString&&) noexcept ->UIViewport*;
        // close all popupwindow
        void ClosePopup() noexcept;
        // get now popupwindow
        auto GetNowPopup() const noexcept->CUIWindow*;
        // get now popupwindow with type
        auto GetNowPopup(PopupType type) const noexcept->CUIWindow*;
        // close tooltip
        void CloseTooltip() noexcept;
        // set title name
        void SetTitleName(const char16_t*) noexcept;
        // set title name
        void SetTitleName(CUIString&&) noexcept;
        // get title name
        auto GetTitleName() const noexcept->U16View;
        // set pos of window
        void SetPos(Point2L pos) noexcept;
        // get pos of window
        auto GetPos() const noexcept->Point2L;
        // set absolute rect(= set pos + resize)
        void SetAbsoluteRect(const RectL& rect) noexcept;
        // resize window  : absolute
        void ResizeAbsolute(Size2L size) noexcept;
        // resize window : relative
        void ResizeRelative(Size2F size) noexcept;
        // set color color
        void SetClearColor(const ColorF&) noexcept;
        // set now cursor
        void SetNowCursor(const CUICursor&) noexcept;
        // set now cursor to default
        void SetNowCursor(std::nullptr_t) noexcept;
    public:
        // register access key
        void RegisterAccessKey(UIControl& ctrl) noexcept;
        // find control, return null if notfound
        auto FindControl(const char* id) noexcept ->UIControl*;
        // control attached
        void ControlAttached(UIControl& ctrl) noexcept;
        // control disattached              [null this ptr acceptable]
        void ControlDisattached(UIControl& ctrl) noexcept;
        // add named control                [null this ptr acceptable]
        void AddNamedControl(UIControl& ctrl) noexcept;
        // close popupwindow until not popup[null this ptr acceptable]
        void ClosePopupHighLevel() noexcept;
        // set captured control
        void SetCapture(UIControl& ctrl) noexcept;
        // release captured control, return true if released
        bool ReleaseCapture(UIControl& ctrl) noexcept;
        // set focus of control,
        bool SetFocus(UIControl& ctrl) noexcept;
        // kill focus of control,
        void KillFocus(UIControl& ctrl) noexcept;
        // set now default control
        void SetDefault(UIControl& ctrl) noexcept;
        // reset window default control(set window-default control to default)
        void ResetDefault() noexcept;
        // mark dirty rect
        void MarkDirtRect(const RectF& rect) noexcept;
        // will do full render this frame?
        bool IsFullRenderThisFrame() const noexcept;
    public:
        // delete later
        void DeleteLater() noexcept;
        // delete now
        void Delete() noexcept;
        // set control world changed
        void SetControlWorldChanged(UIControl&) noexcept;
        // before render
        void BeforeRender() noexcept;
        // render
        auto Render() noexcept->Result;
        // Recreate
        auto RecreateDeviceData() noexcept->Result;
        // release window device data
        void ReleaseDeviceData() noexcept;
        // get viewport
        auto RefViewport() noexcept ->UIViewport&;
        // get viewport
        auto RefViewport() const noexcept->const UIViewport& { 
            return const_cast<CUIWindow*>(this)->RefViewport(); }
        // get parent
        auto GetParent() const noexcept { return m_parent; }
        // get window handle
        HWND GetHwnd() const { return m_hwnd; }
        // is top level window
        bool IsTopLevel() const noexcept { return !m_parent; }
        // is inline window
        bool IsInlineWindow() const noexcept { return false; }
        // mark: has script
        void MarkHasScript() noexcept { m_bHasScript = true; }
    protected:
        // recursive set result
        void recursive_set_result(uintptr_t result) noexcept;
        // add child
        void add_child(CUIWindow& child) noexcept;
        // remove child
        void remove_child(CUIWindow& child) noexcept;
        // recreate_device window
        auto recreate_window() noexcept->Result;
        // release window only device data
        void release_window_only_device() noexcept;
        // ctor
        CUIWindow(CUIWindow* parent, WindowConfig cfg) noexcept;
        // no copy
        CUIWindow(const CUIWindow&) noexcept = delete;
        // dtor
        ~CUIWindow() noexcept;
    private:
        // private data
        Private*            m_private = nullptr;
    protected:
        // window handle
        HWND                m_hwnd = nullptr;
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // style sheet
        CUIStyleSheet*      m_pStyleSheet = nullptr;
#endif
        // parent window
        CUIWindow*          m_parent = nullptr;
        // topest world changed control
        UIControl*          m_pTopestWcc = nullptr;
#ifdef LUI_ACCESSIBLE
        // accessible
        CUIAccessibleWnd*   m_pAccessible = nullptr;
#endif
    public:
        // custom script data
        void*               custom_script_data = nullptr;
        // config
        WindowConfig  const config;
    protected:
        // in dtor
        bool                m_inDtor : 1;
        // in exec
        bool                m_bInExec : 1;
        // has script
        bool                m_bHasScript : 1;
        // ctor failed
        bool                m_bCtorFaild : 1;
        // state: under "minsize changed" list
        bool                m_bMinsizeList = false;
    };
    // WindowConfig | WindowConfig
    inline CUIWindow::WindowConfig operator|(
        CUIWindow::WindowConfig a, CUIWindow::WindowConfig b) noexcept {
        using target_t = uint16_t;
        static_assert(sizeof(target_t) == sizeof(CUIWindow::WindowConfig), "same!");
        const auto aa = static_cast<target_t>(a);
        const auto bb = static_cast<target_t>(b);
        return CUIWindow::WindowConfig(aa | bb);
    }
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


namespace LongUI {
    // viewport, logic window viewport
    class UIViewport : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // viewports
        using Viewports = POD::Vector<UIViewport*>;
        // friend window
        friend CUIWindow;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // [NEW] on window closed
        virtual void WindowClosed() noexcept;
        // [NEW] on subview popup
        virtual void SubViewportPopupBegin(UIViewport&, PopupType) noexcept;
        // [NEW] on subview popup closed
        virtual void SubViewportPopupEnd(UIViewport&, PopupType) noexcept;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View view) noexcept override;
        // ctor for control
        UIViewport(UIControl& pseudo_parent, CUIWindow::WindowConfig, const MetaControl&) noexcept;
    public:
        // ctor
        UIViewport(
            CUIWindow* parent = nullptr,
            CUIWindow::WindowConfig config = CUIWindow::Config_Default
        ) noexcept;
        // dtor
        ~UIViewport() noexcept;
        // ref the window
        auto&RefWindow() noexcept { return m_window; }
        // get hoster
        auto GetHoster() const noexcept { return m_pHoster; }
        // assin new hoster
        void AssignNewHoster(UIControl& h) noexcept { m_pHoster = &h; }
        // PopupBegin to hoster
        void HosterPopupBegin() noexcept;
        // PopupEnd to hoster
        void HosterPopupEnd() noexcept;
        // add subviewport
        void AddSubViewport(UIViewport& sub) noexcept;
        // find subviewport with unique string
        auto FindSubViewportWithUnistr(const char*) const noexcept->UIViewport*;
        // find subviewport with normal string
        auto FindSubViewport(U8View view) const noexcept->UIViewport*;
        // just reset zoom
        void JustResetZoom(float x, float y) noexcept;
        // get real size(size * scale)
        auto GetRealSize() const noexcept { return m_szReal; }
        // Adjust size
        auto AdjustSize(Size2F) const noexcept->Size2L;
        // Adjust size
        auto AdjustZoomedSize(Size2F, Size2L) const noexcept->Size2L;
    private:
        // resize window
        void resize_window(Size2F size) noexcept;
    protected:
        // real size
        Size2F              m_szReal = {};
        // window
        CUIWindow           m_window;
        // last hoster, will set null after closed
        UIControl*          m_pHoster = nullptr;
        // sub-viewports
        Viewports           m_subviewports;
    };
    // get meta info for UIViewport
    LUI_DECLARE_METAINFO(UIViewport);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui

// ui namespace
namespace LongUI {
    // ui meta typedef
    struct UIMetaTypeDef;
    // menu list
    class UIMenuList;
    // menu item
    class UIMenuItem;
    // menupopup control
    class UIMenuPopup : public UIViewport {
        // super class
        using Super = UIViewport;
        // friend class
        friend UIMenuList;
        // friend class
        friend UIMenuItem;
        // friend class
        friend UIMetaTypeDef;
    public:
        // command selected changed
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
    protected:
        // ctor
        UIMenuPopup(UIControl* hoster, const MetaControl&) noexcept;
        // init hoster
        void init_hoster(UIControl* hoster) noexcept { m_pHoster = hoster; }
        // set selected
        //void set_selected(UIControl* hoster) noexcept { m_pHoster = hoster; }
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuPopup() noexcept;
        // ctor
        UIMenuPopup(UIControl* hoster) noexcept : UIMenuPopup(hoster, UIMenuPopup::s_meta) {}
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept;
        // window closed
        void WindowClosed() noexcept override;
        // popup begin
        void SubViewportPopupBegin(UIViewport&, PopupType) noexcept override;
    public:
        // add item
        void AddItem(CUIString&& label) noexcept;
        // get last selected
        auto GetLastSelected() const noexcept { return m_pLastSelected; }
        // get selected index
        auto GetSelectedIndex() const noexcept { return m_iSelected; }
        // select first item
        void SelectFirstItem() noexcept;
        // clear select
        void ClearSelected() noexcept;
        // set delay closed popup
        void SetDelayClosedPopup() noexcept;
        // mark no delay closed popup
        void MarkNoDelayClosedPopup() noexcept;
    protected:
        // add child
        //void add_child(UIControl& child) noexcept override;
        // select child
        void select(UIControl* child) noexcept;
        // change select
        static void change_select(UIControl* old, UIControl* now) noexcept;
        // save selected?
        auto is_save_selected() const noexcept { return m_state.custom_data; }
        // save selected: true
        auto save_selected_true() noexcept { m_state.custom_data = true; }
        // save selected: false
        auto save_selected_false() noexcept { m_state.custom_data = false; }
        // init clear color for defualt ctxmenu
        void init_clear_color_for_default_ctxmenu() noexcept;
        // init clear color for defualt combobox
        void init_clear_color_for_default_combobox() noexcept;
        // selected before init
        //void selected_before_init(UIControl&c) noexcept { m_pPerSelected = &c; }
    public:
        // has padding for menuitem
        bool HasPaddingForItem() const noexcept { return !is_save_selected(); }
    protected:
        // last-selected
        UIMenuItem*             m_pLastSelected = nullptr;
        // pre-selected
        UIControl*              m_pPerSelected = nullptr;
        // delay closed time capsule
        CUITimeCapsule*         m_pDelayClosed = nullptr;
        // selected index
        int32_t                 m_iSelected = -1;
        // mouse in
        bool                    m_bMouseIn = false;
        // no delay closed once
        bool                    m_bNoClosedOnce = false;
    };
    // get meta info for UIMenuPopup
    LUI_DECLARE_METAINFO(UIMenuPopup);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // spacer
    class UIMenuSeparator : public UIControl {
        // super class
        using Super = UIControl;
        // friend class
        friend UIMetaTypeDef;
    protected:
        // ctor
        UIMenuSeparator(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIMenuSeparator() noexcept = default;
        // ctor
        UIMenuSeparator(UIControl* parent = nullptr) noexcept :UIMenuSeparator(parent, UIMenuSeparator::s_meta) {}
    };
    // get meta info for UIMenuSeparator
    LUI_DECLARE_METAINFO(UIMenuSeparator);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // popupset
    using UIPopup = UIMenuPopup;
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // ui meta typedef
    struct UIMetaTypeDef;
    // spacer
    class UISpacer : public UIControl {
        // super class
        using Super = UIControl;
        // friend class
        friend UIMetaTypeDef;
    protected:
        // ctor
        UISpacer(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UISpacer() noexcept;
        // ctor
        UISpacer(UIControl* parent = nullptr) noexcept:UISpacer(parent, UISpacer::s_meta) {}
        // render
        void Render() const noexcept override;
    };
    // get meta info for UISpacer
    LUI_DECLARE_METAINFO(UISpacer);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // popupset
    using UIPopupSet = UISpacer;
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui
// tmp->hbox

// ui namespace
namespace LongUI {
    // progress
    class UIProgress : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    protected:
        // ctor
        UIProgress(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIProgress() noexcept;
        // ctor
        UIProgress(UIControl* parent = nullptr) noexcept : UIProgress(parent, UIProgress::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl*, const EventArg&) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept;
#endif
    public:
        // get max
        auto GetMax() const noexcept { return m_max; }
        // get value
        auto GetValue() const noexcept { return m_value; }
        // set max
        void SetMax(float max) noexcept;
        // set value
        void SetValue(float value) noexcept;
    private:
        // init this bar
        void init_bar() noexcept;
        // adjust flex
        void adjust_flex() noexcept;
    private:
        // private data
        Private*                m_private = nullptr;
        // max value
        float                   m_max = 100.f;
        // value
        float                   m_value = 0.f;
    };
    // get meta info for UIProgress
    LUI_DECLARE_METAINFO(UIProgress);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // image control
    class UIImage;
    // redio group
    class UIRadioGroup;
    // radio
    class UIRadio : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
        // init radio
        void init_radio() noexcept;
    public:
        // on commnad event
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
    public:
        // set checked
        void SetChecked(bool) noexcept;
        // set selected(sameas checked)
        void SetSelected(bool sel) noexcept { this->SetChecked(sel); }
        // set image source
        void SetImageSource(U8View src) noexcept;
        // get text
        auto GetText() const noexcept ->const char16_t*;
        // get text- string object
        auto GetTextString() const noexcept -> const CUIString&;
        // set text
        void SetText(const CUIString& text) noexcept;
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View text) noexcept;
    protected:
        // ctor
        UIRadio(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRadio() noexcept;
        // ctor
        UIRadio(UIControl* parent = nullptr) noexcept : UIRadio(parent, UIRadio::s_meta) {}
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
    private:
        // radio group
        UIRadioGroup*       m_pRadioGroup = nullptr;
        // private data
        Private*            m_private = nullptr;
        // image child
        UIImage*            m_pImageChild = nullptr;
    };
    // get meta info for UIRadio
    LUI_DECLARE_METAINFO(UIRadio);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // radio control
    class UIRadio;
    // radiogroup
    class UIRadioGroup : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    public:
        // command selected changed
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
        // select: item selected
        //static constexpr auto _onSelect() noexcept { return GuiEvent::Event_OnSelect; }
    public:
        // get checked radio
        auto GetChecked() const noexcept { return m_pChecked; }
        // set checked radio
        void SetChecked(UIRadio& radio) noexcept { this->set_checked(&radio); }
        // set checked radio to null
        void SetChecked(std::nullptr_t) noexcept { this->set_checked(nullptr); }
    protected:
        // ctor
        UIRadioGroup(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRadioGroup() noexcept;
        // ctor
        UIRadioGroup(UIControl* parent = nullptr) noexcept : UIRadioGroup(parent, UIRadioGroup::s_meta) {}
        // update
        void Update() noexcept override;
        //// do normal event
        //auto DoEvent(UIControl* sender, const EventArg& arg) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    private:
        // set checked radio
        void set_checked(UIRadio* radio) noexcept;
    protected:
        // checked radio
        UIRadio*            m_pChecked = nullptr;
    };
    // get meta info for UIRadioGroup
    LUI_DECLARE_METAINFO(UIRadioGroup);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // item
    class UIRichListItem;
    // rich listbox
    class UIRichListBox : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRichListBox() noexcept;
        // ctor
        UIRichListBox(UIControl* parent = nullptr) noexcept : UIRichListBox(parent, UIRichListBox::s_meta) {}
        // do event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // get now selected
        auto GetSelected() const noexcept { return m_pSelectedItem; };
        // select item, null to clear selected
        void SelectItem(UIRichListItem* item =nullptr) noexcept;
        // item detach
        void ItemDetached(UIRichListItem& item) noexcept;
    protected:
        // add child
        void add_child(UIControl& ctrl) noexcept override;
        // lui std ctor
        UIRichListBox(UIControl* parent, const MetaControl&) noexcept;
        // selected item
        UIRichListItem*         m_pSelectedItem = nullptr;
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIRichListBox);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // box
    class UIRichListBox;
    // tool bar
    class UIRichListItem : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend UIRichListBox;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIRichListItem() noexcept;
        // ctor
        UIRichListItem(UIControl* parent = nullptr) noexcept : UIRichListItem(parent, UIRichListItem::s_meta) {}
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    protected:
        // set selected
        void set_selected(bool) noexcept;
        // lui std ctor
        UIRichListItem(UIControl* parent, const MetaControl&) noexcept;
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIRichListItem);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui

// ui namespace
namespace LongUI {
    // scale/slider control
    class UIScale : public UIControl {
        // super class
        using Super = UIControl;
        // init slider
        void init_slider() noexcept;
        // mouse click
        void mouse_click(Point2F) noexcept;
    protected:
        // ctor
        UIScale(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIScale() noexcept;
        // ctor
        UIScale(UIControl* parent = nullptr) noexcept:UIScale(parent, UIScale::s_meta) {}
    public:
        // value changed event
        static constexpr auto _onChange() noexcept { return GuiEvent::Event_OnChange; }
    public:
        // recreate_device
        //auto Recreate() noexcept->Result override;
        // render
        //void Render() const noexcept override;
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept -> EventAccept override;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    public:
        // set orient
        //void SetOrient(AttributeOrient o) noexcept;
        // set value
        void SetValue(float value) noexcept;
        // set min
        void SetMin(float value) noexcept;
        // set max
        void SetMax(float value) noexcept;
        // set page increment
        void SetPageIncrement(float pi) noexcept;
        // add value
        void AddValue(float value) noexcept { SetValue(m_fValue + value); }
        // get min value
        auto GetMin() const noexcept { return m_fMin; }
        // get max value
        auto GetMax() const noexcept { return m_fMax; }
        // get value
        auto GetValue() const noexcept { return m_fValue; }
        // decrease
        void Decrease() noexcept { AddValue(-increment); }
        // increase
        void Increase() noexcept { AddValue(+increment); }
        // decrease page
        void DecreasePage() noexcept { AddValue(-m_fPageIncrement); }
        // increase page
        void IncreasePage() noexcept { AddValue(+m_fPageIncrement); }
        // get orient
        auto GetOrient() const noexcept { return static_cast<AttributeOrient>(m_state.orient); }
        // get page increment
        auto GetPage() const noexcept { return m_fPageIncrement; }
    private:
        // refresh thumb postion
        void refresh_thumb_postion() noexcept;
        // check page increment
        void refresh_thumb_size() noexcept;
    protected:
        // min value
        float                   m_fMin = 0.f;
        // max value
        float                   m_fMax = 100.0f;
        // now value
        float                   m_fValue = 0.f;
        // click offset
        float                   m_fClickOffset = 0.;
        // page increment
        float                   m_fPageIncrement = 10.f;
    public:
        // increment value
        float                   increment = 1.f;
        // thumb control
        UIImage                 thumb;
    };
    // slider
    using UISlider = UIScale;
    // get meta info for UIImage
    LUI_DECLARE_METAINFO(UIScale);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


namespace LongUI {
    // scroll bar
    class UIScrollBar final : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // init bar
        void init_bar() noexcept;
        // private impl
        struct Private;
    protected:
        // ctor
        UIScrollBar(AttributeOrient o, UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // ctor
        UIScrollBar(AttributeOrient o, UIControl* parent = nullptr) noexcept : UIScrollBar(o, parent, UIScrollBar::s_meta) {}
        // ctor
        UIScrollBar(UIControl* parent) noexcept : UIScrollBar(Orient_Vertical, parent, UIScrollBar::s_meta) {}
        // dtor
        ~UIScrollBar() noexcept;
        // update
        void Update() noexcept override;
        // do normal event
        auto DoEvent(UIControl * sender, const EventArg & e) noexcept ->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
    public:
        // get value
        auto GetValue() const noexcept -> float;
    public:
        // set value
        void SetValue(float v) noexcept;
        // set max
        void SetMax(float v) noexcept;
        // set page increment
        void SetPageIncrement(float pi) noexcept;
        // set increment
        void SetIncrement(float pi) noexcept;
#ifdef LUI_ACCESSIBLE
    protected:
        // accessible event
        auto accessible(const AccessibleEventArg&) noexcept->EventAccept override;
#endif
    private:
        // private data
        Private*        m_private = nullptr;
    };
    // get meta info for UIScrollBar
    LUI_DECLARE_METAINFO(UIScrollBar);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // container splitter
    class UISplitter : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UISplitter(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UISplitter() noexcept;
        // ctor
        UISplitter(UIControl* parent = nullptr) noexcept : UISplitter(parent, UISplitter::s_meta) {}
    public:
        // set orient
        void SetOrient(AttributeOrient o) noexcept;
        // get orient
        auto GetOrient() const noexcept { return static_cast<AttributeOrient>(m_state.orient); }
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        //// update, postpone change some data
        //void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // change cursor
        void change_cursor() noexcept;
        // hovered curor
        CUICursor           m_hovered;
        // last clicked pos
        Point2F             m_ptLastPos = {};
    private:
    };
    // get meta info for UISplitter
    LUI_DECLARE_METAINFO(UISplitter);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // status bar
    class UIStatusBar : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIStatusBar() noexcept = default;
        // ctor
        UIStatusBar(UIControl* parent = nullptr) noexcept : UIStatusBar(parent, UIStatusBar::s_meta) {}
    protected:
        // lui std ctor
        UIStatusBar(UIControl* parent, const MetaControl&) noexcept;
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIStatusBar);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // status bar panel
    class UIStatusBarPanel : public UILabel {
        // super class
        using Super = UILabel;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIStatusBarPanel() noexcept = default;
        // ctor
        UIStatusBarPanel(UIControl* parent = nullptr) noexcept : UIStatusBarPanel(parent, UIStatusBarPanel::s_meta) {}
    protected:
        // lui std ctor
        UIStatusBarPanel(UIControl* parent, const MetaControl&) noexcept;
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIStatusBarPanel);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tab item
    class UITab : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // private impl
        struct Private;
    protected:
        // ctor
        UITab(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITab() noexcept;
        // ctor
        UITab(UIControl* parent = nullptr) noexcept : UITab(parent, UITab::s_meta) {}
    public:
        // set selected
        void SetSelected() noexcept;
        // set text
        void SetText(const CUIString& str) noexcept;
        // force mark selected
        void ForceMark() noexcept { m_oStyle.state.selected = true; }
        // force mark after
        void ForceAfter() noexcept { m_oStyle.state.after_seltab = true; }
        // force clear after
        void ForceBefore() noexcept { m_oStyle.state.after_seltab = false; }
    public:
        // do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        //void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept override;
#endif
    private:
        // private data
        Private*            m_private = nullptr;
    };
    // get meta info for UITab
    LUI_DECLARE_METAINFO(UITab);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tabs
    class UITabs;
    // tabpanels 
    class UITabPanels;
    // tabbox container
    class UITabBox : public UIControl {
        // super class
        using Super = UIControl;
    public:
        // command: selected changed
        static constexpr auto _onCommand() noexcept { return GuiEvent::Event_OnCommand; }
    public:
        // set selected index
        void SetSelectedIndex(uint32_t index) noexcept;
        // get selected index
        auto GetSelectedIndex() const noexcept { return m_index; }
    protected:
        // ctor
        UITabBox(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITabBox() noexcept;
        // ctor
        UITabBox(UIControl* parent = nullptr) noexcept : UITabBox(parent, UITabBox::s_meta) {}

    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
        // relayout
        void relayout() noexcept;
        // init tabbox
        void init_tabbox() noexcept;
    protected:
        // tabs
        UITabs*                 m_pTabs = nullptr;
        // tabpanels
        UITabPanels*            m_pTabPanels = nullptr;
        // current selected index
        uint32_t                m_index = 0;
    private:
    };
    // get meta info for UITabBox
    LUI_DECLARE_METAINFO(UITabBox);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tab single panel
    class UITabPanel : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    protected:
        // ctor
        UITabPanel(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITabPanel() noexcept;
        // ctor
        UITabPanel(UIControl* parent = nullptr) noexcept : UITabPanel(parent, UITabPanel::s_meta) {}
    private:
    };
    // get meta info for UITabPanel
    LUI_DECLARE_METAINFO(UITabPanel);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tab panels container
    class UITabPanels : public UIDeck {
        // super class
        using Super = UIDeck;
    protected:
        // ctor
        UITabPanels(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITabPanels() noexcept;
        // ctor
        UITabPanels(UIControl* parent = nullptr) noexcept : UITabPanels(parent, UITabPanels::s_meta) {}
    public:
        // do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        //// update, postpone change some data
        //void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
    private:
    };
    // get meta info for UITabPanels
    LUI_DECLARE_METAINFO(UITabPanels);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tab
    class UITab;
    // tabs container
    class UITabs : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    protected:
        // ctor
        UITabs(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITabs() noexcept;
        // ctor
        UITabs(UIControl* parent = nullptr) noexcept : UITabs(parent, UITabs::s_meta) {}
    public:
        // set selected tab
        void SetSelectedTab(UITab& tab) noexcept;
        // set selected index
        void SetSelectedIndex(uint32_t) noexcept;
        // tab removed
        void TabRemoved(UITab& tab) noexcept;
    public:
        // do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        //// update, postpone change some data
        //void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
#ifndef DEBUG
        // assert added child in debug
        void add_child(UIControl&) noexcept override;
#endif
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept override;
#endif
    protected:
        // last selected
        UITab*              m_pLastSelected = nullptr;
    private:
    };
    // get meta info for UITabs
    LUI_DECLARE_METAINFO(UITabs);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef DEBUG
//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // test control
    class UITest : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UITest(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITest() noexcept;
        // ctor
        UITest(UIControl* parent = nullptr) noexcept : UITest(parent, UITest::s_meta) {}
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        void Render() const noexcept override;
        // recreate/init device(gpu) resource
        auto Recreate(bool release_only) noexcept->Result override;
    protected:
    private:
    };
    // get meta info for UITest
    LUI_DECLARE_METAINFO(UITest);
}
#endif



// config marco for this

// enable UNDO-REDO feature
#define TBC_UNDOREDO




#ifndef PCN_NOVTABLE
#ifdef _MSC_VER
#define PCN_NOVTABLE _declspec(novtable)
#else
#define PCN_NOVTABLE
#endif
#endif

#ifndef PCN_NOINLINE
#ifdef _MSC_VER
#define PCN_NOINLINE _declspec(noinline)
#else
#define PCN_NOINLINE
#endif
#endif




#include <cstdint>

// richtb namespace
namespace TextBC {
    struct Node { Node* prev, *next; };
    struct SizeF { float width, height; };
    struct Point2F { float x, y; };
    struct HitTest { uint32_t pos; uint32_t u16_trailing; };
    struct RectWHF { float x, y, width, height; };
    struct U16View { const char16_t* first, *second; };
    struct CharMetrics { float x, width; };
    struct Range { uint32_t pos; uint32_t len; };
    struct CBCSmallObject {};
    inline bool operator==(const Point2F& a, const Point2F& b) noexcept {
        return a.x == b.x && a.y == b.y; }
}

// richtb namespace
namespace TextBC {
    // text content
    struct IBCTextContent;
    // text platform
    struct PCN_NOVTABLE IBCTextPlatform {
        // metrics event
        enum MetricsEvent : uint32_t {
            // get size.        arg:(union) [out]<SizeF*>
            Event_GetSize = 0,
            // get baseline.    arg:(union) [out]<float*>
            Event_GetBaseline,
            // hit test         arg:(union) [out]<HitTest*>        [in]<float*>        {relative position in this cell}
            Event_HitTest,
            // char metrics     arg:(union) [out]<CharMetrics*>    [in]<uint32_t*>     {relative position in this cell}
            Event_CharMetrics,
        };
        // error beep
        virtual void ErrorBeep() noexcept = 0;
        // is valid password [char16_t only]
        virtual bool IsValidPassword(char16_t) noexcept = 0;
        // generate text
        virtual void GenerateText(void* string, U16View view) noexcept = 0;
        // need redraw
        virtual void NeedRedraw() noexcept = 0;
        // draw caret, TODO: set caret rect
        virtual void DrawCaret(void* ctx, Point2F offset, const RectWHF& rect) noexcept = 0;
        // draw selection
        virtual void DrawSelection(void* ctx, Point2F offset, const RectWHF[], uint32_t len) noexcept = 0;
        // delete content
        virtual void DeleteContent(IBCTextContent&) noexcept = 0;
        // draw content
        virtual void DrawContent(IBCTextContent&, void* ctx, Point2F pos) noexcept = 0;
        // content metrics event
        virtual void ContentEvent(IBCTextContent&, MetricsEvent, void*) noexcept = 0;
        // create content
        virtual auto CreateContent(
            const char16_t*, 
            uint32_t len, 
            IBCTextContent&& old /* maybe null */
        ) noexcept->IBCTextContent* = 0;
#ifndef NDEBUG
        // debug output
        virtual void DebugOutput(const char*) noexcept = 0;
        // debug draw cell
        virtual void DrawCell(void* ctx, const RectWHF& rect, int index) noexcept = 0;
#endif
    };
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui header

// TextBC

// cursor

// ui namespace
namespace LongUI {
    // textbox
    class UITextBox : public UIControl, 
        protected TextBC::IBCTextPlatform {
        // super class
        using Super = UIControl;
        // text content
        using Text = TextBC::IBCTextContent;
        // private impl
        struct Private;
    protected:
        // ctor
        UITextBox(UIControl* parent, const MetaControl&) noexcept;
    public:
        // When [pressed enter key, or killed-focus] if text changed
        static constexpr auto _onChange() noexcept { return GuiEvent::Event_OnChange; }
        // This event is sent when a user enters text in a textbox
        static constexpr auto _onInput() noexcept { return GuiEvent::Event_OnInput; }
        // selection changed
        //static inline constexpr auto _selectionChanged() noexcept { return GuiEvent::Event_Select; }
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITextBox() noexcept;
        // ctor
        UITextBox(UIControl* parent = nullptr) noexcept :UITextBox(parent, UITextBox::s_meta) {}
    public:
        // trigger event
        auto TriggerEvent(GuiEvent event) noexcept->EventAccept override;
        // normal event
        auto DoEvent(UIControl*, const EventArg& e) noexcept->EventAccept override;
        // update
        void Update() noexcept override;
        // render
        void Render() const noexcept override;
        // mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept -> EventAccept override;
        // input event
        auto DoInputEvent(InputEventArg e) noexcept->EventAccept override;
        // recreate device resource
        auto Recreate(bool release_only) noexcept->Result override;
    protected:
        // error beep
        void ErrorBeep() noexcept override;
        // is valid password [char16_t only]
        bool IsValidPassword(char16_t) noexcept override;
        // generate text
        void GenerateText(void* string, TextBC::U16View view) noexcept override;
        // need redraw
        void NeedRedraw() noexcept override;
        // draw caret, TODO: set caret rect
        void DrawCaret(void* ctx, TextBC::Point2F, const TextBC::RectWHF& rect) noexcept override;
        // draw selection
        void DrawSelection(void* ctx, TextBC::Point2F, const TextBC::RectWHF[], uint32_t len) noexcept override;
        // create content
        auto CreateContent(const char16_t*, uint32_t len, Text&& old) noexcept->Text* override;
        // delete content
        void DeleteContent(Text&) noexcept override;
        // draw content
        void DrawContent(Text&, void*, TextBC::Point2F) noexcept override;
        // content metrics event
        void ContentEvent(Text&, MetricsEvent, void*) noexcept override;
#ifndef NDEBUG
        // debug output
        void DebugOutput(const char*) noexcept override;
        // draw cell
        void DrawCell(void* ctx, const TextBC::RectWHF& rect, int index) noexcept override;
#endif
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // try trigger change event
        void try_trigger_change_event() noexcept;
        // mark change event could be triggered
        void mark_change_could_trigger() noexcept;
        // clear change event could be triggered
        void clear_change_could_trigger() noexcept;
        // is change event could be triggered?
        bool is_change_could_trigger() const noexcept;
        // selection changed
        void on_selected_changed() noexcept;
    public:
        // set text
        void SetText(CUIString&& text) noexcept;
        // set text
        void SetText(U16View view) noexcept;
        // request text, not const method
        auto RequestText() noexcept -> const CUIString&;
    private:
        // text used font
        TextFont                m_tfBuffer;
        // hovered curor
        CUICursor               m_hovered;
        // cols/size
        uint32_t                m_uCols = 20;
        // rows
        uint32_t                m_uRows = 1;
        // max length
        uint32_t                m_uMaxLength = 0x00ffffff;
        // flag
        uint16_t                m_flag = 0;
        // password char [UCS2 set only]
        char16_t                m_chPassword = 0x25cf;
        // private data         TODO: NO POINTER
        Private*                m_private = nullptr;
        // init textbox
        void init_textbox() noexcept;
        // init private data
        void init_private() noexcept;
        // create private data
        void create_private() noexcept;
        // delete private data
        void delete_private() noexcept;
        // set text
        void private_set_text() noexcept;
        // private use cached
        void private_use_cached() noexcept;
        // private set text
        void private_set_text(CUIString&& text) noexcept;
        // private mark readonly
        void private_mark_readonly() noexcept;
        // private mark multiline
        void private_mark_multiline() noexcept;
        // private mark password
        void private_mark_password() noexcept;
        // private mouse down
        void private_mouse_down(Point2F, bool shift) noexcept;
        // private mouse up
        void private_mouse_up(Point2F) noexcept;
        // private mouse up
        void private_mouse_move(Point2F) noexcept;
        // private key down
        void private_keydown(uint32_t key) noexcept;
        // on char input
        void private_char(char32_t) noexcept;
        // private update
        void private_update() noexcept;
        // private resized
        void private_resize(Size2F) noexcept;
#ifdef LUI_TEXTBOX_USE_UNIFIED_INPUT
        // private left
        void private_left() noexcept;
        // private up
        void private_up() noexcept;
        // private right
        void private_right() noexcept;
        // private down
        void private_down() noexcept;
#endif
    public:

    };
    // get meta info for UITextBox
    LUI_DECLARE_METAINFO(UITextBox);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // tool bar
    class UIToolBar : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // friend class
        friend UIMetaTypeDef;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIToolBar() noexcept;
        // ctor
        UIToolBar(UIControl* parent = nullptr) noexcept : UIToolBar(parent, UIToolBar::s_meta) {}
    protected:
        // lui std ctor
        UIToolBar(UIControl* parent, const MetaControl&) noexcept;
    };
    // get meta info for UIBoxLayout
    LUI_DECLARE_METAINFO(UIToolBar);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // toolbarbutton
    class UIToolBarButton : public UIButton {
        // super class
        using Super = UIButton;
        // private impl
        struct Private;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UIToolBarButton() noexcept;
        // ctor
        UIToolBarButton(UIControl* parent = nullptr) noexcept : UIToolBarButton(parent, UIToolBarButton::s_meta) {}
    protected:
        // ctor
        UIToolBarButton(UIControl* parent, const MetaControl&) noexcept;
    public:
        // do normal event
        auto DoEvent(UIControl*, const EventArg&)noexcept->EventAccept override;

    };
    // get meta info for UIToolBarButton
    LUI_DECLARE_METAINFO(UIToolBarButton);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // toolbar separator
    using UIToolBarSeparator = UISpacer;
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // toolbox
    using UIToolBox = UIBoxLayout;
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// ui

// ui namespace
namespace LongUI {
    // tooltip control
    class UITooltip : public UIViewport {
        // super class
        using Super = UIViewport;
    protected:
        // ctor
        UITooltip(UIControl* hoster, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITooltip() noexcept;
        // ctor
        UITooltip(UIControl* hoster) noexcept : UITooltip(hoster, UITooltip::s_meta) {}
    protected:
    };
    // get meta info for UITooltip
    LUI_DECLARE_METAINFO(UITooltip);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tree
    class UITree;
    // treerow
    class UITreeRow;
    // treechildren
    class UITreeChildren;
    // treeitem control
    class UITreeItem : public UIControl {
        // super class
        using Super = UIControl;
    protected:
        // ctor
        UITreeItem(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeItem() noexcept;
        // ctor
        UITreeItem(UIControl* parent = nullptr) noexcept : UITreeItem(parent, UITreeItem::s_meta) {}
    public:
        // is selected?
        auto IsSelected() const noexcept { return m_oStyle.state.selected; }
        // select to this
        //void SelectToThis() noexcept;
        // select this
        //void Select(bool exsel) noexcept;
        // get row
        auto GetRow() const noexcept { return m_pRow; }
        // get tree node
        auto GetTreeNode() const noexcept { return m_pTree; }
        // get tree children
        auto GetTreeChildren() const noexcept { return m_pChildren; }
        // tree children changed
        void TreeChildrenChanged(bool has_child) noexcept;
        // tree children closed
        void TreeChildrenOpenClose(bool open) noexcept;
        // tree children level offset
        void TreeLevelOffset(float offset) noexcept { m_fLevelOffset = offset; }
        // set tree root as this
        void AsSameTreeTo(const UITreeItem& x) noexcept { m_pTree = x.m_pTree; }
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add child
        void add_child(UIControl& child) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept override;
#endif
        // relayout base
        void relayout_base(UIControl* head) noexcept;
        // refresh minsize
        void refresh_minsize(UIControl* head) noexcept;
    protected:
        // tree root
        UITree*                 m_pTree = nullptr;
        // tree row
        UITreeRow*              m_pRow = nullptr;
        // tree children
        UITreeChildren*         m_pChildren = nullptr;
        // level offset
        float                   m_fLevelOffset = 0.f;
        // marked selected
        bool                    m_bMarkdSel = false;
    private:
    };
    // get meta info for UITreeItem
    LUI_DECLARE_METAINFO(UITreeItem);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // cols
    class UITreeCols;
    // tree
    class UITree : public UITreeItem {
        // super class
        using Super = UITreeItem;
        // item list
        using ItemList = POD::Vector<UITreeItem*>;
    protected:
        // ctor
        UITree(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITree() noexcept;
        // ctor
        UITree(UIControl* parent = nullptr) noexcept : UITree(parent, UITree::s_meta) {}
    public:
        // is multi-selected?
        bool IsMultiple() const noexcept { return m_seltype == Seltype_Multiple; }
        // get cols
        auto GetCols() const noexcept { return m_pCols; }
        // item removed. called from UITreeItem's dtor
        void ItemRemoved(UITreeItem&) noexcept;
        // select item
        void SelectItem(UITreeItem&, bool exadd) noexcept;
        // select to
        void SelectTo(UITreeItem&) noexcept;
        // clear select
        void ClearSelected(UITreeItem&) noexcept;
        // clear all select
        void ClearAllSelected() noexcept;
        // get selected items
        auto&GetSelected() const noexcept { return m_selected; };
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add attribute
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // add child
        void add_child(UIControl& child) noexcept override;
#ifdef LUI_ACCESSIBLE
        // accessible api
        auto accessible(const AccessibleEventArg& args) noexcept->EventAccept override;
#endif
        // select item
        void select_item(UITreeItem&) noexcept;
    protected:
        // cols
        UITreeCols*         m_pCols = nullptr;
        // last op
        UITreeItem*         m_pLastOp = nullptr;
        // selected
        ItemList            m_selected;
        // display row | xul::rows related
        uint16_t            m_displayRow = 0;
        // unused u8
        char                m_unusedU8 = 0;
        // select type
        AttributeSeltype    m_seltype = Seltype_Multiple;
    private:
    };
    // get meta info for UITree
    LUI_DECLARE_METAINFO(UITree);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // treecell control
    class UITreeCell : public UILabel {
        // super class
        using Super = UILabel;
    protected:
        // ctor
        UITreeCell(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeCell() noexcept;
        // ctor
        UITreeCell(UIControl* parent = nullptr) noexcept : UITreeCell(parent, UITreeCell::s_meta) {}
    public:
        // do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        //void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // add
        void add_attribute(uint32_t key, U8View value) noexcept override;
        // add child
        //void add_child(UIControl& child) noexcept;
    private:
    };
    // get meta info for UITreeCell
    LUI_DECLARE_METAINFO(UITreeCell);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tree children
    class UITreeChildren : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
    protected:
        // ctor
        UITreeChildren(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeChildren() noexcept;
        // ctor
        UITreeChildren(UIControl* parent = nullptr) noexcept : UITreeChildren(parent, UITreeChildren::s_meta) {}
    public:
        // set level offset
        void SetLevelOffset(float offset);
    public:
        //// do normal event
        //auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        //// do mouse event
        //auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        //// render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        //// recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
#ifndef NDEBUG
        // add child for debug
        void add_child(UIControl& child) noexcept override;
#endif

    protected:
        bool                    m_bHasChild = false;
    private:
    };
    // get meta info for UITreeChildren
    LUI_DECLARE_METAINFO(UITreeChildren);
}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // treecol
    class UITreeCol : public UIListHeader {
        // super class
        using Super = UIListHeader;
    protected:
        // ctor
        UITreeCol(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeCol() noexcept;
        // ctor
        UITreeCol(UIControl* parent = nullptr) noexcept:UITreeCol(parent, UITreeCol::s_meta) {}
    };
    // get meta info for UISpacer
    LUI_DECLARE_METAINFO(UITreeCol);
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tree col
    class UITreeCol;
    // treecols control
    class UITreeCols : public UIBoxLayout {
        // super class
        using Super = UIBoxLayout;
        // item list
        //using ColTree = POD::Vector<UITreeCol*>;
    protected:
        // ctor
        UITreeCols(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeCols() noexcept;
        // ctor
        UITreeCols(UIControl* parent = nullptr) noexcept : UITreeCols(parent, UITreeCols::s_meta) {}
    protected:
        // do event
        auto DoEvent(UIControl* s, const EventArg& e) noexcept->EventAccept override;
        // update
        //void Update() noexcept override;
    private:
        // do update for item
        static void do_update_for_item(UIControl&) noexcept;
    };
    // get meta info for UITreeCols
    LUI_DECLARE_METAINFO(UITreeCols);
}


/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

//#include "../util/ui_double_click.h"

// ui namespace
namespace LongUI {
    // tree row
    class UITreeRow : public UIControl {
        // super class
        using Super = UIControl;
        // private
        struct Private;
    protected:
        // ctor
        UITreeRow(UIControl* parent, const MetaControl&) noexcept;
    public:
        // class meta
        static const  MetaControl   s_meta;
        // dtor
        ~UITreeRow() noexcept;
        // ctor
        UITreeRow(UIControl* parent = nullptr) noexcept : UITreeRow(parent, UITreeRow::s_meta) {}
    public:
        // is selected?
        //auto IsSelected() const noexcept { return m_oStyle.state.selected; }
        // get row string
        void GetRowString(CUIString&) const noexcept;
        // set has child
        void SetHasChild(bool has) noexcept;
        // open node
        bool OpenNode() noexcept;
        // close node
        bool CloseNode() noexcept;
        // toggle node
        bool ToggleNode() noexcept;
        // set level offset
        void SetLevelOffset(float offset) noexcept;
    public:
        // do normal event
        auto DoEvent(UIControl* sender, const EventArg& e) noexcept->EventAccept override;
        // do mouse event
        auto DoMouseEvent(const MouseEventArg& e) noexcept->EventAccept override;
        // update, postpone change some data
        void Update() noexcept override;
        // render this control only, [Global rendering and Incremental rendering]
        //void Render() const noexcept override;
        // recreate/init device(gpu) resource
        //auto Recreate() noexcept->Result override;
    protected:
        // open/close node
        void open_close(bool open) noexcept;
        // relayout
        void relayout() noexcept;
        // refresh minsize
        void refresh_minsize() noexcept;
    private:
        // private data
        Private*                m_private = nullptr;
    protected:
        // offset
        float                   m_fLevelOffset = 0.f;
        // node closed
        bool                    m_bOpened = true;
        // node keep child
        bool                    m_bHasChild = false;
    };
    // get meta info for UITreeRow
    LUI_DECLARE_METAINFO(UITreeRow);
}

/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// needed interfaces
struct IUnknown;
struct IDropTarget;
struct IDataObject;
struct IDropSource;
struct IDropTargetHelper;


// direct3d
struct ID3D11Device;
struct ID3D11Device;
struct ID3D11DeviceContext;
struct ID3D11DeviceContext;
struct ID3D11Debug;
struct ID3D11Texture2D;
struct ID3D10Multithread;
struct ID3D10Multithread;

// direct2d
struct ID2D1DrawTransform;
struct ID2D1TransformNode;
struct ID2D1Transform;
struct ID2D1EffectImpl;
struct ID2D1Brush;
struct ID2D1SolidColorBrush;
struct ID2D1ImageBrush;
struct ID2D1Bitmap;
struct ID2D1Bitmap1;
struct ID2D1Factory;
struct ID2D1Factory1;
struct ID2D1Factory2;
struct ID2D1Factory4;
struct ID2D1Device;
struct ID2D1Device1;
struct ID2D1Device3;
struct ID2D1DeviceContext;
struct ID2D1DeviceContext1;
struct ID2D1DeviceContext3;
struct ID2D1Geometry;
struct ID2D1Mesh;

// directwrite
struct IDWriteTextFormat;
struct IDWriteTextFormat1;
struct IDWriteTextLayout;
struct IDWriteTextLayout1;
struct IDWriteFactory;
struct IDWriteFontCollection;
struct IDWriteFactory1;
struct IDWriteTextRenderer;
struct IDWriteTextRenderer1;
struct IDWriteInlineObject;
struct IDWriteFontFileEnumerator;
struct IDWriteFontCollectionLoader;
struct IDWritePixelSnapping;

// dxgi
struct IDXGIFactory;
struct IDXGIFactory1;
struct IDXGIFactory2;
struct IDXGIDevice;
struct IDXGIDevice1;
struct IDXGIAdapter;
struct IDXGIOutput;
struct IDXGISurface;
struct IDXGISwapChain1;
struct IDXGISwapChain2;


// MF
struct IMFMediaEngineClassFactory;
struct IMFMediaEngine;
struct IMFMediaEngineEx;
struct IMFMediaEngineNotify;

// dcomp
struct IDCompositionDevice;

#include <cstdint>

// ui
namespace LongUI {
    // rgba
    constexpr uint32_t operator ""_rgba(unsigned long long value) noexcept {
        static_assert(sizeof(value) >= sizeof(uint32_t), "bad sizeof");
        return helper::rgba(static_cast<uint32_t>(value));
    }
    // rgba color
    enum ColorRGBA : uint32_t {
        // VS 2017 intelli-sense bug
#if 0
        // SP
        RGBA_TianyiBlue     = 0x66CCFFFF_rgba,
        RGBA_Transparent    = 0x00000000_rgba,
        RGBA_TransparentB   = 0x00000000_rgba, // BLACK
        RGBA_TransparentM   = 0x80808000_rgba, // MIDDLE
        RGBA_TransparentW   = 0xFFFFFF00_rgba, // WHITE
        // WEB#141
        RGBA_RebeccaPurple  = 0x663399FF_rgba,
        // WEB#140
        RGBA_AliceBlue      = 0xF0F8FFFF_rgba,
        RGBA_AntiqueWhite   = 0xFAEBD7FF_rgba,
        RGBA_Aqua           = 0x00FFFFFF_rgba,
        RGBA_Aquamarine     = 0x7FFFD4FF_rgba,
        RGBA_Azure          = 0xF0FFFFFF_rgba,
        RGBA_Beige          = 0xF5F5DCFF_rgba,
        RGBA_Bisque         = 0xFFE4C4FF_rgba,
        RGBA_Black          = 0x000000FF_rgba,
        RGBA_BlanchedAlmond = 0xFFEBCDFF_rgba,
        RGBA_Blue           = 0x0000FFFF_rgba,
        RGBA_BlueViolet     = 0x8A2BE2FF_rgba,
        RGBA_Brown          = 0xA52A2AFF_rgba,
        RGBA_BurlyWood      = 0xDEB887FF_rgba,
        RGBA_CadetBlue      = 0x5F9EA0FF_rgba,
        RGBA_Chartreuse     = 0x7FFF00FF_rgba,
        RGBA_Chocolate      = 0xD2691EFF_rgba,
        RGBA_Coral          = 0xFF7F50FF_rgba,
        RGBA_CornflowerBlue = 0x6495EDFF_rgba,
        RGBA_Cornsilk       = 0xFFF8DCFF_rgba,
        RGBA_Crimson        = 0xDC143CFF_rgba,
        RGBA_Cyan           = 0x00FFFFFF_rgba,
        RGBA_DarkBlue       = 0x00008BFF_rgba,
        RGBA_DarkCyan       = 0x008B8BFF_rgba,
        RGBA_DarkGoldenRod  = 0xB8860BFF_rgba,
        RGBA_DarkGray       = 0xA9A9A9FF_rgba,
        RGBA_DarkGreen      = 0x006400FF_rgba,
        RGBA_DarkKhaki      = 0xBDB76BFF_rgba,
        RGBA_DarkMagenta    = 0x8B008BFF_rgba,
        RGBA_DarkOliveGreen = 0x556B2FFF_rgba,
        RGBA_Darkorange     = 0xFF8C00FF_rgba,
        RGBA_DarkOrchid     = 0x9932CCFF_rgba,
        RGBA_DarkRed        = 0x8B0000FF_rgba,
        RGBA_DarkSalmon     = 0xE9967AFF_rgba,
        RGBA_DarkSeaGreen   = 0x8FBC8FFF_rgba,
        RGBA_DarkSlateBlue  = 0x483D8BFF_rgba,
        RGBA_DarkSlateGray  = 0x2F4F4FFF_rgba,
        RGBA_DarkTurquoise  = 0x00CED1FF_rgba,
        RGBA_DarkViolet     = 0x9400D3FF_rgba,
        RGBA_DeepPink       = 0xFF1493FF_rgba,
        RGBA_DeepSkyBlue    = 0x00BFFFFF_rgba,
        RGBA_DimGray        = 0x696969FF_rgba,
        RGBA_DimGrey        = 0x696969FF_rgba,
        RGBA_DodgerBlue     = 0x1E90FFFF_rgba,
        RGBA_FireBrick      = 0xB22222FF_rgba,
        RGBA_FloralWhite    = 0xFFFAF0FF_rgba,
        RGBA_ForestGreen    = 0x228B22FF_rgba,
        RGBA_Fuchsia        = 0xFF00FFFF_rgba,
        RGBA_Gainsboro      = 0xDCDCDCFF_rgba,
        RGBA_GhostWhite     = 0xF8F8FFFF_rgba,
        RGBA_Gold           = 0xFFD700FF_rgba,
        RGBA_GoldenRod      = 0xDAA520FF_rgba,
        RGBA_Gray           = 0x808080FF_rgba,
        RGBA_Green          = 0x008000FF_rgba,
        RGBA_GreenYellow    = 0xADFF2FFF_rgba,
        RGBA_HoneyDew       = 0xF0FFF0FF_rgba,
        RGBA_HotPink        = 0xFF69B4FF_rgba,
        RGBA_IndianRed      = 0xCD5C5CFF_rgba,
        RGBA_Indigo         = 0x4B0082FF_rgba,
        RGBA_Ivory          = 0xFFFFF0FF_rgba,
        RGBA_Khaki          = 0xF0E68CFF_rgba,
        RGBA_Lavender       = 0xE6E6FAFF_rgba,
        RGBA_LavenderBlush  = 0xFFF0F5FF_rgba,
        RGBA_LawnGreen      = 0x7CFC00FF_rgba,
        RGBA_LemonChiffon   = 0xFFFACDFF_rgba,
        RGBA_LightBlue      = 0xADD8E6FF_rgba,
        RGBA_LightCoral     = 0xF08080FF_rgba,
        RGBA_LightCyan      = 0xE0FFFFFF_rgba,
        RGBA_LightGoldenRodYellow   = 0xFAFAD2FF_rgba,
        RGBA_LightGray      = 0xD3D3D3FF_rgba,
        RGBA_LightGreen     = 0x90EE90FF_rgba,
        RGBA_LightPink      = 0xFFB6C1FF_rgba,
        RGBA_LightSalmon    = 0xFFA07AFF_rgba,
        RGBA_LightSeaGreen  = 0x20B2AAFF_rgba,
        RGBA_LightSkyBlue   = 0x87CEFAFF_rgba,
        RGBA_LightSlateGray = 0x778899FF_rgba,
        RGBA_LightSteelBlue = 0xB0C4DEFF_rgba,
        RGBA_LightYellow    = 0xFFFFE0FF_rgba,
        RGBA_Lime           = 0x00FF00FF_rgba,
        RGBA_LimeGreen      = 0x32CD32FF_rgba,
        RGBA_Linen          = 0xFAF0E6FF_rgba,
        RGBA_Magenta        = 0xFF00FFFF_rgba,
        RGBA_Maroon         = 0x800000FF_rgba,
        RGBA_MediumAquaMarine       = 0x66CDAAFF_rgba,
        RGBA_MediumBlue     = 0x0000CDFF_rgba,
        RGBA_MediumOrchid   = 0xBA55D3FF_rgba,
        RGBA_MediumPurple   = 0x9370DBFF_rgba,
        RGBA_MediumSeaGreen = 0x3CB371FF_rgba,
        RGBA_MediumSlateBlue= 0x7B68EEFF_rgba,
        RGBA_MediumSpringGreen      = 0x00FA9AFF_rgba,
        RGBA_MediumTurquoise= 0x48D1CCFF_rgba,
        RGBA_MediumVioletRed= 0xC71585FF_rgba,
        RGBA_MidnightBlue   = 0x191970FF_rgba,
        RGBA_MintCream      = 0xF5FFFAFF_rgba,
        RGBA_MistyRose      = 0xFFE4E1FF_rgba,
        RGBA_Moccasin       = 0xFFE4B5FF_rgba,
        RGBA_NavajoWhite    = 0xFFDEADFF_rgba,
        RGBA_Navy           = 0x000080FF_rgba,
        RGBA_OldLace        = 0xFDF5E6FF_rgba,
        RGBA_Olive          = 0x808000FF_rgba,
        RGBA_OliveDrab      = 0x6B8E23FF_rgba,
        RGBA_Orange         = 0xFFA500FF_rgba,
        RGBA_OrangeRed      = 0xFF4500FF_rgba,
        RGBA_Orchid         = 0xDA70D6FF_rgba,
        RGBA_PaleGoldenRod  = 0xEEE8AAFF_rgba,
        RGBA_PaleGreen      = 0x98FB98FF_rgba,
        RGBA_PaleTurquoise  = 0xAFEEEEFF_rgba,
        RGBA_PaleVioletRed  = 0xDB7093FF_rgba,
        RGBA_PapayaWhip     = 0xFFEFD5FF_rgba,
        RGBA_PeachPuff      = 0xFFDAB9FF_rgba,
        RGBA_Peru           = 0xCD853FFF_rgba,
        RGBA_Pink           = 0xFFC0CBFF_rgba,
        RGBA_Plum           = 0xDDA0DDFF_rgba,
        RGBA_PowderBlue     = 0xB0E0E6FF_rgba,
        RGBA_Purple         = 0x800080FF_rgba,
        RGBA_Red            = 0xFF0000FF_rgba,
        RGBA_RosyBrown      = 0xBC8F8FFF_rgba,
        RGBA_RoyalBlue      = 0x4169E1FF_rgba,
        RGBA_SaddleBrown    = 0x8B4513FF_rgba,
        RGBA_Salmon         = 0xFA8072FF_rgba,
        RGBA_SandyBrown     = 0xF4A460FF_rgba,
        RGBA_SeaGreen       = 0x2E8B57FF_rgba,
        RGBA_SeaShell       = 0xFFF5EEFF_rgba,
        RGBA_Sienna         = 0xA0522DFF_rgba,
        RGBA_Silver         = 0xC0C0C0FF_rgba,
        RGBA_SkyBlue        = 0x87CEEBFF_rgba,
        RGBA_SlateBlue      = 0x6A5ACDFF_rgba,
        RGBA_SlateGray      = 0x708090FF_rgba,
        RGBA_Snow           = 0xFFFAFAFF_rgba,
        RGBA_SpringGreen    = 0x00FF7FFF_rgba,
        RGBA_SteelBlue      = 0x4682B4FF_rgba,
        RGBA_Tan            = 0xD2B48CFF_rgba,
        RGBA_Teal           = 0x008080FF_rgba,
        RGBA_Thistle        = 0xD8BFD8FF_rgba,
        RGBA_Tomato         = 0xFF6347FF_rgba,
        RGBA_Turquoise      = 0x40E0D0FF_rgba,
        RGBA_Violet         = 0xEE82EEFF_rgba,
        RGBA_Wheat          = 0xF5DEB3FF_rgba,
        RGBA_White          = 0xFFFFFFFF_rgba,
        RGBA_WhiteSmoke     = 0xF5F5F5FF_rgba,
        RGBA_Yellow         = 0xFFFF00FF_rgba,
        RGBA_YellowGreen    = 0x9ACD32FF_rgba,
#else
        // SP
        RGBA_TianyiBlue     = helper::rgba(0x66, 0xCC, 0xFF, 0xFF),
        RGBA_Transparent    = helper::rgba(0x00, 0x00, 0x00, 0x00),
        RGBA_TransparentB   = helper::rgba(0x00, 0x00, 0x00, 0x00), // BLACK
        RGBA_TransparentM   = helper::rgba(0x80, 0x80, 0x80, 0x00), // MIDDLE
        RGBA_TransparentW   = helper::rgba(0xFF, 0xFF, 0xFF, 0x00), // WHITE
        // WEB#141
        RGBA_RebeccaPurple  = helper::rgba(0x66, 0x33, 0x99, 0xFF),
        // WEB#140
        RGBA_AliceBlue      = helper::rgba(0xF0, 0xF8, 0xFF, 0xFF),
        RGBA_AntiqueWhite   = helper::rgba(0xFA, 0xEB, 0xD7, 0xFF),
        RGBA_Aqua           = helper::rgba(0x00, 0xFF, 0xFF, 0xFF),
        RGBA_Aquamarine     = helper::rgba(0x7F, 0xFF, 0xD4, 0xFF),
        RGBA_Azure          = helper::rgba(0xF0, 0xFF, 0xFF, 0xFF),
        RGBA_Beige          = helper::rgba(0xF5, 0xF5, 0xDC, 0xFF),
        RGBA_Bisque         = helper::rgba(0xFF, 0xE4, 0xC4, 0xFF),
        RGBA_Black          = helper::rgba(0x00, 0x00, 0x00, 0xFF),
        RGBA_BlanchedAlmond = helper::rgba(0xFF, 0xEB, 0xCD, 0xFF),
        RGBA_Blue           = helper::rgba(0x00, 0x00, 0xFF, 0xFF),
        RGBA_BlueViolet     = helper::rgba(0x8A, 0x2B, 0xE2, 0xFF),
        RGBA_Brown          = helper::rgba(0xA5, 0x2A, 0x2A, 0xFF),
        RGBA_BurlyWood      = helper::rgba(0xDE, 0xB8, 0x87, 0xFF),
        RGBA_CadetBlue      = helper::rgba(0x5F, 0x9E, 0xA0, 0xFF),
        RGBA_Chartreuse     = helper::rgba(0x7F, 0xFF, 0x00, 0xFF),
        RGBA_Chocolate      = helper::rgba(0xD2, 0x69, 0x1E, 0xFF),
        RGBA_Coral          = helper::rgba(0xFF, 0x7F, 0x50, 0xFF),
        RGBA_CornflowerBlue = helper::rgba(0x64, 0x95, 0xED, 0xFF),
        RGBA_Cornsilk       = helper::rgba(0xFF, 0xF8, 0xDC, 0xFF),
        RGBA_Crimson        = helper::rgba(0xDC, 0x14, 0x3C, 0xFF),
        RGBA_Cyan           = helper::rgba(0x00, 0xFF, 0xFF, 0xFF),
        RGBA_DarkBlue       = helper::rgba(0x00, 0x00, 0x8B, 0xFF),
        RGBA_DarkCyan       = helper::rgba(0x00, 0x8B, 0x8B, 0xFF),
        RGBA_DarkGoldenRod  = helper::rgba(0xB8, 0x86, 0x0B, 0xFF),
        RGBA_DarkGray       = helper::rgba(0xA9, 0xA9, 0xA9, 0xFF),
        RGBA_DarkGreen      = helper::rgba(0x00, 0x64, 0x00, 0xFF),
        RGBA_DarkKhaki      = helper::rgba(0xBD, 0xB7, 0x6B, 0xFF),
        RGBA_DarkMagenta    = helper::rgba(0x8B, 0x00, 0x8B, 0xFF),
        RGBA_DarkOliveGreen = helper::rgba(0x55, 0x6B, 0x2F, 0xFF),
        RGBA_Darkorange     = helper::rgba(0xFF, 0x8C, 0x00, 0xFF),
        RGBA_DarkOrchid     = helper::rgba(0x99, 0x32, 0xCC, 0xFF),
        RGBA_DarkRed        = helper::rgba(0x8B, 0x00, 0x00, 0xFF),
        RGBA_DarkSalmon     = helper::rgba(0xE9, 0x96, 0x7A, 0xFF),
        RGBA_DarkSeaGreen   = helper::rgba(0x8F, 0xBC, 0x8F, 0xFF),
        RGBA_DarkSlateBlue  = helper::rgba(0x48, 0x3D, 0x8B, 0xFF),
        RGBA_DarkSlateGray  = helper::rgba(0x2F, 0x4F, 0x4F, 0xFF),
        RGBA_DarkTurquoise  = helper::rgba(0x00, 0xCE, 0xD1, 0xFF),
        RGBA_DarkViolet     = helper::rgba(0x94, 0x00, 0xD3, 0xFF),
        RGBA_DeepPink       = helper::rgba(0xFF, 0x14, 0x93, 0xFF),
        RGBA_DeepSkyBlue    = helper::rgba(0x00, 0xBF, 0xFF, 0xFF),
        RGBA_DimGray        = helper::rgba(0x69, 0x69, 0x69, 0xFF),
        RGBA_DimGrey        = helper::rgba(0x69, 0x69, 0x69, 0xFF),
        RGBA_DodgerBlue     = helper::rgba(0x1E, 0x90, 0xFF, 0xFF),
        RGBA_FireBrick      = helper::rgba(0xB2, 0x22, 0x22, 0xFF),
        RGBA_FloralWhite    = helper::rgba(0xFF, 0xFA, 0xF0, 0xFF),
        RGBA_ForestGreen    = helper::rgba(0x22, 0x8B, 0x22, 0xFF),
        RGBA_Fuchsia        = helper::rgba(0xFF, 0x00, 0xFF, 0xFF),
        RGBA_Gainsboro      = helper::rgba(0xDC, 0xDC, 0xDC, 0xFF),
        RGBA_GhostWhite     = helper::rgba(0xF8, 0xF8, 0xFF, 0xFF),
        RGBA_Gold           = helper::rgba(0xFF, 0xD7, 0x00, 0xFF),
        RGBA_GoldenRod      = helper::rgba(0xDA, 0xA5, 0x20, 0xFF),
        RGBA_Gray           = helper::rgba(0x80, 0x80, 0x80, 0xFF),
        RGBA_Green          = helper::rgba(0x00, 0x80, 0x00, 0xFF),
        RGBA_GreenYellow    = helper::rgba(0xAD, 0xFF, 0x2F, 0xFF),
        RGBA_HoneyDew       = helper::rgba(0xF0, 0xFF, 0xF0, 0xFF),
        RGBA_HotPink        = helper::rgba(0xFF, 0x69, 0xB4, 0xFF),
        RGBA_IndianRed      = helper::rgba(0xCD, 0x5C, 0x5C, 0xFF),
        RGBA_Indigo         = helper::rgba(0x4B, 0x00, 0x82, 0xFF),
        RGBA_Ivory          = helper::rgba(0xFF, 0xFF, 0xF0, 0xFF),
        RGBA_Khaki          = helper::rgba(0xF0, 0xE6, 0x8C, 0xFF),
        RGBA_Lavender       = helper::rgba(0xE6, 0xE6, 0xFA, 0xFF),
        RGBA_LavenderBlush  = helper::rgba(0xFF, 0xF0, 0xF5, 0xFF),
        RGBA_LawnGreen      = helper::rgba(0x7C, 0xFC, 0x00, 0xFF),
        RGBA_LemonChiffon   = helper::rgba(0xFF, 0xFA, 0xCD, 0xFF),
        RGBA_LightBlue      = helper::rgba(0xAD, 0xD8, 0xE6, 0xFF),
        RGBA_LightCoral     = helper::rgba(0xF0, 0x80, 0x80, 0xFF),
        RGBA_LightCyan      = helper::rgba(0xE0, 0xFF, 0xFF, 0xFF),
        RGBA_LightGoldenRodYellow   = helper::rgba(0xFA, 0xFA, 0xD2, 0xFF),
        RGBA_LightGray      = helper::rgba(0xD3, 0xD3, 0xD3, 0xFF),
        RGBA_LightGreen     = helper::rgba(0x90, 0xEE, 0x90, 0xFF),
        RGBA_LightPink      = helper::rgba(0xFF, 0xB6, 0xC1, 0xFF),
        RGBA_LightSalmon    = helper::rgba(0xFF, 0xA0, 0x7A, 0xFF),
        RGBA_LightSeaGreen  = helper::rgba(0x20, 0xB2, 0xAA, 0xFF),
        RGBA_LightSkyBlue   = helper::rgba(0x87, 0xCE, 0xFA, 0xFF),
        RGBA_LightSlateGray = helper::rgba(0x77, 0x88, 0x99, 0xFF),
        RGBA_LightSteelBlue = helper::rgba(0xB0, 0xC4, 0xDE, 0xFF),
        RGBA_LightYellow    = helper::rgba(0xFF, 0xFF, 0xE0, 0xFF),
        RGBA_Lime           = helper::rgba(0x00, 0xFF, 0x00, 0xFF),
        RGBA_LimeGreen      = helper::rgba(0x32, 0xCD, 0x32, 0xFF),
        RGBA_Linen          = helper::rgba(0xFA, 0xF0, 0xE6, 0xFF),
        RGBA_Magenta        = helper::rgba(0xFF, 0x00, 0xFF, 0xFF),
        RGBA_Maroon         = helper::rgba(0x80, 0x00, 0x00, 0xFF),
        RGBA_MediumAquaMarine       = helper::rgba(0x66, 0xCD, 0xAA, 0xFF),
        RGBA_MediumBlue     = helper::rgba(0x00, 0x00, 0xCD, 0xFF),
        RGBA_MediumOrchid   = helper::rgba(0xBA, 0x55, 0xD3, 0xFF),
        RGBA_MediumPurple   = helper::rgba(0x93, 0x70, 0xDB, 0xFF),
        RGBA_MediumSeaGreen = helper::rgba(0x3C, 0xB3, 0x71, 0xFF),
        RGBA_MediumSlateBlue= helper::rgba(0x7B, 0x68, 0xEE, 0xFF),
        RGBA_MediumSpringGreen      = helper::rgba(0x00, 0xFA, 0x9A, 0xFF),
        RGBA_MediumTurquoise= helper::rgba(0x48, 0xD1, 0xCC, 0xFF),
        RGBA_MediumVioletRed= helper::rgba(0xC7, 0x15, 0x85, 0xFF),
        RGBA_MidnightBlue   = helper::rgba(0x19, 0x19, 0x70, 0xFF),
        RGBA_MintCream      = helper::rgba(0xF5, 0xFF, 0xFA, 0xFF),
        RGBA_MistyRose      = helper::rgba(0xFF, 0xE4, 0xE1, 0xFF),
        RGBA_Moccasin       = helper::rgba(0xFF, 0xE4, 0xB5, 0xFF),
        RGBA_NavajoWhite    = helper::rgba(0xFF, 0xDE, 0xAD, 0xFF),
        RGBA_Navy           = helper::rgba(0x00, 0x00, 0x80, 0xFF),
        RGBA_OldLace        = helper::rgba(0xFD, 0xF5, 0xE6, 0xFF),
        RGBA_Olive          = helper::rgba(0x80, 0x80, 0x00, 0xFF),
        RGBA_OliveDrab      = helper::rgba(0x6B, 0x8E, 0x23, 0xFF),
        RGBA_Orange         = helper::rgba(0xFF, 0xA5, 0x00, 0xFF),
        RGBA_OrangeRed      = helper::rgba(0xFF, 0x45, 0x00, 0xFF),
        RGBA_Orchid         = helper::rgba(0xDA, 0x70, 0xD6, 0xFF),
        RGBA_PaleGoldenRod  = helper::rgba(0xEE, 0xE8, 0xAA, 0xFF),
        RGBA_PaleGreen      = helper::rgba(0x98, 0xFB, 0x98, 0xFF),
        RGBA_PaleTurquoise  = helper::rgba(0xAF, 0xEE, 0xEE, 0xFF),
        RGBA_PaleVioletRed  = helper::rgba(0xDB, 0x70, 0x93, 0xFF),
        RGBA_PapayaWhip     = helper::rgba(0xFF, 0xEF, 0xD5, 0xFF),
        RGBA_PeachPuff      = helper::rgba(0xFF, 0xDA, 0xB9, 0xFF),
        RGBA_Peru           = helper::rgba(0xCD, 0x85, 0x3F, 0xFF),
        RGBA_Pink           = helper::rgba(0xFF, 0xC0, 0xCB, 0xFF),
        RGBA_Plum           = helper::rgba(0xDD, 0xA0, 0xDD, 0xFF),
        RGBA_PowderBlue     = helper::rgba(0xB0, 0xE0, 0xE6, 0xFF),
        RGBA_Purple         = helper::rgba(0x80, 0x00, 0x80, 0xFF),
        RGBA_Red            = helper::rgba(0xFF, 0x00, 0x00, 0xFF),
        RGBA_RosyBrown      = helper::rgba(0xBC, 0x8F, 0x8F, 0xFF),
        RGBA_RoyalBlue      = helper::rgba(0x41, 0x69, 0xE1, 0xFF),
        RGBA_SaddleBrown    = helper::rgba(0x8B, 0x45, 0x13, 0xFF),
        RGBA_Salmon         = helper::rgba(0xFA, 0x80, 0x72, 0xFF),
        RGBA_SandyBrown     = helper::rgba(0xF4, 0xA4, 0x60, 0xFF),
        RGBA_SeaGreen       = helper::rgba(0x2E, 0x8B, 0x57, 0xFF),
        RGBA_SeaShell       = helper::rgba(0xFF, 0xF5, 0xEE, 0xFF),
        RGBA_Sienna         = helper::rgba(0xA0, 0x52, 0x2D, 0xFF),
        RGBA_Silver         = helper::rgba(0xC0, 0xC0, 0xC0, 0xFF),
        RGBA_SkyBlue        = helper::rgba(0x87, 0xCE, 0xEB, 0xFF),
        RGBA_SlateBlue      = helper::rgba(0x6A, 0x5A, 0xCD, 0xFF),
        RGBA_SlateGray      = helper::rgba(0x70, 0x80, 0x90, 0xFF),
        RGBA_Snow           = helper::rgba(0xFF, 0xFA, 0xFA, 0xFF),
        RGBA_SpringGreen    = helper::rgba(0x00, 0xFF, 0x7F, 0xFF),
        RGBA_SteelBlue      = helper::rgba(0x46, 0x82, 0xB4, 0xFF),
        RGBA_Tan            = helper::rgba(0xD2, 0xB4, 0x8C, 0xFF),
        RGBA_Teal           = helper::rgba(0x00, 0x80, 0x80, 0xFF),
        RGBA_Thistle        = helper::rgba(0xD8, 0xBF, 0xD8, 0xFF),
        RGBA_Tomato         = helper::rgba(0xFF, 0x63, 0x47, 0xFF),
        RGBA_Turquoise      = helper::rgba(0x40, 0xE0, 0xD0, 0xFF),
        RGBA_Violet         = helper::rgba(0xEE, 0x82, 0xEE, 0xFF),
        RGBA_Wheat          = helper::rgba(0xF5, 0xDE, 0xB3, 0xFF),
        RGBA_White          = helper::rgba(0xFF, 0xFF, 0xFF, 0xFF),
        RGBA_WhiteSmoke     = helper::rgba(0xF5, 0xF5, 0xF5, 0xFF),
        RGBA_Yellow         = helper::rgba(0xFF, 0xFF, 0x00, 0xFF),
        RGBA_YellowGreen    = helper::rgba(0x9A, 0xCD, 0x32, 0xFF),
#endif
    };
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


#include <utility>


// ui namespace
namespace LongUI {
    // control
    class UIControl;
    // contrl control
    class CUIControlControl;
    // time capsule
    class CUITimeCapsule : public Node<CUITimeCapsule>,
        public CUISmallObject {
        // friend
        friend CUIControlControl;
    protected:
        // ctor
        CUITimeCapsule(
            void(* call)(void*, float p) noexcept,
            void(* dtor)(void*) noexcept,
            float total) noexcept;
        // dtor
        ~CUITimeCapsule() noexcept ;
        // delete this
        void dispose() noexcept;
        // normal check hoster last end
        void normal_check_hoster_last_end() noexcept;
    public:
        // force terminate
        void Terminate() noexcept;
        // restart
        void Restart() noexcept;
        // call this
        bool Call(float delta) noexcept;
        // is more mo than
        bool IsMoreMOThan(const CUITimeCapsule& x) const noexcept;
        // set hoster
        void SetHoster(UIControl& hoster) noexcept { m_pHoster = &hoster; }
        // is same hoster
        bool IsSameHoster(UIControl& hoster) const noexcept { return m_pHoster == &hoster; }
    private:
        // call ptr
        void(* const m_pCall)(void*, float p) noexcept;
        // dtor ptr
        void(* const m_pDtor)(void*) noexcept;
        // pointer
        UIControl *         m_pHoster = nullptr;
        // total time
        float      const    m_fTotalTime;
        // time done
        float               m_fDoneTime = 0.f;
    };
    // impl namespace
    namespace detail {
        // impl for time capsule
        template<typename T> struct time_capsule_helper : CUITimeCapsule {
            // alignof T cannot greater double(std::max_align_t)
            static_assert(alignof(T) <= alignof(double), "to large!");
            // T data
            typename std::aligned_storage<sizeof(T), alignof(T)>::type     buffer;
            // ctor
            time_capsule_helper(
                T&& func,
                void(*call)(void*, float p) noexcept,
                void(*dtor)(void*) noexcept,
                float total) noexcept : CUITimeCapsule(call, dtor, total) {
                detail::ctor_dtor<T>::create(&this->buffer, std::move(func));
            }
            // operator ()
            static void call(void* ptr, float p) noexcept {
                auto& obj = reinterpret_cast<time_capsule_helper*>(ptr)->buffer;
                reinterpret_cast<T&>(obj)(p);
            }
        };
        // create time capsule
        template<typename T>
        inline auto create(float total, T&& func) noexcept ->CUITimeCapsule* {
            return new(std::nothrow) detail::time_capsule_helper<T>(
                std::move(func), 
                detail::time_capsule_helper<T>::call,
                detail::ctor_dtor<T>::delete_obj_ptr().ptr,
                total
                );
        }
    }
}


// c++
#include <type_traits>
// ui
// time capsule

// ui namespace
namespace LongUI {
    // detail namespace
    namespace detail {
        // cc size
        template<size_t> struct cc;
        // 32bit
        template<> struct cc<4> { enum { size = 16*9+24, align = 4 }; };
        // 64bit
        template<> struct cc<8> { enum { size = 24*9+32, align = 8 };  };
    }
    // basic animation
    struct ControlAnimationBasic;
    // private data for control control
    struct PrivateCC;
    // style sheet
    class CUIStyleSheet;
    // control
    class UIControl;
    // control control
    class CUIControlControl {
        // friend struct
        friend PrivateCC;
        // CUIXulStream
        struct CUIXulStream;
        // after create time capsule
        static auto after_create_tc(CUITimeCapsule*, UIControl* ctrl) noexcept->CUITimeCapsule*;
        // refresh time capsule
        static void refresh_time_capsule(UIControl&, CUITimeCapsule&) noexcept;
    public:
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // start extra animation
        void StartExtraAnimation(UIControl&, StyleStateTypeChange) noexcept;
#endif
        // start basic animation
        void StartBasicAnimation(UIControl&, StyleStateTypeChange) noexcept;
        // find basic animation
        auto FindBasicAnimation(const UIControl&) const noexcept -> const ControlAnimationBasic*;
    public:
        // create time capsule for control
        template<typename T>
        auto CreateTimeCapsule(T&& func, float total, UIControl* ctrl = nullptr) noexcept {
            return this->after_create_tc(detail::create<T>(total, std::move(func)), ctrl); }
        // dispose time capsule for control
        void DisposeTimeCapsule(UIControl& ctrl) noexcept;
        // refresh time capsule for control
        void RefreshTimeCapsule(UIControl& ctrl) noexcept;
    public:
        // add init list
        void AddInitList(UIControl& ctrl) noexcept;
        // add update list
        void AddUpdateList(UIControl& ctrl) noexcept;
        // add next update list
        void AddNextUpdateList(UIControl& ctrl) noexcept;
        // control attached
        void ControlAttached(UIControl& ctrl) noexcept;
        // control disattached
        void ControlDisattached(UIControl& ctrl) noexcept;
        // invalidate control
        void InvalidateControl(UIControl& ctrl) noexcept;
    public:
        // set xul dir [internal use]
        void SetXulDir(U8View) noexcept;
        // get xul dir [internal use]
        auto GetXulDir() const noexcept -> U8View;
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // add global css string
        void AddGlobalCssString(U8View) noexcept;
        // add global css file
        void AddGlobalCssFile(U8View file_name) noexcept;
        // get style sheet
        auto GetStyleSheet() const noexcept { return m_pStyleSheet; }
        // get style cached control list
        auto GetStyleCachedControlList() noexcept -> void*;
#endif
    public:
        // make xul tree
        static bool MakeXul(UIControl& ctrl, const char* xul) noexcept;
        // render 
        static void RecursiveRender(
            const UIControl& ctrl,
            const RectF region[],
            uint32_t length
        ) noexcept;
    protected:
        // update time capsule
        void update_time_capsule(float delta) noexcept;
        // has time capsule?
        bool has_time_capsule() const noexcept;
        // update control
        void update_control_in_list() noexcept;
        // init control, return true if update-list not empty
        bool init_control_in_list() noexcept;
        // update count
        //auto update_count() noexcept ->uint32_t;
        // push next update
        void push_next_update() noexcept;
        // normal update
        void normal_update() noexcept;
        // dirty update
        void dirty_update() noexcept;
        // copy ctor
        CUIControlControl(const CUIControlControl&) noexcept = delete;
        // ctor
        CUIControlControl() noexcept;
        // dtor
        ~CUIControlControl() noexcept;
    private:
        // update basic animation
        void update_basic_animation(uint32_t delta) noexcept;
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // update extra animation
        void update_extra_animation(uint32_t delta) noexcept;
        // do animation in formto list
        void do_animation_in_from_to(UIControl& ctrl) noexcept;
#endif
        // dispose all time capsule
        void dispose_all_time_capsule() noexcept;
    private:
        // time capsule head
        Node<CUITimeCapsule>    m_oHeadTimeCapsule;
        // time capsule tail
        Node<CUITimeCapsule>    m_oTailTimeCapsule;
    protected:
#ifndef LUI_DISABLE_STYLE_SUPPORT
        // style sheet
        CUIStyleSheet*          m_pStyleSheet = nullptr;
#endif
        // time tick
        uint32_t                m_dwTimeTick;
        // delta time(unit: ms)
        uint32_t                m_dwDeltaTime;
    private:
        // private data
        std::aligned_storage<
            detail::cc<sizeof(void*)>::size,
            detail::cc<sizeof(void*)>::align
        >::type                 m_private;
        // get cc
        auto&cc() noexcept { return reinterpret_cast<PrivateCC&>(m_private); }
        // get const cc
        auto&cc() const noexcept { return reinterpret_cast<const PrivateCC&>(m_private); }
    };
}


/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

namespace LongUI {
    // control
    class UIControl;
    // control meta info
    struct MetaControl {
        // super class
        const MetaControl*  super_class;
        // element name
        const char*         element_name;
        // create control
        auto (*create_func)(UIControl*) noexcept->UIControl*;
    };
}

// control meta info 
#define LUI_CONTROL_META_INFO(T, ele) \
    static UIControl* create_##T(UIControl* p) noexcept {\
        return new(std::nothrow) T{ p };\
    }\
    const MetaControl T::s_meta = {\
        &T::Super::s_meta,\
        ele,\
        create_##T\
    };

// control meta info 
#define LUI_CONTROL_META_INFO_NO(T, ele) \
    const MetaControl T::s_meta = {\
        &T::Super::s_meta,\
        ele,\
        nullptr\
    };

#include <cstdint>

// utf-16 based filename file

namespace LongUI {
    /// <summary>
    /// file
    /// </summary>
    class CUIFile {
    public:
        // error handle
        enum : intptr_t { ERROR_HANDLE = -1 };
        // open flag
        enum OpenFlag : uint32_t {
            // read
            Flag_Read = 1 << 0,
            // write
            Flag_Write = 1 << 1,
            // create always
            Flag_CreateAlways = 1 << 2,
            // open always, create if not exsit
            Flag_OpenAlways = 1 << 3,
        };
        // seek type
        enum TypeOfSeek : uint32_t {
            // begin of file
            Seek_Begin = 0,
            // current of file
            Seek_Current = 1,
            // end of file
            Seek_End = 2
        };
    private:
        // utf-8 file name
        enum : uint32_t { Flag_UTF8FileName = 1ul << 31 };
    public:
        // ctor
        CUIFile(const char16_t* namefile, OpenFlag) noexcept;
        // ctor
        CUIFile(const char* namefile, OpenFlag) noexcept;
        // dtor
        ~CUIFile() noexcept;
        // ok?
        bool IsOk() const noexcept { return m_hFile != ERROR_HANDLE; }
        // ok?
        bool IsOK() const noexcept { return m_hFile != ERROR_HANDLE; }
        // ok?
        operator bool() const noexcept { return this->IsOk(); }
        // tell, tell position of file
        auto Tell() const noexcept->uint32_t;
        // get file size less than 4GB
        auto GetFilezize() const noexcept->uint32_t;
        // seek, set file pointer less than 2GB
        auto Seek(int32_t offset, TypeOfSeek seek) const noexcept->uint32_t;
        // read file, return byte read
        auto Read(void* buffer, uint32_t bufread) const noexcept->uint32_t;
        // write file, return byte writed
        auto Write(const void* buffer, uint32_t bufwrite) noexcept->uint32_t;
        // get handle
        void*GetHandle() const noexcept { return reinterpret_cast<void*>(m_hFile); }
    private:
        // ctor
        CUIFile(OpenFlag, const char16_t* namefile) noexcept;
        // file handle
        intptr_t        m_hFile = ERROR_HANDLE;
    };
    // operator | for OF
    constexpr CUIFile::OpenFlag operator|(CUIFile::OpenFlag a, CUIFile::OpenFlag b) noexcept {
        return static_cast<CUIFile::OpenFlag>(static_cast<uint32_t>(a) | b);
    }
    // ctor with wchar file name
    inline CUIFile::CUIFile(const char16_t* n, OpenFlag f) noexcept :
        CUIFile(static_cast<OpenFlag>(f), n){}
    // ctor with char file name
    inline CUIFile::CUIFile(const char* n, OpenFlag f) noexcept :
        CUIFile(static_cast<OpenFlag>(f | Flag_UTF8FileName), reinterpret_cast<const char16_t*>(n)) {}
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// basic type
//#include "../util/ui_ostype.h"

#ifndef NDEBUG
#define LUI_FRAMEID << LongUI::get_frame_id() << "_F "
namespace LongUI { auto get_frame_id() noexcept->uint32_t; }
#else 
#define LUI_FRAMEID
#endif

// helper marco
#define _lui_inter_debug LongUI::CUIDebug::GetInstance()
#ifndef NDEBUG
#define _lui_inter_extra << LongUI::Interfmt("<%4dL@%s>: ", int(__LINE__), __FUNCTION__)
#define longui_debug_hr(hr, msg) if (!hr) LUIDebug(Error) << msg << LongUI::endl
#else
#define _lui_inter_extra
#define longui_debug_hr(hr, msg) (void)0
#endif
// debug marco
#define LUIDebug(lv) _lui_inter_debug << LongUI::DebugStringLevel::DLevel_##lv _lui_inter_extra


// ui namespace
namespace LongUI {
#ifndef NDEBUG
    // mouse event
    enum class MouseEvent : uint32_t;
    // color
    struct ColorF;
    // struct
    struct StyleStateTypeChange;
#endif
    // debug string level
    enum DebugStringLevel : uint32_t {
        // None level
        DLevel_None = 0,
        // level Log
        DLevel_Log,
        // level Hint
        DLevel_Hint,
        // level Warning
        DLevel_Warning,
        // level Error
        DLevel_Error,
        // level Fatal
        DLevel_Fatal,
        // level's size
        DLEVEL_SIZE
    };
    // endl for longUI
    struct EndL { }; extern EndL const endl;
    // debug
    class CUIDebug {
    public:
        // set unhandled exp handler
        static void InitUnExpHandler() noexcept;
        // output debug string
        void OutputString(
            DebugStringLevel level,
            const wchar_t* str,
            bool flush
        ) noexcept;
#ifdef NDEBUG
        // get debug instance
        static auto GetInstance() noexcept->CUIDebug& {
            return *static_cast<CUIDebug*>(nullptr);
    }
        // overload << operator 重载 << 运算符
        template<typename T>
        inline const CUIDebug& operator<< (const T&) const noexcept { return *this; }
        // output with wide char
        inline void Output(DebugStringLevel, const char16_t*) const noexcept { }
        // output with utf-8
        inline void Output(DebugStringLevel, const char*) const noexcept { }

#else
        // get debug instance
        static auto GetInstance() noexcept->CUIDebug&;
    protected:
        // last DebugStringLevel
        DebugStringLevel        m_lastLevel = DebugStringLevel::DLevel_Log;
        // time tick count
        uint32_t                m_timeTick = 0;
        // log file
        CUIFile                 m_logFile;
    public:
        // overload << operator for DebugStringLevel
        CUIDebug& operator<< (const DebugStringLevel l)  noexcept { m_lastLevel = l; return *this; }
        // overload << operator for float
        CUIDebug& operator<< (const float f) noexcept;
        // overload << operator for float.2
        CUIDebug& operator<< (const DDFFloat2 f) noexcept;
        // overload << operator for float.3
        CUIDebug& operator<< (const DDFFloat3 f) noexcept;
        // overload << operator for float.4
        CUIDebug& operator<< (const DDFFloat4 f) noexcept;
        // overload << operator for uint32_t
        CUIDebug& operator<< (const uint32_t o) noexcept;
        // overload << operator for int32_t
        CUIDebug& operator<< (const int32_t o) noexcept;
        // overload << operator for bool
        CUIDebug& operator<< (const bool b) noexcept;
        // overload << operator for void*
        CUIDebug& operator<< (const void*) noexcept;
        // overload << operator for control
        CUIDebug& operator<< (const UIControl*) noexcept;
        // overload << operator for control
        CUIDebug& operator<< (const UIControl& c) noexcept { return *this << &c; }
        // overload << operator for endl
        CUIDebug& operator<< (const LongUI::EndL&) noexcept;
        // overload << operator for Matrix
        CUIDebug& operator<< (const Matrix3X2F& m) noexcept;
        // overload << operator for DXGI_ADAPTER_DESC*
        CUIDebug& operator<< (const GraphicsAdapterDesc& d) noexcept;
        // overload << operator for ColorF
        CUIDebug& operator<< (const ColorF& r) noexcept;
        // overload << operator for RectF
        CUIDebug& operator<< (const RectF& r) noexcept;
        // overload << operator for Point2F
        CUIDebug& operator<< (const Point2F& p) noexcept;
        // overload << operator for Size2F
        CUIDebug& operator<< (const Size2F& p) noexcept;
        // overload << operator for const char16_t*
        CUIDebug& operator<< (const wchar_t* s) noexcept;
        // overload << operator for const char16_t*
        CUIDebug& operator<< (const char16_t* s) noexcept { this->OutputNoFlush(m_lastLevel, s); return *this; }
        // overload << operator for const char*
        CUIDebug& operator<< (const char* s) noexcept { this->OutputNoFlush(m_lastLevel, s); return *this; }
        // overload << operator for char32_t
        CUIDebug& operator<< (const char32_t ch) noexcept;
        // overload << operator for char16_t
        CUIDebug& operator<< (const char16_t ch) noexcept { return (*this) << char32_t(ch); }
        // overload << operator for char
        CUIDebug& operator<< (const char ch) noexcept { return (*this) << char32_t(ch); }
        // overload << operator for char
        CUIDebug& operator<< (const wchar_t ch) noexcept { return (*this) << char32_t(ch); }
        // overload << operator for CUIString
        CUIDebug& operator<< (const CUIString& s) noexcept;
        // overload << operator for utf-8 string-view
        CUIDebug& operator<< (const U8View s) noexcept;
        // overload << operator for MouseEvent
        CUIDebug& operator<< (MouseEvent e) noexcept;
        // overload << operator for MouseEvent
        CUIDebug& operator<< (StyleStateTypeChange e) noexcept;
        // output debug string with flush
        void Output(DebugStringLevel l, const char16_t* s) noexcept;
        // output debug string with flush
        void Output(DebugStringLevel l, const char* s) noexcept;
    private:
        // output debug (utf-8) string without flush
        void OutputNoFlush(DebugStringLevel l, const char* s) noexcept;
        // output debug string without flush
        void OutputNoFlush(DebugStringLevel l, const char16_t* s) noexcept;
    public:
#endif
    protected:
#ifdef NDEBUG
        // ctor
        CUIDebug() noexcept = default;
#else
        // ctor
        CUIDebug(const char16_t* file = u"") noexcept;
#endif
        // dtor
        ~CUIDebug() noexcept = default;
        // ctor
        CUIDebug(const CUIDebug&) noexcept = delete;
        // ctor
        CUIDebug(CUIDebug&&) noexcept = delete;
    };
    // formated buffer
#ifndef NDEBUG
    auto Formated(const char* format, ...) noexcept -> const char*;
    auto Interfmt(const char* format, ...) noexcept -> const char*;
#else
    static auto Formated(...) noexcept { return static_cast<const char*>(nullptr); }
#endif
}

#include <type_traits>
#include <cstdint>


// ui namespace
namespace LongUI {
    // detail namespace
    namespace detail {
        // impl
        template<size_t> struct locker_impl_info {};
        // impl for 32 bit
        template<> struct locker_impl_info<4> { enum { size = 24, align = 4 }; };
        // impl for 64 bit
        template<> struct locker_impl_info<8> { enum { size = 40, align = 8 }; };
    }
    // locker, could be used in "Recursive Calls"
    class CUILocker {
        // buffer size
        enum { buf_size = detail::locker_impl_info<sizeof(void*)>::size };
        // buffer align
        enum { buf_align = detail::locker_impl_info<sizeof(void*)>::align };
    public:
        // ctor
        CUILocker() noexcept;
        // dtor
        ~CUILocker() noexcept;
        // lock
        void Lock() noexcept;
        // unlock
        void Unlock() noexcept;
        // get recursion count
        auto GetRecursionCount() const noexcept->uint32_t;
    public:
        // cannot be moved
        CUILocker(CUILocker&&) noexcept = delete;
        // cannot be copied
        CUILocker(const CUILocker&) noexcept = delete;
        // cannot be operator= moved
        auto operator=(CUILocker&&) noexcept->CUILocker& = delete;
        // cannot be operator= copied
        auto operator=(const CUILocker&) noexcept->CUILocker& = delete;
    protected:
        // buffer storage
        std::aligned_storage<buf_size, buf_align>::type m_impl;
    };
}

//#include "ui_interface.h"
#include <cstdint>

// ui namespace
namespace LongUI {
    // script
    struct ScriptUI;
    // argument
    struct EventArgument;
    // control info list
    struct ControlInfoList;
    // Font arg
    struct FontArg;
    // error info
    struct ErrorInfo {
        // sub error info
        union SubInfo {
            // handle id
            uintptr_t   id;
            // string
            const char* u8str;
            // sub info
        }               sub;
        // main error info
        enum MainError : uint32_t {
            // out of memory - sub[0 or size to try alloc]
            Error_OutOfMemory,
            // file not found - sub[nullptr or filename]
            Error_FileNotFound_U8,
            // file not found - sub[nullptr or filename]
            Error_FileNotFound_U16,
            // xml parse failed - sub[0 or ]
            Error_XmlParseFailed,
            // main error info
        }               main;
        // error level
        enum ErrorLevel : uint32_t {
            // level: warning
            Level_Warning = 0,
            // level: error
            Level_Error,
            // level: fatal
            Level_Fatal,
            // level of error
        }               level;
    };
    // ConfigureFlag decl
    enum ConfigureFlag : uint32_t;
    // operator |
    constexpr ConfigureFlag operator|(ConfigureFlag a, ConfigureFlag b) noexcept {
        return static_cast<ConfigureFlag>(uint32_t(a) | uint32_t(b));
    }
    // operator &
    constexpr ConfigureFlag operator&(ConfigureFlag a, ConfigureFlag b) noexcept {
        return static_cast<ConfigureFlag>(uint32_t(a) & uint32_t(b));
    }
    // flag
    enum ConfigureFlag : uint32_t {
        // no flag
        Flag_None = 0,
        // all flags
        Flag_All = uint32_t(-1),
        // flag for CPU rendering, if not, will call IUIInterface::ChooseAdapter
        Flag_RenderByCPU = 1 << 0,
        // output debug string?
        Flag_OutputDebugString = 1 << 1,
        // quit on last window closed
        Flag_QuitOnLastWindowClosed = 1 << 2,
        // only one system window, like game(all child window will be inline window)
        Flag_OnlyOneSystemWindow = 1 << 3,
        // no hi-dpi auto scale
        Flag_NoAutoScaleOnHighDpi = 1 << 4,
        // subpixel text rendering as default value for window/viewport
        Flag_SubpixelTextRenderingAsDefault = 1 << 5,
        // -------------------------------------------------------------
        // [debug flag under DEBUG MODE] output font family infomation
        Flag_DbgOutputFontFamily = 1 << 10,
        // [debug flag under DEBUG MODE] output time-took to NONE
        Flag_DbgOutputTimeTook = 1 << 11,
        // [debug flag under DEBUG MODE] draw colored dirty rect
        Flag_DbgDrawDirtyRect = 1 << 12,
        // [debug flag under DEBUG MODE] draw textbox cell rect
        Flag_DbgDrawTextCell = 1 << 13,
        // [debug flag under DEBUG MODE] display debug window
        Flag_DbgDebugWindow = 1 << 14,
        // [debug flag under DEBUG MODE] Dnt link style sheet
        Flag_DbgNoLinkStyle = 1 << 15,
        // -------------------------------------------------------------
        // defualt flag
        Flag_Default = Flag_None
#ifndef NDEBUG
        | Flag_RenderByCPU
#endif
        | Flag_OutputDebugString
        | Flag_QuitOnLastWindowClosed
        //| Flag_NoAutoScaleOnHighDpi
        //| Flag_DbgOutputTimeTook 
        //| Flag_DbgDrawDirtyRect
        | Flag_DbgDrawTextCell
        | Flag_DbgDebugWindow
    };
    // UI Configure Interface
    struct PCN_NOVTABLE IUIConfigure /*: IUIRefCount*/ {
#ifndef NDEBUG
        /// <summary>
        /// Gets the name of the simple log file.
        /// </summary>
        /// <returns></returns>
        virtual auto GetSimpleLogFileName() noexcept ->CUIString = 0;
#endif

        /// <summary>
        /// Loads the data from URL.
        /// </summary>
        /// <param name="url_in_utf8">The URL in UTF8.</param>
        /// <param name="url_in_utf16">The URL in UTF16.</param>
        /// <param name="buffer">The output buffer.</param>
        /// <returns></returns>
        virtual void LoadDataFromUrl(U8View url_in_utf8, const CUIString& url_in_utf16, POD::Vector<uint8_t>& buffer) noexcept = 0;

        /// <summary>
        /// Gets the locale name
        /// </summary>
        /// <param name="name">The locale name buffer</param>
        /// <remarks>empty for local locale name</remarks>
        virtual void GetLocaleName(char16_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept = 0;

        /// <summary>
        /// Defaults the font arg
        /// </summary>
        /// <param name="arg">The argument.</param>
        /// <param name="family">The font family name.</param>
        virtual void DefaultFontArg(FontArg& arg) noexcept = 0;

        /// <summary>
        /// Adds the control class info.
        /// </summary>
        /// <remarks>call CUIManager::RegisterControl to add control class</remarks>
        virtual void RegisterControl(ControlInfoList& list) noexcept = 0;

        /// <summary>
        /// Chooses the video adapter.
        /// </summary>
        /// <param name="adapters">The adapter array</param>
        /// <param name="length">The length of adapters</param>
        /// <remarks>
        /// if set "Flag_RenderByCPU", you should choose a video card,return the index.
        /// if return code out of range, will set by default(null pointer adapter)
        /// btw, in the adapter list, also include the WARP-adapter
        /// </remarks>
        /// <returns>index of adapters</returns>
        virtual auto ChooseAdapter(const GraphicsAdapterDesc adapters[/*length*/], const uint32_t length /*<=64*/) noexcept->uint32_t = 0;

        /// <summary>
        /// Shows the error.
        /// </summary>
        /// <param name="info">The information.</param>
        virtual void OnError(ErrorInfo info) noexcept = 0;
    public:
        // run a section script for event
        virtual bool Evaluation(ScriptUI, UIControl&) noexcept = 0;
        // alloc the script memory and copy into(may be compiled into byte code)
        virtual auto AllocScript(U8View) noexcept-> ScriptUI = 0;
        // free the script memory
        virtual void FreeScript(ScriptUI) noexcept = 0;
        // eval script for window init, may be called over once for single window
        virtual void Evaluation(U8View, CUIWindow&) noexcept =0;
        // finalize window script if has script
        virtual void FinalizeScript(CUIWindow&) noexcept =0;
    public:
        // alloc for normal space
        virtual void*NormalAlloc(size_t length) noexcept = 0;
        // free for normal space
        virtual void NormalFree(void* address) noexcept = 0;
        // realloc for normal space
        virtual void*NormalRealloc(void* address, size_t length) noexcept = 0;
        // alloc for small space
        virtual void*SmallAlloc(size_t length) noexcept = 0;
        // free for small space
        virtual void SmallFree(void* address) noexcept = 0;
    public:
        /// <summary>
        /// Begins the render thread.
        /// </summary>
        /// <returns>return true if ok</returns>
        virtual auto BeginRenderThread() noexcept ->Result = 0;
        /// <summary>
        /// Ends the render thread.
        /// </summary>
        virtual void EndRenderThread() noexcept = 0;
        /// <summary>
        /// Recursions the MSG loop.
        /// </summary>
        virtual auto RecursionMsgLoop() noexcept ->uintptr_t = 0;
        /// <summary>
        /// break current msg-loop
        /// </summary>
        virtual void BreakMsgLoop(uintptr_t code) noexcept = 0;
    };
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// basic type
#include <type_traits>

// ui namespace
namespace LongUI {
    // priavte wndmgr
    struct PrivateWndMgr;
    // window list
    struct WindowVector;
    // detail namespace
    namespace detail {
        // private data for manager
        template<size_t> struct private_wndmgr;
        // 32bit
        template<> struct private_wndmgr<4> { enum { size = 72, align = 8 }; };
        // 64bit
        template<> struct private_wndmgr<8> { enum { size = 96, align = 8 }; };
    }
    // UI Window Manager
    class CUIWndMgr {
        // friend
        friend CUIWindow;
    public:
        // get main dpi x
        auto GetMainDpiX() const noexcept { return m_uMainDpiX; }
        // get main dpi y
        auto GetMainDpiY() const noexcept { return m_uMainDpiY; }
        // mark window minsize changed, donothing if null
        void MarkWindowMinsizeChanged(CUIWindow* window) noexcept;
        // get window list
        auto GetWindowList() const noexcept->const WindowVector&;
        // move subviewport to global
        void MoveSubViewToGlobal(UIViewport&) noexcept;
        // find subviewport with unique string
        auto FindSubViewportWithUnistr(const char*) const noexcept->UIViewport*;
    protected:
        // close helper
        void close_helper(CUIWindow& wnd) noexcept;
        // add a window
        void add_window(CUIWindow&) noexcept;
        // remove a window
        void remove_window(CUIWindow&) noexcept;
        // before all windows 
        void before_render_windows() noexcept;
        // render all windows
        auto render_windows() noexcept->Result;
        // recreate_device all windows
        auto recreate_windows() noexcept->Result;
        // update delta time
        auto update_delta_time() noexcept -> float;
        // sleep for vblank
        void sleep_for_vblank() noexcept;
        // refresh window minsize
        void refresh_window_minsize() noexcept;
        // refresh control world in each window
        void refresh_window_world() noexcept;
    private:
        // is quit on last window closed
        static bool is_quit_on_last_window_closed() noexcept;
        // exit
        static void exit() noexcept;
    protected:
        // main monitor dpi x
        uint16_t                m_uMainDpiX = 96;
        // main monitor dpi y
        uint16_t                m_uMainDpiY = 96;
        // ununsed
        uint32_t                m_dwDisplayFrequency = 0;
        // vsync count
        uint32_t                m_dwWaitVSCount = 0;
        // vsync start time
        uint32_t                m_dwWaitVSStartTime = 0;
    private:
        // private data
        std::aligned_storage<
            detail::private_wndmgr<sizeof(void*)>::size,
            detail::private_wndmgr<sizeof(void*)>::align
        >::type                 m_private;
        // wm
        auto& wm() noexcept { return reinterpret_cast<PrivateWndMgr&>(m_private); }
        // wm
        auto& wm() const noexcept { return reinterpret_cast<const PrivateWndMgr&>(m_private); }
    protected:
        // refresh display frequency
        void refresh_display_frequency() noexcept;
        // ctor
        CUIWndMgr(Result& out) noexcept;
        // ctor
        CUIWndMgr(const CUIWndMgr&) noexcept = delete;
        // ctor
        CUIWndMgr(CUIWndMgr&&) noexcept = delete;
        // dtor
        ~CUIWndMgr() noexcept;
    };
}

/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
/*
     system-supported image file format list:
      - png
      - jpg
      - gif
      - and more
*/
    // rgba-color
    union RGBA;
    // priavte resmgr
    struct PrivateResMgr;
    // config
    struct IUIConfigure;
    // configure flag
    enum ConfigureFlag : uint32_t;
    // color float
    struct ColorF;
    // UI Window Manager
    class CUIResMgr {
        // my friend
        friend PrivateResMgr;
        // screen
        struct IScreen;
        // Debug
        struct Debug;
        // private data
        enum : size_t {
            // pointer count
            p_ptr_count = 4 + 2 + 4 + 1,
            // 32bit count
            p_32b_count = 0 + 2 + 2 + 2 + 2 + 1,
            // size count
            p_size =    p_ptr_count * sizeof(void*) + 
                        p_32b_count * sizeof(uint32_t)
        };
        // type of m_private
        struct private_t { alignas(void*) char buf[p_size]; };
    public:
        // get graphics factory
        auto&RefGraphicsFactory() noexcept { return *m_pGraphicsFactory; }
        // get 2d renderer
        auto&Ref2DRenderer() noexcept { return *m_p2DRenderer; }
        // get 3d device
        auto&Ref3DDevice() noexcept { return *m_p3DDevice; }
        // get native renderer
        auto GetNativeRenderer() const noexcept { return m_pNativeStyle; }
        // get common color brush with color
        static auto RefCCBrush(const ColorF&) noexcept->I::Brush&;
        // ref 2d factory, use reinterpret_cast<XX&>
        static auto Ref2DFactory() noexcept ->int&;
    public:
        // create ctl font
        auto CreateCtlFont(const FontArg&, I::Font*&, const StyleText*s=nullptr) noexcept->Result;
        // create ctl text
        auto CreateCtlText(const TextArg&, I::Text*&) noexcept->Result;
        // get default font data
        auto GetDefaultFont() const noexcept -> const FontArg&;
    public:
        // save as png
        auto SaveAsPng(I::Bitmap& bmp, const wchar_t* file) noexcept->Result;
        // load resource, return id
        auto LoadResource(U8View, ResourceType, bool is_xul_dir) noexcept->uint32_t;
        // get resource data
        auto GetResoureceData(uint32_t id)const noexcept->const ResourceData&;
        // add resource ref-count
        void AddResourceRefCount(uint32_t id) noexcept;
        // release resource ref-count
        void ReleaseResourceRefCount(uint32_t id) noexcept;
        // create bitmap from system-supported image file
        auto CreateBitmapFromSSImageFile(U8View view, I::Bitmap*&) noexcept->Result;
        // create bitmap from system-supported image memory
        auto CreateBitmapFromSSImageMemory(uint8_t* ptr, uint32_t len, I::Bitmap*&) noexcept->Result;
        // create bitmap with init-data
        auto CreateBitmap(Size2U size, const RGBA* color, uint32_t pitch, I::Bitmap*&) noexcept->Result;
        // create bitmap without init-data
        auto CreateBitmap(Size2U size, I::Bitmap*& bmp) noexcept { 
            return CreateBitmap(size, nullptr, 0, bmp); }
    private:
        // create bitmap
        auto create_bitmap_private(uint8_t*, uint32_t, void*&) noexcept->Result;
    protected:
        // init default font data
        auto init_default_font(IUIConfigure*) noexcept->Result;
    protected:
        // graphics factory
        I::FactoryGraphics*     m_pGraphicsFactory = nullptr;
        // 3d device
        I::Device3D*            m_p3DDevice = nullptr;
        // 3d renderer
        I::Renderer3D*          m_p3DRenderer = nullptr;
        // 2d renderer
        I::Renderer2D*          m_p2DRenderer = nullptr;
        // main screen
        IScreen*                m_pMainScreen = nullptr;
        // native style renderer
        void*                   m_pNativeStyle = nullptr;
    protected:
        // common color brush
        I::Brush*               m_pCommonBrush = nullptr;
    private:
#ifndef NDEBUG
        // debug
        Debug*                  m_pDebug = nullptr;
#endif
        // private data
        private_t               m_private;
        // PrivateResMgr data
        auto&rm() noexcept { return reinterpret_cast<PrivateResMgr&>(m_private); }
        // PrivateResMgr data
        auto&rm() const noexcept { return reinterpret_cast<const PrivateResMgr&>(m_private); }
        // release device
        void release_device() noexcept;
        // release res-list
        void release_res_list() noexcept;
    protected:
        // original local name length, LOCALE_NAME_MAX_LENGTH = 85
        enum { olnl = 85 + 3 };
        // local name
        char16_t                m_szLocaleName[olnl];
    protected:
        // redirect screen
        void redirect_screen() noexcept;
        // wait for vblank
        bool wait_for_vblank() noexcept;
        // recreate device
        auto recreate_device(IUIConfigure*, ConfigureFlag) noexcept->Result;
        // recreate resource
        auto recreate_resource() noexcept->Result;
        // ctor
        CUIResMgr(IUIConfigure* cfg, Result& hr) noexcept;
        // ctor
        CUIResMgr(const CUIResMgr&) noexcept = delete;
        // ctor
        CUIResMgr(CUIResMgr&&) noexcept = delete;
        // dtor
        ~CUIResMgr() noexcept;
    };
}



// ui namespace
namespace LongUI {
    // thread-waiter
    class CUIWaiter {
        // impl
        struct impl_info { void* buf[2];};
        // buffer size
        enum { buf_size = sizeof(impl_info) };
        // buffer align
        enum { buf_align = alignof(impl_info) };
    public:
        // ctor
        CUIWaiter() noexcept;
        // dtor
        ~CUIWaiter() noexcept;
        // wait
        void Wait() noexcept;
        // notify all
        void Broadcast() noexcept;
        // reset, could notify again?
        //void Reset() noexcept;
    public:
        // cannot be moved
        CUIWaiter(CUIWaiter&&) noexcept = delete;
        // cannot be copied
        CUIWaiter(const CUIWaiter&) noexcept = delete;
        // cannot be operator= moved
        auto operator=(CUIWaiter&&) noexcept->CUIWaiter& = delete;
        // cannot be operator= copied
        auto operator=(const CUIWaiter&) noexcept->CUIWaiter& = delete;
    protected:
        // buffer storage
        impl_info                   m_impl;
    };
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// debug
// locker
// config
// cc
// window manager
// resource manager
// string view
// ostype
// type
#include <type_traits>
// waiter

// longui manager
#define UIManager (LongUI::CUIManager::GetInstance())

// ui namespace
namespace LongUI {
    // detail namespace
    namespace detail { 
        // ctor_dtor
        template<typename T> struct ctor_dtor;
        // private data for manager
        template<size_t> struct private_manager;
        // 32bit
        template<> struct private_manager<4> { enum { size = 64, align = 4 }; };
        // 64bit
        template<> struct private_manager<8> { enum { size = 104, align = 8 }; };
    }
    // input
    class CUIInputKM;
    // config keeper, make sure config inited first
    struct ConfigKeeper { IUIConfigure* config; };
    // longui ui-manager
    class CUIManager final : 
        protected ConfigKeeper,
        public CUIDebug,
        public CUIResMgr, 
        public CUIWndMgr,
        public CUIControlControl {
        // refresh system info
        void refresh_system_info() noexcept;
    public:
        // input
        friend CUIInputKM;
        // ctor_dtor
        friend detail::ctor_dtor<CUIManager>;
        // interface for memory management
        struct IMM;
        // private
        struct Private;
    public:
        // get instance
        static inline auto GetInstance() noexcept->CUIManager&;
        // delete later for control
        static void DeleteLater(UIControl&) noexcept;
        // initialize
        auto Initialize(
            IUIConfigure* config = nullptr,
            ConfigureFlag cfgflag = ConfigureFlag::Flag_Default
        ) noexcept ->Result;
        // uninitialize
        void Uninitialize() noexcept;
        // do one frame
        void OneFrame() noexcept;
        // wait vblank
        void WaitForVBlank() noexcept;
        // need recreate_device
        void NeedRecreate() noexcept;
    public:
        // add [unique]/[release-free] text
        auto GetUniqueText(U8View pair) noexcept->const char*;
        // create control within element name
        auto CreateControl(U8View element, UIControl* parent) noexcept->UIControl*;
    public:
        // call this on kill focus to manage input
        //void OnKillFocus() noexcept;
        // get wheel scroll lines
        auto GetWheelScrollLines() const noexcept { return m_uWheelScrollLines; }
        // get wheel scroll chars
        auto GetWheelScrollChars() const noexcept { return m_uWheelScrollChars; }
        // get delta time in ms
        auto GetDeltaTimeMs() const noexcept { return m_dwDeltaTime; }
        // get delta time in sec.
        auto GetDeltaTime() const noexcept { return m_fDeltaTime; }
        // get app run time in ms
        //auto GetAppTimeTick() const noexcept { return m_dwTimeTick - m_cStartTick; }
        // lock data
        void DataLock() noexcept { m_uiDataLocker.Lock(); }
        // unlock data
        void DataUnlock() noexcept { m_uiDataLocker.Unlock(); }
        // lock rendering
        void RenderLock() noexcept { m_uiRenderLocker.Lock(); }
        // unlock rendering
        void RenderUnlock() noexcept { m_uiRenderLocker.Unlock(); }
        // get data locker recursion count
        auto DataRecursion() const noexcept { return m_uiDataLocker.GetRecursionCount(); }
        // get gui thread id
        auto GetGuiThreadId() const noexcept { return m_uGuiThreadId; }
    public:
        // exit
        void Exit(uintptr_t code = 0) noexcept;
        // break loop
        void BreakMsgLoop(uintptr_t code) noexcept { this->config->BreakMsgLoop(code); }
        // msg-loop(could be in recursion)
        void RecursionMsgLoop() noexcept { this->config->RecursionMsgLoop(); }
        // show error with result code
        bool ShowError(Result hr, const wchar_t* str_b = nullptr) noexcept;
        // load data from url
        void LoadDataFromUrl(U8View url_utf8, POD::Vector<uint8_t>& buffer) noexcept;
    public:
        // run a section script for event
        bool Evaluation(ScriptUI s, UIControl& c) noexcept { return this->config->Evaluation(s, c); }
        // alloc the script memory and copy into
        auto AllocScript(U8View view) noexcept { return this->config->AllocScript(view); }
        // free the script memory
        void FreeScript(ScriptUI script) noexcept { this->config->FreeScript(script); }
        // eval script for window init
        void Evaluation(U8View v, CUIWindow& w) noexcept { this->config->Evaluation(v, w); }
        // finalize window script if has script
        void FinalizeScript(CUIWindow& w) noexcept { this->config->FinalizeScript(w); };
    private:
        // ctor
        CUIManager(IUIConfigure*, ConfigureFlag, Result& ) noexcept;
        // ctor
        CUIManager(const CUIManager&) noexcept = delete;
        // ctor
        CUIManager(CUIManager&&) noexcept = delete;
        // dtor
        ~CUIManager() noexcept;
        // this manager
        inline auto this_() noexcept->CUIManager*;
    public:
#ifndef  NDEBUG
        // alloc counter: normal  [CUIManager::GetInstance().alloc_counter_n_dbg]
        size_t                  alloc_counter_n_dbg = 0;
        // alloc counter: small   [CUIManager::GetInstance().alloc_counter_s_dbg]
        size_t                  alloc_counter_s_dbg = 0;
#endif // ! NDEBUG
        // flag for configure
        ConfigureFlag const     flag;
    private:
        // delta time in sec.
        float                   m_fDeltaTime = 0.f;
        // app start tick
        //uint32_t                m_cStartTick = 0;
        // wheel scroll lines 
        uint32_t                m_uWheelScrollLines = 3;
        // wheel scroll chars
        uint32_t                m_uWheelScrollChars = 3;
        // gui thread id
        uint32_t                m_uGuiThreadId = 0;
        // unused u32
        uint32_t                m_uUnused = 0;
        // tool window
        HWND                    m_hToolWnd = nullptr;
#ifndef NDEBUG
        // debug window
        CUIWindow*              m_pDebugWindow = nullptr;
#endif
        // data locker
        CUILocker               m_uiDataLocker;
        // rendering locker
        CUILocker               m_uiRenderLocker;
        // time capsule waiter
        CUIWaiter               m_uiTimeCapsuleWaiter;
    protected:
        // try recreate_device all device resource
        void try_recreate() noexcept;
        // call time capsule#1
        void call_time_capsule_s1() noexcept;
        // call time capsule#2
        void call_time_capsule_s2() noexcept;
        // private manager
        auto&pm() noexcept { return reinterpret_cast<Private&>(m_private); }
        // private data
        std::aligned_storage<
            detail::private_manager<sizeof(void*)>::size,
            detail::private_manager<sizeof(void*)>::align
        >::type                 m_private;
    private:
        // recreate_device flag
        bool                    m_flagRecreate = false;
        // window minsize changed flag
        bool                    m_flagWndMinSizeChanged = false;
    };
    // int code
    inline auto IntCode(uintptr_t code) noexcept -> int {
        return static_cast<int32_t>(static_cast<uint32_t>(code));
    }
    // int code
    inline auto IntCode(int code) noexcept -> uintptr_t {
        return static_cast<uint32_t>(static_cast<int32_t>(code));   
    }
    // auto data locker
    class CUIDataAutoLocker {
    public:
        // ctor
        CUIDataAutoLocker() noexcept { CUIManager::GetInstance().DataLock(); }
        // dtor
        ~CUIDataAutoLocker() noexcept { CUIManager::GetInstance().DataUnlock(); }
    };
    // auto dxgi(rendering) locker
    class CUIRenderAutoLocker {
    public:
        // ctor
        CUIRenderAutoLocker() noexcept { CUIManager::GetInstance().RenderLock(); }
        // dtor
        ~CUIRenderAutoLocker() noexcept { CUIManager::GetInstance().RenderUnlock(); }
    };
    // blocking gui operation auto unlocker
    class CUIBlockingGuiOpAutoUnlocker {
        // counter
        const uint32_t  m_counter;
        // init
        static auto init() noexcept->uint32_t;
        // uninit
        static void uninit(uint32_t) noexcept;
    public:
        // ctor
        CUIBlockingGuiOpAutoUnlocker() noexcept : m_counter(init()) {};
        // dtor
        ~CUIBlockingGuiOpAutoUnlocker() noexcept { uninit(m_counter); }
    };
    /// <summary>
    /// single instance buffer for longui manager
    /// </summary>
    extern std::aligned_storage<sizeof(CUIManager), alignof(CUIManager)>::type s_bufManager;
    /// <summary>
    /// Gets the ui manager instance.
    /// 获取UI管理器实例
    /// </summary>
    /// <returns></returns>
    inline auto CUIManager::GetInstance() noexcept -> CUIManager & {
        return reinterpret_cast<CUIManager&>(s_bufManager);
    }
}



// ui
// c++
#include <cstddef>

namespace LongUI {
    // popup type
    enum class PopupType : uint32_t {
        // type exclusive : invoke via exclusive hoster, will keep same width as hoster
        Type_Exclusive = 0,
        // type popup     : maybe by active control(left click)
        Type_Popup,
        // type context   : maybe by context menu(right click)
        Type_Context,  
        // type tooltip   : maybe by hover(leave to release)
        Type_Tooltip,
    };
    // popup window from name
    auto PopupWindowFromName(
        UIControl& ctrl,
        const char* name,
        Point2F pos,
        PopupType type
    ) noexcept ->EventAccept;
    // popup window from viewport
    void PopupWindowFromViewport(
        UIControl& ctrl,
        UIViewport& viewport,
        Point2F pos,
        PopupType type
    ) noexcept;
    // popup window from tooltip text
    void PopupWindowFromTooltipText(
        UIControl& ctrl,
        const char* text,
        Point2F pos
    ) noexcept;
    // close tooltip window
    void PopupWindowCloseTooltip(
        UIControl& ctrl
    ) noexcept;
}

// output to stdout
#define UI_TRACE_TO_STDOUT

// you should implement uidbg_trace
//#define UI_TRACE_TO_CUSTOM

#ifdef NDEBUG
#define UI_TRACE_MSG(msg)
#define UI_FREE_DATA()
#else
#define UI_FREE_DATA() uidbg_freedata()
#include <cstdint>

using uidbg_trace_func = void(*) ();
void uidbg_freedata() noexcept;
bool uidbg_breakpoint() noexcept;
auto uidbg_init_trace(uidbg_trace_func) noexcept->uint32_t;
void uidbg_goto_id(uint32_t id) noexcept;
void uidbg_trace(uint32_t id, const char* func, const char* msg) noexcept;

#define UI_TRACE_MSG(msg) {\
static uint32_t s_tid_ = uidbg_init_trace([] { uidbg_breakpoint(); });\
uidbg_trace(s_tid_, __FUNCTION__, msg);\
}
#endif

#define UI_TRACE UI_TRACE_MSG("-")


// longui::effect namespace
namespace LongUI { namespace Effect {
    // value index
    enum IndexBorderImage : uint32_t {
        BImage_Matrix,
        BImage_Draw,

        VERTEX_FULLCOUNT = 9 * (2 * 3),
        VERTEX_NOFILLCOUNT = 8 * (2 * 3),
    };
    // release common data
    void ReleaseBorderImage() noexcept;
    // register border image
    auto RegisterBorderImage(void* factory) noexcept->Result;
    // border image Zone Matrix
    struct BorderImageMatrix {
        // zone matrix: zone0 part
        RectF           zone0; // { 81, 81, 0.f, 0.f };
        // zone matrix: zone1 part
        RectF           zone1; // { 1280 - 81 - 81, 720 - 81 - 81, 0.3333f, 0.3333f };
        // zone matrix: zone2 part
        RectF           zone2; // { 81, 81, 0.6666f, 0.6666f };
        // zone matrix: zone3 part
        RectF           zone3; // { 1280, 720, 1.f, 1.f };
        // repeat
        RectF           repeat; // { 4, 3.5f, 2.1f, 1.5f };
    };
}}



namespace LongUI {
    /// <summary>
    /// drag event
    /// </summary>
    enum DragEvent {
        // drag enter on this control
        Event_DragEnter,
        // drag over on this control
        Event_DragOver,
        // drag leave on this control
        Event_DragLeave,
        // drop data
        Event_Drop,
    };
}

#include <cstdint>

namespace LongUI {
    // gui event, EventAccept: have no effect 
    struct ImplicitGroupGuiArg : EventArg {
        // group name
        const char* const group_name;
        // ctor
        ImplicitGroupGuiArg(const char* g) noexcept : group_name(g) {
            this->nevent = NoticeEvent::Event_ImplicitGroupChecked;
        }
    };
    // do ImplicitGroupGuiArg
    void DoImplicitGroupGuiArg(UIControl&, const char* group) noexcept;
}


namespace LongUI {
    // initialize event, EventAccept: have no effect 
    struct EventInitializeArg : EventArg {
        // ctor
        EventInitializeArg() noexcept { 
            this->nevent = NoticeEvent::Event_Initialize;
            this->derived = static_cast<uint32_t>(Result::RS_OK);
        }
        // set result
        void SetResult(Result hr) const noexcept {
            const auto code = static_cast<uint32_t>(hr.code);
            const_cast<uint32_t&>(this->derived) = code;
        }
        // get result
        auto GetResult() const noexcept -> Result { 
            return{ static_cast<int32_t>(this->derived) };
        }
    };
}

#include <cstdint>

namespace LongUI {
    // splitter event, EventAccept: have no effect 
    struct EventSplitterArg : EventArg {
        // offset x
        const float     offset_x;
        // offset y
        const float     offset_y;
        // ctor
        EventSplitterArg(float x, float y) noexcept:
            offset_x(x), offset_y(y) {
            nevent = NoticeEvent::Event_Splitter;
            derived = 0;
        }
    };
}
#include <cstdint>
#include <type_traits>


namespace LongUI {
    // file finding
    class CUIFindFile {
        // error handle
        enum : intptr_t { ERROR_HANDLE = -1 };
        // buffer size
        enum { buf_size = 592 };
        // buffer align
        enum { buf_align = 4 };
        // string type
        using string_t = const wchar_t*;
    public:
        // ctor: first file
        CUIFindFile(string_t first) noexcept;
        // dtor: first file
        ~CUIFindFile() noexcept;
        // ok? first file found?
        bool IsOk() const noexcept { return m_file != ERROR_HANDLE; }
        // find next
        bool FindNext() noexcept;
    public:
        // is directory?
        bool IsDirectory() const noexcept;
        // get file size, 32bit
        auto GetFileSize() const noexcept ->uint32_t;
        // get file name
        auto GetFileName() const noexcept ->string_t;
        // get file size, 64bit
        auto GetFileSize64() const noexcept ->uint64_t;
    protected:
        // file handle
        intptr_t                                        m_file;
        // buffer storage
        std::aligned_storage<buf_size, buf_align>::type m_impl;
    };
}
#include <cstdint>

// ui namespace
namespace LongUI {
    // path op namespace
    namespace PathOP {
        // canonical the path
        auto Canonical(char* buf) noexcept ->uint32_t;
        // base path length
        enum { FILEOP_MAX_PATH = 512 };
        // uri path
        struct UriPath { char path[FILEOP_MAX_PATH]; };
        // make uri path
        auto MakeUriPath(UriPath& buf, U8View prefix, U8View path) noexcept ->U8View;
        // base path
        struct BasePath { wchar_t path[FILEOP_MAX_PATH]; };
        // get temp path, return string length
        auto TempDirectoryPath(BasePath&) noexcept -> uint32_t;
        // get temp path, return string length
        auto TempDirectoryPath(CUIString&) noexcept->uint32_t;
        // get temp path, return tmp-id, <path>\<pre><uuuu>.tmp
        auto TempFileName(
            const wchar_t* path, 
            const wchar_t* prefix, 
            BasePath& filename
        ) noexcept->uint32_t;
    }
}

#include <cstdint>

// ui namespace
namespace LongUI { 
    // Graphics Adapter Desc
    struct GraphicsAdapterDesc {
        // shared memory
        size_t              shared_system;
        // dedicated video memory
        size_t              dedicated_video;
        // dedicated system memory
        size_t              dedicated_system;
        // friend name
        char16_t            friend_name[128];
    };
}

#include <cstdint>

// ui namespace
namespace LongUI {
    // interpolation mode
    enum InterpolationMode : uint8_t {
        // Nearest Neighbor
        Mode_NearestNeighbor    = 0,
        // Linear
        Mode_Linear             = 1,
        // Cubic
        Mode_Cubic              = 2,
        // Multi Sample Linear
        Mode_MultiSampleLinear  = 3,
        // Anisotropic
        Mode_Anisotropic        = 4,
        // High Quality Cubic
        Mode_HighQualityCubic   = 5,
        // Fant
        Mode_Fant               = 6,
        // MipmapLinear
        Mode_MipmapLinear       = 7
    };
}


// ui
#ifndef LUI_DISABLE_STYLE_SUPPORT

namespace LongUI {
    // image output
    struct IImageOutput;
    // border renderer
    class CUIRendererBorder : public CUISmallObject {
    public:
        // ctor
        CUIRendererBorder() noexcept;
        // dtor
        ~CUIRendererBorder() noexcept;
        // move ctor
        CUIRendererBorder(CUIRendererBorder&&) = delete;
        // copy ctor
        CUIRendererBorder(const CUIRendererBorder&) = delete;
        // before render
        void BeforeRender() noexcept;
        // render border
        void RenderBorder(const Box& box) const noexcept;
        // release device data
        void ReleaseDeviceData() noexcept;
        // create device data
        auto CreateDeviceData() noexcept->Result;
    public:
        // set image id
        void SetImageId(uint32_t ) noexcept;
        // set image repeat
        void SetImageRepeat(AttributeRepeat repeat) noexcept;
        // set image slice
        void SetImageSlice(const RectF&, bool fill) noexcept;
        // get image id
        auto GetImageId() const noexcept { return m_idImage; }
        // get image repeat
        auto GetImageRepeat() const noexcept { return m_repeat; }
        // get image slice
        bool GetImageSlice(RectF& output) const noexcept {
            output = m_rcSlice; return m_bSliceFill; }
    private:
        // calculate repeat
        void calculate_repeat(RectF& rect, const Box& box, Size2F size) const noexcept;
        // refresh image
        auto refresh_image() noexcept->Result;
        // release effect
        void release_effect() noexcept;
        // refresh real slice
        void refresh_real_slice() noexcept;
        // render default border
        void render_default_border(const Box& box) const noexcept;
        // ----------- CACHE-DATA -----------
        // size of image
        Size2F              m_szImage = {};
        // real slice rect
        RectF               m_rcRealSlice = { };
    private:
        // ------------- GPU-RES ------------
        // effect
        I::Effect*          m_pBorder = nullptr;
        // iamge output
        IImageOutput*       m_pOutput = nullptr;
    private:
        // ------------- CPU-RES ------------
        // rect for image slice
        RectF               m_rcSlice = {};
        // resource for image
        uint32_t            m_idImage = 0;
        // fill for image slice
        bool                m_bSliceFill = false;
        // [FLAG]image layout changed
        bool                m_bLayoutChanged = false;
        // repeat for image
        AttributeRepeat     m_repeat = Repeat_Stretch2;
    public:
        // style
        AttributeBStyle     style = Style_None;
        // border color
        ColorF              color = {};
        // radius x
        float               radius_x = 0.f;
        // radius y
        float               radius_y = 0.f;
    };
}
#endif

#ifndef LUI_DISABLE_STYLE_SUPPORT

namespace LongUI {
    // box
    struct Box;
    // background renderer
    class CUIRendererBackground : public CUISmallObject {
    public:
        // ctor
        CUIRendererBackground() noexcept;
        // dtor
        ~CUIRendererBackground() noexcept;
        // move ctor
        CUIRendererBackground(CUIRendererBackground&&) = delete;
        // copy ctor
        CUIRendererBackground(const CUIRendererBackground&) = delete;
        // render color
        void RenderColor(const Box& box, Size2F) const noexcept;
        // render image
        void RenderImage(const Box& box, Size2F) const noexcept;
        // refresh image
        auto RefreshImage() noexcept->Result;
        // create device data
        auto CreateDeviceData() noexcept->Result;
        // release device data
        void ReleaseDeviceData();
    private:
        // release brush
        void release_brush() noexcept;
        // ----------- CACHE-DATA -----------
        // image size
        Size2F              m_szImage = {};
        // ------------- GPU-RES ------------
        // image brush
        I::Brush*           m_pImageBrush = nullptr;
    public:
        // ------------- CPU-RES ------------
        // background-color
        ColorF              color;
        // background-size
        //Size2F              size;
        // background-image
        uint32_t            image_id = 0;
        // background-clip
        AttributeBox        clip = Box_BorderBox;
        // background-repeat
        AttributeRepeat     repeat = Repeat_Repeat;
        // background-origin 
        AttributeBox        origin = Box_PaddingBox;
        // background-attachment
        AttributeAttachment attachment = Attachment_Scroll;
    };
}
#endif


// longui::impl
namespace LongUI { namespace impl {
    // dcomp window buf
    struct dcomp_window_buf { void* buf[3]; };
    // init dcomp support[full support start at win8.1]
    void init_dcomp_support() noexcept;
    // check support for dcomp
    bool check_dcomp_support() noexcept;
    // uninit dcomp support
    void uninit_dcomp_support() noexcept;
    // init
    void init_dcomp(dcomp_window_buf&) noexcept;
    // create data
    auto create_dcomp(dcomp_window_buf&, HWND, I::Swapchan&) noexcept -> Result;
    // release
    void release_dcomp(dcomp_window_buf&) noexcept;
}}

// ui

// ui namespace
namespace LongUI {
    // native geometry
    namespace I { struct GeometryEx; }
    // geometry object
    class CUIGeometry final : public CUINoMo {
    public:
        // ctor
        CUIGeometry() noexcept {}
        // dtor
        ~CUIGeometry() noexcept { this->release(); }
        // steal from native interface
        auto StealFrom(I::Geometry* p) noexcept->Result;
        // draw render
        void Draw(I::Renderer2D&, I::Brush&, const Matrix3X2F&, float width) noexcept;
        // fill render
        void Fill(I::Renderer2D&, I::Brush&, const Matrix3X2F&) noexcept;
        // recreate_device
        auto Recreate() noexcept ->Result;
        // create from points
        static auto CreateFromPoints(CUIGeometry& obj, 
                                     const Point2F[], 
                                     uint32_t count) noexcept ->Result;
    private:
        // release
        void release() noexcept;
    private:
        // native interface - raw ptr
        I::Geometry*        m_pDawPtr = nullptr;
        // native interface - realization
        I::GeometryEx*      m_pRealization = nullptr;
    };
}

// ui

namespace LongUI {
    // fill rect with std brush
    void FillRectStdBrush(
        I::Renderer2D& renderer,
        I::Brush& brush,
        const RectF& rect,
        float opactiy
    ) noexcept;
}


// LongUI::Matrix namespace
namespace LongUI { namespace Matrix {
    // d2d matrix helper : rotate
    void MakeRotateMatrix(float angle, const Point2F& center, Matrix3X2F& matrix) noexcept;
    // d2d matrix helper : skew
    void MakeSkewMatrix(float x, float y, const Point2F&, Matrix3X2F&) noexcept;
    // Matrix3x2F
    struct Matrix3x2F : Matrix3X2F {
        // ctor
        inline Matrix3x2F(
            float m11, float m12, float m21, 
            float m22, float m31, float m32
        ) noexcept {
            this->_11 = m11; this->_12 = m12; this->_21 = m21;
            this->_22 = m22; this->_31 = m31; this->_32 = m32;
        }
        // ctor
        inline Matrix3x2F() noexcept {};
        // make a identity matrix
        static inline Matrix3x2F Identity() noexcept {
            Matrix3x2F identity;
            identity._11 = 1.; identity._12 = 0.;
            identity._21 = 0.; identity._22 = 1.;
            identity._31 = 0.; identity._32 = 0.;
            return identity;
        }
        // make a translation matrix
        static inline Matrix3x2F Translation(const Size2F& size) noexcept {
            Matrix3x2F translation;
            translation._11 = 1.0; translation._12 = 0.0;
            translation._21 = 0.0; translation._22 = 1.0;
            translation._31 = size.width; translation._32 = size.height;
            return translation;
        }
        // make a translation matrix - overload
        static inline Matrix3x2F Translation(float x, float y) noexcept {
            return Translation(Size2F{ x, y });
        }
        // make a scale matrix 
        static inline Matrix3x2F Scale(const Size2F& size, const Point2F& center = Point2F{0.}) noexcept {
            Matrix3x2F scale;
            scale._11 = size.width; scale._12 = 0.0;
            scale._21 = 0.0; scale._22 = size.height;
            scale._31 = center.x - size.width * center.x;
            scale._32 = center.y - size.height * center.y;
            return scale;
        }
        // make a scale matrix - overload
        static inline Matrix3x2F Scale(float x, float y, const Point2F& center = Point2F{0.}) noexcept {
            return Scale(Size2F{ x, y }, center);
        }
        // make a rotation matrix
        static inline Matrix3x2F Rotation(float angle, const Point2F& center = Point2F{0.}) noexcept {
            Matrix3x2F rotation;
            Matrix::MakeRotateMatrix(angle, center, rotation);
            return rotation;
        }
        // make a skew matrix
        static inline Matrix3x2F Skew(float angleX, float angleY, const Point2F& center = Point2F{0.}) noexcept {
            Matrix3x2F skew;
            Matrix::MakeSkewMatrix(angleX, angleY, center, skew);
            return skew;
        }
        // force cast - const overload
        static inline const Matrix3x2F* ReinterpretBaseType(const Matrix3X2F* pMatrix) noexcept  {
            return static_cast<const Matrix3x2F*>(pMatrix);
        }
        // force cast
        static inline Matrix3x2F* ReinterpretBaseType(Matrix3X2F* pMatrix) noexcept {
            return static_cast<Matrix3x2F*>(pMatrix);
        }
        // Determinant
        inline auto Determinant() const noexcept ->float {
            return (this->_11 * this->_22) - (this->_12 * this->_21);
        }
#if 0
        // is invertible?
        inline bool IsInvertible() const noexcept {
            return !!Dll::D2D1IsMatrixInvertible(this);
            //return !!DX::D2D1IsMatrixInvertible(this);
        }
        // Invert
        inline bool Invert() noexcept {
            return !!Dll::D2D1InvertMatrix(this);
            //return !!DX::D2D1InvertMatrix(this);
        }
#endif
        // is Identity?
        bool IsIdentity() const noexcept;
        // set the product
        void SetProduct(const Matrix3X2F& a, const Matrix3X2F& b) noexcept;
        // operator a*b
        inline Matrix3x2F operator*(const Matrix3X2F &matrix) const noexcept {
            Matrix3x2F result;
            result.SetProduct(*this, matrix);
            return result;
        }
        // Transform Point
        inline Point2F TransformPoint(const Point2F& point) const noexcept {
            Point2F result = {
                point.x * _11 + point.y * _21 + _31,
                point.x * _12 + point.y * _22 + _32
            };
            return result;
        }
    };
}}

// ui

// ui namespace
namespace LongUI {
    // native geometry
    namespace I { struct Mesh; }
    // 2d triangle
    struct TriangleF {
        // point 1-3
        Point2F     a, b, c;
    };
    // create mesh from triangles
    auto CreateMesh(I::Mesh*&, const TriangleF[], uint32_t len) noexcept->Result;
    // fill mesh
    void FillMesh(I::Mesh&, I::Renderer2D&, I::Brush&, const Matrix3X2F&) noexcept;
    // releash mesh
    void SafeReleaseMesh(I::Mesh*) noexcept;
}

/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// ui namespace
namespace LongUI {
    // input of ui for keyboard/mouse
    class CUIInputKM final {
    public:
        // mouse button index
        enum MB : uint32_t { 
            MB_L = 1 << 0, // Left-Button 
            MB_R = 1 << 1, // Right-Button
            MB_M = 1 << 2, // Middle-Buttom
            MB_X1= 1 << 3, // X1-Button
            MB_X2= 1 << 4, // X2-Button
        };
        // keyboard button index
        enum KB : uint32_t { 
            KB_BACK           = 0X08, // BACK
            KB_TAB            = 0X09, // TAB
            KB_CLEAR          = 0X0C, // CLEAR
            KB_RETURN         = 0X0D, // RETURN
            KB_SHIFT          = 0X10, // SHIFT
            KB_CONTROL        = 0X11, // CTRL
            KB_MENU           = 0X12, // MENU
            KB_PAUSE          = 0x13, 
            KB_CAPITAL        = 0x14, 
            KB_KANA           = 0x15, 
            KB_HANGUL         = 0x15, 
            KB_JUNJA          = 0x17, 
            KB_FINAL          = 0x18, 
            KB_HANJA          = 0x19, 
            KB_KANJI          = 0x19, 
            KB_ESCAPE         = 0x1B, 
            KB_CONVERT        = 0x1C, 
            KB_NONCONVERT     = 0x1D, 
            KB_ACCEPT         = 0x1E, 
            KB_MODECHANGE     = 0x1F, 
            KB_SPACE          = 0x20, 
            KB_PRIOR          = 0x21, 
            KB_NEXT           = 0x22, 
            KB_END            = 0x23, 
            KB_HOME           = 0x24, 
            KB_LEFT           = 0x25, 
            KB_UP             = 0x26, 
            KB_RIGHT          = 0x27, 
            KB_DOWN           = 0x28, 
            KB_SELECT         = 0x29, 
            KB_PRINT          = 0x2A, 
            KB_EXECUTE        = 0x2B, 
            KB_SNAPSHOT       = 0x2C, 
            KB_INSERT         = 0x2D, 
            KB_DELETE         = 0x2E, 
            KB_HELP           = 0x2F, 
            KB_A              = 'A',
            KB_B              = 'B',
            KB_C              = 'C',
            KB_D              = 'D',
            KB_E              = 'E',
            KB_F              = 'F',
            KB_G              = 'G',
            KB_H              = 'H',
            KB_I              = 'I',
            KB_J              = 'J',
            KB_K              = 'K',
            KB_L              = 'L',
            KB_M              = 'M',
            KB_N              = 'N',
            KB_O              = 'O',
            KB_P              = 'P',
            KB_Q              = 'Q',
            KB_R              = 'R',
            KB_S              = 'S',
            KB_T              = 'T',
            KB_U              = 'U',
            KB_V              = 'V',
            KB_W              = 'W',
            KB_X              = 'X',
            KB_Y              = 'Y',
            KB_Z              = 'Z',
#ifdef LUI_LRKEY_NOT_WORKING
            KB_LWIN           = 0x5B, 
            KB_RWIN           = 0x5C, 
#endif
            KB_APPS           = 0x5D, 
            KB_SLEEP          = 0x5F, 
            KB_NUMPAD0        = 0x60, 
            KB_NUMPAD1        = 0x61, 
            KB_NUMPAD2        = 0x62, 
            KB_NUMPAD3        = 0x63, 
            KB_NUMPAD4        = 0x64, 
            KB_NUMPAD5        = 0x65, 
            KB_NUMPAD6        = 0x66, 
            KB_NUMPAD7        = 0x67, 
            KB_NUMPAD8        = 0x68, 
            KB_NUMPAD9        = 0x69, 
            KB_MULTIPLY       = 0x6A, 
            KB_ADD            = 0x6B, 
            KB_SEPARATOR      = 0x6C, 
            KB_SUBTRACT       = 0x6D, 
            KB_DECIMAL        = 0x6E, 
            KB_DIVIDE         = 0x6F, 
            KB_F1             = 0x70, 
            KB_F2             = 0x71, 
            KB_F3             = 0x72, 
            KB_F4             = 0x73, 
            KB_F5             = 0x74, 
            KB_F6             = 0x75, 
            KB_F7             = 0x76, 
            KB_F8             = 0x77, 
            KB_F9             = 0x78, 
            KB_F10            = 0x79, 
            KB_F11            = 0x7A, 
            KB_F12            = 0x7B, 
            KB_F14            = 0x7D, 
            KB_F15            = 0x7E, 
            KB_F16            = 0x7F, 
            KB_F17            = 0x80, 
            KB_F18            = 0x81, 
            KB_F19            = 0x82, 
            KB_F20            = 0x83, 
            KB_F21            = 0x84, 
            KB_F22            = 0x85, 
            KB_F23            = 0x86, 
            KB_F24            = 0x87, 
            KB_NUMLOCK        = 0x90, 
            KB_SCROLL         = 0x91, 
            KB_OEM_NEC_EQUAL  = 0x92,    // '=' key on numpad
            KB_OEM_FJ_JISHO   = 0x92,    // 'Dictionary' key
            KB_OEM_FJ_MASSHOU = 0x93,    // 'Unregister word' key
            KB_OEM_FJ_TOUROKU = 0x94,    // 'Register word' key
            KB_OEM_FJ_LOYA    = 0x95,    // 'Left OYAYUBI' key
            KB_OEM_FJ_ROYA    = 0x96,    // 'Right OYAYUBI' key
#ifdef LUI_LRKEY_NOT_WORKING
            KB_LSHIFT         = 0xA0, 
            KB_RSHIFT         = 0xA1, 
            KB_LCONTROL       = 0xA2, 
            KB_RCONTROL       = 0xA3, 
            KB_LMENU          = 0xA4, 
            KB_RMENU          = 0xA5, 
#endif
            KB_BROWSER_BACK        = 0xA6, 
            KB_BROWSER_FORWARD     = 0xA7, 
            KB_BROWSER_REFRESH     = 0xA8, 
            KB_BROWSER_STOP        = 0xA9, 
            KB_BROWSER_SEARCH      = 0xAA, 
            KB_BROWSER_FAVORITES   = 0xAB, 
            KB_BROWSER_HOME        = 0xAC, 
            KB_VOLUME_MUTE         = 0xAD, 
            KB_VOLUME_DOWN         = 0xAE, 
            KB_VOLUME_UP           = 0xAF, 
            KB_MEDIA_NEXT_TRACK    = 0xB0, 
            KB_MEDIA_PREV_TRACK    = 0xB1, 
            KB_MEDIA_STOP          = 0xB2, 
            KB_MEDIA_PLAY_PAUSE    = 0xB3, 
            KB_LAUNCH_MAIL         = 0xB4, 
            KB_LAUNCH_MEDIA_SELECT = 0xB5, 
            KB_LAUNCH_APP1         = 0xB6, 
            KB_LAUNCH_APP2         = 0xB7, 
            KB_OEM_1          = 0xBA,    // ';:' for US
            KB_OEM_PLUS       = 0xBB,    // '+' any country
            KB_OEM_COMMA      = 0xBC,    // ',' any country
            KB_OEM_MINUS      = 0xBD,    // '-' any country
            KB_OEM_PERIOD     = 0xBE,    // '.' any country
            KB_OEM_2          = 0xBF,    // '/?' for US
            KB_OEM_3          = 0xC0,    // '`~' for US
            KB_OEM_AX         = 0xE1,   //  'AX' key on Japanese AX kbd
            KB_OEM_102        = 0xE2,   //  "<>" or "\|" on RT 102-key kbd.
            KB_ICO_HELP       = 0xE3,   //  Help key on ICO
            KB_ICO_00         = 0xE4,   //  00 key on ICO
            KB_OEM_RESET      = 0xE9, 
            KB_OEM_JUMP       = 0xEA, 
            KB_OEM_PA1        = 0xEB, 
            KB_OEM_PA2        = 0xEC, 
            KB_OEM_PA3        = 0xED, 
            KB_OEM_WSCTRL     = 0xEE, 
            KB_OEM_CUSEL      = 0xEF, 
            KB_OEM_ATTN       = 0xF0, 
            KB_OEM_FINISH     = 0xF1, 
            KB_OEM_COPY       = 0xF2, 
            KB_OEM_AUTO       = 0xF3, 
            KB_OEM_ENLW       = 0xF4, 
            KB_OEM_BACKTAB    = 0xF5, 
            KB_ATTN           = 0xF6, 
            KB_CRSEL          = 0xF7, 
            KB_EXSEL          = 0xF8, 
            KB_EREOF          = 0xF9, 
            KB_PLAY           = 0xFA, 
            KB_ZOOM           = 0xFB, 
            KB_NONAME         = 0xFC, 
            KB_PA1            = 0xFD, 
            KB_OEM_CLEAR      = 0xFE, 
        };
        // the buffer size of kerboard
        enum : uint32_t {  KEYBOARD_BUFFER_SIZE = 256 } ;
    private:
        // mouse button index
        enum MBI : uint32_t {
            MBI_ThisFrame= 0,   // this frame data
            MBI_LastFrame,      // last frame data
            MBI_SIZE            // buffer count
        };
    public:
        // get instance
        static auto Instance() noexcept->CUIInputKM&;
        // get key state
        static bool GetKeyState(KB) noexcept;
#ifdef LUI_RAWINPUT
        // ctor
        CUIInputKM() noexcept;
        // clear mouse state
        void ClearMouseState() noexcept { 
            m_bufMButton[MBI_ThisFrame] = 0; 
            m_bufMButton[MBI_LastFrame] = 0; 
        }
        // init with tool window
        auto Init(HWND) noexcept ->Result;
        // get mouse position
        auto GetMousePosition() const noexcept { return m_ptMouse; };
        // get mouse position/long
        auto GetMousePositionL() const noexcept { return m_ptMouseL; };
        // is mouse button pressed?
        auto IsMbPressed(MB b) const noexcept { return !!(m_bufMButton[MBI_ThisFrame] & b); }
        // is mouse button down?
        auto IsMbDown(MB b) const noexcept { return (m_bufMButton[MBI_ThisFrame] & b) != 0 && (m_bufMButton[MBI_LastFrame] & b) == 0; }
        // is mouse button up?
        auto IsMbUp(MB b) const noexcept { return (m_bufMButton[MBI_ThisFrame] & b) == 0 && (m_bufMButton[MBI_LastFrame] & b) != 0; }
        // is keyboard pressed?
        auto IsKbPressed(KB b) const noexcept { return m_pKeyState[b]; }
        // is keyboard down?
        auto IsKbDown(KB b) const noexcept { return m_pKeyState[b] && m_pKeyStateOld[b] == 0; }
        // is keyboard down?
        auto IsKbUp(KB b) const noexcept { return m_pKeyState[b] == 0 && m_pKeyStateOld[b] != 0;  }
    public:
        // update, impl @ UIUtil.cpp
        void AfterUpdate() noexcept;
        // update with HRAWINPUT
        void Update(HRAWINPUT) noexcept;
    protected:
        // mouse postion
        Point2F         m_ptMouse{0.f, 0.f};
        // mouse postion
        Point2L         m_ptMouseL{0, 0};
        // mouse button buffer
        char            m_bufMButton[MBI_SIZE];
        // unused
        char            m_unused_u8x6[MBI_SIZE * 3];
        // KeyState for this frame
        bool*           m_pKeyState = m_abKeyStateBuffer;
        // KeyState for last frame
        bool*           m_pKeyStateOld = m_abKeyStateBuffer + KEYBOARD_BUFFER_SIZE;
        // key state buffer
        bool            m_abKeyStateBuffer[KEYBOARD_BUFFER_SIZE * 2] = {0};
#endif
    };
}


// VECTOR

// ui namespace
namespace LongUI {
    // control info list
    struct ControlInfoList : POD::Vector<const MetaControl*> {};
}
/**
* Copyright (c) 2014-2016 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

// interfaces
// core type

// ui namespace
namespace LongUI {
    // CUIDefaultConfigure, default impl for IUIConfigure
    class CUIDefaultConfigure : public IUIConfigure {
    public:
        // ctor
        CUIDefaultConfigure() noexcept = default;
        // dtor
        ~CUIDefaultConfigure() noexcept = default;
    public:
#ifndef NDEBUG
        // get logfile name
        auto GetSimpleLogFileName() noexcept->CUIString override;
#endif
        // Get string from table
        //virtual auto GetString(TableString tbl) noexcept -> const wchar_t*;
        // get locale name of ui(for text)
        void GetLocaleName(char16_t name[/*LOCALE_NAME_MAX_LENGTH*/]) noexcept override;
        // get default font arg
        void DefaultFontArg(FontArg& arg) noexcept override;
        // add all controls
        void RegisterControl(ControlInfoList& list) noexcept override;
        // if use gpu render, you should choose a video card, return the index
        auto ChooseAdapter(const GraphicsAdapterDesc adapters[], const uint32_t length) noexcept ->uint32_t override;
        // load data from url on file not found
        void LoadDataFromUrl(U8View url_in_utf8, const CUIString& url_in_utf16, POD::Vector<uint8_t>& buffer) noexcept override;
        // show the error string
        void OnError(ErrorInfo info) noexcept override;
    public:
        // run a section script for event
        bool Evaluation(ScriptUI, UIControl&) noexcept override;
        // alloc the script memory and copy into(may be compiled into byte code)
        auto AllocScript(U8View) noexcept->ScriptUI override;
        // free the script memory
        void FreeScript(ScriptUI) noexcept override;
        // eval script for window init
        void Evaluation(U8View, CUIWindow&) noexcept override;
        // finalize window script if has script
        void FinalizeScript(CUIWindow&) noexcept override;
    public:
        // alloc for normal space
        void*NormalAlloc(size_t length) noexcept override;
        // free for normal space
        void NormalFree(void* address) noexcept override;
        // realloc for normal space
        void*NormalRealloc(void* address, size_t length) noexcept override;
        // alloc for small space
        void*SmallAlloc(size_t length) noexcept override;
        // free for small space
        void SmallFree(void* address) noexcept override;
    public:
        // Begins the render thread.
        auto BeginRenderThread() noexcept ->Result override;
        // Ends the render thread.
        void EndRenderThread() noexcept override;
        // Recursions the MSG loop.
        auto RecursionMsgLoop() noexcept ->uintptr_t override;
        // break msg-loop
        void BreakMsgLoop(uintptr_t) noexcept override;
    private:
        // render thread handle
        uintptr_t               m_hRenderThread = 0;
        // exit flag
        bool                    m_bExitFlag = false;
    };
}



// ui

// c++
#include <cstdint>
#include <cassert>

// ui namespace
namespace LongUI {
    // rgba
    union RGBA;
    // Shared Image
    class CUIImage : public CUISharedResource {
    protected:
        // private ctor
        CUIImage(I::Bitmap& bmp) noexcept : m_bitmap(&bmp) { assert(m_bitmap); }
        // private dtor
        inline ~CUIImage() noexcept;
    public:
        // destroy object
        void Destroy() noexcept override;
        // create image
        static auto CreateImage(
            I::Bitmap& bmp,
            CUISharedResource*& ptr
        ) noexcept->Result;
        // make error bitmap
        static auto MakeError(I::Bitmap&) noexcept->Result;
    public:
        // get size
        auto GetSize() const noexcept { return m_size; }
        // get bitmap
        auto&RefBitmap() const noexcept { return *m_bitmap; }
        // recreate bitmap
        void RecreateBitmap(I::Bitmap&) noexcept;
    public:
        // render
        void Render(
            I::Renderer2D& renderer,
            const RectF* des_rect = nullptr,
            const RectF* src_rect = nullptr,
            float opacity = 1.f,
            InterpolationMode mode = Mode_Linear
        ) const noexcept;
    private:
        // bitmap data
        I::Bitmap*          m_bitmap;
        // size of bitmap
        Size2U              m_size;
    };
}


// ui namespace
namespace LongUI {
    // color
    struct ColorF;
    // draw args
    struct NativeDrawArgs {
        // border edge rect
        RectF               border;
        // state from
        StyleState          from;
        // state to(vaild if progress > 0)
        StyleState          to;
        // progress
        float               progress;
        // type
        AttributeAppearance appearance;
    };
    // get duration args
    struct GetDurationArgs {
        // type
        AttributeAppearance appearance;
    };
    // control class
    // sub element type
    /*enum class SubElement : uint8_t {

    };*/
    // adjust sub element rect in native style
    //void NativeStyleAdjustSubElement(SubElement sube, RectF& rect) noexcept;
    // draw native style
    void NativeStyleDraw(const NativeDrawArgs& args) noexcept;
    // init native style
    void NativeStyleInit(UIControl& ctrl, AttributeAppearance) noexcept;
    // get animation dur
    auto NativeStyleDuration(const GetDurationArgs) noexcept -> uint32_t;
    // get foreground color if changed
    auto NativeFgColor(StyleState now) noexcept->uint32_t;
    // get foreground color if exist
    //bool NativeStyleGetForeground(const NativeDrawArgs& args, ColorF&) noexcept;
}


namespace LongUI {
    /// <summary>
    /// atring attribute table
    /// </summary>
    struct StrAttr {

    };
}

#include <cstdint>

// virtual dtor
#define FIBER_DTOR_TYPE virtual

#ifdef LUI_FIBER
namespace LongUI {
    // fiber
    class CUIFiber;
    // lambda fiber
    template<typename T> class CUILambdaFiber;
    /// <summary>
    /// main fiber class, one main fiber in one thread
    /// </summary>
    class CUIMainFiber {
        // self type
        using Self = CUIMainFiber;
        // friend class
        friend CUIFiber;
    public:
        // ctor, create one for one thread
        CUIMainFiber() noexcept;
        // dtor
        ~CUIMainFiber() noexcept;
        // create fiber with class, default stack-size is 1M, you can set as small as possible
        template<class T> auto CreateFiber(size_t stack = 0/*alignas 4k*/) noexcept ->T {
            return{ stack, m_fiber };
        }
        // create fiber with lambda
        template<class T> auto CreateFiber(T, size_t stack = 0) noexcept->CUILambdaFiber<T>;
    public:
        // no copy ctor
        CUIMainFiber(const Self&) = delete;
        // no copy assgin
        Self&operator=(const Self&) = delete;
        // no move ctor?
        CUIMainFiber(Self&&) = delete;
        // no move assgin?
        Self&operator=(Self&&) = delete;
    private:
        // fiber pointer
        void*           m_fiber;
    };
    /// <summary>
    /// fiber class
    /// </summary>
    class CUIFiber {
        // self type
        using Self = CUIFiber;
        // friend class
        friend CUIMainFiber;
        // run fiber
        virtual void run() noexcept = 0;
    protected:
        // ctor
        CUIFiber(size_t stack, void* main) noexcept;
        // yield, switch to main
        void yield() noexcept { return switch_to(m_main); }
        // get fiber data
        static void* get_fibder_data() noexcept;
    public:
        // dtor
        FIBER_DTOR_TYPE ~CUIFiber() noexcept;
        // is ok?
        bool IsOK() const noexcept { return !!m_fiber; }
        // switch to this
        void Resume() noexcept { return switch_to(m_fiber); }
        // yield
        static void FiberYield() noexcept;
    public:
        // move ctor
        CUIFiber(Self&& x) noexcept : m_main(x.m_main), m_fiber(x.m_fiber) { x.m_fiber = nullptr; }
        // no copy ctor
        CUIFiber(const Self&) = delete;
        // no copy assgin
        Self&operator=(const Self&) = delete;
        // no move assgin?
        Self&operator=(Self&&) = delete;
    private:
        // switch to fiber
        static void switch_to(void* ptr) noexcept;
        // switch to fiber with arg
        static auto switch_to(void* ptr, intptr_t arg) noexcept->intptr_t;
        // main fiber
        void*           m_main;
        // fiber pointer
        void*           m_fiber;
#ifndef NDEBUG
        // debug flag
        bool            m_released = true;
#endif
    };
    template<typename T>
    class CUILambdaFiber : public CUIFiber {
        // friend class
        friend CUIMainFiber;
        // ctor
        CUILambdaFiber(size_t stack, void* main, T call) noexcept
            : CUIFiber(stack, main), m_lambda(call) {}
        // run fiber
        void run() noexcept override { m_lambda(); }
        // lambda
        T           m_lambda;
    };
    /// <summary>
    /// Creates the fiber.
    /// </summary>
    /// <param name="">The .</param>
    /// <returns></returns>
    template<class T>
    auto CUIMainFiber::CreateFiber(T call, size_t stack) noexcept -> CUILambdaFiber<T> {
        const auto ptr = CUIFiber::get_fibder_data();
        return CUILambdaFiber<T>{stack, m_fiber, call};
    }
    // helper func
    inline void fiber_yield() noexcept { CUIFiber::FiberYield(); }
}

// into top namespace
using LongUI::fiber_yield;
#endif
#include <type_traits>


// ui namespace
namespace LongUI {
    // detail namespace
    namespace detail {
        // impl
        template<size_t> struct rwlocker_impl_info {};
        // impl for 32 bit
        template<> struct rwlocker_impl_info<4> { enum { size = 4, align = 4 }; };
        // impl for 64 bit
        template<> struct rwlocker_impl_info<8> { enum { size = 8, align = 8 }; };
    }
    // read-write locker, couldn't be used in "Recursive Calls"
    class CUIRWLocker {
        // buffer size
        enum { buf_size = detail::rwlocker_impl_info<sizeof(void*)>::size };
        // buffer align
        enum { buf_align = detail::rwlocker_impl_info<sizeof(void*)>::align };
    public:
        // ctor
        CUIRWLocker() noexcept;
        // dtor
        ~CUIRWLocker() noexcept;
        // reader-lock
        void ReaderLock() noexcept;
        // writer-lock
        void WriterLock() noexcept;
        // reader-unlock
        void ReaderUnlock() noexcept;
        // writer-unlock
        void WriterUnlock() noexcept;
    public:
        // cannot be moved
        CUIRWLocker(CUIRWLocker&&) noexcept = delete;
        // cannot be copied
        CUIRWLocker(const CUIRWLocker&) noexcept = delete;
        // cannot be operator= moved
        auto operator=(CUIRWLocker&&) noexcept->CUIRWLocker& = delete;
        // cannot be operator= copied
        auto operator=(const CUIRWLocker&) noexcept->CUIRWLocker& = delete;
    protected:
        // buffer storage
        std::aligned_storage<buf_size, buf_align>::type m_impl;
    };
    // auto writer locker
    class CUIAutoWriterLocker {
    public:
        // ctor
        CUIAutoWriterLocker(CUIRWLocker& l) noexcept : m_locker(l) { l.WriterLock(); }
        // dtor
        ~CUIAutoWriterLocker() noexcept { m_locker.WriterUnlock(); }
    protected:
        // locker
        CUIRWLocker&        m_locker;
    };
    // auto reader locker
    class CUIAutoReaderLocker {
    public:
        // ctor
        CUIAutoReaderLocker(CUIRWLocker& l) noexcept : m_locker(l) { l.ReaderLock(); }
        // dtor
        ~CUIAutoReaderLocker() noexcept { m_locker.ReaderUnlock(); }
    protected:
        // locker
        CUIRWLocker&        m_locker;
    };
}

// c++
#include <cstdint>
// ui

// ui namespace
namespace LongUI {
    // the type of aniamtion
    enum AnimationType : uint8_t {
        Type_LinearInterpolation = 0,   // 线性插值
        Type_QuadraticEaseIn,           // 平方渐入插值
        Type_QuadraticEaseOut,          // 平方渐出插值
        Type_QuadraticEaseInOut,        // 平方渐入渐出插值
        Type_CubicEaseIn,               // 立方渐入插值
        Type_CubicEaseOut,              // 立方渐出插值
        Type_CubicEaseInOut,            // 立方渐入渐出插值
        Type_QuarticEaseIn,             // 四次渐入插值
        Type_QuarticEaseOut,            // 四次渐出插值
        Type_QuarticEaseInOut,          // 四次渐入渐出插值
        Type_QuinticEaseIn,             // 五次渐入插值
        Type_QuinticEaseOut,            // 五次渐出插值
        Type_QuinticEaseInOut,          // 五次渐入渐出插值
        Type_SineEaseIn,                // 正弦渐入插值
        Type_SineEaseOut,               // 正弦渐出插值
        Type_SineEaseInOut,             // 正弦渐入渐出插值
        Type_CircularEaseIn,            // 四象圆弧插值
        Type_CircularEaseOut,           // 二象圆弧插值
        Type_CircularEaseInOut,         // 圆弧渐入渐出插值
        Type_ExponentialEaseIn,         // 指数渐入插值
        Type_ExponentialEaseOut,        // 指数渐出插值
        Type_ExponentialEaseInOut,      // 指数渐入渐出插值
        Type_ElasticEaseIn,             // 弹性渐入插值
        Type_ElasticEaseOut,            // 弹性渐出插值
        Type_ElasticEaseInOut,          // 弹性渐入渐出插值
        Type_BackEaseIn,                // 回退渐入插值
        Type_BackEaseOut,               // 回退渐出插值
        Type_BackEaseInOut,             // 回退渐出渐出插值
        Type_BounceEaseIn,              // 反弹渐入插值
        Type_BounceEaseOut,             // 反弹渐出插值
        Type_BounceEaseInOut,           // 反弹渐入渐出插值
    };
    // easing function
    auto EasingFunction(AnimationType type, float x) noexcept -> float;
    // cubic bezier
    //auto CubicBezierEx(float t, uint32_t arg) noexcept ->float;
    // control class
    class UIControl;
#ifndef LUI_DISABLE_STYLE_SUPPORT
    // ssvalue2
    struct SSFromTo {
        // from
        SSValue     from;
        // to
        SSValue     to;
    };
    // indeterminate value
    auto IndeterminateValue(const SSFromTo&, float) noexcept->SSValue;
#ifdef NDEBUG
    enum { EXTRA_FROM_TO_LIST_LENGTH = 8 };
#else
    enum { EXTRA_FROM_TO_LIST_LENGTH = 4 };
#endif
    // extra control animation
    struct ControlAnimationExtra {
        // control pointer
        UIControl*          ctrl;
        // target state time done(unit: ms)
        uint16_t            done;
        // target state duration(unit: ms)
        uint16_t            duration;
        // changed list length
        uint32_t            length;
        // value list
        SSFromTo            list[EXTRA_FROM_TO_LIST_LENGTH];
        // get rate
        auto GetRate() const noexcept { return float(done) / float(duration); }
    };
#endif
    // basic control animation
    struct ControlAnimationBasic {
        // control
        UIControl*          ctrl;
        // origin state
        StyleState          origin;
        // target state time done(unit: ms)
        uint16_t            done;
        // target state duration(unit: ms)
        uint16_t            duration;
        // fg color from
        uint32_t            fgcolor1;
        // fg color to
        uint32_t            fgcolor2;
        // get rate
        auto GetRate() const noexcept { return float(done) / float(duration); }
    };
}


// ui namespace
namespace LongUI {
    // copy text to clipboard
    bool CopyTextToClipboard(U16View view) noexcept;
    // paste text from clipboard
    bool PasteTextToClipboard(CUIString& str) noexcept;
}

// ui
namespace LongUI {
    // colorsystem
    namespace ColorSystem {
        // CSs
        struct RGBA; struct HSVA; struct HSLA;
        // RGBA
        struct RGBA { 
            // rgba data
            float r, g, b, a; 
            // to colorf
            operator ColorF&() noexcept { 
                return reinterpret_cast<ColorF&>(*this); 
            }
            // to const colorf
            operator const ColorF&() const noexcept { 
                return reinterpret_cast<const ColorF&>(*this); 
            }
            // to HSLA
            //HSLA toHSLA() const noexcept;
            // to HSVA
            //HSVA toHSVA() const noexcept;
        };
        // HSVA(0~360, 0~1, 0~1, 0~1)
        //struct HSVA { 
        //    // hsva data
        //    float h, s, v, a;
        //    // to HSLA
        //    HSLA toHSLA() const noexcept;
        //    // to RGBA
        //    RGBA toRGBA() const noexcept;
        //};
        // HSLA(0~360, 0~1, 0~1, 0~1)
        struct HSLA { 
            // hsla data
            float h, s, l, a;
            // to RGBA
            RGBA toRGBA() const noexcept;
            // to HSVA
            //HSVA toHSVA() const noexcept;
        };
    }
    // CS
    namespace CS = ColorSystem;
}
#include <cstdint>

namespace LongUI {
    // get ms tick
    auto GetTimeTick() noexcept->uint32_t;
    // get system double click time
    auto GetDoubleClickTime() noexcept->uint32_t;
    // the time-meter - high
    class CUITimeMeterH {
    public:
        // QueryPerformanceFrequency
        static void QueryPerformanceFrequency(uint64_t& ll) noexcept;
        // QueryPerformanceCounter
        static void QueryPerformanceCounter(uint64_t& ll) noexcept;
        // refresh the frequency
        void inline RefreshFrequency() noexcept { QueryPerformanceFrequency(m_cpuFrequency); }
        // start timer
        void inline Start() noexcept { QueryPerformanceCounter(m_cpuCounterStart); }
        // move end var to start var
        void inline MovStartEnd() noexcept { m_cpuCounterStart = m_cpuCounterEnd; }
        // delta time in sec.
        template<typename T> auto inline Delta_s() noexcept {
            CUITimeMeterH::QueryPerformanceCounter(m_cpuCounterEnd);
            return static_cast<T>(m_cpuCounterEnd - m_cpuCounterStart) / static_cast<T>(m_cpuFrequency);
        }
        // delta time in ms.
        template<typename T> auto inline Delta_ms() noexcept {
            CUITimeMeterH::QueryPerformanceCounter(m_cpuCounterEnd);
            return static_cast<T>(m_cpuCounterEnd - m_cpuCounterStart)*static_cast<T>(1e3) / static_cast<T>(m_cpuFrequency);
        }
        // delta time in micro sec.
        template<typename T> auto inline Delta_mcs() noexcept {
            CUITimeMeterH::QueryPerformanceCounter(m_cpuCounterEnd);
            return static_cast<T>(m_cpuCounterEnd - m_cpuCounterStart)*static_cast<T>(1e6) / static_cast<T>(m_cpuFrequency);
        }
    private:
        // CPU freq
        uint64_t            m_cpuFrequency;
        // CPU start counter
        uint64_t            m_cpuCounterStart = 0u;
        // CPU end counter
        uint64_t            m_cpuCounterEnd = 0u;
    public:
        // ctor
        CUITimeMeterH() noexcept { RefreshFrequency(); }
    };
    // the time-meter : medium
    class CUITimeMeterM {
    public:
        // refresh the frequency
        auto inline RefreshFrequency() noexcept { }
        // start timer
        auto inline Start() noexcept { m_dwStart = LongUI::GetTimeTick(); }
        // move end var to start var
        auto inline MovStartEnd() noexcept { m_dwStart = m_dwNow; }
        // delta time in sec.
        template<typename T> auto inline Delta_s() noexcept {
            m_dwNow = LongUI::GetTimeTick();
            return static_cast<T>(m_dwNow - m_dwStart) * static_cast<T>(0.001);
        }
        // delta time in ms.
        template<typename T> auto inline Delta_ms() noexcept {
            m_dwNow = LongUI::GetTimeTick();
            return static_cast<T>(m_dwNow - m_dwStart);
        }
        // delta time in micro sec.
        template<typename T> auto inline Delta_mcs() noexcept {
            m_dwNow = LongUI::GetTimeTick();
            return static_cast<T>(m_dwNow - m_dwStart) * static_cast<T>(1000);
        }
    private:
        // start time
        uint32_t                   m_dwStart = 0;
        // now time
        uint32_t                   m_dwNow = 0;
    public:
        // ctor
        CUITimeMeterM() noexcept { this->Start(); }
    };
    // time-meter for ui
    using CUITimeMeter = CUITimeMeterM;
}

namespace LongUI {
    // double click helper
    class CUIDbClick {
    public:
        // ctor
        CUIDbClick(uint32_t dur = LongUI::GetDoubleClickTime()) noexcept 
         : m_dwDbClickDur(dur) {}
        // dtor
        ~CUIDbClick() noexcept {}
        // no copy ctor
        CUIDbClick(const CUIDbClick&) noexcept = delete;
        // click, return ture if db-clicked
        bool Click() noexcept;
    protected:
        // time dur
        uint32_t        m_dwDbClickDur;
        // time pt
        uint32_t        m_dwDbClickPt = 0;
    };
    // double click helper - point support
    class CUIDbClickEx : public CUIDbClick {
    public:
        // ctor
        CUIDbClickEx(uint32_t dur) noexcept : CUIDbClick(dur) {}
        // ctor
        CUIDbClickEx() noexcept : CUIDbClick() {}
        // click, return ture if db-clicked
        bool Click(int32_t x, int32_t y) noexcept;
        // click, return ture if db-clicked
        bool Click(float x, float y) noexcept { 
            static_assert(sizeof(int32_t) == sizeof(float), "must be same");
            return Click(
                reinterpret_cast<const int32_t&>(x),
                reinterpret_cast<const int32_t&>(y)
            );
        }
    private:
        // point x
        int32_t           m_x = 0;
        // point y
        int32_t           m_y = 0;
    };
}
#include <utility>

namespace LongUI { namespace detail {
    // struct: unicall_funcptr_t
    template<typename Result, typename... Args>
    struct unicall_funcptr_t {
        Result(UNICALL* ptr)(Args...) noexcept;
    };
    // struct unicall_funcptr_helper
    template<typename T, typename Result, typename... Args>
    struct unicall_funcptr_helper {
        static Result UNICALL call(Args... args) noexcept {
            T lambda{ *static_cast<T*>(nullptr) };
            return lambda(std::forward<Args>(args)...);
        }
    };
    // function get_unicall_funcptr
    template<typename Result, typename... Args, typename T>
    inline auto get_unicall_funcptr(T) noexcept ->unicall_funcptr_t<Result, Args...> {
        unicall_funcptr_t<Result, Args...> rv;
        rv.ptr = unicall_funcptr_helper<T, Result, Args...>::call;
        return rv;
    }
}}

// c++
#include <algorithm>

// ui namespace
namespace LongUI { 
    // [begin, end-1) already be sorted
    template<typename T, typename U>
    void LastSort(T begin, T end, U comp) noexcept {
        if (end - begin < 2) return;
        for (auto itr = end - 1; itr != begin; --itr) {
            if (comp(itr[-1], itr[0])) break;
            std::swap(itr[-1], itr[0]);
        }
    }
    // remove begin to end
    template<typename T>
    void Remove(T begin, T end) noexcept {
        for (auto itr = begin; itr < end - 1; ++itr) {
            std::swap(itr[0], itr[1]);
        }
    }
}



// longui::detail namespace
namespace LongUI { namespace detail {
    // clamp for float
    inline auto clamp(float d, float min, float max) noexcept {
        const float t = d < min ? min : d;
        return t > max ? max : t;
    }
    // get percent value
    inline auto get_percent_value(float f) noexcept { return f * 1e3f; }
    // is percent value?
    inline auto is_percent_value(float f) noexcept { return f > -1.f && f < 1.f; }
    // make percent value from 1.00
    inline auto mark_percent_from1(float f) noexcept { return f * 1e-3f; }
    // make percent value from 100%
    inline auto mark_percent_from100(float f) noexcept { return f * 1e-5f; }
    // make percent value from int 10000
    inline auto mark_percent_from10000(float f) noexcept { return f * 1e-7f; }
}}
#include <cstdint>

namespace LongUI {
    // system time
    struct SystemTime;
    // file time
    struct FileTime {
        // time
        uint64_t        time;
        // to system time
        bool ToSystemTime(SystemTime& time) const noexcept;
    };
    // system time
    struct SystemTime {
        // from system time
        static void FromSystemTime(SystemTime& st) noexcept;
        // from system time
        static auto FromSystemTime() noexcept ->SystemTime {
            SystemTime st; FromSystemTime(st); return st;
        }
        // year
        uint16_t        year;
        // month
        uint16_t        month;
        // day of week
        uint16_t        day_of_week;
        // day
        uint16_t        day;
        // hour
        uint16_t        wHour;
        // minute
        uint16_t        minute;
        // second
        uint16_t        second;
        // ms
        uint16_t        milliseconds;
        // to file time
        bool ToFileTime(FileTime&) const noexcept;
    };
}
#include <cstdint>


namespace LongUI {
    /// <summary>
    /// unicode namespace
    /// </summary>
    namespace Unicode {
        // swap big/little endian
        inline void SwapEndian(char*, char*) noexcept {}
        // swap big/little endian
        void SwapEndian(char16_t* begin, char16_t* end) noexcept;
        // swap big/little endian
        void SwapEndian(char32_t* begin, char32_t* end) noexcept;
        // get buffer length within null char
        template<typename DST, typename SRC>
        auto GetBufferLength(const SRC str[]) noexcept->uint32_t;
        // get buffer length without null char
        template<typename DST, typename SRC>
        auto GetBufferLength(PodStringView<SRC>) noexcept->uint32_t;
        // convert to within null char
        template<typename DST, typename SRC>
        auto To(typename DST::type buf[], uint32_t buflen, const SRC str[]) noexcept->uint32_t;
        // convert to without null char
        template<typename DST, typename SRC>
        auto To(typename DST::type buf[], uint32_t buflen, PodStringView<SRC>) noexcept->uint32_t;
        // ---------------------------------------
        // utf16 -> utf-8
        template<> auto GetBufferLength<UTF8>(const char16_t str[]) noexcept->uint32_t;
        // utf16 -> utf-8
        template<> auto GetBufferLength<UTF8>(PodStringView<char16_t>) noexcept->uint32_t;
        // utf-8 -> utf16
        template<> auto GetBufferLength<UTF16>(const char str[]) noexcept->uint32_t;
        // utf-8 -> utf16
        template<> auto GetBufferLength<UTF16>(PodStringView<char>) noexcept->uint32_t;
        // utf16 -> utf-8
        template<> auto To<UTF8>(char buf[], uint32_t buflen, const char16_t str[]) noexcept->uint32_t;
        // utf16 -> utf-8
        template<> auto To<UTF8>(char buf[], uint32_t buflen, PodStringView<char16_t>) noexcept->uint32_t;
        //  utf-8 -> utf16
        template<> auto To<UTF16>(char16_t buf[], uint32_t buflen, const char str[]) noexcept->uint32_t;
        //  utf-8 -> utf16
        template<> auto To<UTF16>(char16_t buf[], uint32_t buflen, PodStringView<char>) noexcept->uint32_t;
    }
}

// UI  wchar sp
namespace LongUI {
    namespace Unicode {
        // wchar -> utf-8
        template<> inline auto GetBufferLength<UTF8>(const wchar_t str[]) noexcept->uint32_t {
            using type = typename WChar::same::type;
            return GetBufferLength<UTF8>(reinterpret_cast<const type*>(str));
        }
        // wchar -> utf-8
        template<> inline auto GetBufferLength<UTF8>(PodStringView<wchar_t> v) noexcept->uint32_t {
            using type = typename WChar::same::type;
            return GetBufferLength<UTF8>(PodStringView<type>{
                reinterpret_cast<const type*>(v.first),
                    reinterpret_cast<const type*>(v.second)
            });
        }
        // utf-8 -> wchar
        template<> inline auto GetBufferLength<WChar>(const char str[]) noexcept->uint32_t {
            using type = typename WChar::same;
            return GetBufferLength<type>(str);
        }
        // utf-8 -> wchar
        template<> inline auto GetBufferLength<WChar>(PodStringView<char> v) noexcept->uint32_t {
            using type = typename WChar::same;
            return GetBufferLength<type>(v);
        }

        // utf16 -> utf-8
        template<> inline auto To<UTF8>(char buf[], uint32_t buflen, const wchar_t str[]) noexcept->uint32_t {
            using type = typename WChar::same::type;
            return To<UTF8>(buf, buflen, reinterpret_cast<const type*>(str));
        }
        // utf16 -> utf-8
        template<> inline auto To<UTF8>(char buf[], uint32_t buflen, PodStringView<wchar_t> v) noexcept->uint32_t {
            using type = typename WChar::same::type;
            return To<UTF8>(buf, buflen, PodStringView<type>{
                reinterpret_cast<const type*>(v.first),
                    reinterpret_cast<const type*>(v.second)
            });
        }
        //  utf-8 -> utf16
        template<> inline auto To<WChar>(wchar_t buf[], uint32_t buflen, const char str[]) noexcept->uint32_t {
            using type = typename WChar::same;
            return To<type>(reinterpret_cast<type::type*>(buf), buflen, str);
        }
        //  utf-8 -> utf16
        template<> inline auto To<WChar>(wchar_t buf[], uint32_t buflen, PodStringView<char> v) noexcept->uint32_t {
            using type = typename WChar::same;
            return To<type>(reinterpret_cast<type::type*>(buf), buflen, v);
        }
    }
}


#include <cstdint>

// attribute selector? obj[attr="sb"]
//#define SAC_ATTRIBUTE_SELECTOR
// pure virtual ?
#define SAC_PURE_VIRTUAL


// simpac namespace
namespace SimpAC {
    // char type, utf-8 as default
    using Char = char; // wchar_t char16_t char32_t
    // string pair
    struct StrPair {
        // pair
        const Char* first, *second;
        // begin
        auto begin() const noexcept { return first; }
        // end
        auto end() const noexcept { return second; }
    };
    // func type
    enum FuncType : uint16_t;
    // func value
    struct alignas(void*) FuncValue {
        // string begin pointer
        const Char*     first;
        // string length max in 65,535
        uint16_t        length;
        // type of func
        FuncType        func;
    };
    // split unit
    auto SplitUnit(StrPair& pair) noexcept->StrPair;
    // Combinators
    enum Combinators : uint32_t;
    // Combinators
    enum BasicSelectors : uint32_t;
#ifndef LUI_DISABLE_STYLE_SUPPORT
    // pure virtual ?
#ifdef SAC_PURE_VIRTUAL
#define SAC_PURE_VIRTUAL_SUFFIX = 0
#else
#define SAC_PURE_VIRTUAL_SUFFIX
#endif
    /// <summary>
    /// document
    /// </summary>
    class CACStream {
    public:
        // ctor
        CACStream() noexcept {}
        // dtor
        ~CACStream() noexcept {}
        // load string
        void Load(StrPair, bool inline_style = false) noexcept;
    protected:
        // state for combinator
        enum class combinator_state;
        // state for css-parser
        enum class css_state : unsigned;
        // start to parse coment
        bool parse_comment(StrPair& view) noexcept;
        // start to parse selector at level-1
        auto parse_selector_lv1(char, combinator_state&) noexcept->css_state;
    private:
        // add a comment
        virtual void add_comment(StrPair) noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a selector
        virtual void add_selector(BasicSelectors, StrPair) noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a selector-combinator
        virtual void add_selector_combinator(Combinators) noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a comma under selector
        virtual void add_selector_comma() noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // begin properties {
        virtual void begin_properties() noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // end properties }
        virtual void end_properties() noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a property
        virtual void begin_property(StrPair) noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a value
        virtual void add_value(StrPair) noexcept SAC_PURE_VIRTUAL_SUFFIX;
        // add a function value
        virtual void add_func_value(FuncValue value, StrPair raw_func) noexcept SAC_PURE_VIRTUAL_SUFFIX;
#ifdef SAC_ATTRIBUTE_SELECTOR
        // add a attribute selector
        virtual void add_attribute_selector(BasicSelectors, StrPair, StrPair) noexcept SAC_PURE_VIRTUAL_SUFFIX;
#endif 
    protected:
    };
#endif
    // Combinators
    enum Combinators : uint32_t {
        // Adjacent sibling selectors   A + B
        Combinators_AdjacentSibling = 0,
        // General sibling selectors    A ~ B
        Combinators_GeneralSibling,
        // Child selectors              A > B
        Combinators_Child,
        // Descendant selectors         A   B
        Combinators_Descendant,
    };
    // Basic Selectors
    enum BasicSelectors : uint32_t {
        // Type selectors               elementname
        Selectors_Type = 0,
        // Class selectors              .classname
        Selectors_Class,
        // ID selectors                 #idname
        Selectors_Id,
        // Universal selectors          *
        Selectors_Universal,
        // Pseudo classed selectors     :nth-child(2)
        Selectors_PseudoClass,
        // Pseudo elements selectors    ::maker
        Selectors_PseudoElement,
#ifdef SAC_ATTRIBUTE_SELECTOR
        // Attribute selectors: set     E[foo]
        Selectors_AttributeSet,
        // Attribute selectors: Exact   E[foo="bar"]
        Selectors_AttributeExact,
        // Attribute selectors: List    E[foo~="bar"]
        Selectors_AttributeList,
        // Attribute selectors: Hyphen  E[foo|="bar"]
        Selectors_AttributeHyphen,
        // Attribute selectors: Contain E[foo*="bar"]
        Selectors_AttributeContain,
        // Attribute selectors: Begin   E[foo^="bar"]
        Selectors_AttributeBegin,
        // Attribute selectors: End     E[foo&="bar"]
        Selectors_AttributeEnd,
#endif
    };
    // func type: see also SimpAC::FUNC_HASH_LIST
    enum FuncType : uint16_t {
        Type_None = 0,
        Type_Attr,              // attr()
        Type_Calc,              // calc()
        Type_CubicBezier,       // cubic-bezier()
        Type_Hsl,               // hsl()
        Type_Hsla,              // hsla()
        Type_LinearGradient,    // linear-gradient()
        Type_RadialGradient,    // radial-gradient()
        Type_ReLinearGradient,  // repeating-linear-gradient()
        Type_ReRadialGradient,  // repeating-radial-gradient()
        Type_Rgb,               // rgb()
        Type_Rgba,              // rgba()
        Type_Url,               // url()
        Type_Var,               // var()
        Type_Unknown,           // unknown
    };
}

#include <cstdint>

// if you insure xml correct, simpax won't check error EXCEPT OOM
//#define SAX_NO_ERROR_CHECK

//define your own __restrict if not support "__restrict"
//#define __restrict

//#define SAX_API _declspec(dllexport)
#define SAX_API

#define SAX_PURE_METHOD = 0

namespace SimpAX {
    // char type, utf-8 as default
    using Char = char; // wchar_t char16_t char32_t
    // string pair
    struct StrPair { 
        // pair
        const Char* a, *b; 
        // begin
        auto begin() const noexcept { return a; }
        // end
        auto end() const noexcept { return b; }
    };
    // stack element
    struct StackEle {
        // string pair
        StrPair             pair;
        // user pointer
        void*               user_ptr;
        // user data
        size_t              user_data;
    };
    // is same
    SAX_API bool IsSame(const StrPair a, const StrPair b) noexcept;
    // StrPair == StrPair
    inline bool operator ==(const StrPair a, const StrPair b) noexcept { return IsSame(a, b); }
    // StrPair != StrPair
    inline bool operator !=(const StrPair a, const StrPair b) noexcept { return !IsSame(a, b); }
    // Result
    struct Result { 
        // error code enum
        enum Code : uint32_t {
            // ok
            Code_OK = 0,
            // internal error
            Code_InternalError,
            // out of memory
            Code_OOM,
            // bad pi
            Code_BadPI,
            // bad comment
            Code_BadComment,
            // bad element
            Code_BadElement,
            // mismatched element
            Code_Mismatched,
            // syntax error
            Code_SyntaxError,
            // erro code
        }               code;
        // error position
        uint32_t        pos; 
        // is ok
        bool IsOk() const noexcept { return code == Code_OK; }
    };
    /// <summary>
    /// documen
    /// </summary>
    class CAXStream {
    public:
        // fixed stack length
        enum { FIXED_STACK_LENGTH = 12 };
        // Processing Instruction
        struct PIs { StrPair target, instructions; };
        // attributes
        struct ATTRs { StrPair key, value; };
        // ctor
        SAX_API CAXStream() noexcept;
        // dtor
        SAX_API ~CAXStream() noexcept;
        // load string
        SAX_API auto Load(const Char* str) noexcept ->Result;
        // find char in pair, return null on not-found
        static auto FindChar(StrPair, Char) noexcept -> const Char*;
        // find equation in pair
        static auto FindEquation(StrPair, const Char*) noexcept->StrPair;
    private:
        // free
        static void free(void*) noexcept;
        // memory alloc
        static void*malloc(size_t) noexcept;
        // re-alloc
        static void*realloc(void* ptr, size_t) noexcept;
    private:
        // add Processing Instruction
        virtual void add_processing(const PIs& attr) noexcept SAX_PURE_METHOD;
        // begin element
        virtual void begin_element(const StrPair tag) noexcept SAX_PURE_METHOD;
        // end element
        virtual void end_element(const StrPair tag) noexcept SAX_PURE_METHOD;
        // add attribute
        virtual void add_attribute(const ATTRs& attr) noexcept SAX_PURE_METHOD;
        // add comment
        virtual void add_comment(const StrPair ) noexcept SAX_PURE_METHOD;
        // add text, maybe add more once like <a>A<b/>B</a>
        virtual void add_text(const StrPair) noexcept SAX_PURE_METHOD;
    protected:
        // find first namespace
        SAX_API static void find_1st_namespace(StrPair& pair) noexcept;
        // try get value in instructions
        SAX_API static bool try_get_instruction_value(const Char* key, StrPair& ins) noexcept;
        // element stack begin
        auto stack_begin() noexcept { return m_pStackBase; }
        // element stack end
        auto stack_end() noexcept { return m_pStackTop; }
#ifdef NDEBUG
        // top element
        auto stack_top() noexcept->StackEle& { return m_pStackTop[-1]; }
#else
        // top element
        SAX_API auto stack_top() noexcept->StackEle&;
#endif
    private:
        // interpret escape
        void interpret_escape(StrPair&) noexcept;
        // check ok
        bool is_stack_ok() const noexcept { return !!m_pStackBase; }
        // push element
        bool push(StrPair str);
        // pop element
        void pop();
        // grow up
        void grow_up();
    private:
        // escape buffer
        Char*           m_pEscapeBuffer = nullptr;
        // escape buffer end
        Char*           m_pEscapeBufferEnd = nullptr;
        // stack base
        StackEle*       m_pStackBase = m_aStackBuffer;
        // stack top len
        StackEle*       m_pStackTop = m_aStackBuffer;
        // stack top cap
        StackEle*       m_pStackCap = m_aStackBuffer + FIXED_STACK_LENGTH;
        // fixed buffer
        StackEle        m_aStackBuffer[FIXED_STACK_LENGTH];
    };
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cassert>
#include <cstdint>
#include <type_traits>

// TextBC namespace
namespace TextBC {
    // detail namespace
    namespace detail {
        // buffer base class
        class buffer_base {
        protected:
            // ctor
            buffer_base() noexcept;
            // dtor
            ~buffer_base() noexcept;
        protected:
            // resize buffer
            bool resize_buffer(uint32_t, size_t size_of) noexcept;
            // is ok?
            bool is_ok() const noexcept { return !!m_data; }
            // assert index
            void assert_index(uint32_t i) const noexcept { assert(i < m_length); }
            // clear
            void clear() noexcept { m_length = 0; }
        protected:
            // data pointer
            void*               m_data = nullptr;
            // length of data
            uint32_t            m_length = 0;
            // capacity of data
            uint32_t            m_capacity = 0;
        };
    }
    // buffer class
    template<typename T> class CBCBuffer: public detail::buffer_base {
        // tptr / const tptr
        using tptr = T * ; using cptr = const T*;
        // must be pod
        static_assert(std::is_pod<T>::value, "must be pod");
        // must be pod
        static_assert(alignof(T) <= alignof(double), "'alignof' must be less than double");
        // tr pointer
        static tptr tr(void* ptr) noexcept { return reinterpret_cast<T*>(ptr); }
        // tr pointer
        static cptr ct(void* ptr) noexcept { return reinterpret_cast<const T*>(ptr); }
    public:
        // ctor
        CBCBuffer() noexcept {}
        // dtor
        ~CBCBuffer() noexcept {}
        // resize
        bool Resize(uint32_t l) noexcept { return this->resize_buffer(l, sizeof(T)); }
        // get size
        auto GetSize() const noexcept { return m_length; }
        // get data
        auto GetData() noexcept { return tr(m_data); }
        // is ok
        bool IsOK() const noexcept { return this->is_ok(); }
        // clear
        void Clear() noexcept { this->clear(); }
    public:
        // operaotr[]
        auto&operator[](uint32_t index) noexcept { return this->at(index); }
        // operaotr[]
        auto&operator[](uint32_t index) const noexcept { return this->cat(index); }
        // begin pointer
        auto begin() noexcept { return tr(m_data); }
        // end pointer
        auto end() noexcept { return tr(m_data) + m_length; }
        // begin pointer
        auto begin() const noexcept { return ct(m_data); }
        // end pointer
        auto end() const noexcept { return ct(m_data) + m_length; }
    private:
        // get at
        auto&at(uint32_t i) noexcept { assert_index(i); return tr(m_data)[i]; }
        // get const at
        const auto&cat(uint32_t i) const noexcept { assert_index(i); return tr(m_data)[i]; }
    };
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cassert>
#include <cstdint>

// TextBC namespace
namespace TextBC {
    // fixed length
#ifdef NDEBUG
    enum { TEXT_CELL_NICE_LENGTH = 40, TEXT_CELL_NICE_MAX = 40 };
#else
    enum { TEXT_CELL_NICE_LENGTH = 10, TEXT_CELL_NICE_MAX = 10 };
#endif
    // fixed-length string
    class CBCString {
    public:
        // ctor
        CBCString() noexcept { m_data[0] = 0; }
        // dtor
        ~CBCString() noexcept {}
    public: // STL like interface
        // get length
        auto size() const noexcept { return m_length; }
        // get c-style string
        auto c_str() const noexcept { return m_data; }
        // resize
        void resize(uint32_t s) noexcept { m_length = s; this->mark_eos(); }
        // oprator []
        auto&operator[](uint32_t i) noexcept { assert(i<TEXT_CELL_NICE_MAX); return m_data[i]; }
        // oprator []
        auto&operator[](uint32_t i) const noexcept { assert(i<TEXT_CELL_NICE_MAX); return m_data[i]; }
        // erase string
        void erase(uint32_t pos, uint32_t len) noexcept;
        // insert string
        void insert(uint32_t pos, const char16_t* str, uint32_t len) noexcept;
    private:
        // mark end-of-string
        void mark_eos() noexcept { assert(m_length < TEXT_CELL_NICE_MAX+2); m_data[m_length] = 0; }
    private:
        // string length
        uint32_t            m_length = 0;
        // string data(1 for null 1 for surrogate )
        char16_t            m_data[TEXT_CELL_NICE_MAX + 2];
    };
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cstdint>

// TextBC namespace
namespace TextBC {
    // text content
    struct IBCTextContent;
    // text document
    class CBCTextDocument;
    // text cell
    class CBCTextCell : public CBCSmallObject, public Node {
        // friend class
        //friend CBCTextDocument;
    public:
        // ctor
        CBCTextCell(CBCTextDocument& doc) noexcept;
        // dtor
        ~CBCTextCell() noexcept;
        // get content
        auto GetContent() const noexcept { return m_pContent; }
    public:
        // sleep
        void Sleep() noexcept;
        // awake
        void Awake(const char16_t*, uint32_t len) noexcept;
        // begin layout
        void BeginLayout() noexcept;
        // end layout
        void EndLayout() noexcept;
        // remove text, return true if CR/LF deleted
        bool RemoveText(Range) noexcept;
        // insert text
        auto InsertText(uint32_t, U16View) noexcept -> uint32_t;
        // remove text obly
        void RemoveTextOnly(Range) noexcept;
        // create new cell after this
        auto NewAfterThis() noexcept ->CBCTextCell*;
        // delete node
        void DeleteNode() noexcept;
        // find cell at begin of same line
        auto FindBeginSameLine() noexcept->CBCTextCell*;
        // find cell at end of same line
        auto FindEndSameLine() noexcept->CBCTextCell*;
    public:
        // just remove from list
        inline void RemoveFromListOnly() noexcept;
        // move EOL to next node
        inline void MoveEOL2Next() noexcept;
    public:
        // mark as eol
        void MarkAsEOL() noexcept;
        // mark as bol
        void MarkAsBOL() noexcept { m_bBeginOfLine = true; };
        // mark dirty
        void MarkDirty() noexcept { m_bDirty = true; }
        // follow bol
        void FollowBOL(const CBCTextCell& x) noexcept { m_bBeginOfLine = x.m_bBeginOfLine; }
        // is eol?
        bool IsEOL() const noexcept { return m_bEndOfLine; }
        // is bol?
        bool IsBOL() const noexcept { return m_bBeginOfLine; }
        // is dirty
        bool IsDirty() const noexcept { return m_bDirty; }
        // is last cell?
        bool IsLastCell() const noexcept { return !this->next->next; }
        // is first cell?
        bool IsFirstCell() const noexcept { return !this->prev->prev; }
        // get size
        auto GetSize() const noexcept { return m_size; }
        // get baseline offset
        auto GetBaseLine() const noexcept { return m_fBaseline; }
        // get string length
        auto GetStringLen() const noexcept { return m_text.size(); }
        // get char count
        auto GetCharCount() const noexcept { return m_cCharCount; }
        // get string ptr
        auto GetStringPtr() const noexcept { return m_text.c_str(); }
        // get string length no eol
        auto GetStrLenNoEOL() const noexcept -> uint32_t { 
            return GetStringLen() - (IsEOL() ? m_bCRLF + 1 : 0); }
    protected:
        // clear bol
        void clear_bol() noexcept { m_bBeginOfLine = false; }
        // clear eol
        void clear_eol() noexcept { m_bEndOfLine = false; }
    protected:
        // document
        CBCTextDocument&            m_document;
        // content
        IBCTextContent*             m_pContent = nullptr;
        // unit size of this cell
        SizeF                       m_size = SizeF{ 0 };
        // baseline offset
        float                       m_fBaseline = 0.f;
        // char count(char count != string len)
        uint16_t                    m_cCharCount = 0;
        // is crlf end for line
        bool                        m_bCRLF;
        // dirty
        bool                        m_bDirty : 1;
        // begin of line
        bool                        m_bBeginOfLine : 1;
        // end of line
        bool                        m_bEndOfLine : 1;
#ifndef NDEBUG
        // in layout
        bool                        m_bInLayout : 1;
#endif
        // text
        CBCString                   m_text;
    };
}



/// <summary>
/// Removes from list only.
/// </summary>
/// <returns></returns>
inline void TextBC::CBCTextCell::RemoveFromListOnly() noexcept {
    this->prev->next = this->next;
    this->next->prev = this->prev;
#ifndef NDEBUG
    this->prev = nullptr;
    this->next = nullptr;
#endif
}


#ifndef NDEBUG
void bc_assert_move_eol(TextBC::CBCTextCell&) noexcept;
#endif

/// <summary>
/// Moves the eo l2 next.
/// </summary>
/// <remarks>
/// EOL = end of line
/// </remarks>
/// <returns></returns>
inline void TextBC::CBCTextCell::MoveEOL2Next() noexcept {
#ifndef NDEBUG
    bc_assert_move_eol(*this);
#endif
    const auto next_cell = static_cast<CBCTextCell*>(this->next);
    next_cell->m_bEndOfLine = m_bEndOfLine;
    m_bEndOfLine = false;

}

/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/

#include <cstdint>

// TextBC namespace
namespace TextBC {
    // text cell
    class CBCTextCell;
    // text line data
    struct TextLineData {
        // y offset
        double          offset;
        // first cell
        CBCTextCell*    first;
        // last cell
        CBCTextCell*    last;
        // char count to here
        uint32_t        char_count;
        // string len to here
        uint32_t        string_len;
        // max height above baseline
        float           max_height1;
        // max height under baseline
        float           max_height2;
        // TODO: max_height1-> max_baseline  max_height2 -> max_height

        // clear line data
        void Clear(const TextLineData& lastline) noexcept;
        // add cell
        void operator +=(CBCTextCell&) noexcept;
        // calculate line width ex
        static auto CalculateWidth(const CBCTextCell*, const CBCTextCell*) noexcept ->float;
        // calculate line height ex
        static auto CalculateHeight(const CBCTextCell*, const CBCTextCell*) noexcept ->float;
        // calculate line width
        auto CalculateWidth() const noexcept ->float {
            return this->CalculateWidth(this->first, this->last);
        }
    };
    
}
/**
* Copyright (c) 2014-2018 dustpg   mailto:dustpg@gmail.com
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/


// TextBC namespace
namespace TextBC {
    // dirty rect
    struct DirtyRect { uint32_t x, y, width, height; };
    // Dirty rectangles
    using DirtyRects = CBCBuffer<DirtyRect>;
    // text document
    class CBCTextDocument {
        // lines_t
        using lines_t = CBCBuffer<TextLineData>;
        // selection_t
        using selection_t = CBCBuffer<RectWHF>;
        // until call
        struct until_call {
            // function ptr
            bool (*func)(void* this_ptr, uint64_t) noexcept;
        };
    public:
        // flag
        enum Flag : uint16_t {
            // none flag
            Flag_None = 0,
            // custom flag
            Flag_Custom = 1 << 0,
            // None CR-LF mode(LF Mode)
            Flag_NoneCRLR = 1 << 1,
            // [unsupported] alllow dragging 
            Flag_AllowDrag = 1 << 2,
            // [unsupported] rich text
            Flag_RichText = 1 << 3,
            // read only
            Flag_ReadOnly = 1 << 4,
            // multi line
            Flag_MultiLine = 1 << 5,
            // password mode
            Flag_UsePassword = 1 << 6,
            // [unsupported] auto scroll if caret move out
            Flag_AutoScroll = 1 << 7,


            // newline return true if ctrl enter even multi line mode
            Flag_TrueIfCtrlEnterEvenMultiLine = 1 << 15,
        };
    protected:
        // find func return value
        struct find_rv {
            // line data
            const TextLineData*     line;
            // cell data
            CBCTextCell*            cell;
            // char count to the cell
            uint32_t                char_count;
            // string len to the cell
            uint32_t                string_len;
        };
    public:
        // init arg
        struct InitArgs {
            // max text length
            uint32_t    max_length;
            // flag
            Flag        flag;
            // password char
            char16_t    password;
        };
    public:
        // ctor
        CBCTextDocument(IBCTextPlatform&, InitArgs) noexcept;
        // no copy ctor
        CBCTextDocument(const CBCTextDocument&) noexcept = delete;
        // no move ctor
        CBCTextDocument(CBCTextDocument&&) noexcept = delete;
        // dtor
        ~CBCTextDocument() noexcept;
    public:
        // render, pass null for DirtyRects if didn't support
        void Render(void* context, DirtyRects* =nullptr) noexcept;
        // get flag
        auto GetFlag() const noexcept { return m_flag; }
        // is CRLF?
        bool IsCRLF() const noexcept { return m_bCRLF; }
        // get string length
        auto GetStringLength() const noexcept { return m_cTotalLen; }
        // get password-char
        auto GetPasswordChar() const noexcept { return m_chPassword; }
        // get viewport pos
        auto GetViewportPos() const noexcept { return m_ptViewport; }
        // get viewport size
        auto GetViewportSize() const noexcept { return m_szViewport; }
        // get content size
        auto GetContentSize() const noexcept { return m_szContent; }
    public:
        // request range
        template<class T> void RequestRange(T& string, Range range) noexcept {
            return this->request_range(&string, range);}
        // request selected
        template<class T> void RequestSelected(T& string) noexcept {
            return this->request_range(&string, GetSelectionRange());}
        // request text
        template<class T> void RequestText(T& string) noexcept {
            return this->request_text(&string);}
        // set text
        void SetText(U16View view) noexcept;
        // is text changed
        auto IsTextChanged() const noexcept { return m_textChanged; }
        // clear text changed
        void ClearTextChanged() noexcept { m_textChanged = false; }
        // is selection changed
        auto IsSelectionChanged() const noexcept { return m_selectionChanged; }
        // clear selection changed
        void ClearSelectionChanged() noexcept { m_selectionChanged = false; }
    public:
        // on lbutton up
        void OnLButtonUp(Point2F pt) noexcept;
        // on lbutton down
        void OnLButtonDown(Point2F pt, bool shift) noexcept;
        // on lbutton hold&move
        void OnLButtonHold(Point2F pt) noexcept;
        // on char
        void OnChar(char32_t ch) noexcept;
        // on text
        void OnText(U16View view) noexcept;
        // on newline, return true if single line mode
        bool OnNewLine() noexcept;
        // on backspace
        void OnBackspace(bool ctrl) noexcept;
        // on delete
        void OnDelete(bool ctrl) noexcept;
        // on left
        void OnLeft(bool ctrl, bool shift) noexcept;
        // on right
        void OnRight(bool ctrl, bool shift) noexcept;
        // on up
        void OnUp(bool shift) noexcept;
        // on down
        void OnDown(bool shift) noexcept;
        // on select all
        void OnSelectAll() noexcept;
        // on home
        void OnHome(bool ctrl, bool shift) noexcept;
        // on end
        void OnEnd(bool ctrl, bool shift) noexcept;
    public:
        // get selection
        auto GetSelectionRange() const noexcept->Range;
        // delete selection
        void DeleteSelection() noexcept;
        // remove text
        void RemoveText(Range) noexcept;
        // insert text
        void InsertText(uint32_t pos, U16View view) noexcept;
        // hit test
        auto HitTest(Point2F) noexcept ->HitTest;
        // set selection
        void SetSelection(uint32_t pos, bool keep_anchor) noexcept;
        // set selection from point
        void SetSelection(Point2F pos, bool keep_anchor) noexcept;
        // set viewport size
        void SetViewportSize(SizeF) noexcept;
        // set viewport pos
        void SetViewportPos(Point2F) noexcept;
        // sleep, free some cached memory
        void Sleep() noexcept;
#ifdef TBC_UNDOREDO
        // clear undo stack
        void ClearUndoStack() noexcept;
        // undo
        void Undo() noexcept;
        // redo
        void Redo() noexcept;
        // can undo
        bool CanUndo() const noexcept { return m_pUndoNow != &m_undoStackBottom; }
        // can redo
        bool CanRedo() const noexcept { return m_pUndoNow != m_pUndoStackTop; }
        // mark end of operation
        void MarkEndOfOperation() noexcept;
#else
        // clear undo stack
        void ClearUndoStack() noexcept {}
        void Undo() noexcept {}
        // redo
        void Redo() noexcept {}
        // can undo
        bool CanUndo() const noexcept { return false; }
        // can redo
        bool CanRedo() const noexcept { return false; }
        // mark end of operation
        void MarkEndOfOperation() noexcept {}
#endif
    protected:
        // remove text
        void remove_text(Range) noexcept;
        // remove all
        void remove_all() noexcept;
        // insert text
        void insert_text(uint32_t pos, U16View view) noexcept;
        // find insert node
        auto find_insert_node(uint32_t, U16View, float&, uint32_t&) noexcept->CBCTextCell*;
        // sync cache until <T>
        void sync_cache_until(until_call call, uint64_t) noexcept;
        // sync cache to length
        void sync_cache_to_length(uint32_t pos) noexcept;
        // sync cache to offset
        void sync_cache_to_offset(double offset) noexcept;
        // split cell
        void split_cell(TextLineData& line, CBCTextCell& node, uint32_t pos) noexcept;
        // refresh selection metrics
        void refresh_selection_metrics(Range) noexcept;
        // adjust content size + 
        void adjust_content_size_insert(float, CBCTextCell*, CBCTextCell*) noexcept;
        // adjust content size - 
        void adjust_content_size_remove(float, CBCTextCell* first, CBCTextCell* last) noexcept;
        // recalculate content size
        void recalculate_content_size() noexcept;
        // free list
        void free_mem_list() noexcept;
        // delete selection only
        void delete_selection() noexcept;
        // request text
        void request_text(void* string) noexcept;
        // request range
        void request_range(void* string, Range range) noexcept;
    protected:
        // get char metrics
        auto char_metrics(CBCTextCell& cell, uint32_t offset) noexcept->CharMetrics;
        // find cell or after cell or last cell by pos
        auto find_cell_or_la_by_pos(uint32_t pos) const noexcept->find_rv;
        // find last valid cell
        auto find_last_valid_cell() const noexcept->find_rv;
        // set selection
        void set_selection(uint32_t, uint32_t pos) noexcept;
        // update caret rect
        void update_caret_rect() noexcept;
        // align caret to nearest cluster
        //void align_carent_to_cluster() noexcept;
        // hit test at position
        auto hittest_at(uint32_t) noexcept ->const TextLineData*;
        // get string length before
        auto get_strlen_before() const noexcept->uint32_t;
        // get string length behind
        auto get_strlen_behind() const noexcept->uint32_t;
        // play beep
        void play_beep() noexcept;
        // truncation text
        void truncation_text(U16View&, ptrdiff_t) noexcept;
        // add line data
        static auto add_line(TextLineData&, const TextLineData&, CBCTextCell* node) noexcept->CBCTextCell*;
        // truncation password
        static void truncation_password(IBCTextPlatform&, U16View&) noexcept;
        // truncation singleline
        static void truncation_singleline(U16View&) noexcept;
        // relayout cell
        static void relayout_cell(CBCTextCell& cell) noexcept;
    private:
        // mark text changed
        inline void text_changed() noexcept { m_textChanged = true; }
        // mark selection changed
        inline void selection_changed() noexcept { m_selectionChanged = true; }
        // get absolute position
        inline auto get_abs_pos() const noexcept->uint32_t { return m_uCaretPos /*+ m_uCaretOffset*/; }
        // valid length
        inline auto cache_valid_length() const noexcept->uint32_t;
        // valid offset
        inline auto cache_valid_offset() const noexcept->double;
        // clear hittest cache
        inline void clear_last_hittest() noexcept;
        // cache hittest data
        inline void cache_last_hittest(CBCTextCell* c, uint32_t p, Point2F) noexcept;
#ifdef TBC_UNDOREDO
    private:
        // free undo/redo stack
        void free_undo_stack() noexcept;
        // insert text for undo/redo node
        void insert_text_unre(const void*) noexcept;
        // remove text for undo/redo node
        void remove_text_unre(const void*) noexcept;
        // add remove text for undo/redo
        void add_remove_text_unre(uint32_t pos, U16View) noexcept;
        // add insert text for undo/redo
        void add_insert_text_unre(uint32_t pos, U16View) noexcept;
        // operation with length
        void*operation_length(uint32_t len) noexcept;
        // free prev
        static void free_prev(void* ptr) noexcept;
#endif
    private:
#ifdef NDEBUG
        // debug outout anchor
        void debug_anchor() noexcept {}
#else
        // debug outout anchor
        void debug_anchor() noexcept;
#endif
    public:
#ifdef NDEBUG
        // debug outout undo-stack
        void DebugOutUndoStack() noexcept {}
#else
        // debug outout undo-stack
        void DebugOutUndoStack() noexcept;
#endif
    public:
        // platform
        IBCTextPlatform&    platform;
    protected:
        // text cell head
        Node                m_head = Node{ nullptr, &m_tail };
        // text cell tail
        Node                m_tail = Node{ &m_head, nullptr};
        // total string len
        uint32_t            m_cTotalLen = 0;
        // total char count
        uint32_t            m_cTotalCount = 0;
        // max char count
        uint32_t    const   m_cMaxLen;
        // flag
        Flag        const   m_flag;
        // password char
        char16_t    const   m_chPassword;
        // line data
        lines_t             m_lines;
        // selection data
        selection_t         m_selections;
        // valid line count
        uint32_t            m_cValidLine = 0;
        // XXX:caret rect
        RectWHF             m_rcCaret = RectWHF{};
        // caret line real[+1s]
        uint32_t            m_caretLineReal = 1;
        // caret line temp[+1s]
        uint32_t            m_caretLineTemp = 1;
        // last selection range
        Range               m_lastSelection{ 0, 0 };
        // mouse down pos
        Point2F             m_ptMoseDown{ -1.f, -1.f };
        // viewport pos
        Point2F             m_ptViewport{ 0.f, 0.f };
        // content size
        SizeF               m_szContent{ 0.f, 0.f };
        // viewport size
        SizeF               m_szViewport{ 100.f, 30.f };
        // anchor positon               
        uint32_t            m_uAnchor = 0;
        // caret positon                
        uint32_t            m_uCaretPos = 0;
        // draw caret?
        bool                m_bDrawCaret = false;
        // crlf?
        bool                m_bCRLF = true;
        // click in selection?
        bool                m_bClickInSelection : 1;
        // text changed
        bool                m_textChanged : 1;
        // selection changed
        bool                m_selectionChanged : 1;

#ifdef TBC_UNDOREDO
        // undo-redo mode
        bool                m_recordUndoRedo : 1;
#endif

        // begin line(+1) for viewport
        uint32_t            m_beginLineVisible = 1;
        // unused u32
        uint32_t            m_unused = 0;

        // cached hittest start
        uint32_t            m_lastHitStart = 0xffff;
        // cached hittest pos
        Point2F             m_lastHitCellPos{ -1.f, -1.f };
        // cached hittest cell
        CBCTextCell*        m_lastHitTest = nullptr;

        // free list
        CBCTextCell*        m_pFreeList = nullptr;
#if 0
        // LIMITED BUFFER begin
        Node*               m_pBufferBegin = &m_tail;
        // LIMITED BUFFER end
        Node*               m_pBufferEnd = &m_tail;
        // LIMITED BUFFER max count
        uint32_t            m_cBufferMax = 128;
        // LIMITED BUFFER cell count
        uint32_t            m_cBufferCount = 0;
#endif
#ifdef TBC_UNDOREDO
        // length for dynamic-length buffer
        uint32_t            m_undoDynamic = 0;
        // length for undo/redo stack-to-now
        uint32_t            m_undoStackLen = 0;
        // undo/redo stack-top
        void*               m_pUndoStackTop = &m_undoStackBottom;
        // undo/redo stack-now
        void*               m_pUndoNow = &m_undoStackBottom;
        // bottom of list
        Node                m_undoStackBottom = { nullptr };
#ifndef NDEBUG
        // debug buffer
        int32_t             m_debugBuf[8] = { -1, -2, -3, -4, -5, -6, -7, -8 };
#endif
#endif
    public:
        enum {
            // init reserve line count
            INIT_RESERVE_LINE = 10,
        };
    };
}
